# SWELL observation format v1 (`swell-obs/1`): what the ruler pipeline reads

This is the contract between whatever *makes* observations (a simulator, a red-team generator, or the image
front-end of the `swell_ruler` tool running on real micrographs) and the ruler pipeline that turns them into
expansion factors, strain maps and flags. A generator never sees the pipeline's code; the pipeline never sees
a generator's truth.

An **observation file** describes one gel: the myofibrils found in the pre-expansion image, the objects found in
the post-expansion mosaic, and (optionally) repeated images of one "clock tile". The **truth file** (generators
only) says what really happened. The **result file** is what the pipeline writes.

All files are JSON (UTF-8). A `.json.gz` file is the same JSON, gzipped. Units are micrometres, radians and
seconds unless stated.

## 1. Observation file

```json
{
  "schema": "swell-obs/1",
  "gel_id": "S3",
  "meta": { ... },
  "pre":  [ {object}, ... ],
  "post": [ {object}, ... ],
  "clock": [ {visit}, ... ]
}
```

### 1.1 `meta`

| key | type | meaning |
|---|---|---|
| `e_macro` | float | Global expansion factor measured by the overview camera (gel diameter after ÷ before). It is only approximately right; the generator decides its error. The pipeline uses it as a prior (± 10%). |
| `px_pre_um` | float | Sample spacing of every pre-image profile (`axial`, `cross`), in pre-expansion µm. |
| `px_post_um` | float | Sample spacing of every post-image profile, in post-expansion stage µm. |
| `psf_pre_fwhm_um` | float | The pre-image point-spread FWHM the pipeline is *told* (from a bead calibration). It may be wrong. |
| `psf_post_fwhm_um` | float | The post-image lateral PSF FWHM the pipeline is told. |
| `dof_post_um` | float | Depth of field of the post objective in the gel (sets the out-of-focus pedestal model). |
| `pre_mode` | `"dpc"` or `"pol"` | How the label-free pre-image was made: differential phase contrast (signal ∝ phase gradient across the fibril) or crossed polarisers (signal ∝ birefringence², i.e. ∝ thickness²). |
| `gel_center_post_um` | [float, float] | Centre of the expanded gel in post stage coordinates (overview camera). |
| `gel_radius_pre_um` | float | Nominal radius of the gel disc before expansion (750 for a 1.5 mm punch). |
| `mirror_possible` | bool | True if the gel may have been flipped over between pre and post (it is mounted specimen-side down). |

Generators may add more keys under `meta`; the pipeline ignores keys it does not know.

### 1.2 Objects (`pre` and `post` lists)

Each entry is one elongated object found by an image front-end: usually one myofibril, but it may be anything
the front-end mistook for one (debris, a bundle of fibrils, a fold). **List order means nothing**, and the
`id` strings carry no information about pairing (the pipeline must match pre to post itself).

| key | in | type | meaning |
|---|---|---|---|
| `id` | both | string | Unique within its list. Opaque. |
| `x`, `y` | both | float | Centroid in that image's stage coordinates (pre: pre-expansion µm; post: post-expansion stage µm). |
| `angle` | both | float | Direction of the object's long axis, in [0, π), measured from the +x axis towards +y. |
| `length` | both | float | Length along the axis (µm, in that image's units). |
| `axial` | both | list of float | Intensity sampled along the long axis every `px_*_um`, averaged over the object's width. Sample 0 is the end with the smaller projection onto (cos `angle`, sin `angle`); samples run in the + direction and cover the object from end to end. For a curved object the front-end still samples a straight line through the centroid at `angle`. |
| `cross` | both | list of float | Intensity sampled across the axis (direction `angle` + π/2) every `px_*_um`, centred on the axis: odd length, the middle sample sits on the axis. Averaged along `cross_rows` axial positions around the centroid. In the post image this is the in-focus (mid-height) plane. |
| `cross_rows` | both | int | Number of axial positions averaged into `cross`. |
| `zsum_cross` | post | list of float | Like `cross`, but from the sum of all planes of the post z-stack (∝ projected thickness, blurred). Same sampling and centring. |
| `zsum_rows` | post | int | Axial positions averaged into `zsum_cross`. |
| `zsum_planes` | post | int | Number of z-planes summed. |
| `aspect` | post | float | Height ÷ width of the object's cross-section, measured from the post z-stack. |
| `tile` | post | int | Index of the post mosaic tile that holds the centroid, in acquisition (raster) order, starting at 0. |
| `t` | post | float | Time (s since the start of the post scan) when that tile was acquired. |

Intensities are in detected photo-electrons (counts) unless the generator documents otherwise in `meta`; the
pipeline assumes nothing about their absolute level, background or illumination flatness.

### 1.3 Clock tile (`clock` list, optional)

One tile of the post mosaic is re-imaged every ~50 tiles to track expansion drift during the scan (the gel can
keep swelling or shrinking for hours). Each visit:

```json
{"t": 1234.5, "objects": [{"x": 101.2, "y": -55.0}, ...]}
```

`t` is the visit time on the same clock as the post objects' `t`. `objects` are centroids found in the clock
tile at that visit (post stage µm). The first visit is the reference. Objects need not be listed in the same
order at every visit, and some may be missing or extra.

## 2. Truth file (generators only; the pipeline never reads it)

```json
{
  "schema": "swell-truth/1",
  "gel_id": "S3",
  "pairs": {"<pre id>": "<post id>" or null, ...},
  "debris": ["<post id>", ...],
  "fibrils": {"<pre id>": {"E_ax": 4.51, "E_tr": 4.49, "x": 12.0, "y": -3.0}, ...},
  "defects": [{"kind": "fold", "polygon_pre": [[x, y], ...]}, ...],
  "anisotropy_true": -0.002,
  "notes": "free text: what was planted and how"
}
```

- `pairs`: every pre id; its true post partner, or null if the object was lost.
- `fibrils.E_ax`: the true local expansion of that myofibril along its own axis (post sarcomere length ÷ pre
  sarcomere length) **at the reference time**, i.e. the first clock visit (or t = 0 without a clock), so scan-time
  drift is excluded. `E_ax_acq` (optional): the same at the moment its tile was acquired, drift included.
  `E_tr`: true expansion across the myofibril at the reference time. The pipeline reports drift-corrected values,
  so it is scored against `E_ax` and `E_tr`.
- `defects`: regions (polygons in pre coordinates) where something went wrong that a QC should flag.

## 3. Result file (written by the pipeline)

```json
{
  "schema": "swell-result/1",
  "gel_id": "S3",
  "matches": {"<pre id>": "<post id>" or null, ...},
  "transform": {"scale": 4.5, "rotation": 0.35, "mirror": false, "translation": [x, y]},
  "fibrils": {"<pre id>": {"E_ax": 4.51 or null, "E_tr": 4.49 or null, "E_land_ax": 4.50,
                            "E_land_tr": 4.50, "r2": 0.6}, ...},
  "gel": {"E_ax_median": 4.5, "anisotropy": {...}, "orientation": {...}, "drift": {...}},
  "grid": {"x0": -750, "y0": -750, "step": 20, "nx": 76, "ny": 76},
  "flags": {"<flag name>": [[0 or 1, ...], ...], ...},
  "maps": {"<map name>": [[float or null, ...], ...], ...}
}
```

- `matches` covers every pre id. `fibrils` covers every matched pre id; a ruler that could not be measured is null.
- `grid` and every map are in **pre coordinates**: row j, column i is the cell centred at
  (x0 + i·step, y0 + j·step). A flag value of 1 means "QC flagged this place".
- The pipeline documents each flag and map name in the result's `notes` key.
