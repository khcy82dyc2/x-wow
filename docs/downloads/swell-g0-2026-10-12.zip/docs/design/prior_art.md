# SWELL prior art (F-19): what others did first, and what is left for SWELL

Systematic search promised in Order 2 (F-19), run on 2026-10-10 (Life 5) after a fresh AI review (another Claude instance). Engines:
web search (general), PubMed Central and publisher pages, bioRxiv. Each line gives the search string, the date
and what it found. "Not found" means not found by these searches, never "does not exist".

## Searches

| # | date | search string (engine) | relevant hits |
|---|---|---|---|
| 1 | 2026-10-10 | `Zhang 2016 Scientific Reports 6 22691 expansion mini-microscopy hybrid microscopy webcam` (web) | Zhang, Chang et al. 2016, *Sci Rep* 6:22691 (ExMM) |
| 2 | 2026-10-10 | `Sheard 2019 ACS Nano 13 2143 enhanced expansion microscopy ryanodine receptor sarcomere expansion factor Z-disc spacing` (web; full text PMC6396323 read) | Sheard et al. 2019, *ACS Nano* 13:2143 |
| 3 | 2026-10-10 | `expansion microscopy low-cost 3D-printed microscope OpenFlexure smartphone "expansion microscopy" open hardware` (web) | OpenFlexure papers only; no ExM on OpenFlexure found |
| 4 | 2026-10-10 | `expansion microscopy skeletal muscle myofibril sarcomere length expansion factor measurement isotropy Z-disc` (web) | NPC as intrinsic reporter (Pesce et al. 2019/2020); ~~no skeletal-myofibril ExM ruler found~~ *wrong (corrected 2026-10-10): Migliore's 2022 thesis expanded isolated rabbit myofibrils and used the A-band as its ruler; see the addendum* |
| 5 | 2026-10-10 | `"expansion microscopy" "sarcomere" "intrinsic" ruler OR reporter "expansion factor" muscle cardiomyocyte alpha-actinin z-line spacing` (web, extended) | photobleaching reporter (PMC7114699); GelMap (PMC10555834); NPC reporter (PMC7065622) |
| 6 | 2026-10-10 | `expansion microscopy Drosophila flight muscle OR zebrafish muscle OR skeletal myofibrils ExM sarcomere nanoscale 2021 2022 2023` (web) | heart-tissue ExM (MIT); SIM nanobody sarcomere work (non-ExM) |
| 7 | 2026-10-10 | `low-cost expansion microscopy smartphone OR "cell phone" OR "Raspberry Pi" OR "3D printed" microscope imaging expanded samples` (web) | low-cost microscopes (Fourier ptychography, smartphone upgrades); none imaging expanded samples |
| 8 | 2026-10-10 | `"expansion microscopy" centriole OR microtubule "internal ruler" OR "molecular ruler" isotropy expansion factor validation U-ExM` (web) | U-ExM used the centriole as a molecular ruler (Gambarotto et al. 2019) |
| 9 | 2026-10-10 | `"expansion microscopy" skeletal muscle fibers titin OR nebulin OR "Z-disc" OR "sarcomere" nanoscale 2020..2025 paper` (web, extended) | ExM of the neuromuscular junction in human and murine muscle biopsies, ~3.5× (PMC12272245; protocol PMC12765181); SIM and DNA-PAINT sarcomere work (not ExM) |
| 10 | 2026-10-10 | `"expansion microscopy" chicken OR "chicken breast" OR poultry muscle meat` (web) | none |

## What others did first

- **Cheap optics + expansion (SWELL idea 1, "grow the sample, not the glass").** Zhang, Chang, … Boyden &
  Khademhosseini, "Hybrid Microscopy: Enabling Inexpensive High-Performance Imaging through Combined Physical and
  Optical Magnifications", *Sci Rep* 6:22691 (2016), doi:10.1038/srep22691. They paired ExM (~4.5×) with a
  webcam-based mini-microscope ("expansion mini-microscopy", ExMM) and report resolution comparable to a benchtop
  microscope before expansion at a hundred- to thousand-fold lower price, aimed at point-of-care use. **SWELL may
  not claim the idea of pairing expansion with cheap optics.**
- **Sarcomeres as an intrinsic ruler for local expansion (SWELL idea 2).** Sheard, Hurley, Colyer, … Jayasinghe,
  "Three-Dimensional and Chemical Mapping of Intracellular Signaling Nanodomains in Health and Disease with
  Enhanced Expansion Microscopy", *ACS Nano* 13:2143–2157 (2019), doi:10.1021/acsnano.8b08742. In cardiomyocytes
  they "used the periodicity of the myocytes' sarcomeres and fixed-width of z-discs as intrinsic reporters of
  local gel expansion" and the regularity of z-disc spacing to confirm isotropy. **SWELL may not claim the idea of
  muscle as an ExM ruler.**
- **Internal molecular rulers in ExM.** U-ExM itself was tuned with the centriole as a molecular ruler
  (Gambarotto et al., *Nat Methods* 16:71, 2019, doi:10.1038/s41592-018-0238-1).
- **ExM on muscle.** ExM has been applied to the neuromuscular junction in human and murine muscle biopsies at
  ~3.5× (PMC12272245, PMC12765181), and a 2022 thesis imaged expanded myofibrillar bundles in transmitted light
  (already in the inspiration ledger; it also used the A-band as its expansion ruler, see the addendum below). No
  ExM of chicken or other meat was found.
- **Intrinsic calibration and deformation mapping in ExM.** GelMap (a fluorescent grid in the gel that expands
  with the sample; expansion factor and local deformation maps without cellular references), PMC10555834;
  Damstra … Kapitein, *Nat Methods* 20:1573 (2023), doi:10.1038/s41592-023-02001-y; nuclear pore complexes as an
  intrinsic reporter (Pesce … Bianchini, *J Biophotonics* 12:e201900018, 2019, doi:10.1002/jbio.201900018);
  photobleached 3D features as an intrinsic ruler (Vanheusden … Hofkens, *ACS Omega* 5:6792, 2020,
  doi:10.1021/acsomega.0c00118). **SWELL's whole-gel strain map is one more member of this family, not a
  new kind of QC.**

## Wording on the site

The site never claimed "first" in so many words, but "Why it works" presented the two core ideas without their
originators. Both now carry a "who got there first" line (Zhang 2016; Sheard 2019), and the inspiration ledger
lists all five works above. Anything SWELL adds is phrased as an addition, never a first.

## What SWELL adds (claimed only as "not found by the searches above")

*Narrowed on 2026-10-10, after the expert test (see the addendum below): imaging the same specimen before and after expansion goes back to Chen, Tillberg & Boyden 2015, and maps of local expansion error are not new. The bullets below stand only as narrowed there.*

- A **paired, per-myofibril** period ratio against a **label-free pre-image of the same fibril** (Sheard et al.
  used the post-expansion periodicity; measuring the same specimen before and after expansion goes back to Chen,
  Tillberg & Boyden 2015, credited 2026-10-10), with a Z-disc-ladder estimator that carries sarcomere jitter, and a
  measured contrast threshold for the label-free pre-image (docs/design/preimage_v1.md).
- A whole-gel map that keeps **axial and transverse** factors separate and adds landmark (positional) factors,
  with flags scored against planted defects, a red-team gel built by a separate AI agent and a clock tile for scan-time drift.
  *(2026-10-10: a map of local expansion error is not new in itself: Chen 2015 and GelMap 2023 made such maps.)*
- **Supermarket chicken** as a free reference specimen (proposed, untested; nicknamed the "Chicken Standard"), and the open,
  automated, low-cost instrument around it.

These are design claims on synthetic data. None has been built or tested.

## Addendum, 2026-10-10 (runner life 7): corrections after the charter's expert test

The expert test (an AI agent role-playing a sceptical expansion-microscopy specialist; an AI review, not an expert or
independent one) ran 17 more searches and opened 19 sources on 2026-10-10. What it changes here:
- **Search 4 was wrong.** "No skeletal-myofibril ExM ruler found" is false: Migliore's 2022 MS thesis (University of
  North Texas) expanded isolated rabbit myofibrils (proExM), imaged them without labels in transmitted light, and used
  the A-band width divided by 1.5 µm as the expansion ruler (its §2.8). The thesis was already in the inspiration
  ledger, described only as "expanded myofibrillar bundles".
- **Pairing has an ancestor.** Chen, Tillberg & Boyden 2015 (Science 347:543, doi:10.1126/science.1260088) imaged the
  same cells and brain slices before and after expansion and measured the root-mean-square length error against
  measurement length: under 1% of the distance in cultured cells, 2–4% in brain slices (author manuscript PMC4312537,
  read 2026-10-10 by the X-WOW agent from the full text). Credit it wherever SWELL's pairing is pitched.
- **More predecessors to credit:** Tillberg et al. 2016 and Chozinski et al. 2016 (same-specimen distortion after
  expansion); Vanheusden et al. 2020 (a before/after intrinsic ruler used as QC); VISTA (Miao, Lin, Qian & Wei 2022,
  label-free before/after expansion factor); Sheard's 2021 Leeds thesis (the sarcomere expansion factor came out lower
  than the gel's); Scheible & Tinnefeld 2018 (DNA-origami nanorulers proposed as in-gel references, a preprint).
- **"What SWELL adds", narrowed.** The one combination still not found: chicken myofibrils embedded in the gel as a free
  reference spread through its volume, each long fibril's sarcomere period read twice (label-free, by differential
  phase contrast, before expansion; stained after), giving that fibril's own axial factor with no lithography,
  pre-label or super-resolution pre-image. The whole-gel strain map is not new (Chen 2015, GelMap 2023).
- **"Feels like 2030" fails** (principle 12): expansion on cheap optics (2016), printed microscopes with 40×/0.65
  objectives (2020), super-resolution on low-cost open microscopes (2024) and automated 96-well expansion (2023) exist.
- **A risk the design must face:** dense protein structures can expand less than the gel around them (Damstra et al.
  2022; Sheard 2021), so a myofibril's factor may differ from the gel's. Report fibril/gel and fibril/landmark ratios as
  measurements, ideally against an in-gel grid.

The full review is kept in the project's private notes.
