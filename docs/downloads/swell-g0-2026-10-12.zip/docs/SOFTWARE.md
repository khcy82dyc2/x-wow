# SOFTWARE: SWELL toolchain (installed 2026-10-09, Life 1)

Everything lives inside **D:\SWELL**, per the coexistence rule (INV-17):
- portable apps in `.tools/`;
- Python packages in `.venv/`;
- caches and app config redirected into `.tools/` by `tools/env.sh` / `tools/env.ps1`.

No installer was run. No global package, PATH or scheduled-task change was made. Two leaks were found and fixed:
- **FreeCAD's user config in %APPDATA%:** removed, and redirected into `.tools/cfg/freecad`.
- **Java preferences in HKCU\Software\JavaSoft:** Fiji and QuPath keep them in the registry on Windows, and the first runs created 44 keys. All were removed; the registry is back to its pre-session state.

The smoke test now snapshots and cleans these keys itself, and fails on any new user folder (D-25). Interactive GUI use of Fiji or QuPath will create normal per-user Java preference keys; that is ordinary app settings, not an install.

**Reproduce from scratch:** `bash tools/setup_tools.sh`. It downloads exact versions, checks the publisher's SHA256 where one is published, and logs every file's hash in `.tools/manifest.txt`.
**Prove it works:** `python tools/smoke_tools.py` gives **25/25 PASS: 24 checks do real work** (register, render, slice, resolve, compile, round-trip) and **1 is import-only** (mpremote: no Pico until P1). It ends with a leak check (report in `.tools/smoke_report.json`).
**Activate per shell:** `source tools/env.sh` (Git Bash) or `. .\tools\env.ps1` (PowerShell).

## By purpose

| Purpose | Tool | Version | Where | Smoke check (what it actually did) |
|---|---|---|---|---|
| **CAD (parametric, scripted)** | CadQuery (+ OCP) | 2.8.0 (OCP 7.9.3.1.1) | .venv | Built a holed block, exported STEP + STL, checked the volume |
| CAD (OpenFlexure source) | OpenSCAD | 2026.10.05 snapshot | .tools/openscad | Compiled a .scad and exported STL |
| CAD (visual, assemblies, STEP) | FreeCAD | 1.1.4 | .tools/freecad | Headless FreeCADCmd built a 10 mm cube, volume 1000 |
| Fit checks / interference | trimesh + manifold3d | 5.1.1 / 3.5.4 | .venv | Boolean overlap of two boxes = 200.0 mm³ (exact) |
| **Slicer** | PrusaSlicer (CLI + GUI) | 2.9.6 | .tools/prusaslicer | Sliced the CadQuery STL to G-code with a print-time estimate |
| **Python** | uv + CPython | 0.12.24 / 3.12.15 | .tools/uv, .tools/python | Created .venv; 251 packages pinned in software/requirements.lock (pypdf added in Life 2) |
| Numerics | numpy, scipy, pandas, matplotlib, pint, uncertainties, statsmodels | 2.5.3, 1.18.1, 3.0.6, 3.11.2, 0.26.1, 3.2.3, 0.15.0 | .venv | Mixed-effects model fit (statsmodels) |
| **Image analysis** | scikit-image, OpenCV (headless), tifffile, imagecodecs | 0.26.0, 5.0.0.93, 2026.9.20, 2026.8.16 | .venv | Phase correlation recovered a (−5, 3) px shift exactly |
| Image analysis (GUI, macros, plugins) | Fiji (ImageJ) with bundled JDK | 2.16.0 / 1.54p | .tools/fiji | Headless macro created an image and returned the version (use `ImageJ-win64.exe --headless --console -batch`) |
| **Viewers** | napari (PySide6) + napari-ome-zarr | 0.9.2 / 0.10.0 | .venv | Rendered an image layer and took a 1200 × 900 screenshot (hidden window, PySide6 6.12.0) |
| Viewer (whole-slide / OME-TIFF) | QuPath | 0.7.0 | .tools/qupath | Headless Groovy script opened an OME-TIFF and read 80 × 48 (correct) |
| **Stitching** | multiview-stitcher; SWELL's own stitcher (Order 6); Fiji Grid/Collection stitching | 0.1.62 | .venv, .tools/fiji | Registered two overlapping tiles and corrected a 5 px placement error to within ~1 px at default settings |
| **Registration** | SimpleITK; itk-elastix | 2.5.6; 0.25.4 | .venv | Both recovered a (3, 3) px translation: SimpleITK (2.83, 2.83), elastix (3.00, 3.02) |
| **Data format** | zarr + ome-zarr; dask | 3.4.1 + 0.18.0; 2026.8.0 | .venv | OME-Zarr write → read, bit-identical |
| **Optics: ray tracing** | rayoptics | 0.9.10 | .venv | Paraxial model of a BK7 singlet, efl 25.47 mm |
| Optics: PSF models | MicroscPSF-Py (Gibson–Lanni); pyotf (pupil, vectorial) | 0.2; 0.0.3 | .venv | Dry 0.65 NA into water PSF stack; pupil PSF stack |
| Optics: design numbers | software/sim/design_calc.py (SWELL) | v0 | repo | Produces docs/design/calc_v0.md (audit evidence) |
| **Paper writing** | Pandoc | 3.12.1 | .tools/pandoc | Markdown → DOCX |
| Paper PDF | Typst | 0.15.1 | .tools/typst | Compiled a page with math to PDF |
| **References** | Manubot (citation by DOI/PMID → CSL JSON), bibtexparser, requests | 0.6.1, 2.1.0 | .venv | Resolved doi:10.1126/science.1260088 → "Expansion microscopy", *Science* 2015 |
| **Electronics docs** | WireViz + Graphviz | 0.4.1 + 16.1.0 | .venv, .tools/graphviz | `dot` rendered an SVG |
| **Firmware** | mpremote + pyserial (MicroPython on the Pico 2) | 1.29.0 | .venv | **Import-only** until a Pico exists (P1); the Pico is flashed by drag-and-drop UF2 (no toolchain) |
| **Hardware service** | FastAPI + uvicorn + httpx | 0.143.0 / 0.54.0 / 0.28.1 | .venv | Test client hit `/ping` |
| **Tests / lint** | pytest, pytest-cov, hypothesis, ruff | 9.1.1, 7.1.0, 6.168.5, 0.16.10 | .venv | Used by every order |
| Utilities | 7zr (official standalone), py7zr | current, 1.1.3 | .tools/dl/7zr, .venv | Unpacked FreeCAD's BCJ2 .7z |
| Documents (Life 2) | pypdf | 6.20.0 | .venv | [personal detail removed]; reads datasheets and SDS PDFs (Orders 2, 3) |

## Pi imaging (runs on the Pi, not this PC)
- **OS:** Raspberry Pi OS (64-bit) on a Pi 5. `python3-picamera2` and libcamera come from apt, not pip.
- **Pi-side lock:** SWELL's service pins its own deps in `software/pi/requirements-pi.txt` (Order 6).
- **PC tests:** they use a fake picamera2 adapter, so the full stack runs here against the simulator.
- **Mono IMX296 support:** the vendor claims libcamera/Picamera2 support (F-5); verified on hardware at G1.
- **Writing the SD card** needs administrator rights on Windows, so **Raspberry Pi Imager** is the only system-wide install. It is in HUMAN_QUEUE **S-2**, to be done with the first P1 session.

## Deliberately not installed
| Tool | Why not |
|---|---|
| KiCad | No custom PCB: module-based electronics with screw terminals (D-8). Revisit only if a PCB becomes cheaper than modules |
| LaTeX (TeX Live / MiKTeX) | Huge and system-wide. Typst covers PDF; Pandoc covers DOCX for journals; Tectonic can be added portably if a journal demands LaTeX source |
| Zotero | Needs a system installer and a GUI. Manubot resolves DOIs to CSL directly, which is reproducible and scriptable |
| psfmodels | No Windows wheel for Python 3.12, and a build needs a system compiler. Replaced by MicroscPSF-Py + pyotf |
| ASHLAR | Needs Java via pyjnius for its readers. multiview-stitcher + Fiji + SWELL's own stitcher cover it |
| Arduino IDE / CLI | Not needed: the Pico runs MicroPython (D-8). Add portable arduino-cli only if timing forces C |
| Docker / WSL | System-level; nothing needs them |

## Disk use
~12 GB in total:
- .venv: 3.3 GB
- .tools apps: ~4 GB
- caches: ~4.6 GB, re-downloadable. `.tools/dl` and `.tools/uv-cache` may be deleted to reclaim space; `setup_tools.sh` restores them.

## Rebuilders
`tools/setup_tools.sh` plus `software/requirements.lock` give any maker the same toolchain, hash-checked. The download list is in the script, and the checksums are in `.tools/manifest.txt` (copied into docs at G6).
