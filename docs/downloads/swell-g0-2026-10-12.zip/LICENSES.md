# LICENSES: third-party terms SWELL depends on

SWELL's own licence (set at the G0 public release, 2026-10-09): CC0 1.0 for docs, text, data and the simulation code; CERN-OHL-P v2 for hardware design files. See README.md and LICENSES/. Third-party items marked "(confirm)" below were not re-checked for this release, except OpenFlexure (see README.md).

## Forked or reused designs and code
| Component | Use in SWELL | Licence | Obligations |
|---|---|---|---|
| OpenFlexure Microscope v7 hardware (OpenSCAD) | Stage, optics module and illumination, to be forked from a pinned beta5 commit (nothing forked yet) | CERN Open Hardware Licence v2, strongly reciprocal (CERN-OHL-S-2.0: the project's License file, checked 2026-10-09) | Modified sources released under the same licence when distributed; keep notices |
| OpenFlexure software | Not reused (D-6); the Sangaboard serial protocol is matched for compatibility | confirm (GPL family expected) | None while not copied |

## Tools used to build SWELL (not shipped in the instrument)
| Tool | Version | Licence |
|---|---|---|
| uv | 0.12.24 | MIT / Apache-2.0 |
| CPython | 3.12.15 | PSF |
| FreeCAD | 1.1.4 | LGPL-2.1+ |
| OpenSCAD | 2026.10.05 snapshot | GPL-2.0 |
| PrusaSlicer | 2.9.6 | AGPL-3.0 |
| Fiji / ImageJ | 2.16.0 / 1.54p | GPL-3.0 (ImageJ 1.x public domain) |
| QuPath | 0.7.0 | GPL-3.0 |
| Pandoc | 3.12.1 | GPL-2.0+ |
| Typst | 0.15.1 | Apache-2.0 |
| Graphviz | 16.1.0 | EPL (confirm version) |
| 7-Zip (7zr) | current | LGPL-2.1 |
| Python packages | software/requirements.lock (250 pinned) | Various (BSD/MIT/Apache/LGPL/GPL); the audit list is generated at G6 |

## Data and protocols
- protocols.io protocols are cited, not copied; each one's licence (typically CC BY 4.0) is honoured with attribution in protocols/.
