#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
S3: red-team synthetic expansion-microscopy gel for the SWELL ruler pipeline.

Writes   <out>/obs.json.gz    (swell-obs/1, the only file a pipeline may read)
         <out>/truth.json.gz  (swell-truth/1, for the scorer only)
Default <out> is data/sim/S3 under the project folder (resolved relative to this file).

Deterministic: one fixed seed, per-object child seeds (so --workers does not change the output).
Every model choice and number is listed in README.md next to this file.

How it works (short): a physical scene is built in pre-expansion material coordinates (myofibrils as
curved 3-D rods with a sarcomere density pattern, bundles, debris, defects), mapped into the post stage
frame by a smooth deformation field plus rotation, mirror, fold, bubble-lens, wrinkle, scan-time drift and
stage/stitching errors. Each object is then *rendered* (pre: phase image -> two-axis DPC; post: 3-D slab
model -> widefield z-stack plane and z-sum, both with Airy-core + Lorentzian-halo OTFs, field-dependent
astigmatism, illumination fall-off, background structure, Poisson + read + fixed-pattern noise), and an
emulated image front-end segments it and samples the profiles exactly as the schema describes.

Run:  python software/redteam/s3_gen.py [--workers 8] [--quick N]      (from the project folder)
"""
import argparse
import gzip
import io
import json
import math
import os
import sys
import time

import numpy as np
from scipy import fft as sfft
from scipy import ndimage as ndi
from scipy.special import j1
from matplotlib.path import Path as MplPath

SEED = 20261010
GEL_ID = "S3"
HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_OUT = os.path.normpath(os.path.join(HERE, "..", "..", "data", "sim", "S3"))

# =====================================================================================
# 1. Parameters (documented in README.md; change nothing without re-documenting)
# =====================================================================================
# --- gel geometry and deformation (pre-expansion µm, gel centre at pre (0, 0)) ---
R_NOMINAL = 750.0          # radius the pipeline is told
R_TRUE = 747.0             # actual punch radius (punches cut slightly small)
R_PLACE = 735.0            # fibrils lie within this radius
E0 = 4.383                 # expansion scale of the deformation map at the reference time
BETA_RADIAL = 0.006        # area dilatation grows as 2*beta*(r/R)^2 towards the edge
EPS_ANISO = 0.003          # gel in-plane anisotropy: stretch 1+eps along TH_ANISO, 1-eps across
TH_ANISO = math.radians(30.0)
RAND_STRAIN = 0.0020       # rms axial strain of the random smooth field
RAND_MODES = 48
RAND_LAMBDA = (150.0, 600.0)
GEL_THICK_PRE = 66.0       # gel thickness before expansion (sets the fold lift)

# --- global transform pre -> post stage ---
ROT = 2.4517               # rad
MIRROR = True              # post = c + R(ROT) @ diag(1,-1) @ phi(pre)
C_POST = (11873.4, 7432.9) # true gel centre in post stage µm
PIVOT_OFF = (410.0, -260.0)  # the scan-time drift scales about this point (gel stuck to glass there)

# --- intrinsic fibril transverse factor: E_tr = (1 + a_i) * gel transverse stretch ---
ANISO_A0 = -0.010
ANISO_KW = -0.010          # per µm of diameter above 1.05 µm (thicker fibrils swell less)
ANISO_SD = 0.004

# --- scan-time expansion drift (fractional change of linear expansion) ---
DRIFT = dict(A1=0.0072, tau1=2600.0, A2=0.0009, P2=2520.0, ph2=1.1, A3=-0.0040, T3=7200.0)
T_OVERVIEW = -300.0        # overview-camera picture (e_macro) taken 5 min before the scan
E_MACRO_CAM_ERR = 0.0015   # overview camera calibration error (fractional)
CENTER_ERR_SD = 30.0       # overview-camera gel-centre error, post µm per axis

# --- defects (pre coordinates) ---
FOLD = dict(theta=math.radians(205.0), d=600.0, crease_lost=10.0, crease_c=0.04, crease_len=12.0, drape=60.0)
BUBBLE = dict(c=(380.0, 330.0), r=90.0, H=20.0, lens_D=3.0, lens_w=0.15, core_D=0.04, poly_scale=1.15,
              blur_extra=0.9, blur_core=1.2, gain_core=0.6, bg_ring=0.40)
WRINKLE = dict(c=(417.0, -169.0), hx=130.0, hy=100.0, ang=math.radians(70.0), lam=45.0, A=10.0,
               taper=25.0, phase=0.4)
CURVED = dict(c=(-377.0, 227.0), a=135.0, b=95.0, ang=math.radians(20.0))
BUNDLE = dict(c=(-91.0, -430.0), a=120.0, b=95.0, ang=math.radians(-15.0))
UNDER = dict(c=(-60.0, 120.0), delta=-0.08, sigma=40.0, r_poly=80.0)
OVER = dict(c=(60.0, 470.0), a_line=80.0, n_src=5, sigma=30.0, delta=0.0266, ang=math.radians(-35.0),
            poly_a=134.0, poly_b=54.0)
CLOCK_MAX_R = 350.0        # the clock tile is the most crowded tile within this pre radius, >150 um from defects

# --- population ---
N_FIBRIL_OBJECTS = 1198    # pre objects that are myofibrils (singles + bundles)
N_PRE_DEBRIS = 12
N_POST_DEBRIS = 74
P_WASHED = 0.008           # fibril detached / digested away before the post image

# --- pre image (label-free DPC) ---
PX_PRE = 0.1
PSF_PRE_TOLD = 0.40
PRE_CORE_FWHM = 0.44
PRE_HALO = (0.08, 1.2)     # (energy fraction, gamma µm) of the Lorentzian (2-D Cauchy) halo
PRE_TAN = 0.683            # tan of the half-angle of the detection cone in water
PRE_FOCUS_SD = 0.25        # per pre tile focus error, µm
DPC_GAIN = 150.0           # DPC asymmetry x1000 per rad/µm of phase gradient
DPC_NOISE = 18.0           # per pixel, x1000 asymmetry units, at full illumination
DPC_FPN = 3.0
PHASE_PER_UM = 0.62        # rad per µm of thickness per unit protein density
FOV_PRE = 204.8
STEP_PRE = 184.32
PRE_TILE_ERR = 0.06        # stitching residual per pre tile, µm per axis
PRE_STAGE_SCALE = (-0.0003, 0.0004)
PRE_HOME = (-5200.0, 3100.0)

# --- post image (pan-protein fluorescence, widefield z-stack) ---
PX_POST = 0.2
PSF_POST_TOLD = 0.42
POST_CORE_FWHM = 0.43
POST_HALO = (0.05, 3.0)
POST_TAN = 0.683           # NA 0.75 into n = 1.33
DOF_TOLD = 1.6
NPL = 21                   # z-planes
DZ_PL = 0.75               # plane spacing, µm
AF_SD = 0.4                # autofocus error, µm
ASTIG = (0.07, 0.20)       # radial / tangential extra Gaussian sigma (µm) at the tile corner
B_POST = 480.0             # photo-electrons per µm of column per unit density (in focus)
BG_POST = 380.0            # background photo-electrons per pixel per plane
READ_NOISE = 2.0
CAM_OFFSET = 100.0
PRNU_SD = 0.01
DSNU_SD = 1.2
COL_SD = 0.7
FOV_POST = 409.6
STEP_POST = 368.64
N_SIDE_POST = 19
POST_TILE_ERR = 0.35       # per tile repeatability, µm per axis
CLOCK_VISIT_ERR = 1.0      # stage return error for a clock visit, µm per axis
POST_STAGE_SCALE = (0.0008, -0.0005)
POST_HOME = (0.0, 0.0)
CLOCK_EVERY = 50

# --- emulated front-end ---
FE_THR = 0.30

# =====================================================================================
# 2. Small utilities
# =====================================================================================

def rot2(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s], [s, c]])


def unit(v):
    v = np.asarray(v, float)
    n = np.linalg.norm(v, axis=-1, keepdims=True)
    return v / np.maximum(n, 1e-12)


def perp(v):
    v = np.asarray(v, float)
    return np.stack([-v[..., 1], v[..., 0]], axis=-1)


def otf_pupil(k, kc):
    q = np.clip(np.asarray(k, float) / kc, 0.0, 1.0)
    return (2.0 / np.pi) * (np.arccos(q) - q * np.sqrt(1.0 - q * q))


def jinc(x):
    x = np.asarray(x, float)
    out = np.ones_like(x)
    m = np.abs(x) > 1e-9
    out[m] = 2.0 * j1(x[m]) / x[m]
    return out


def softplus(x, eps):
    return eps * np.logaddexp(0.0, np.asarray(x, float) / eps)


def ellipse_poly(c, a, b, ang, n=48):
    t = np.linspace(0, 2 * np.pi, n, endpoint=False)
    p = np.stack([a * np.cos(t), b * np.sin(t)], 1) @ rot2(ang).T
    return p + np.asarray(c)


def circle_poly(c, r, n=48):
    return ellipse_poly(c, r, r, 0.0, n)


def in_poly(pts, poly):
    return MplPath(np.asarray(poly)).contains_points(np.atleast_2d(pts))


def clip_convex(subject, clip):
    """Sutherland-Hodgman: clip polygon `subject` by the convex polygon `clip` (counter-clockwise)"""
    out = [np.asarray(p, float) for p in subject]
    C = np.asarray(clip, float)
    for i in range(len(C)):
        a, b = C[i], C[(i + 1) % len(C)]
        inp, out = out, []
        if not inp:
            break

        def inside(p):
            return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]) >= 0

        def cross(p, q):
            d1, d2 = q - p, b - a
            den = d1[0] * d2[1] - d1[1] * d2[0]
            t = ((a[0] - p[0]) * d2[1] - (a[1] - p[1]) * d2[0]) / den
            return p + t * d1
        s = inp[-1]
        for e in inp:
            if inside(e):
                if not inside(s):
                    out.append(cross(s, e))
                out.append(e)
            elif inside(s):
                out.append(cross(s, e))
            s = e
    return np.array(out)


def seg_dist(P, A, B):
    """distance from points P (n,2) to segments A->B (m,2) -> (n,m)"""
    AB = B - A
    AP = P[:, None, :] - A[None, :, :]
    den = np.maximum(np.sum(AB * AB, 1), 1e-12)
    t = np.clip(np.sum(AP * AB[None], 2) / den[None], 0, 1)
    D = AP - t[..., None] * AB[None]
    return np.sqrt(np.sum(D * D, 2))


def dist_to_poly(pts, poly):
    """0 inside, else distance to the boundary"""
    pts = np.atleast_2d(pts)
    poly = np.asarray(poly)
    A = poly
    B = np.roll(poly, -1, axis=0)
    d = seg_dist(pts, A, B).min(1)
    return np.where(in_poly(pts, poly), 0.0, d)


def polyline_dist(P, Q):
    if len(P) < 2 or len(Q) < 2:
        return float(np.min(np.linalg.norm(P[:, None] - Q[None], axis=2)))
    d1 = seg_dist(P, Q[:-1], Q[1:]).min()
    d2 = seg_dist(Q, P[:-1], P[1:]).min()
    return float(min(d1, d2))


def odd(n):
    n = int(n)
    return n if n % 2 == 1 else n + 1


def rng_for(*keys):
    return np.random.default_rng(np.random.SeedSequence([SEED] + [int(k) for k in keys]))


# =====================================================================================
# 3. Drift, deformation field, transform, specimen height
# =====================================================================================

def swell_raw(t):
    t = np.asarray(t, float)
    D = DRIFT
    return (D["A1"] * (1.0 - np.exp(-t / D["tau1"]))
            + D["A2"] * np.sin(2 * np.pi * t / D["P2"] + D["ph2"])
            + D["A3"] * np.sign(t) * np.abs(t / D["T3"]) ** 3)


class GelMap:
    """phi: pre material µm -> expanded gel frame (post µm, before rotation/mirror/translation)."""

    def __init__(self, rng):
        n = np.array([math.cos(TH_ANISO), math.sin(TH_ANISO)])
        self.A = np.eye(2) + EPS_ANISO * (2 * np.outer(n, n) - np.eye(2))
        m = RAND_MODES
        lam = np.exp(rng.uniform(math.log(RAND_LAMBDA[0]), math.log(RAND_LAMBDA[1]), m))
        ang = rng.uniform(0, 2 * np.pi, m)
        self.kv = (2 * np.pi / lam)[:, None] * np.stack([np.cos(ang), np.sin(ang)], 1)
        pa = rng.uniform(0, 2 * np.pi, m)
        self.pol = np.stack([np.cos(pa), np.sin(pa)], 1)
        self.ph = rng.uniform(0, 2 * np.pi, m)
        self.amp = 1.0 / np.linalg.norm(self.kv, axis=1)
        pts = rng.uniform(-600, 600, (6000, 2))
        dirs = rng.uniform(0, np.pi, 6000)
        t = np.stack([np.cos(dirs), np.sin(dirs)], 1)
        h = 0.5
        du = (self.u_rand(pts + h * t) - self.u_rand(pts - h * t)) / (2 * h)
        strain = np.sum(du * t, 1)
        self.amp *= RAND_STRAIN / strain.std()
        self.src = [(np.array(UNDER["c"]), UNDER["delta"], UNDER["sigma"])]
        d = np.array([math.cos(OVER["ang"]), math.sin(OVER["ang"])])
        for q in np.linspace(-OVER["a_line"], OVER["a_line"], OVER["n_src"]):
            self.src.append((np.array(OVER["c"]) + q * d, OVER["delta"], OVER["sigma"]))
        self.nf = np.array([math.cos(FOLD["theta"]), math.sin(FOLD["theta"])])
        self.df = FOLD["d"]

    def u_rand(self, p):
        arg = p @ self.kv.T + self.ph
        return np.cos(arg) @ (self.amp[:, None] * self.pol)

    def u_rad(self, p):
        r2 = np.sum(p * p, 1, keepdims=True)
        return (BETA_RADIAL / (2 * R_TRUE ** 2)) * r2 * p

    def u_def(self, p):
        u = np.zeros_like(p)
        for c, dl, sg in self.src:
            d = p - c
            r2 = np.sum(d * d, 1, keepdims=True)
            f = np.where(r2 > 1e-9, (1 - np.exp(-r2 / (2 * sg * sg))) / np.maximum(r2, 1e-9), 1 / (2 * sg * sg))
            u = u + dl * sg * sg * f * d
        return u

    def u_crease(self, p):
        dlt = p @ self.nf - self.df
        a = np.abs(dlt)
        c, L0, lc = FOLD["crease_c"], FOLD["crease_lost"], FOLD["crease_len"]
        U = np.where(a < L0, -c * a, -c * L0 - c * lc * (1 - np.exp(-(a - L0) / lc)))
        return (np.sign(dlt) * U)[:, None] * self.nf[None, :]

    def phi(self, p):
        p = np.atleast_2d(np.asarray(p, float))
        q = (p + self.u_rad(p) + self.u_rand(p)) @ self.A.T + self.u_def(p) + self.u_crease(p)
        return E0 * q

    def jac(self, p, h=0.25):
        p = np.atleast_2d(np.asarray(p, float))
        ex = np.array([h, 0.0])
        ey = np.array([0.0, h])
        jx = (self.phi(p + ex) - self.phi(p - ex)) / (2 * h)
        jy = (self.phi(p + ey) - self.phi(p - ey)) / (2 * h)
        return np.stack([jx, jy], axis=2)


def wrinkle_h(p):
    W = WRINKLE
    k = np.array([math.cos(W["ang"]), math.sin(W["ang"])])
    kp = np.array([-k[1], k[0]])
    d = np.atleast_2d(p) - np.array(W["c"])
    xi = d @ k
    eta = d @ kp

    def win(x, hlf, tp):
        a = np.clip((hlf - np.abs(x)) / tp, 0, 1)
        return np.sin(0.5 * np.pi * a) ** 2

    env = win(xi, W["hx"], W["taper"]) * win(eta, W["hy"], W["taper"])
    return env * W["A"] * (1.0 + np.sin(2 * np.pi * xi / W["lam"] + W["phase"]))


def dome_h(p):
    d = np.atleast_2d(p) - np.array(BUBBLE["c"])
    r = np.linalg.norm(d, axis=1)
    x = 1 - (r / BUBBLE["r"]) ** 2
    return BUBBLE["H"] * np.sqrt(softplus(x, 0.02))


def surf_h(p):
    """height of the gel's specimen face above the coverslip from wrinkles and the bubble dome (post µm)"""
    return wrinkle_h(p) + dome_h(p)


class World:
    """Everything geometric that maps pre material -> post stage at the reference time."""

    def __init__(self, rng):
        self.gm = GelMap(rng)
        M = np.diag([1.0, -1.0]) if MIRROR else np.eye(2)
        self.Rm = rot2(ROT) @ M
        self.c = np.array(C_POST)
        self.pivot = self.c + np.array(PIVOT_OFF)
        self.nf = self.gm.nf
        self.df = self.gm.df
        self.tf = np.array([-self.nf[1], self.nf[0]])
        self.Xb = self.G(np.array([BUBBLE["c"]]))[0]
        Jb = self.gm.jac(np.array([BUBBLE["c"]]))[0]
        self.Eb = math.sqrt(abs(np.linalg.det(Jb)))
        self.rb_post = BUBBLE["r"] * self.Eb
        self.h_gel = GEL_THICK_PRE * E0

    def G(self, p):
        return self.c + self.gm.phi(p) @ self.Rm.T

    def JG(self, p):
        return np.einsum("ij,njk->nik", self.Rm, self.gm.jac(p))

    def delta_fold(self, p):
        return np.atleast_2d(p) @ self.nf - self.df

    def in_flap(self, p):
        return self.delta_fold(p) > 0

    def in_overlap(self, p):
        p = np.atleast_2d(p)
        dl = self.delta_fold(p)
        pr = p - 2 * dl[:, None] * self.nf[None, :]
        return (dl < 0) & (np.linalg.norm(pr, axis=1) < R_TRUE)

    def fold_lift(self, p):
        """main gel lying on the tucked flap: lifted by one gel thickness where the flap is under it and
        draping back down to the glass over FOLD['drape'] µm (pre) outside the flap's edge"""
        p = np.atleast_2d(p)
        dl = self.delta_fold(p)
        pr = p - 2 * dl[:, None] * self.nf[None, :]
        x = np.clip((R_TRUE + FOLD["drape"] - np.linalg.norm(pr, axis=1)) / FOLD["drape"], 0, 1)
        return np.where(dl < 0, self.h_gel * x * x * (3 - 2 * x), 0.0)

    def spec_h(self, p):
        """height of the main gel's specimen face above the coverslip (post µm)"""
        return surf_h(p) + self.fold_lift(p)

    def spec_grad(self, p, h=0.5):
        p = np.atleast_2d(p)
        gx = (self.spec_h(p + [h, 0]) - self.spec_h(p - [h, 0])) / (2 * h)
        gy = (self.spec_h(p + [0, h]) - self.spec_h(p - [0, h])) / (2 * h)
        return np.stack([gx, gy], 1)

    def G_flap(self, p):
        p = np.atleast_2d(p)
        dl = self.delta_fold(p)
        pl = p - dl[:, None] * self.nf[None, :]
        Xl = self.G(pl)
        tpost = unit(np.einsum("nij,j->ni", self.JG(pl), self.tf))
        d = self.G(p) - Xl
        dt = np.sum(d * tpost, 1, keepdims=True)
        return Xl + 2 * dt * tpost - d

    def _lens_dr(self, r):
        """radial image displacement (post µm) from looking through the air dome: a meniscus bump at the
        rim plus a diverging-lens demagnification of the core (zero at the centre and at the rim)"""
        rb = self.rb_post
        w = BUBBLE["lens_w"] * rb
        q = np.clip(r / rb, 0, 1)
        dr = BUBBLE["lens_D"] * np.exp(-((r - rb) / w) ** 2) - BUBBLE["core_D"] * rb * q * (1 - q * q)
        g = (BUBBLE["lens_D"] * np.exp(-((r - rb) / w) ** 2) * (-2 * (r - rb) / w ** 2)
             - np.where(r < rb, BUBBLE["core_D"] * (1 - 3 * q * q), 0.0))
        return dr, g

    def lens(self, X):
        d = X - self.Xb
        r = np.linalg.norm(d, axis=1, keepdims=True)
        dr, _ = self._lens_dr(r)
        return X + dr * d / np.maximum(r, 1e-9)

    def lens_stretch(self, X):
        """radial magnification (1 + d dr/dr) at post points X"""
        d = X - self.Xb
        r = np.linalg.norm(d, axis=1)
        _, g = self._lens_dr(r)
        return 1.0 + g, unit(d)

    def post_ref(self, p, flap):
        """material points -> post stage at the reference time (no drift, no stage error)"""
        X = self.G_flap(p) if flap else self.G(p)
        return self.lens(X)

    def pre_of_post(self, X):
        """approximate inverse (global affine) used only for tile bookkeeping"""
        A = E0 * self.Rm
        return (np.atleast_2d(X) - self.c) @ np.linalg.inv(A).T


# =====================================================================================
# 4. Optics
# =====================================================================================

def kc_for(fwhm):
    return 1.029 / fwhm


class PostOptics:
    def __init__(self):
        self.kc = kc_for(POST_CORE_FWHM)
        self.dk = 0.002
        self.kmax = math.sqrt(2) / (2 * PX_POST) + 0.01
        self.k = np.arange(0, self.kmax + self.dk, self.dk)
        k = self.k
        base = (1 - POST_HALO[0]) * otf_pupil(k, self.kc) + POST_HALO[0] * np.exp(-2 * np.pi * POST_HALO[1] * k)
        self.base = base
        self.dzs = np.arange(-40.0, 40.0001, 0.05)
        rho = np.maximum(np.abs(self.dzs) - 0.3, 0) * POST_TAN
        self.T_focus = (base[None, :] * jinc(2 * np.pi * k[None, :] * rho[:, None])).astype(np.float32)
        self.offs = np.arange(-40.0, 40.0001, 0.1)
        T = np.zeros((self.offs.size, k.size))
        for p in range(NPL):
            zp = (p - (NPL - 1) / 2) * DZ_PL
            rho = np.maximum(np.abs(zp - self.offs) - 0.3, 0) * POST_TAN
            T += base[None, :] * jinc(2 * np.pi * k[None, :] * rho[:, None])
        self.T_sum = T.astype(np.float32)

    def row_focus(self, dz):
        i = int(round((np.clip(dz, -40, 40) + 40.0) / 0.05))
        return self.T_focus[i]

    def row_sum(self, off):
        i = int(round((np.clip(off, -40, 40) + 40.0) / 0.1))
        return self.T_sum[i]


def fpn_patterns():
    r = np.random.default_rng(np.random.SeedSequence([SEED, 999]))
    prnu = (1.0 + r.normal(0, PRNU_SD, (2048, 2048))).astype(np.float32)
    dsnu = r.normal(0, DSNU_SD, (2048, 2048)).astype(np.float32)
    hot = r.random((2048, 2048)) < 0.001
    dsnu[hot] += r.uniform(20, 80, hot.sum()).astype(np.float32)
    col = r.normal(0, COL_SD, 2048).astype(np.float32)
    dpc_x = r.normal(0, DPC_FPN, (2048, 2048)).astype(np.float32)
    dpc_y = r.normal(0, DPC_FPN, (2048, 2048)).astype(np.float32)
    return dict(prnu=prnu, dsnu=dsnu, col=col, dpc_x=dpc_x, dpc_y=dpc_y)


def post_illum(xc, yc):
    """illumination x detection fall-off within a post tile (camera µm coords)"""
    cx, cy = FOV_POST / 2 + 15.0, FOV_POST / 2 - 10.0
    r = np.hypot(xc - cx, yc - cy) / (FOV_POST / math.sqrt(2))
    psi = 0.6
    g = 1 + 0.08 * ((xc - FOV_POST / 2) / (FOV_POST / 2) * math.cos(psi) + (yc - FOV_POST / 2) / (FOV_POST / 2) * math.sin(psi))
    return (1 - 0.24 * r * r) * g


def pre_illum(xc, yc):
    r = np.hypot(xc - FOV_PRE / 2, yc - FOV_PRE / 2) / (FOV_PRE / math.sqrt(2))
    return 1 - 0.30 * r * r


def dpc_offsets(xc, yc):
    u = xc / FOV_PRE - 0.5
    v = yc / FOV_PRE - 0.5
    r2 = (u * u + v * v) * 2
    ox = 6 + 10 * u - 4 * v + 5 * r2
    oy = -3 + 7 * v + 3 * u - 4 * r2
    return ox, oy


# =====================================================================================
# 5. Sarcomere density model
# =====================================================================================

def box_avg(rho, ds, width):
    n = rho.size
    C = np.concatenate([[0.0], np.cumsum(rho.astype(float)) * ds])
    idx = np.arange(n) + 0.5
    hw = 0.5 * width / ds
    e = np.arange(n + 1, dtype=float)
    return ((np.interp(idx + hw, e, C) - np.interp(idx - hw, e, C)) / width).astype(np.float32)


def build_density(rng, L, sl0, ends, contrast):
    """protein density along a myofibril (pre and post stain versions) on a 0.01 µm grid"""
    ds = 0.01
    pad = 1.0
    s = np.arange(-pad, L + pad + 1e-9, ds)
    n = s.size
    prm = dict(A=rng.normal(1.60, 0.015), lthin=rng.normal(1.05, 0.03), wZ=rng.uniform(0.07, 0.11), wM=0.07,
               rho_thick=0.70, rho_thin=0.30, rho_Z=rng.uniform(1.4, 1.7), rho_M=rng.uniform(0.2, 0.35),
               zboost=1.25)
    nmax = int((L + 3 * sl0) / (0.7 * sl0)) + 6
    ar = np.zeros(nmax)
    ar[0] = rng.normal(0, 0.010)
    e = rng.normal(0, 0.010 * math.sqrt(1 - 0.64), nmax)
    for i in range(1, nmax):
        ar[i] = 0.8 * ar[i - 1] + e[i]
    sls = sl0 * (1 + ar) + rng.normal(0, 0.022, nmax)
    z0 = -rng.uniform(0, sl0)
    smear = np.zeros(n)
    fray_fac = np.ones(n)
    for side, kind in (("L", ends[0]), ("R", ends[1])):
        zs = z0 + np.concatenate([[0.0], np.cumsum(sls)])
        if kind == "damage":
            nd = int(rng.integers(1, 4))
            fac = rng.uniform(1.2, 1.6) if rng.random() < 0.5 else rng.uniform(0.78, 0.9)
            zone = nd * sl0
            for k in range(nmax):
                a, b = zs[k], zs[k + 1]
                if side == "L" and b > 0 and a < zone:
                    sls[k] *= fac
                if side == "R" and a < L and b > L - zone:
                    sls[k] *= fac
            m = rng.uniform(0.3, 0.7)
            if side == "L":
                smear = np.maximum(smear, np.where(s < zone, m, 0))
            else:
                smear = np.maximum(smear, np.where(s > L - zone, m, 0))
        elif kind == "fray":
            fl = rng.uniform(1.5, 4.0)
            if side == "L":
                zmask = s < fl
            else:
                zmask = s > L - fl
            smear = np.maximum(smear, np.where(zmask, 0.5, 0))
            fray_fac = np.where(zmask, 0.75, fray_fac)
    zs = z0 + np.concatenate([[0.0], np.cumsum(sls)])
    rho_pre = np.zeros(n)
    rho_post = np.zeros(n)
    for k in range(nmax):
        za, sl = zs[k], sls[k]
        if za > L + pad:
            break
        i0 = max(0, int(math.floor((za + pad) / ds)))
        i1 = min(n, int(math.ceil((za + sl + pad) / ds)) + 1)
        if i1 <= i0:
            continue
        x = s[i0:i1] - za
        A = min(prm["A"], sl - prm["wZ"] - 0.02)
        A = max(A, 0.3)
        thick = prm["rho_thick"] * prm["A"] / A
        d = np.where(np.abs(x - sl / 2) < A / 2, thick, 0.0)
        d = d + np.where(x < prm["lthin"], prm["rho_thin"], 0.0)
        d = d + np.where(x > sl - prm["lthin"], prm["rho_thin"], 0.0)
        d = d + np.where(np.abs(x - sl / 2) < prm["wM"] / 2, prm["rho_M"], 0.0)
        zm = (x < prm["wZ"] / 2) | (x > sl - prm["wZ"] / 2)
        rho_pre[i0:i1] = np.where(zm, prm["rho_Z"], d)
        rho_post[i0:i1] = np.where(zm, prm["rho_Z"] * prm["zboost"], d)
    inside = (s >= 0) & (s <= L)
    out = []
    for rho in (rho_pre, rho_post):
        mu = rho[inside].mean()
        rho = mu + contrast * (rho - mu)
        if smear.any():
            w = max(3, int(round(sl0 / ds)))
            loc = ndi.uniform_filter1d(rho, w, mode="nearest")
            rho = (1 - smear) * rho + smear * loc
        rho = rho * fray_fac
        rho = np.where(inside, rho, 0.0)
        out.append(rho.astype(np.float32))
    # true mean sarcomere length within the fibril (coverage-weighted)
    cov = []
    for k in range(nmax):
        a, b = zs[k], zs[k + 1]
        ov = max(0.0, min(b, L) - max(a, 0.0))
        if ov > 0:
            cov.append((ov, sls[k]))
    cov = np.array(cov)
    sl_mean = float(np.sum(cov[:, 0] * cov[:, 1]) / np.sum(cov[:, 0]))
    return dict(s0=-pad, ds=ds, rho_pre=out[0], rho_post=out[1], sl_mean=sl_mean, prm=prm)


def smooth_density(rng, L, ds, pad, corr, amp, base=1.0):
    s = np.arange(-pad, L + pad + 1e-9, ds)
    w = rng.normal(0, 1, s.size)
    sg = corr / ds
    f = ndi.gaussian_filter1d(w, sg, mode="wrap")
    f = f / max(f.std(), 1e-9)
    rho = base * (1 + amp * f)
    rho = np.clip(rho, 0.05, None)
    rho = np.where((s >= 0) & (s <= L), rho, 0.0)
    return s, rho


# =====================================================================================
# 6. Population: fibrils, bundles, debris
# =====================================================================================

def sample_width(rng, lo=0.7, hi=2.0, med=1.05):
    return float(np.clip(rng.lognormal(math.log(med), 0.25), lo, hi))


def sample_length(rng):
    return float(np.clip(rng.lognormal(math.log(14.0), 0.5), 5.0, 40.0))


def sample_sl(rng):
    return float(np.clip(rng.normal(1.72, 0.065), 1.52, 2.05))


def sample_theta(rng):
    if rng.random() < 0.4:
        return float((math.radians(35.0) + 0.5 * rng.vonmises(0.0, 2.0)) % math.pi)
    return float(rng.uniform(0, math.pi))


def centreline(c, theta, L, shape, prm, ds=0.2):
    n = max(int(math.ceil(L / ds)), 4) + 1
    s = np.linspace(0.0, L, n)
    if shape == "arc":
        psi = theta + prm * (s - L / 2)
    elif shape == "S":
        psi = theta + prm * np.sin(2 * np.pi * s / L)
    elif shape == "kink":
        psi = theta + prm[0] * (1 / (1 + np.exp(-(s - prm[1]) / 0.3)) - 0.5)
    else:
        psi = np.full_like(s, theta)
    dx, dy = np.cos(psi), np.sin(psi)
    x = np.concatenate([[0.0], np.cumsum(0.5 * (dx[1:] + dx[:-1]) * np.diff(s))])
    y = np.concatenate([[0.0], np.cumsum(0.5 * (dy[1:] + dy[:-1]) * np.diff(s))])
    pts = np.stack([x, y], 1)
    pts += np.asarray(c) - pts.mean(0)
    return s, pts


class Placer:
    def __init__(self, cell=60.0):
        self.cell = cell
        self.grid = {}
        self.items = []

    def _keys(self, pts, pad):
        x0, y0 = pts.min(0) - pad
        x1, y1 = pts.max(0) + pad
        for i in range(int(math.floor(x0 / self.cell)), int(math.floor(x1 / self.cell)) + 1):
            for j in range(int(math.floor(y0 / self.cell)), int(math.floor(y1 / self.cell)) + 1):
                yield (i, j)

    def ok(self, pts, hw, gap):
        seen = set()
        for key in self._keys(pts, 5.0):
            for idx in self.grid.get(key, ()):
                if idx in seen:
                    continue
                seen.add(idx)
                q, qhw = self.items[idx]
                if polyline_dist(pts, q) < hw + qhw + gap:
                    return False
        return True

    def add(self, pts, hw):
        idx = len(self.items)
        self.items.append((pts, hw))
        for key in self._keys(pts, 0.0):
            self.grid.setdefault(key, []).append(idx)


def coarse(pts, step=8):
    idx = np.unique(np.concatenate([np.arange(0, len(pts), step), [len(pts) - 1]]))
    return pts[idx]


def end_kinds(rng):
    out = []
    for _ in range(2):
        r = rng.random()
        out.append("clean" if r < 0.60 else ("fray" if r < 0.85 else "damage"))
    return out


def make_member(rng, c, theta, L, w, shape, sprm, sl0, contrast=None, aniso=None):
    """one myofibril (material comp), plus side strands for frayed ends"""
    s, pts = centreline(c, theta, L, shape, sprm)
    asp = rng.uniform(0.65, 0.95)
    ends = end_kinds(rng)
    if contrast is None:
        contrast = rng.uniform(0.55, 1.0)
    dens = build_density(rng, L, sl0, ends, contrast)
    a = np.full(s.size, w / 2) * (1 + 0.04 * np.interp(s, np.linspace(0, L, 6), rng.normal(0, 1, 6)))
    strands = []
    for side, kind in zip(("L", "R"), ends):
        if kind != "fray":
            continue
        fl = rng.uniform(1.5, 4.0)
        if side == "L":
            zone = s < fl
            frac = np.clip(s / fl, 0, 1)
        else:
            zone = s > L - fl
            frac = np.clip((L - s) / fl, 0, 1)
        a = np.where(zone, a * (0.45 + 0.55 * frac), a)
        # a thin side strand diverging from the fray start
        k0 = int(np.argmin(np.abs(s - (fl if side == "L" else L - fl))))
        tvec = unit(pts[min(k0 + 1, len(pts) - 1)] - pts[max(k0 - 1, 0)])
        sgn = 1 if rng.random() < 0.5 else -1
        dang = sgn * math.radians(rng.uniform(8, 20))
        dirv = rot2(dang) @ (tvec if side == "R" else -tvec)
        st_len = fl * rng.uniform(0.8, 1.1)
        base = pts[k0] + perp(tvec[None])[0] * sgn * a[k0] * 0.6
        ss = np.linspace(0, st_len, max(4, int(st_len / 0.2) + 1))
        spts = base[None, :] + ss[:, None] * dirv[None, :]
        if side == "L":
            spts = spts[::-1]
        sd = build_density(rng, st_len, sl0, ("clean", "clean"), contrast * 0.4)
        strands.append(dict(pts=spts, s=ss, a=np.full(ss.size, rng.uniform(0.14, 0.2)),
                            b=np.full(ss.size, 0.15), dens=sd, strand=True))
    b = a * asp
    if aniso is None:
        aniso = 1.0 + ANISO_A0 + ANISO_KW * (w - 1.05) + rng.normal(0, ANISO_SD)
    main = dict(pts=pts, s=s, a=a, b=b, dens=dens, strand=False, w=w, L=L, sl0=sl0, shape=shape)
    comps = [main] + strands
    for cpt in comps:
        cpt["aniso"] = aniso
    return comps, ends


def make_population(rng, world):
    objs = []
    placer = Placer()
    cur_poly = ellipse_poly(CURVED["c"], CURVED["a"], CURVED["b"], CURVED["ang"])
    bun_poly = ellipse_poly(BUNDLE["c"], BUNDLE["a"], BUNDLE["b"], BUNDLE["ang"])
    parents = [(rng.uniform(-1, 1, 2) * R_PLACE, sample_theta(rng)) for _ in range(60)]
    parents = [(c, t) for c, t in parents if np.linalg.norm(c) < R_PLACE - 30]

    def uniform_in(poly_c, a, b, ang):
        while True:
            q = rng.uniform(-1, 1, 2)
            if q @ q <= 1:
                return np.asarray(poly_c) + rot2(ang) @ (q * [a, b])

    def candidate():
        r = rng.random()
        if r < 0.70:
            while True:
                c = rng.uniform(-R_PLACE, R_PLACE, 2)
                if c @ c < R_PLACE ** 2:
                    return c, sample_theta(rng)
        if r < 0.94:
            pc, pt = parents[int(rng.integers(len(parents)))]
            return pc + rng.normal(0, 22.0, 2), float((pt + rng.normal(0, 0.25)) % math.pi)
        if r < 0.975:
            return uniform_in(CURVED["c"], CURVED["a"], CURVED["b"], CURVED["ang"]), sample_theta(rng)
        return uniform_in(BUNDLE["c"], BUNDLE["a"], BUNDLE["b"], BUNDLE["ang"]), sample_theta(rng)

    n_fail = 0
    while len(objs) < N_FIBRIL_OBJECTS:
        c, th = candidate()
        if c @ c > R_PLACE ** 2:
            continue
        reg = "curved" if in_poly(c, cur_poly)[0] else ("bundled" if in_poly(c, bun_poly)[0] else "none")
        L = sample_length(rng)
        w = sample_width(rng)
        sl0 = sample_sl(rng)
        if reg == "curved":
            L = max(L, 10.0)
            r = rng.random()
            if r < 0.45:
                shape, sprm = "arc", (1 if rng.random() < 0.5 else -1) * rng.uniform(0.5, 1.5) / L
            elif r < 0.75:
                shape, sprm = "S", (1 if rng.random() < 0.5 else -1) * rng.uniform(0.3, 0.6)
            else:
                shape, sprm = "kink", ((1 if rng.random() < 0.5 else -1) * rng.uniform(0.3, 0.8),
                                       rng.uniform(0.3, 0.7) * L)
        else:
            shape, sprm = "arc", rng.normal(0, 1 / 250.0)
        if reg == "bundled" and rng.random() < 0.85:
            obj = make_bundle(rng, c, th, max(L, 8.0), w, sl0)
        else:
            comps, ends = make_member(rng, c, th, L, w, shape, sprm, sl0)
            obj = dict(kind="curved" if reg == "curved" else "fibril", comps=comps, ends=ends, shape=shape)
        allpts = np.concatenate([cp["pts"] for cp in obj["comps"]])
        if np.max(np.sum(allpts ** 2, 1)) > R_PLACE ** 2:
            n_fail += 1
            continue
        hw = max(cp["a"].max() for cp in obj["comps"])
        span = obj.get("span_pts")
        test = coarse(obj["comps"][0]["pts"]) if span is None else span
        hw_test = hw if span is None else obj["span_hw"]
        if not placer.ok(test, hw_test, 1.0):
            n_fail += 1
            continue
        for cp in obj["comps"]:
            placer.add(coarse(cp["pts"]), cp["a"].max())
        obj["region"] = reg
        obj["pre_visible"] = True
        objs.append(obj)
    return objs, placer, n_fail


def make_bundle(rng, c, theta, L, w0, sl0):
    nmem = 3 if rng.random() < 0.3 else 2
    tight = rng.random() < 0.55
    widths = [sample_width(rng, 0.7, 1.6, 1.0) for _ in range(nmem)]
    gaps = rng.uniform(0.0, 0.12, nmem - 1) if tight else rng.uniform(0.25, 0.6, nmem - 1)
    offs = [0.0]
    for i in range(1, nmem):
        offs.append(offs[-1] + widths[i - 1] / 2 + gaps[i - 1] + widths[i] / 2)
    offs = np.array(offs) - np.mean(offs)
    tv = np.array([math.cos(theta), math.sin(theta)])
    nv = np.array([-tv[1], tv[0]])
    curv = rng.normal(0, 1 / 300.0)
    comps = []
    members = []
    sls = []
    for i in range(nmem):
        Lm = L * rng.uniform(0.7, 1.15)
        along = rng.uniform(-0.2, 0.2) * L
        th_m = theta + rng.normal(0, 0.01)
        slm = float(np.clip(sl0 * (1 + rng.normal(0, 0.025)), 1.5, 2.1))
        cm = np.asarray(c) + offs[i] * nv + along * tv
        cps, ends = make_member(rng, cm, th_m, Lm, widths[i], "arc", curv, slm)
        members.append(list(range(len(comps), len(comps) + len(cps))))
        comps.extend(cps)
        sls.append(slm)
    span = np.concatenate([coarse(comps[m[0]]["pts"]) for m in members])
    return dict(kind="bundle_tight" if tight else "bundle_loose", comps=comps, members=members,
                gaps=[float(g) for g in gaps], widths=widths, offs=offs.tolist(), member_sl=sls,
                span_pts=span, span_hw=max(widths) / 2 + 0.2, tight=tight)


def make_post_native(rng, kind, Xc, theta):
    """debris lying on the glass or in the gel, defined directly in post µm"""
    if kind == "deb_lint":
        L = rng.uniform(40, 220)
        w = rng.uniform(3, 10)
        k0 = rng.normal(0, 1 / 150.0)
        s, rho = smooth_density(rng, L, 0.02, 5.0, 8.0, 0.35)
        B = rng.uniform(1.5, 4.0)
        hh_f = rng.uniform(0.6, 1.0)
    elif kind == "deb_beads":
        L = rng.uniform(30, 120)
        w = rng.uniform(2.0, 3.5)
        k0 = rng.normal(0, 1 / 200.0)
        s = np.arange(-5.0, L + 5.0 + 1e-9, 0.02)
        sp = rng.uniform(5.5, 9.5)
        pos = np.arange(rng.uniform(0, sp), L, sp)
        pos = pos + rng.normal(0, 0.1 * sp, pos.size)
        rho = 0.7 + np.zeros_like(s)
        for q in pos:
            rho += 1.3 * np.exp(-0.5 * ((s - q) / 1.2) ** 2)
        rho = np.where((s >= 0) & (s <= L), rho, 0.0)
        B = rng.uniform(1.0, 2.5)
        hh_f = 0.9
    else:  # deb_crack
        L = rng.uniform(80, 300)
        w = rng.uniform(0.8, 1.8)
        k0 = rng.normal(0, 1 / 2000.0)
        s, rho = smooth_density(rng, L, 0.02, 5.0, 3.0, 0.5)
        B = rng.uniform(1.0, 2.0)
        hh_f = 1.5
    ss, pts = centreline(Xc, theta, L, "arc", k0, ds=1.0)
    comp = dict(pts=pts, s=ss, a=np.full(ss.size, w / 2), b=np.full(ss.size, w / 2 * hh_f),
                dens=dict(s0=float(s[0]), ds=0.02, rho_pre=None, rho_post=rho.astype(np.float32)),
                strand=False, aniso=1.0, native=True, Bfac=B, w=w, L=L)
    return comp


def make_debris(rng, world, placer, n):
    """post-only objects: fragments and collagen inside the gel (expanded), lint/beads on the glass,
    cracks in the gel surface."""
    out = []
    kinds = (["deb_fragment"] * 30 + ["deb_lint"] * 25 + ["deb_collagen"] * 15 + ["deb_crack"] * 15
             + ["deb_beads"] * 15)
    tries = 0
    while len(out) < n:
        tries += 1
        kind = kinds[int(rng.integers(len(kinds)))]
        while True:
            c = rng.uniform(-720, 720, 2)
            if c @ c < 720 ** 2:
                break
        if world.in_flap(c)[0] or np.linalg.norm(c - np.array(BUBBLE["c"])) < 1.2 * BUBBLE["r"]:
            continue
        if world.in_overlap(c)[0] and kind in ("deb_lint", "deb_beads"):
            continue
        th = float(rng.uniform(0, math.pi))
        if kind in ("deb_fragment", "deb_collagen"):
            if kind == "deb_fragment":
                L = rng.uniform(4, 12)
                w = rng.uniform(0.45, 0.7)
                comps, ends = make_member(rng, c, th, L, w, "arc", rng.normal(0, 1 / 200.0), sample_sl(rng))
                comps = comps[:1]
            else:
                L = rng.uniform(20, 60)
                w = rng.uniform(0.3, 0.55)
                s, pts = centreline(c, th, L, "arc", rng.normal(0, 1 / 120.0))
                sgrid, rho = smooth_density(rng, L, 0.01, 1.0, 2.0, 0.15)
                comps = [dict(pts=pts, s=s, a=np.full(s.size, w / 2), b=np.full(s.size, w / 2 * 0.9),
                              dens=dict(s0=-1.0, ds=0.01, rho_pre=None, rho_post=rho.astype(np.float32)),
                              strand=False, aniso=1.0, Bfac=rng.uniform(1.2, 2.0), w=w, L=L)]
            if np.max(np.sum(comps[0]["pts"] ** 2, 1)) > 735 ** 2:
                continue
            if not placer.ok(coarse(comps[0]["pts"]), comps[0]["a"].max(), 1.0):
                continue
            placer.add(coarse(comps[0]["pts"]), comps[0]["a"].max())
            out.append(dict(kind=kind, comps=comps, region="none", pre_visible=False, native=False,
                            on_glass=False))
        else:
            Xc = world.post_ref(c[None], False)[0]
            comp = make_post_native(rng, kind, Xc, th)
            out.append(dict(kind=kind, comps=[comp], region="none", pre_visible=False, native=True,
                            on_glass=kind in ("deb_lint", "deb_beads"), anchor_pre=c))
    return out


def make_pre_debris(rng, placer, n):
    out = []
    while len(out) < n:
        r = rng.random()
        while True:
            c = rng.uniform(-720, 720, 2)
            if c @ c < 715 ** 2:
                break
        th = float(rng.uniform(0, math.pi))
        if r < 0.5:
            kind, L, w = "pre_lint", rng.uniform(15, 50), rng.uniform(0.6, 1.4)
            s, pts = centreline(c, th, L, "arc", rng.normal(0, 1 / 60.0))
            sg, rho = smooth_density(rng, L, 0.01, 1.0, 3.0, 0.3)
            Bpre = rng.uniform(0.4, 0.9)
        elif r < 0.75:
            kind, L, w = "pre_scratch", rng.uniform(20, 80), 0.25
            s, pts = centreline(c, th, L, "arc", 0.0)
            sg, rho = smooth_density(rng, L, 0.01, 1.0, 5.0, 0.2)
            Bpre = -0.6
        else:
            kind, L, w = "pre_crystal", rng.uniform(4, 12), rng.uniform(0.5, 1.0)
            s, pts = centreline(c, th, L, "arc", 0.0)
            sg, rho = smooth_density(rng, L, 0.01, 1.0, 50.0, 0.0)
            Bpre = 1.0
        if np.max(np.sum(pts ** 2, 1)) > 735 ** 2:
            continue
        if not placer.ok(coarse(pts), w / 2, 1.0):
            continue
        placer.add(coarse(pts), w / 2)
        comp = dict(pts=pts, s=s, a=np.full(s.size, w / 2), b=np.full(s.size, w / 2 * 0.8),
                    dens=dict(s0=-1.0, ds=0.01, rho_pre=rho.astype(np.float32), rho_post=None),
                    strand=False, aniso=1.0, Bpre_abs=Bpre, w=w, L=L)
        out.append(dict(kind=kind, comps=[comp], region="none", pre_visible=True, post_visible=False))
    return out


# =====================================================================================
# 7. Mosaics, timeline, autofocus
# =====================================================================================

class PreMosaic:
    def __init__(self, rng):
        self.origin = np.array([-FOV_PRE / 2 - 4 * STEP_PRE] * 2) + STEP_PRE / 2 - 0.5 * STEP_PRE
        self.n = 10
        cen = []
        for j in range(self.n):
            for i in range(self.n):
                cen.append(self.origin + STEP_PRE * np.array([i + 0.5, j + 0.5]))
        self.cen = np.array(cen)
        S = np.diag(PRE_STAGE_SCALE)
        self.off = -(self.cen - np.array(PRE_HOME)) @ S.T + rng.normal(0, PRE_TILE_ERR, self.cen.shape)
        self.focus = rng.normal(0, PRE_FOCUS_SD, len(self.cen))
        self.dpc_tile = rng.normal(0, 1.5, (len(self.cen), 2))

    def tile_of(self, X):
        ij = np.floor((np.atleast_2d(X) - self.origin) / STEP_PRE).astype(int)
        ij = np.clip(ij, 0, self.n - 1)
        return ij[:, 1] * self.n + ij[:, 0]

    def cell(self, k):
        i, j = k % self.n, k // self.n
        x0, y0 = self.origin + STEP_PRE * np.array([i, j])
        return (float(x0), float(y0), float(x0 + STEP_PRE), float(y0 + STEP_PRE))

    def cam(self, k, X, Y):
        c = self.cen[k]
        return X - (c[0] - FOV_PRE / 2), Y - (c[1] - FOV_PRE / 2)


class PostMosaic:
    def __init__(self, rng, world, center_told, e_macro):
        self.center = np.asarray(center_told)
        n = N_SIDE_POST
        self.n = n
        self.origin = self.center - STEP_POST * n / 2
        Rpost = R_NOMINAL * e_macro + 150.0
        cells, cen = [], []
        for j in range(n):
            for i in range(n):
                cc = self.origin + STEP_POST * np.array([i + 0.5, j + 0.5])
                # square [cc +- FOV/2] intersects the disc?
                dx = max(abs(cc[0] - self.center[0]) - FOV_POST / 2, 0)
                dy = max(abs(cc[1] - self.center[1]) - FOV_POST / 2, 0)
                if dx * dx + dy * dy <= Rpost ** 2:
                    cells.append((i, j))
                    cen.append(cc)
        self.cells = cells
        self.cen = np.array(cen)
        self.index = {c: k for k, c in enumerate(cells)}
        S = np.diag(POST_STAGE_SCALE)
        self.off = -(self.cen - np.array(POST_HOME)) @ S.T + rng.normal(0, POST_TILE_ERR, self.cen.shape)
        # timeline
        t = 0.0
        visits = []

        def visit():
            nonlocal t
            dur = 24.0 + rng.gamma(2.0, 1.0)
            visits.append(t + dur / 2)
            t += dur
        visit()
        self.t = np.zeros(len(cells))
        for k in range(len(cells)):
            if k > 0 and k % CLOCK_EVERY == 0:
                visit()
            dur = 20.0 + rng.gamma(2.0, 1.0) + (12.0 if rng.random() < 0.05 else 0.0)
            self.t[k] = t + dur / 2
            t += dur
        visit()
        self.visits = np.array(visits)
        self.t_end = t
        self.t_ref = self.visits[0]
        # autofocus: median specimen mid-height over the tile (sampled), + error
        self.zaf = np.zeros(len(cells))
        gx = np.linspace(-FOV_POST / 2, FOV_POST / 2, 9)
        for k, cc in enumerate(self.cen):
            Xs = np.array([(cc[0] + a, cc[1] + b) for a in gx for b in gx])
            P = world.pre_of_post(Xs)
            ok = np.linalg.norm(P, axis=1) < R_TRUE
            ok &= ~world.in_flap(P)
            if ok.sum() < 3:
                self.zaf[k] = 1.8 + rng.normal(0, AF_SD)
                continue
            P = P[ok]
            z = world.spec_h(P) + 1.8
            self.zaf[k] = float(np.median(z)) + rng.normal(0, AF_SD)

    def tile_of(self, X):
        X = np.atleast_2d(X)
        ij = np.floor((X - self.origin) / STEP_POST).astype(int)
        out = np.full(len(X), -1)
        for q, (i, j) in enumerate(ij):
            out[q] = self.index.get((int(i), int(j)), -1)
        bad = out < 0
        if bad.any():
            d = np.linalg.norm(X[bad, None, :] - self.cen[None], axis=2)
            out[bad] = np.argmin(d, axis=1)
        return out

    def cell(self, k):
        i, j = self.cells[k]
        x0, y0 = self.origin + STEP_POST * np.array([i, j])
        return (float(x0), float(y0), float(x0 + STEP_POST), float(y0 + STEP_POST))

    def cam(self, k, X, Y):
        c = self.cen[k]
        return X - (c[0] - FOV_POST / 2), Y - (c[1] - FOV_POST / 2)


# =====================================================================================
# 8. Image components
# =====================================================================================

def finalize(c):
    pts = c["pts"]
    d = pts[-1] - pts[0]
    L = float(np.hypot(*d))
    if L < 1e-6 or len(pts) < 2:
        return None
    eu = d / L
    ev = np.array([-eu[1], eu[0]])
    rel = pts - pts[0]
    u = rel @ eu
    v = rel @ ev
    good = np.concatenate([[True], np.diff(u) > 1e-6])
    if not good.all():
        keep = [0]
        for i in range(1, len(u)):
            if u[i] > u[keep[-1]] + 1e-6:
                keep.append(i)
        keep = np.array(keep)
        for key in ("pts", "s", "hw", "hh", "zc"):
            c[key] = c[key][keep]
        u, v = u[keep], v[keep]
        pts = c["pts"]
        if len(u) < 2:
            return None
    c["p0"] = pts[0].copy()
    c["eu"] = eu
    c["ev"] = ev
    c["u"] = u
    c["v"] = v
    c["dvdu"] = np.gradient(v, u) if len(u) > 2 else np.zeros_like(u)
    dsdu = np.gradient(c["s"], u) if len(u) > 2 else np.full(len(u), (c["s"][-1] - c["s"][0]) / max(u[-1] - u[0], 1e-9))
    c["dsdu0"] = float(dsdu[0])
    c["dsdu1"] = float(dsdu[-1])
    hm = float(np.max(c["hw"]))
    c["bbox"] = (pts[:, 0].min() - hm, pts[:, 1].min() - hm, pts[:, 0].max() + hm, pts[:, 1].max() + hm)
    c["zr"] = (float(np.min(c["zc"] - c["hh"])), float(np.max(c["zc"] + c["hh"])))
    return c


def comp_local(c, X, Y):
    rx = X - c["p0"][0]
    ry = Y - c["p0"][1]
    u = rx * c["eu"][0] + ry * c["eu"][1]
    v = rx * c["ev"][0] + ry * c["ev"][1]
    uk = c["u"]
    vc = np.interp(u, uk, c["v"])
    sl = np.interp(u, uk, c["dvdu"])
    cb2 = 1.0 / (1.0 + sl * sl)
    dv = v - vc
    n = dv * np.sqrt(cb2)
    uf = u + dv * sl * cb2
    s = np.interp(uf, uk, c["s"])
    s = np.where(uf < uk[0], c["s"][0] + (uf - uk[0]) * c["dsdu0"], s)
    s = np.where(uf > uk[-1], c["s"][-1] + (uf - uk[-1]) * c["dsdu1"], s)
    hw = np.interp(uf, uk, c["hw"])
    hh = np.interp(uf, uk, c["hh"])
    zc = np.interp(uf, uk, c["zc"])
    return n, s, hw, hh, zc


def rho_at(c, s):
    r = c["rho"]
    f = (s - c["rs0"]) / c["rds"]
    i0 = np.floor(f).astype(np.int64)
    fr = f - i0
    n = r.size
    ok = (i0 >= 0) & (i0 < n - 1)
    i0c = np.clip(i0, 0, n - 2)
    val = r[i0c] * (1 - fr) + r[i0c + 1] * fr
    return np.where(ok, val, 0.0)


def subbox(c, x0, y0, nx, ny, px, pad):
    """pixel index box covering the comp (padded), intersected with its mosaic cell if it has one"""
    bx0, by0, bx1, by1 = c["bbox"]
    bx0, by0, bx1, by1 = bx0 - pad, by0 - pad, bx1 + pad, by1 + pad
    cl = c.get("clip")
    if cl is not None:
        bx0, by0 = max(bx0, cl[0]), max(by0, cl[1])
        bx1, by1 = min(bx1, cl[2] - 1e-9), min(by1, cl[3] - 1e-9)
    i0 = max(0, int(math.ceil((bx0 - x0) / px - 1e-9)))
    i1 = min(nx, int(math.floor((bx1 - x0) / px + 1e-9)) + 1)
    j0 = max(0, int(math.ceil((by0 - y0) / px - 1e-9)))
    j1 = min(ny, int(math.floor((by1 - y0) / px + 1e-9)) + 1)
    if i1 <= i0 or j1 <= j0:
        return None
    return j0, j1, i0, i1


# =====================================================================================
# 9. Rendering + emulated front-end
# =====================================================================================

def frontend_mask(seg, allow, x0, y0, px, min_len):
    vals = seg[allow]
    if vals.size < 12:
        return None
    peak = np.percentile(vals, 99.5)
    if not np.isfinite(peak) or peak <= 0:
        return None
    m = (seg > FE_THR * peak) & allow
    m = ndi.binary_closing(m, structure=np.ones((3, 3), bool), iterations=2) & allow
    lab, nl = ndi.label(m)
    if nl == 0:
        return None
    sizes = np.bincount(lab.ravel())[1:]
    k = int(np.argmax(sizes)) + 1
    m = lab == k
    jj, ii = np.nonzero(m)
    if jj.size < 12:
        return None
    X = x0 + ii * px
    Y = y0 + jj * px
    w = np.clip(seg[jj, ii], 0, None) + 1e-9
    cx = float(np.sum(w * X) / np.sum(w))
    cy = float(np.sum(w * Y) / np.sum(w))
    mx, my = X.mean(), Y.mean()
    dx, dy = X - mx, Y - my
    cxx, cyy, cxy = np.mean(dx * dx), np.mean(dy * dy), np.mean(dx * dy)
    th = (0.5 * math.atan2(2 * cxy, cxx - cyy)) % math.pi
    sp = (X - cx) * math.cos(th) + (Y - cy) * math.sin(th)
    smin = float(sp.min() - 0.5 * px)
    smax = float(sp.max() + 0.5 * px)
    length = smax - smin
    if length < min_len:
        return None
    width = float(jj.size * px * px / max(length, px))
    return dict(cx=cx, cy=cy, th=th, smin=smin, smax=smax, length=length, width=width)


def sample_band(img, x0, y0, px, cx, cy, th, s_arr, n_arr, axis_mean):
    S, N = np.meshgrid(s_arr, n_arr, indexing="ij")
    ct, st = math.cos(th), math.sin(th)
    X = cx + S * ct - N * st
    Y = cy + S * st + N * ct
    cols = (X - x0) / px
    rows = (Y - y0) / px
    v = ndi.map_coordinates(img, [rows.ravel(), cols.ravel()], order=1, mode="nearest").reshape(S.shape)
    return v.mean(axis=axis_mean)


def profiles(img_axial, img_cross, fe, x0, y0, px, cross_half, rows_frac, rows_max, img_extra=None,
             extra_rows_frac=None, extra_rows_max=None):
    th = fe["th"]
    N = int(math.floor(fe["length"] / px)) + 1
    s_arr = fe["smin"] + px * np.arange(N)
    hwb = max(0.5 * fe["width"], px)
    m = max(1, int(round(hwb / px)))
    n_band = px * np.arange(-m, m + 1)
    axial = sample_band(img_axial, x0, y0, px, fe["cx"], fe["cy"], th, s_arr, n_band, 1)
    M = int(math.ceil(cross_half / px))
    n_arr = px * np.arange(-M, M + 1)
    R = odd(np.clip(round(rows_frac * fe["length"] / px), 5, rows_max))
    r_arr = px * (np.arange(R) - (R - 1) / 2)
    cross = sample_band(img_cross, x0, y0, px, fe["cx"], fe["cy"], th, r_arr, n_arr, 0)
    out = dict(axial=axial, cross=cross, cross_rows=int(R), s_first=float(s_arr[0]), s_last=float(s_arr[-1]))
    if img_extra is not None:
        R2 = odd(np.clip(round(extra_rows_frac * fe["length"] / px), 5, extra_rows_max))
        r2 = px * (np.arange(R2) - (R2 - 1) / 2)
        out["zsum_cross"] = sample_band(img_extra, x0, y0, px, fe["cx"], fe["cy"], th, r2, n_arr, 0)
        out["zsum_rows"] = int(R2)
    return out


def smooth_field(rng, shape, sigma_px):
    f = ndi.gaussian_filter(rng.normal(0, 1, shape), sigma_px, mode="wrap")
    return f / max(f.std(), 1e-9)


def render_pre(task, fpn):
    """task: dict(target comps, neighbour comps, tile, seed, expected length/width) -> obs entry or None"""
    rng = np.random.default_rng(np.random.SeedSequence([SEED, 11, task["seed"]]))
    px = PX_PRE
    tc = task["target"]
    allc = tc + task["neigh"]
    bb = np.array([c["bbox"] for c in tc])
    W = task["wexp"]
    margin = max(3.5, 2.6 * W) + 1.5
    x0 = math.floor((bb[:, 0].min() - margin) / px) * px
    y0 = math.floor((bb[:, 1].min() - margin) / px) * px
    nx = sfft.next_fast_len(int(math.ceil((bb[:, 2].max() + margin - x0) / px)) + 1, real=True)
    ny = sfft.next_fast_len(int(math.ceil((bb[:, 3].max() + margin - y0) / px)) + 1, real=True)
    xs = x0 + px * np.arange(nx)
    ys = y0 + px * np.arange(ny)
    phase = np.zeros((ny, nx))
    allow = np.zeros((ny, nx), bool)
    for ci, c in enumerate(allc):
        sb = subbox(c, x0, y0, nx, ny, px, 2 * px)
        if sb is None:
            continue
        j0, j1, i0, i1 = sb
        X, Y = np.meshgrid(xs[i0:i1], ys[j0:j1])
        n, s, hw, hh, zc = comp_local(c, X, Y)
        t = 2 * hh * np.sqrt(np.clip(1 - (n / np.maximum(hw, 1e-6)) ** 2, 0, None))
        phase[j0:j1, i0:i1] += c["B"] * rho_at(c, s) * t
        if ci < len(tc):
            fp = (np.abs(n) < hw + px) & (rho_at(c, s) > 0)
            allow[j0:j1, i0:i1] |= fp
    # background phase structure: smooth inhomogeneity + dust specks
    phase += 0.012 * smooth_field(rng, phase.shape, 2.5 / px)
    nsp = rng.poisson(nx * ny * px * px / 300.0)
    if nsp:
        X, Y = np.meshgrid(xs, ys)
        for _ in range(nsp):
            cx, cy = rng.uniform(xs[0], xs[-1]), rng.uniform(ys[0], ys[-1])
            sg = rng.uniform(0.2, 0.8)
            phase += rng.uniform(0.03, 0.15) * np.exp(-((X - cx) ** 2 + (Y - cy) ** 2) / (2 * sg * sg))
    kx = sfft.rfftfreq(nx, px)[None, :]
    ky = sfft.fftfreq(ny, px)[:, None]
    K = np.sqrt(kx * kx + ky * ky)
    k = task["tile"]
    rho_def = abs(task["focus"]) * PRE_TAN
    otf = ((1 - PRE_HALO[0]) * otf_pupil(K, kc_for(PRE_CORE_FWHM)) + PRE_HALO[0] * np.exp(-2 * np.pi * PRE_HALO[1] * K))
    otf = otf * jinc(2 * np.pi * K * rho_def)
    Ph = sfft.rfft2(phase)
    Gx = sfft.irfft2(1j * 2 * np.pi * kx * otf * Ph, s=(ny, nx)) * DPC_GAIN
    Gy = sfft.irfft2(1j * 2 * np.pi * ky * otf * Ph, s=(ny, nx)) * DPC_GAIN
    X, Y = np.meshgrid(xs, ys)
    xc, yc = task["cam"](X, Y)
    ill = np.clip(pre_illum(xc, yc), 0.3, None)
    ox, oy = dpc_offsets(xc, yc)
    ix = np.clip((xc / px).astype(int), 0, 2047)
    iy = np.clip((yc / px).astype(int), 0, 2047)
    sdn = DPC_NOISE / np.sqrt(ill)
    Gx = Gx + ox + task["dpc_off"][0] + fpn["dpc_x"][iy, ix] + rng.normal(0, 1, Gx.shape) * sdn
    Gy = Gy + oy + task["dpc_off"][1] + fpn["dpc_y"][iy, ix] + rng.normal(0, 1, Gy.shape) * sdn
    # front-end: Tikhonov phase reconstruction with the *told* PSF, then segmentation
    otf_t = otf_pupil(K, kc_for(PSF_PRE_TOLD))
    Hx = 1j * 2 * np.pi * kx * otf_t
    Hy = 1j * 2 * np.pi * ky * otf_t
    den = np.abs(Hx) ** 2 + np.abs(Hy) ** 2 + 0.3
    Gxh = sfft.rfft2(Gx / DPC_GAIN)
    Gyh = sfft.rfft2(Gy / DPC_GAIN)
    rec = sfft.irfft2((np.conj(Hx) * Gxh + np.conj(Hy) * Gyh) / den, s=(ny, nx))
    rec = ndi.gaussian_filter(rec, 1.0)
    rec = np.abs(rec - np.median(rec))
    allow = ndi.binary_dilation(allow, iterations=int(round(0.5 / px)))
    fe = frontend_mask(rec, allow, x0, y0, px, 0.25 * task["lexp"])
    if fe is None:
        return None
    ct, st = math.cos(fe["th"]), math.sin(fe["th"])
    Gax = ct * Gx + st * Gy
    Gcr = -st * Gx + ct * Gy
    pr = profiles(Gax, Gcr, fe, x0, y0, px, max(3.0, 2.2 * fe["width"]), 0.5, 101)
    out = dict(fe=fe, prof=pr)
    if task.get("debug"):
        out.update(img=dict(Gx=Gx, Gy=Gy, phase=phase, rec=rec, x0=x0, y0=y0))
    return out


def render_post(task, fpn, optics):
    rng = np.random.default_rng(np.random.SeedSequence([SEED, 12, task["seed"]]))
    px = PX_POST
    tc = task["target"]
    allc = tc + task["neigh"]
    bb = np.array([c["bbox"] for c in tc])
    W = task["wexp"]
    margin = max(16.0, 2.6 * W) + 6.0
    x0 = math.floor((bb[:, 0].min() - margin) / px) * px
    y0 = math.floor((bb[:, 1].min() - margin) / px) * px
    nx = sfft.next_fast_len(int(math.ceil((bb[:, 2].max() + margin - x0) / px)) + 1, real=True)
    ny = sfft.next_fast_len(int(math.ceil((bb[:, 3].max() + margin - y0) / px)) + 1, real=True)
    xs = x0 + px * np.arange(nx)
    ys = y0 + px * np.arange(ny)
    zf = task["zf"]
    zaf = task["zaf"]
    geo = []
    allow = np.zeros((ny, nx), bool)
    for ci, c in enumerate(allc):
        sb = subbox(c, x0, y0, nx, ny, px, 2 * px)
        if sb is None:
            continue
        j0, j1, i0, i1 = sb
        X, Y = np.meshgrid(xs[i0:i1], ys[j0:j1])
        n, s, hw, hh, zc = comp_local(c, X, Y)
        r = rho_at(c, s)
        if ci < len(tc):
            allow[j0:j1, i0:i1] |= (np.abs(n) < hw + px) & (r > 0)
        geo.append((sb, n, hw, hh, zc, r * c["B"], c["zr"]))
    if not geo:
        return None
    zlo = min(g[6][0] for g in geo)
    zhi = max(g[6][1] for g in geo)
    nsl = int(math.ceil((zhi - zlo) / 0.5)) + 1
    nsl = min(nsl, 40)
    dz = (zhi - zlo) / max(nsl - 1, 1) if nsl > 1 else 0.5
    zsl = zlo + dz * np.arange(nsl) if nsl > 1 else np.array([0.5 * (zlo + zhi)])
    dz = max(dz, 1e-3) if nsl > 1 else max(zhi - zlo, 0.2)
    kx = sfft.rfftfreq(nx, px)[None, :]
    ky = sfft.fftfreq(ny, px)[:, None]
    K = np.sqrt(kx * kx + ky * ky)
    fi = K / optics.dk
    i0k = np.clip(np.floor(fi).astype(np.int64), 0, optics.k.size - 2)
    frk = fi - i0k
    Ff = np.zeros((ny, nx // 2 + 1), complex)
    Fs = np.zeros((ny, nx // 2 + 1), complex)
    D = np.zeros((ny, nx))
    for zj in zsl:
        D[:] = 0.0
        any_ = False
        for sb, n, hw, hh, zc, rB, zr in geo:
            if zj < zr[0] - dz or zj > zr[1] + dz:
                continue
            hc = hw * np.sqrt(np.clip(1 - ((zj - zc) / np.maximum(hh, 1e-6)) ** 2, 0, None))
            occ = np.clip((hc - np.abs(n)) / px + 0.5, 0, 1) * (hc > 0)
            j0, j1, i0, i1 = sb
            D[j0:j1, i0:i1] += rB * occ * dz
            any_ = True
        if not any_:
            continue
        Dh = sfft.rfft2(D)
        rf = optics.row_focus(zf - zj)
        rs = optics.row_sum(zj - zaf)
        Ff += Dh * (rf[i0k] * (1 - frk) + rf[i0k + 1] * frk)
        Fs += Dh * (rs[i0k] * (1 - frk) + rs[i0k + 1] * frk)
    # field-dependent astigmatism + extra blur (fold overlap / bubble)
    fr, fdir = task["field"]
    sr = ASTIG[0] * fr * fr
    stg = ASTIG[1] * fr * fr
    kr = kx * fdir[0] + ky * fdir[1]
    kt = -kx * fdir[1] + ky * fdir[0]
    se = task["extra_blur"]
    ast = np.exp(-2 * np.pi ** 2 * ((sr * sr + se * se) * kr * kr + (stg * stg + se * se) * kt * kt))
    If = sfft.irfft2(Ff * ast, s=(ny, nx)) * task.get("gain", 1.0)
    Is = sfft.irfft2(Fs * ast, s=(ny, nx)) * task.get("gain", 1.0)
    X, Y = np.meshgrid(xs, ys)
    xc, yc = task["cam"](X, Y)
    ill = np.clip(post_illum(xc, yc), 0.3, None)
    bg = BG_POST * task["bg_fac"] * (1 + 0.08 * smooth_field(rng, (ny, nx), 15.0 / px))
    if task.get("ring") is not None:
        Xb, rbp = task["ring"]
        rr = np.hypot(X - Xb[0], Y - Xb[1])
        bg = bg * (1 + BUBBLE["bg_ring"] * np.exp(-((rr - rbp) / (0.05 * rbp)) ** 2))
    ix = np.clip((xc / px).astype(int), 0, 2047)
    iy = np.clip((yc / px).astype(int), 0, 2047)
    prnu = fpn["prnu"][iy, ix]
    dsnu = fpn["dsnu"][iy, ix] + fpn["col"][ix]
    lam_f = np.clip(ill * (If + bg) * prnu, 0, None)
    lam_s = np.clip(ill * (Is + NPL * bg) * prnu, 0, None)
    imf = rng.poisson(lam_f) + rng.normal(0, READ_NOISE, lam_f.shape) + dsnu + CAM_OFFSET
    ims = rng.poisson(lam_s) + rng.normal(0, READ_NOISE * math.sqrt(NPL), lam_s.shape) + NPL * (dsnu + CAM_OFFSET)
    seg = ndi.gaussian_filter(imf.astype(float), 1.5)
    seg = seg - np.percentile(seg, 20)
    allow = ndi.binary_dilation(allow, iterations=int(round(2.0 / px)))
    fe = frontend_mask(seg, allow, x0, y0, px, 0.3 * task["lexp"])
    if fe is None:
        return None
    pr = profiles(imf, imf, fe, x0, y0, px, max(12.0, 2.2 * fe["width"]), 0.5, 151, img_extra=ims,
                  extra_rows_frac=0.7, extra_rows_max=251)
    out = dict(fe=fe, prof=pr)
    if task.get("debug"):
        out.update(img=dict(imf=imf, ims=ims, If=If, x0=x0, y0=y0))
    return out


def run_task(args):
    kind, task = args
    if kind == "pre":
        return render_pre(task, _G["fpn"])
    return render_post(task, _G["fpn"], _G["optics"])


_G = {}


def _init_worker():
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    _G["fpn"] = fpn_patterns()
    _G["optics"] = PostOptics()


# =====================================================================================
# 10. Building image comps for pre and post
# =====================================================================================

def pre_image_comps(obj, pm):
    """Stitched pre mosaic: every tile the object touches shows the whole object with that tile's offset,
    clipped to the tile's cell, so a seam produces a jump (gap or repeat), never a doubled intensity."""
    out = []
    for c in obj["comps"]:
        d = c["dens"]
        if d.get("rho_pre") is None:
            continue
        tiles = sorted(set(int(k) for k in pm.tile_of(c["pts"])))
        for k in tiles:
            ic = dict(pts=c["pts"] + pm.off[k], s=c["s"].copy(), hw=c["a"].copy(), hh=c["b"].copy(),
                      zc=c["b"].copy(), tile=k, clip=pm.cell(k) if len(tiles) > 1 else None)
            ic["rho"] = d["rho_pre_box"]
            ic["rs0"] = d["s0"]
            ic["rds"] = d["ds"]
            ic["B"] = c.get("Bpre_abs", PHASE_PER_UM * c.get("Bpre_fac", 1.0))
            if finalize(ic) is not None:
                out.append(ic)
    return out


def post_material_geometry(obj, world):
    """per material comp: reference post points + widths/heights/z + truth axial/transverse stretch"""
    flap = obj.get("flap", False)
    res = []
    for c in obj["comps"]:
        p = c["pts"]
        J = world.gm.jac(p)
        tv = unit(np.gradient(p, axis=0))
        nv = perp(tv)
        Jt = np.einsum("nij,nj->ni", J, tv)
        Jn = np.einsum("nij,nj->ni", J, nv)
        detJ = np.abs(np.linalg.det(J))
        Ez = np.sqrt(detJ)
        if flap:
            gh = np.zeros_like(p)
            lift = np.full(len(p), world.h_gel)
            sgn = -1.0
        else:
            gh = world.spec_grad(p)
            lift = world.spec_h(p)
            sgn = 1.0
        eax = np.sqrt(np.sum(Jt * Jt, 1) + np.sum(gh * tv, 1) ** 2)
        etr = c["aniso"] * np.sqrt(np.sum(Jn * Jn, 1) + np.sum(gh * nv, 1) ** 2)
        X = world.post_ref(p, flap)
        hw = c["a"] * c["aniso"] * np.linalg.norm(Jn, axis=1)
        mag, rdir = world.lens_stretch(world.G_flap(p) if flap else world.G(p))
        tpost = unit(np.einsum("nij,nj->ni", world.JG(p), nv))
        hw = hw * (1 + (mag - 1) * np.sum(tpost * rdir, 1) ** 2)
        hh = c["b"] * c["aniso"] * Ez
        zc = lift + sgn * hh
        res.append(dict(X=X, hw=hw, hh=hh, zc=zc, eax=eax, etr=etr, Ez=Ez, Jn=np.linalg.norm(Jn, axis=1)))
    return res


def post_image_comps(obj, geom, pmos, dfun, pivot):
    """apply tile split, drift (at each tile's time, about the pivot) and stage offsets -> image comps.
    Objects stuck to the glass (lint, bead chains) do not take part in the gel's drift."""
    out = []
    glass = bool(obj.get("on_glass"))
    for ci, (c, g) in enumerate(zip(obj["comps"], geom)):
        tiles = sorted(set(int(k) for k in pmos.tile_of(g["X"])))
        for k in tiles:
            f = 1.0 if glass else 1.0 + dfun(pmos.t[k])
            X = pivot + f * (g["X"] - pivot) + pmos.off[k]
            ic = dict(pts=X, s=c["s"].copy(), hw=g["hw"] * f, hh=g["hh"] * f, zc=g["zc"].copy(), tile=k,
                      mat_index=ci, clip=pmos.cell(k) if len(tiles) > 1 else None)
            d = c["dens"]
            ic["rho"] = d["rho_post_box"]
            ic["rs0"] = d["s0"]
            ic["rds"] = d["ds"]
            ic["B"] = B_POST * c.get("Bfac", 1.0) * obj.get("Bpost_fac", 1.0)
            if finalize(ic) is not None:
                out.append(ic)
    return out


# =====================================================================================
# 11. Main assembly
# =====================================================================================

def gen_ids(rng, n, used):
    alpha = np.array(list("abcdefghjkmnpqrstuvwxyz23456789"))
    out = []
    while len(out) < n:
        s = "".join(rng.choice(alpha, 10))
        if s not in used:
            used.add(s)
            out.append(s)
    return out


def r6(x, nd):
    return [round(float(v), nd) for v in x]


class _CamPre:
    def __init__(self, c):
        self.c = np.asarray(c)

    def __call__(self, X, Y):
        return X - (self.c[0] - FOV_PRE / 2), Y - (self.c[1] - FOV_PRE / 2)


class _CamPost:
    def __init__(self, c):
        self.c = np.asarray(c)

    def __call__(self, X, Y):
        return X - (self.c[0] - FOV_POST / 2), Y - (self.c[1] - FOV_POST / 2)


def aspect_model(rng, o, comps, fe, defocused):
    """Front-end's deconvolved height/width estimate from the post z-stack (parametric model, see README):
    true full height/width over the central 70 % of the measured length, widened in quadrature by the
    spread of the centreline in z (tilt) and across the sampling line (curvature), plus a residual PSF
    term and 5 % multiplicative noise (10 % if the object is out of focus)."""
    allz = np.concatenate([c["zc"] for c in comps])
    allhw = np.concatenate([c["hw"] for c in comps])
    allhh = np.concatenate([c["hh"] for c in comps])
    pts = np.concatenate([c["pts"] for c in comps])
    ct, st = math.cos(fe["th"]), math.sin(fe["th"])
    sp = (pts[:, 0] - fe["cx"]) * ct + (pts[:, 1] - fe["cy"]) * st
    npp = -(pts[:, 0] - fe["cx"]) * st + (pts[:, 1] - fe["cy"]) * ct
    sel = np.abs(sp) <= 0.35 * fe["length"]
    if sel.sum() < 2:
        sel = np.ones(len(sp), bool)
    H = 2 * float(np.median(allhh[sel]))
    if o["kind"] == "bundle_tight":
        Wd = float(np.max(npp[sel] + allhw[sel]) - np.min(npp[sel] - allhw[sel]))
        sig_n = 0.0
    else:
        Wd = 2 * float(np.median(allhw[sel]))
        sig_n = float(np.std(npp[sel]))
    sig_z = float(np.std(allz[sel]))
    Heff = math.sqrt(H * H + 12 * sig_z ** 2)
    Weff = math.sqrt(Wd * Wd + 12 * sig_n ** 2)
    Hm = math.sqrt(Heff ** 2 + (0.6 * 2.4) ** 2)
    Wm = math.sqrt(Weff ** 2 + (0.6 * PSF_POST_TOLD) ** 2)
    noise = 0.05 * (2.0 if defocused else 1.0)
    return float(Hm / Wm * math.exp(rng.normal(0, noise)))


def defect_polygons(world):
    nf, df = world.nf, world.df
    al = math.acos(df / R_TRUE)
    th = FOLD["theta"]
    arc = np.linspace(th - al, th + al, 40)
    flap = np.stack([R_TRUE * np.cos(arc), R_TRUE * np.sin(arc)], 1)
    # the overlap polygon includes the drape zone outside the flap edge (reflect a wider segment)
    Rd = R_TRUE + FOLD["drape"]
    ald = math.acos(df / Rd)
    arcd = np.linspace(th - ald, th + ald, 40)
    wide = np.stack([Rd * np.cos(arcd), Rd * np.sin(arcd)], 1)
    dl = wide @ nf - df
    ovl = clip_convex(wide - 2 * dl[:, None] * nf[None, :], circle_poly((0.0, 0.0), R_TRUE, 180))
    wk = WRINKLE
    k = np.array([math.cos(wk["ang"]), math.sin(wk["ang"])])
    kp = np.array([-k[1], k[0]])
    corners = np.array([[-1, -1], [1, -1], [1, 1], [-1, 1]], float) * [wk["hx"], wk["hy"]]
    rect = np.array(wk["c"]) + corners[:, :1] * k[None, :] + corners[:, 1:] * kp[None, :]
    return [
        dict(kind="fold", polygon_pre=flap),
        dict(kind="fold_overlap", polygon_pre=ovl),
        dict(kind="bubble", polygon_pre=circle_poly(BUBBLE["c"], BUBBLE["r"] * BUBBLE["poly_scale"])),
        dict(kind="curved", polygon_pre=ellipse_poly(CURVED["c"], CURVED["a"], CURVED["b"], CURVED["ang"])),
        dict(kind="bundled", polygon_pre=ellipse_poly(BUNDLE["c"], BUNDLE["a"], BUNDLE["b"], BUNDLE["ang"])),
        dict(kind="z_tilt", polygon_pre=rect),
        dict(kind="under_expansion", polygon_pre=circle_poly(UNDER["c"], UNDER["r_poly"])),
        dict(kind="over_expansion", polygon_pre=ellipse_poly(OVER["c"], OVER["poly_a"], OVER["poly_b"], OVER["ang"])),
    ]


def make_clock(rng, world, all_objs, geoms, post_mos, dfun, visible):
    """Re-imaged clock tile. Each visit: the stage returns with a repeatability error (common shift of all
    centroids), objects carry the drift at that time, anisotropic localisation noise that grows with
    photobleaching, objects touching the tile border are dropped (they come and go), 4 % go missing,
    0-2 transient extras appear. Objects stuck to the glass do not drift."""
    # the operator picks a crowded tile near the gel centre, away from visible defects
    polys = [d["polygon_pre"] for d in defect_polygons(world)]
    objpts = [(i, np.concatenate([gg["X"] for gg in geoms[i]])) for i in visible]
    best, kc = -1, None
    for k, C in enumerate(post_mos.cen):
        Pc = world.pre_of_post(C[None])
        if np.linalg.norm(Pc) > CLOCK_MAX_R:
            continue
        if min(float(dist_to_poly(Pc, p)[0]) for p in polys) < 150.0:
            continue
        n_in = sum(1 for i, pts in objpts if np.all(np.abs(pts - C) < FOV_POST / 2 - 5.0))
        if n_in > best:
            best, kc = n_in, k
    C = post_mos.cen[kc]
    S = np.diag(POST_STAGE_SCALE)
    stage_off = (C - np.array(POST_HOME)) @ S.T     # true stage position - commanded
    cands = []
    for i, pts in objpts:
        o = all_objs[i]
        w = np.concatenate([gg["hw"] for gg in geoms[i]])
        if np.all(np.abs(pts - C).max(1) > FOV_POST / 2 + 60):
            continue
        tdir = unit(pts[-1] - pts[0])
        cands.append((pts, w, tdir, bool(o.get("on_glass"))))
    visits = []
    for v, tv in enumerate(post_mos.visits):
        f = 1 + dfun(tv)
        e_v = rng.normal(0, CLOCK_VISIT_ERR, 2)
        lo = C + stage_off + e_v - FOV_POST / 2
        hi = C + stage_off + e_v + FOV_POST / 2
        objs = []
        for pts, w, tdir, glass in cands:
            Xt = pts if glass else world.pivot + f * (pts - world.pivot)
            # the front-end discards objects touching the tile border (they come and go with drift/stage error)
            inside = np.all((Xt >= lo + 1.0) & (Xt <= hi - 1.0), axis=1)
            if not inside.all():
                continue
            if rng.random() < 0.04:
                continue
            cen = np.sum(Xt[inside] * w[inside, None], 0) / np.sum(w[inside])
            rep = cen - stage_off - e_v
            sg = 1.10 ** v
            nv = np.array([-tdir[1], tdir[0]])
            rep = rep + tdir * rng.normal(0, 0.35 * sg) + nv * rng.normal(0, 0.08 * sg)
            objs.append({"x": round(float(rep[0]), 3), "y": round(float(rep[1]), 3)})
        for _ in range(int(rng.integers(0, 3))):
            q = C + rng.uniform(-FOV_POST / 2, FOV_POST / 2, 2)
            objs.append({"x": round(float(q[0]), 3), "y": round(float(q[1]), 3)})
        rng.shuffle(objs)
        visits.append({"t": round(float(tv), 2), "objects": objs})
    return visits, kc


def fmt_entry(oid, e, post):
    ang = round(float(e["angle"]) % math.pi, 6)
    if ang >= math.pi:          # rounding can land exactly on pi; the schema wants [0, pi)
        ang = 0.0
    out = {"id": oid, "x": round(float(e["x"]), 3), "y": round(float(e["y"]), 3),
           "angle": ang, "length": round(float(e["length"]), 3)}
    nd = 1 if post else 2
    out["axial"] = r6(e["axial"], nd)
    out["cross"] = r6(e["cross"], nd)
    out["cross_rows"] = int(e["cross_rows"])
    if post:
        out["zsum_cross"] = r6(e["zsum_cross"], 0)
        out["zsum_rows"] = int(e["zsum_rows"])
        out["zsum_planes"] = int(e["zsum_planes"])
        out["aspect"] = round(float(e["aspect"]), 4)
        out["tile"] = int(e["tile"])
        out["t"] = round(float(e["t"]), 2)
    return out


def build_index(ic_map, cell):
    grid = {}
    for comps in ic_map.values():
        for c in comps:
            x0, y0, x1, y1 = c["bbox"]
            for a in range(int(math.floor(x0 / cell)), int(math.floor(x1 / cell)) + 1):
                for b in range(int(math.floor(y0 / cell)), int(math.floor(y1 / cell)) + 1):
                    grid.setdefault((a, b), []).append(c)
    return grid


def neighbours(grid, cell, own, box):
    x0, y0, x1, y1 = box
    out, seen = [], set()
    for a in range(int(math.floor(x0 / cell)), int(math.floor(x1 / cell)) + 1):
        for b in range(int(math.floor(y0 / cell)), int(math.floor(y1 / cell)) + 1):
            for c in grid.get((a, b), ()):
                k = id(c)
                if k in seen or k in own:
                    continue
                seen.add(k)
                bx = c["bbox"]
                if bx[2] < x0 or bx[0] > x1 or bx[3] < y0 or bx[1] > y1:
                    continue
                out.append(c)
    return out


def build_scene(args):
    """everything up to the list of render tasks; returns the state as a dict"""
    T0 = time.time()

    # ---------------- world, overview camera ----------------
    world = World(rng_for(1))
    angs = np.linspace(0, 2 * np.pi, 720, endpoint=False)
    rim = R_TRUE * np.stack([np.cos(angs), np.sin(angs)], 1)
    rim_main = rim[~world.in_flap(rim)]
    Xr = world.G(rim_main)
    X0 = world.G(np.zeros((1, 2)))[0]
    r_post_edge = float(np.linalg.norm(Xr - X0, axis=1).mean())
    t_ref_guess = 13.0
    e_macro = (r_post_edge * (1 + swell_raw(T_OVERVIEW)) / (1 + swell_raw(t_ref_guess)) / R_NOMINAL
               * (1 + E_MACRO_CAM_ERR))
    center_told = X0 + rng_for(2).normal(0, CENTER_ERR_SD, 2)

    # ---------------- population ----------------
    t1 = time.time()
    fibs, placer, nfail = make_population(rng_for(3), world)
    pre_deb = make_pre_debris(rng_for(4), placer, N_PRE_DEBRIS)
    post_deb = make_debris(rng_for(5), world, placer, N_POST_DEBRIS)
    print(f"population: {len(fibs)} fibril objects ({nfail} rejected candidates), {len(pre_deb)} pre debris, "
          f"{len(post_deb)} post debris  [{time.time() - t1:.1f}s]", flush=True)
    brng = rng_for(6)
    for o in fibs + post_deb:
        o["Bpost_fac"] = float(np.exp(brng.normal(0, 0.3)))
        for c in o["comps"]:
            c.setdefault("Bpre_fac", float(brng.uniform(0.85, 1.15)))
    for o in fibs:
        allp = np.concatenate([c["pts"] for c in o["comps"]])
        dl = world.delta_fold(allp)
        o["flap"] = bool(np.all(dl > 0))
        o["crease"] = bool(np.any(np.abs(dl) < FOLD["crease_lost"]) or (np.any(dl > 0) and np.any(dl < 0)))

    # ---------------- mosaics and timeline ----------------
    pmos_pre = PreMosaic(rng_for(7))
    post_mos = PostMosaic(rng_for(8), world, center_told, e_macro)
    t_ref = float(post_mos.t_ref)

    def dfun(t):
        return float((1 + swell_raw(t)) / (1 + swell_raw(t_ref)) - 1)

    dts = np.linspace(0, post_mos.t_end, 400)
    dd = np.array([dfun(t) for t in dts])
    print(f"post mosaic: {len(post_mos.cells)} tiles, scan {post_mos.t_end / 3600:.2f} h, {len(post_mos.visits)} "
          f"clock visits, drift range {dd.min() * 100:+.3f}..{dd.max() * 100:+.3f} %, end {dd[-1] * 100:+.3f} %; "
          f"e_macro={e_macro:.4f}", flush=True)

    # ---------------- losses before imaging ----------------
    all_objs = fibs + pre_deb + post_deb
    r_loss = rng_for(9)
    for o in all_objs:
        o["lost_reason"] = None
    for o in fibs:
        if o["crease"]:
            o["lost_reason"] = "fold_crease"
        elif r_loss.random() < P_WASHED:
            o["lost_reason"] = "detached"

    # ---------------- densities and post geometry ----------------
    for o in all_objs:
        for c in o["comps"]:
            d = c["dens"]
            if d.get("rho_pre") is not None:
                d["rho_pre_box"] = box_avg(d["rho_pre"], d["ds"], PX_PRE)
    geoms = {}
    for i, o in enumerate(all_objs):
        if o["kind"].startswith("pre_"):
            continue
        if o.get("native"):
            c = o["comps"][0]
            X = c["pts"].copy()
            hh = c["b"].copy()
            P = world.pre_of_post(X)
            if o.get("on_glass"):
                base = np.zeros(len(X)) + rng_for(10, i).uniform(0, 1.0)
            else:
                base = world.spec_h(P)
            geoms[i] = [dict(X=X, hw=c["a"].copy(), hh=hh, zc=base + hh, eax=None, etr=None, Ez=None, Jn=None)]
            c["dens"]["rho_post_box"] = box_avg(c["dens"]["rho_post"], c["dens"]["ds"], PX_POST)
        else:
            g = post_material_geometry(o, world)
            geoms[i] = g
            for c, gg in zip(o["comps"], g):
                c["dens"]["rho_post_box"] = box_avg(c["dens"]["rho_post"], c["dens"]["ds"],
                                                    PX_POST / float(np.mean(gg["eax"])))
    # truth expansion per fibril object
    for i, o in enumerate(fibs):
        g = geoms[i]
        mains = [k for k, c in enumerate(o["comps"]) if not c["strand"]]
        o["E_ax"] = float(np.mean(np.concatenate([g[k]["eax"] for k in mains])))
        if o["kind"].startswith("bundle"):
            ws_pre, ws_post, jns = 0.0, 0.0, []
            for mi in o["members"]:
                c = o["comps"][mi[0]]
                k = len(c["pts"]) // 2
                ws_pre += 2 * c["a"][k]
                ws_post += 2 * c["a"][k] * c["aniso"] * g[mi[0]]["Jn"][k]
                jns.append(g[mi[0]]["Jn"][k])
            gp = float(np.sum(o["gaps"]))
            o["E_tr"] = float((ws_post + gp * np.mean(jns)) / (ws_pre + gp))
        else:
            o["E_tr"] = float(np.mean(g[mains[0]]["etr"]))

    # ---------------- image components ----------------
    pre_ic = {i: pre_image_comps(o, pmos_pre) for i, o in enumerate(all_objs) if o.get("pre_visible")}
    post_ic, post_units = {}, []
    for i, o in enumerate(all_objs):
        if o["kind"].startswith("pre_") or o["lost_reason"] is not None:
            continue
        post_ic[i] = post_image_comps(o, geoms[i], post_mos, dfun, world.pivot)
        if o["kind"] == "bundle_loose":
            post_units += [(i, tuple(m)) for m in o["members"]]
        else:
            post_units.append((i, None))
    gpre, cpre = build_index(pre_ic, 40.0), 40.0
    gpost, cpost = build_index(post_ic, 150.0), 150.0
    print(f"geometry done  [{time.time() - T0:.1f}s]", flush=True)

    # ---------------- render tasks ----------------
    quick = args.quick if args.quick and args.quick > 1 else 1
    tasks, meta = [], []
    lost_post = {}
    for n_i, (i, comps) in enumerate(pre_ic.items()):
        if quick > 1 and n_i % quick:
            continue
        if not comps:
            continue
        o = all_objs[i]
        bb = np.array([c["bbox"] for c in comps])
        W = 2 * max(float(c["hw"].max()) for c in comps)
        if o["kind"].startswith("bundle"):
            W = sum(o["widths"]) + sum(o["gaps"])
        mg = max(3.5, 2.6 * W) + 1.5
        box = (bb[:, 0].min() - mg, bb[:, 1].min() - mg, bb[:, 2].max() + mg, bb[:, 3].max() + mg)
        nb = neighbours(gpre, cpre, {id(c) for c in comps}, box)
        allpts = np.concatenate([c["pts"] for c in comps])
        k = int(pmos_pre.tile_of(allpts.mean(0)[None])[0])
        task = dict(target=comps, neigh=nb, seed=i, wexp=W, lexp=float(np.ptp(allpts @ comps[0]["eu"])),
                    tile=k, focus=float(pmos_pre.focus[k]), dpc_off=pmos_pre.dpc_tile[k],
                    cam=_CamPre(pmos_pre.cen[k]))
        tasks.append(("pre", task))
        meta.append(("pre", i, None))
    for n_i, (i, um) in enumerate(post_units):
        if quick > 1 and n_i % quick:
            continue
        o = all_objs[i]
        comps = post_ic[i] if um is None else [c for c in post_ic[i] if c["mat_index"] in um]
        if not comps:
            lost_post[(i, um)] = "not_segmented"
            continue
        bb = np.array([c["bbox"] for c in comps])
        W = 2 * max(float(c["hw"].max()) for c in comps)
        if o["kind"] == "bundle_tight":
            W *= 1.1 * len(o["members"])
        mg = max(16.0, 2.6 * W) + 6.0
        box = (bb[:, 0].min() - mg, bb[:, 1].min() - mg, bb[:, 2].max() + mg, bb[:, 3].max() + mg)
        nb = neighbours(gpost, cpost, {id(c) for c in comps}, box)
        allpts = np.concatenate([c["pts"] for c in comps])
        cen = allpts.mean(0)
        k = int(post_mos.tile_of(cen[None])[0])
        zmid = float(np.median(np.concatenate([c["zc"] for c in comps])))
        half = (NPL - 1) / 2 * DZ_PL
        if abs(zmid - post_mos.zaf[k]) - half > 5.0:
            lost_post[(i, um)] = "out_of_focus"
            continue
        planes = post_mos.zaf[k] + (np.arange(NPL) - (NPL - 1) / 2) * DZ_PL
        zf = float(planes[np.argmin(np.abs(planes - zmid))])
        oc = np.array([FOV_POST / 2 + 15.0, FOV_POST / 2 - 10.0])
        fv = cen - (post_mos.cen[k] - FOV_POST / 2) - oc
        fr = min(1.0, float(np.linalg.norm(fv)) / (FOV_POST / math.sqrt(2)))
        fdir = unit(fv) if np.linalg.norm(fv) > 1e-6 else np.array([1.0, 0.0])
        Ppre = world.pre_of_post(cen[None])
        extra, bgf, ring = 0.0, 1.0, None
        if world.in_overlap(Ppre)[0] or o.get("flap"):
            extra, bgf = 0.15, 1.25
        rb = float(np.linalg.norm(cen - world.Xb)) / world.rb_post
        gain = 1.0
        if rb < 1.3:
            # imaging through the air dome: strong aberration blur inside, meniscus blur at the rim,
            # reflection losses at the air/gel interfaces, bright scattering ring
            core = BUBBLE["blur_core"] if rb < 0.95 else 0.0
            extra = max(extra, core, BUBBLE["blur_extra"] * math.exp(-((rb - 0.9) / 0.15) ** 2))
            ring = (world.Xb, world.rb_post)
            if rb < 1.0:
                gain = BUBBLE["gain_core"]
        task = dict(target=comps, neigh=nb, seed=100000 + n_i, wexp=W, lexp=float(np.ptp(allpts @ comps[0]["eu"])),
                    zf=zf, zaf=float(post_mos.zaf[k]), field=(fr, fdir), extra_blur=extra, bg_fac=bgf, ring=ring, gain=gain,
                    cam=_CamPost(post_mos.cen[k]))
        tasks.append(("post", task))
        meta.append(("post", i, um))
    print(f"{len(tasks)} render tasks  [{time.time() - T0:.1f}s]", flush=True)
    return dict(locals())


def render_all(S, nw):
    tasks = S["tasks"]
    t2 = time.time()
    if nw == 1:
        _init_worker()
        results = [run_task(tk) for tk in tasks]
    else:
        import multiprocessing as mp
        with mp.get_context("spawn").Pool(nw, initializer=_init_worker) as pool:
            results = pool.map(run_task, tasks, chunksize=2)
    print(f"rendered {len(tasks)} objects with {nw} workers  [{time.time() - t2:.1f}s]", flush=True)
    return results


def write_gz(path, obj):
    """gzip JSON with no time stamp and no stored file name in its header (added 2026-10-10), so two runs give
    byte-identical .json.gz files, not only identical JSON."""
    with open(path, "wb") as raw, gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as gz, \
            io.TextIOWrapper(gz, encoding="utf-8", newline="\n") as f:
        json.dump(obj, f, separators=(",", ":"))


def assemble_all(S, results, write=True):
    """turn rendered measurements into obs/truth dicts (and write them)"""
    args, world, all_objs, fibs = S["args"], S["world"], S["all_objs"], S["fibs"]
    tasks, meta, lost_post = S["tasks"], S["meta"], S["lost_post"]
    post_mos, geoms, post_ic, dfun = S["post_mos"], S["geoms"], S["post_ic"], S["dfun"]
    t_ref, e_macro, center_told, X0, dd, T0 = S["t_ref"], S["e_macro"], S["center_told"], S["X0"], S["dd"], S["T0"]
    asp_rng = rng_for(21)
    pre_entries, post_entries = {}, []
    n_pre_fail = 0
    for (kind, task), res, (mk, i, um) in zip(tasks, results, meta):
        o = all_objs[i]
        if kind == "pre":
            if res is None:
                n_pre_fail += 1
                continue
            fe, pr = res["fe"], res["prof"]
            pre_entries[i] = dict(x=fe["cx"], y=fe["cy"], angle=fe["th"], length=fe["length"], axial=pr["axial"],
                                  cross=pr["cross"], cross_rows=pr["cross_rows"], fe=fe, pr=pr)
        else:
            if res is None:
                lost_post[(i, um)] = "not_segmented"
                continue
            fe, pr = res["fe"], res["prof"]
            k = int(post_mos.tile_of(np.array([[fe["cx"], fe["cy"]]]))[0])
            zmid = float(np.median(np.concatenate([c["zc"] for c in task["target"]])))
            asp = aspect_model(asp_rng, o, task["target"], fe, abs(zmid - task["zf"]) > 1.0)
            post_entries.append((i, um, dict(x=fe["cx"], y=fe["cy"], angle=fe["th"], length=fe["length"],
                                             axial=pr["axial"], cross=pr["cross"], cross_rows=pr["cross_rows"],
                                             zsum_cross=pr["zsum_cross"], zsum_rows=pr["zsum_rows"],
                                             zsum_planes=NPL, aspect=asp, tile=k, t=float(post_mos.t[k]))))
    pre_keys = list(pre_entries.keys())
    ids = gen_ids(rng_for(20), len(pre_keys) + len(post_entries), set())
    pre_ids = {i: ids[q] for q, i in enumerate(pre_keys)}
    post_ids = ids[len(pre_keys):]
    by_obj = {}
    for (i, um, e), qid in zip(post_entries, post_ids):
        by_obj.setdefault(i, []).append((um, e, qid))
    pairs, pairs_alt, split_members, truth_f = {}, {}, [], {}
    for i in pre_keys:
        o = all_objs[i]
        pid = pre_ids[i]
        lst = by_obj.get(i, [])
        partner, alts = None, []
        if lst and not o["kind"].startswith("pre_"):
            if o["kind"] == "bundle_loose":
                best, bw = None, -1.0
                for um, e, qid in lst:
                    w = sum(o["comps"][m].get("w", 0.0) for m in um)
                    if w > bw:
                        best, bw = qid, w
                partner = best
                alts = [qid for um, e, qid in lst]
                split_members += [qid for um, e, qid in lst if qid != best]
            else:
                partner = lst[0][2]
        pairs[pid] = partner
        if len(alts) > 1:
            pairs_alt[pid] = alts
        mains = [c for c in o["comps"] if not c.get("strand")]
        cen = np.concatenate([c["pts"] for c in mains]).mean(0)
        tf = dict(kind=o["kind"], x=round(float(cen[0]), 3), y=round(float(cen[1]), 3))
        if "E_ax" in o:
            tf.update(E_ax=round(o["E_ax"], 6), E_tr=round(o["E_tr"], 6),
                      anisotropy=round(o["E_tr"] / o["E_ax"] - 1, 6),
                      sl_pre=round(float(np.mean([c["dens"]["sl_mean"] for c in mains])), 4),
                      width_pre=round(float(np.mean([c["w"] for c in mains])), 3),
                      length_pre=round(float(np.max([c["L"] for c in mains])), 2),
                      shape=mains[0].get("shape"), n_members=len(o.get("members", [0])))
        else:
            tf.update(E_ax=None, E_tr=None)
        if partner is not None:
            e = [e for um, e, qid in lst if qid == partner][0]
            g = geoms[i]
            Xr = np.concatenate([gg["X"] for c, gg in zip(o["comps"], g) if not c.get("strand")]).mean(0)
            tf.update(E_ax_acq=round(o["E_ax"] * (1 + dfun(e["t"])), 6), t=round(e["t"], 2), tile=e["tile"],
                      drift_at_t=round(dfun(e["t"]), 6), x_post_ref=round(float(Xr[0]), 3),
                      y_post_ref=round(float(Xr[1]), 3))
        else:
            if o["kind"].startswith("pre_"):
                tf["lost_reason"] = "pre_only_debris"
            elif o["lost_reason"] is not None:
                tf["lost_reason"] = o["lost_reason"]
            else:
                rs = [lost_post.get((i, um)) for um in ([None] if "members" not in o else
                                                        [tuple(m) for m in o["members"]] + [None])]
                rs = [r for r in rs if r]
                tf["lost_reason"] = rs[0] if rs else "not_segmented"
            if o.get("E_ax") is not None:
                tf["E_ax_acq"] = None
        truth_f[pid] = tf
    debris, debris_kind = [], {}
    for (i, um, e), qid in zip(post_entries, post_ids):
        if i not in pre_ids:
            debris.append(qid)
            debris_kind[qid] = all_objs[i]["kind"] if all_objs[i]["kind"].startswith("deb_") else \
                "fibril_missed_in_pre"
    defects = defect_polygons(world)
    for pid, tf in truth_f.items():
        regs = [d["kind"] for d in defects if in_poly(np.array([[tf["x"], tf["y"]]]), d["polygon_pre"])[0]]
        tf["region"] = regs[0] if regs else None
    visible = [i for i in post_ic if (i, None) not in lost_post]
    clock, clock_tile = make_clock(rng_for(30), world, all_objs, geoms, post_mos, dfun, visible)
    an_clean, an_all = [], []
    for pid, tf in truth_f.items():
        if tf.get("E_ax") is None or pairs[pid] is None or tf["kind"].startswith("bundle"):
            continue
        an_all.append(tf["anisotropy"])
        if tf["region"] is None:
            an_clean.append(tf["anisotropy"])
    aniso_true = float(np.mean(an_clean))
    eax_paired = [tf["E_ax"] for p, tf in truth_f.items() if pairs[p] is not None and tf["E_ax"] is not None]

    # ---------------- write ----------------
    pre_list = [fmt_entry(pre_ids[i], pre_entries[i], post=False) for i in pre_keys]
    post_list = [fmt_entry(qid, e, post=True) for (i, um, e), qid in zip(post_entries, post_ids)]
    sh = rng_for(40)
    sh.shuffle(pre_list)
    sh.shuffle(post_list)
    meta_obs = dict(e_macro=round(e_macro, 5), px_pre_um=PX_PRE, px_post_um=PX_POST, psf_pre_fwhm_um=PSF_PRE_TOLD,
                    psf_post_fwhm_um=PSF_POST_TOLD, dof_post_um=DOF_TOLD, pre_mode="dpc",
                    gel_center_post_um=[round(float(center_told[0]), 2), round(float(center_told[1]), 2)],
                    gel_radius_pre_um=R_NOMINAL, mirror_possible=True, gel_center_pre_um=[0.0, 0.0],
                    intensity_units=("pre: two-axis DPC asymmetry x1000 (signed); axial = phase-gradient component "
                                     "along the object axis (+ direction), cross = component along angle+pi/2. "
                                     "post: photo-electrons including camera offset and background"),
                    post_axial_plane="in-focus (mid-height) plane at the centroid, the same plane as cross",
                    post_zstack=dict(planes=NPL, spacing_um=DZ_PL),
                    post_tile_fov_um=FOV_POST, post_tile_step_um=STEP_POST, post_tiles=len(post_mos.cells),
                    clock_tile=int(clock_tile), pre_tile_fov_um=FOV_PRE, generator="software/redteam/s3_gen.py",
                    seed=SEED)
    obs = {"schema": "swell-obs/1", "gel_id": GEL_ID, "meta": meta_obs, "pre": pre_list, "post": post_list,
           "clock": clock}
    counts = dict(pre=len(pre_list), post=len(post_list),
                  paired=sum(1 for v in pairs.values() if v is not None),
                  lost=sum(1 for p, v in pairs.items() if v is None and truth_f[p]["E_ax"] is not None),
                  pre_debris=sum(1 for p in pairs if truth_f[p]["E_ax"] is None),
                  debris=len(debris), split_members=len(split_members), pre_render_failures=n_pre_fail,
                  clock_visits=len(clock), clock_objects=[len(v["objects"]) for v in clock])
    lost_reasons = {}
    for p, v in pairs.items():
        if v is None:
            r = truth_f[p].get("lost_reason")
            lost_reasons[r] = lost_reasons.get(r, 0) + 1
    counts["lost_reasons"] = lost_reasons
    kinds = {}
    for tf in truth_f.values():
        kinds[tf["kind"]] = kinds.get(tf["kind"], 0) + 1
    counts["pre_kinds"] = kinds
    dk = {}
    for v in debris_kind.values():
        dk[v] = dk.get(v, 0) + 1
    counts["debris_kinds"] = dk
    gel_mean = float(np.mean(eax_paired))
    notes = build_notes(counts, dd, e_macro, gel_mean, aniso_true, post_mos, t_ref)
    truth = {"schema": "swell-truth/1", "gel_id": GEL_ID, "pairs": pairs, "debris": debris, "fibrils": truth_f,
             "defects": [dict(kind=d["kind"], polygon_pre=[[round(float(a), 2), round(float(b), 2)]
                                                           for a, b in d["polygon_pre"]]) for d in defects],
             "anisotropy_true": round(aniso_true, 6),
             "anisotropy_definition": "mean over paired single (non-bundle) fibrils whose centroid lies outside all "
                                      "defect polygons of (E_tr / E_ax - 1); negative = fibrils expand less across",
             "anisotropy_detail": dict(all_paired_singles=round(float(np.mean(an_all)), 6),
                                       clean_sd=round(float(np.std(an_clean)), 6), n_clean=len(an_clean),
                                       intrinsic_a0=ANISO_A0, intrinsic_per_um_width=ANISO_KW,
                                       intrinsic_sd=ANISO_SD, gel_inplane_aniso_amp=EPS_ANISO,
                                       gel_inplane_aniso_axis_pre_rad=TH_ANISO),
             "pairs_alt": pairs_alt, "split_members": split_members, "debris_kind": debris_kind,
             "gel_R_pre": R_NOMINAL, "gel_center_pre": [0.0, 0.0],
             "E_ax_gel_mean_paired": round(gel_mean, 6),
             "E_ax_gel_median_paired": round(float(np.median(eax_paired)), 6),
             "transform": dict(scale_E0=E0, rotation=ROT, mirror=MIRROR,
                               translation=[float(world.c[0]), float(world.c[1])],
                               convention="post = translation + R(rotation) @ diag(1,-1) @ phi(pre), phi ~ E0 (I + strain)",
                               drift_pivot_post=[float(world.pivot[0]), float(world.pivot[1])]),
             "drift": dict(t_ref=round(t_ref, 2), params=DRIFT, visits=[round(float(v), 2) for v in post_mos.visits],
                           d_at_visits=[round(dfun(v), 6) for v in post_mos.visits], t_end=round(post_mos.t_end, 1),
                           d_end=round(dfun(post_mos.t_end), 6), d_min=round(float(dd.min()), 6),
                           d_max=round(float(dd.max()), 6),
                           formula="d(t) = (1+S(t))/(1+S(t_ref)) - 1; S(t) = A1(1-exp(-t/tau1)) + "
                                   "A2 sin(2 pi t/P2 + ph2) + A3 sign(t)|t/T3|^3"),
             "meta_truth": dict(e_macro_told=round(e_macro, 6), e_macro_err_vs_gel_mean=round(e_macro / gel_mean - 1, 6),
                                gel_center_post_true=[float(X0[0]), float(X0[1])],
                                psf_pre_true_core_fwhm=PRE_CORE_FWHM, psf_post_true_core_fwhm=POST_CORE_FWHM,
                                gel_radius_pre_true=R_TRUE),
             "counts": counts, "notes": notes}
    if write:
        os.makedirs(args.out, exist_ok=True)
        write_gz(os.path.join(args.out, "obs.json.gz"), obs)
        write_gz(os.path.join(args.out, "truth.json.gz"), truth)
    print(json.dumps(counts))
    print(f"gel-mean E_ax (paired) {gel_mean:.4f}; e_macro error {100 * (e_macro / gel_mean - 1):+.2f} %; "
          f"anisotropy_true {aniso_true:+.5f}")
    print(f"total {time.time() - T0:.1f}s", flush=True)
    return obs, truth


def main():
    ap = argparse.ArgumentParser(description="S3 red-team synthetic gel generator (swell-obs/1)")
    ap.add_argument("--out", default=DEFAULT_OUT)
    ap.add_argument("--workers", type=int, default=0, help="worker processes for rendering (0 = auto)")
    ap.add_argument("--quick", type=int, default=0, help="development only: render every Nth object")
    args = ap.parse_args()
    S = build_scene(args)
    nw = args.workers if args.workers > 0 else max(1, min(12, (os.cpu_count() or 2) - 2))
    results = render_all(S, nw)
    assemble_all(S, results)


def build_notes(counts, dd, e_macro, gel_mean, aniso_true, post_mos, t_ref):
    return (
        "S3 red-team gel (software/redteam/s3_gen.py; full description in software/redteam/README.md). "
        f"Counts: {json.dumps(counts)}. "
        "Transform: rotation 2.4517 rad, mirror (diag(1,-1) before rotation), translation = true gel centre "
        f"{C_POST}; e_macro told {e_macro:.4f} vs paired gel-mean E_ax {gel_mean:.4f} "
        f"({100 * (e_macro / gel_mean - 1):+.2f} %: punch 747 vs nominal 750 um, overview picture 5 min before the "
        "scan while the gel still swelled, edge expands more than the mean, +0.15 % camera calibration). gel_center_post told with 30 um/axis error. "
        "Deformation: E0 4.383; radial edge dilatation 2*0.006*(r/R)^2; gel in-plane anisotropy +-0.3 % about 30 deg; "
        "random smooth strain 0.2 % rms (48 modes, 150-600 um); under-expansion Gaussian dilatation source at (-60,120) "
        "(-4 % linear at centre, sigma 40 um); over-expansion line of 5 sources at (60,470) (+2.5 %, sigma 30 um, "
        "axis -35 deg). Fold: gel edge beyond the chord n.p = 600 um (n at 205 deg) tucked UNDER the gel when it was "
        "flipped onto the coverslip: flap fibrils are reflected about the crease and lie face to face with the main "
        "layer (both in focus, lifted one gel thickness; the main gel drapes back to the glass over 60 um outside the flap edge); fibrils within 10 um of the crease are destroyed, a 4 % "
        "compressive crease strain decays over 12 um (true strain, in E_ax truth). Bubble: air dome under the gel "
        "at (380,330), radius 90 um pre, 20 um high: the core is lifted (out of the z-stack -> lost unless the tile's "
        "autofocus follows it); seen through air the core is demagnified (diverging lens, -4 % at the centre to +8 % "
        "radial at the rim), blurred (1.2 um extra sigma) and dimmed (x0.6); the rim has a 3 um meniscus "
        "displacement bump (+-4 % radial stretch), 0.9 um extra blur and a bright background ring. Curved region (-377,227): C arcs (bend 0.5-1.5 rad), S shapes, kinks; the "
        "front-end samples a straight line through the centroid. Bundled region (-91,-430): 2-3 parallel fibrils, "
        "independent phases, sarcomere lengths differing by ~2.5 % sd; tight bundles (gap <0.12 um) are one object "
        "in pre and post, loose bundles (gap 0.25-0.6 um) are one object in pre but split into members in post "
        "(pairs = widest member, pairs_alt = all members, the rest listed as split_members). Z-tilt region "
        "(417,-169): the gel surface buckled into wrinkles (wavelength 45 um pre, 10 um amplitude post, slopes up "
        "to ~18 deg) because it swelled more there: projected positions are unchanged but true 3-D E_ax and E_tr "
        "are larger by sqrt(1+(slope.t)^2); fibrils near crests/troughs leave the z-stack. Drift during the "
        f"{post_mos.t_end / 3600:.2f} h scan about a pivot, range {100 * dd.min():+.3f}..{100 * dd.max():+.3f} %, "
        f"end {100 * dd[-1]:+.3f} % (saturating swell + 42 min thermal oscillation - cubic shrink), reference = "
        f"first clock visit t={t_ref:.1f} s; clock tile = most crowded tile within 350 um of the centre and >150 um "
        "from defects, visited every 50 tiles, stage-return error 1 um, localisation "
        "noise 0.35 um along/0.08 um across growing 10 %/visit (bleaching), objects touching the tile border dropped, 4 % missing, 0-2 "
        "extras, glass-stuck debris that does not drift. Imaging: pre two-axis DPC, Airy core 0.44 um (told 0.40) + "
        "8 % Lorentzian halo, per-tile defocus, DPC offsets and fixed pattern, illumination fall-off; post widefield "
        "z-stack 21 x 0.75 um, Airy core 0.43 um (told 0.42) + 5 % halo, geometric defocus, field astigmatism "
        "(up to 0.2 um sigma tangential at tile corners), vignetting 24 %, background structure, Poisson + 2 e- read "
        "+ PRNU/DSNU/column/hot pixels, per-tile autofocus error 0.4 um, stage scale errors (+0.08 %, -0.05 %), tile "
        "repeatability 0.35 um, stitching seams (objects crossing tiles carry both tiles' drift and offsets). "
        "Biology: SL 1.72 +- 0.065 um per fibril, AR(1) 1 % within, 0.022 um jitter, A-band 1.60, thin 1.05, "
        "Z 0.07-0.11 um, M-line, Z stains 1.25x brighter post; ends clean/frayed (side strands)/damaged "
        "(over-stretched or contracted sarcomeres); intrinsic transverse factor a = -1.0 % - 1.0 %/um*(d-1.05) "
        f"+- 0.4 %; anisotropy_true {aniso_true:+.5f}. Lost: {counts.get('lost_reasons')}. "
        f"Debris kinds: {counts.get('debris_kinds')}."
    )


if __name__ == "__main__":
    main()
