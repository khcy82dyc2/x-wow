#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Score a SWELL ruler result (swell-result/1) against the S3 red-team truth (swell-truth/1).

    python software/redteam/score_s3.py RESULT.json[.gz]
        [--truth data/sim/S3/truth.json.gz] [--out data/sim/S3/score.json]
    python software/redteam/score_s3.py --selftest

Writes score.json (every number below) and prints a short markdown table. Scores only what the schema
promises; anything the result does not provide is reported as "not provided" instead of failing.
--selftest scores an in-memory oracle result (must be perfect) and an empty result (must not crash);
it writes nothing.
"""
import argparse
import gzip
import json
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.normpath(os.path.join(HERE, "..", "..", "data", "sim", "S3"))
NP = "not provided"


# ----------------------------------------------------------------------------- io
def load(path):
    op = gzip.open if str(path).endswith(".gz") else open
    with op(path, "rt", encoding="utf-8") as f:
        return json.load(f)


def fnum(v):
    """float or None (never raises)"""
    try:
        if v is None or isinstance(v, bool):
            return None
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None


def rnd(x, n=6):
    if x is None or isinstance(x, str):
        return x
    if isinstance(x, (bool, np.bool_)):
        return bool(x)
    if isinstance(x, (int, np.integer)):
        return int(x)
    x = float(x)
    return round(x, n) if math.isfinite(x) else None


# ----------------------------------------------------------------------------- geometry
def in_poly(pts, poly):
    from matplotlib.path import Path
    return Path(np.asarray(poly, float)).contains_points(np.atleast_2d(pts))


def dist_to_poly(pts, poly):
    pts = np.atleast_2d(np.asarray(pts, float))
    A = np.asarray(poly, float)
    B = np.roll(A, -1, axis=0)
    AB = B - A
    AP = pts[:, None, :] - A[None]
    t = np.clip(np.sum(AP * AB[None], 2) / np.maximum(np.sum(AB * AB, 1), 1e-12)[None], 0, 1)
    d = np.sqrt(np.sum((AP - t[..., None] * AB[None]) ** 2, 2)).min(1)
    return np.where(in_poly(pts, A), 0.0, d)


# ----------------------------------------------------------------------------- metrics
def stats(r):
    r = np.asarray([x for x in r if x is not None and math.isfinite(x)], float)
    if r.size == 0:
        return dict(n=0)
    return dict(n=int(r.size), mean=rnd(r.mean()), sd=rnd(r.std(ddof=1) if r.size > 1 else 0.0),
                rms=rnd(math.sqrt(np.mean(r * r))), median=rnd(np.median(r)),
                robust_sd=rnd(1.4826 * np.median(np.abs(r - np.median(r)))),
                frac_beyond_2pct=rnd(np.mean(np.abs(r) > 0.02)), median_abs=rnd(np.median(np.abs(r))))


def ols(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    if x.size < 3 or np.ptp(x) == 0:
        return None, None
    X = np.stack([np.ones_like(x), x], 1)
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    res = y - X @ beta
    s2 = np.sum(res ** 2) / max(x.size - 2, 1)
    cov = s2 * np.linalg.inv(X.T @ X)
    return float(beta[1]), float(math.sqrt(cov[1, 1]))


ANISO_EST_KEYS = ["estimate", "value", "anisotropy", "est", "a", "delta", "mean", "median", "point",
                  "tr_over_ax_minus_1", "E_tr_over_E_ax_minus_1", "ratio_minus_1", "a_hat", "aniso"]
ANISO_SE_KEYS = ["se", "stderr", "std_err", "sigma", "sd", "err", "error", "uncertainty"]
ANISO_DEF_KEYS = ["definition", "def", "convention", "formula", "meaning", "notes", "note", "description"]
ANISO_CALL_KEYS = ["call", "verdict", "decision", "significant", "anisotropic", "isotropic", "detected", "flag",
                   "result", "conclusion"]


def find_ci(d):
    for k in ("ci", "ci95", "ci_95", "interval", "ci95_pct", "confidence_interval", "range"):
        v = d.get(k)
        if isinstance(v, (list, tuple)) and len(v) == 2 and fnum(v[0]) is not None and fnum(v[1]) is not None:
            return sorted([fnum(v[0]), fnum(v[1])]), k
        if isinstance(v, dict):
            sub = find_ci(v)
            if sub[0] is not None:
                return sub
    pairs = [("ci_lo", "ci_hi"), ("lo", "hi"), ("lower", "upper"), ("low", "high"), ("ci95_lo", "ci95_hi"),
             ("ci_low", "ci_high"), ("ci_lower", "ci_upper"), ("lo95", "hi95"), ("min", "max")]
    for a, b in pairs:
        if fnum(d.get(a)) is not None and fnum(d.get(b)) is not None:
            return sorted([fnum(d[a]), fnum(d[b])]), f"{a}/{b}"
    return None, None


def score_anisotropy(res_gel, truth):
    out = dict(truth=truth.get("anisotropy_true"), truth_definition=truth.get("anisotropy_definition"))
    a_true = fnum(truth.get("anisotropy_true"))
    an = res_gel.get("anisotropy") if isinstance(res_gel, dict) else None
    if an is None:
        out["status"] = NP
        return out
    if fnum(an) is not None:
        an = {"estimate": fnum(an)}
    if not isinstance(an, dict):
        out["status"] = f"unrecognised type {type(an).__name__}"
        return out
    out["keys_found"] = sorted(an.keys())
    est, est_key = None, None
    for k in ANISO_EST_KEYS:
        if fnum(an.get(k)) is not None:
            est, est_key = fnum(an[k]), k
            break
    if est is None:
        floats = [k for k, v in an.items() if fnum(v) is not None and not any(
            s in k.lower() for s in ("ci", "lo", "hi", "se", "sd", "err", "sigma", "n_", "count", "p_", "pval"))
                  and k.lower() not in ("n", "p")]
        if len(floats) == 1:
            est, est_key = fnum(an[floats[0]]), floats[0]
    ci, ci_key = find_ci(an)
    se, se_key = None, None
    for k in ANISO_SE_KEYS:
        if fnum(an.get(k)) is not None:
            se, se_key = fnum(an[k]), k
            break
    if ci is None and est is not None and se is not None:
        ci, ci_key = [est - 1.96 * se, est + 1.96 * se], f"estimate +- 1.96*{se_key}"
    deftxt = " ".join(str(an.get(k, "")) for k in ANISO_DEF_KEYS).lower().replace(" ", "")
    flipped = any(s in deftxt for s in ("e_ax/e_tr", "eax/etr", "ax/tr", "e_ax-e_tr", "eax-etr", "(ax-tr)",
                                        "axial/transverse", "axial-transverse"))
    out.update(estimate_key=est_key, estimate=rnd(est), ci_key=ci_key, ci=[rnd(c) for c in ci] if ci else None,
               se_key=se_key, se=rnd(se), convention="E_ax/E_tr - 1 (sign flipped for scoring)" if flipped
               else "E_tr/E_ax - 1 (schema example sign; assumed unless the result says otherwise)")
    call_raw = None
    for k in ANISO_CALL_KEYS:
        if k in an and not isinstance(an[k], (dict, list)):
            call_raw = (k, an[k])
            break
    out["call_raw"] = None if call_raw is None else f"{call_raw[0]}={call_raw[1]}"
    if est is None:
        out["status"] = "no point estimate found"
        return out
    sgn = -1.0 if flipped else 1.0
    e = sgn * est
    c = sorted([sgn * ci[0], sgn * ci[1]]) if ci else None
    out["estimate_in_truth_convention"] = rnd(e)
    if a_true is not None:
        out["error"] = rnd(e - a_true)
        out["sign_correct"] = bool(np.sign(e) == np.sign(a_true))
        if c:
            out["ci_covers_truth"] = bool(c[0] <= a_true <= c[1])
            excludes0 = not (c[0] <= 0.0 <= c[1])
            out["ci_excludes_zero"] = bool(excludes0)
            claim = "anisotropic" if excludes0 else "no detectable anisotropy"
        else:
            out["ci_covers_truth"] = NP
            claim = None
        if call_raw is not None:
            v = str(call_raw[1]).lower()
            k = call_raw[0].lower()
            if isinstance(call_raw[1], bool) or v in ("true", "false", "0", "1", "yes", "no"):
                pos = v in ("true", "1", "yes")
                if k == "isotropic":
                    pos = not pos
                claim = "anisotropic" if pos else "no detectable anisotropy"
            elif "anisotrop" in v:
                claim = "anisotropic"
            elif "isotrop" in v or "none" in v or "no " in v:
                claim = "no detectable anisotropy"
        out["claim"] = claim
        if claim is None:
            out["call_right"] = NP
        else:
            out["call_right"] = bool(claim == "anisotropic" and out["sign_correct"])
        if not flipped:
            out["error_if_opposite_convention"] = rnd(-est - a_true)
    out["status"] = "scored"
    return out


def grid_cells(grid):
    try:
        x0, y0 = float(grid["x0"]), float(grid["y0"])
        step = float(grid["step"])
        nx, ny = int(grid["nx"]), int(grid["ny"])
    except (KeyError, TypeError, ValueError):
        return None
    xs = x0 + step * np.arange(nx)
    ys = y0 + step * np.arange(ny)
    X, Y = np.meshgrid(xs, ys)
    return X, Y, nx, ny, step


def flag_any(flags, nx, ny):
    acc = np.zeros((ny, nx), bool)
    used, bad = [], []
    per = {}
    if not isinstance(flags, dict):
        return acc, used, bad, per
    for name, arr in flags.items():
        try:
            a = np.array([[1.0 if (v is not None and fnum(v) and fnum(v) > 0) else 0.0 for v in row] for row in arr])
        except TypeError:
            bad.append(name)
            continue
        if a.shape != (ny, nx):
            if a.shape == (nx, ny) and nx != ny:
                a = a.T
                bad.append(f"{name} (transposed)")
            else:
                bad.append(f"{name} shape {a.shape} != ({ny},{nx})")
                continue
        m = a > 0
        per[name] = m
        acc |= m
        used.append(name)
    return acc, used, bad, per


def score(result, truth):
    S = dict(schema_result=result.get("schema", NP), gel_id_result=result.get("gel_id", NP),
             gel_id_truth=truth.get("gel_id"))
    pairs = truth["pairs"]
    alt = truth.get("pairs_alt", {}) or {}
    tf = truth["fibrils"]
    debris = truth.get("debris", [])
    dkind = truth.get("debris_kind", {}) or {}
    matches = result.get("matches")
    if not isinstance(matches, dict):
        matches = {}
        S["matches_status"] = NP
    rfib = result.get("fibrils") if isinstance(result.get("fibrils"), dict) else {}

    # ---------------- matching ----------------
    n_true = sum(1 for p, q in pairs.items() if q is not None)
    correct, wrong, false_pos, missed, matched = set(), [], [], [], 0
    for pid, q in pairs.items():
        r = matches.get(pid)
        if r is not None:
            matched += 1
        ok_set = set([q] if q is not None else []) | set(alt.get(pid, []))
        if q is not None:
            if r is not None and r in ok_set:
                correct.add(pid)
            elif r is None:
                missed.append(pid)
            else:
                wrong.append(pid)
        elif r is not None:
            false_pos.append(pid)
    used = {}
    for pid, r in matches.items():
        if r is not None:
            used[r] = used.get(r, 0) + 1
    S["matching"] = dict(
        true_pairs=n_true, pre_ids_in_truth=len(pairs), pre_ids_in_result=sum(1 for p in pairs if p in matches),
        matched_by_pipeline=matched, correct=len(correct), wrong_partner=len(wrong),
        matched_but_truly_unpaired=len(false_pos), missed=len(missed),
        recall=rnd(len(correct) / n_true) if n_true else None,
        precision=rnd(len(correct) / matched) if matched else NP,
        post_ids_used_more_than_once=sum(1 for v in used.values() if v > 1),
        unknown_pre_ids_in_result=sum(1 for p in matches if p not in pairs))
    # by kind/region of the pre object
    br = {}
    for pid, q in pairs.items():
        t = tf.get(pid, {})
        key = t.get("region") or t.get("kind") or "?"
        b = br.setdefault(key, dict(n=0, true_pairs=0, correct=0, wrong=0, false_pos=0, missed=0))
        b["n"] += 1
        if q is not None:
            b["true_pairs"] += 1
        if pid in correct:
            b["correct"] += 1
        if pid in wrong:
            b["wrong"] += 1
        if pid in false_pos:
            b["false_pos"] += 1
        if pid in missed:
            b["missed"] += 1
    S["matching_by_region"] = br
    # ---------------- debris ----------------
    matched_post = set(v for v in matches.values() if v is not None)
    rej = [d for d in debris if d not in matched_post]
    by = {}
    for d in debris:
        k = dkind.get(d, "debris")
        b = by.setdefault(k, [0, 0])
        b[0] += 1
        b[1] += d not in matched_post
    S["debris"] = dict(n=len(debris), rejected=len(rej), rejection=rnd(len(rej) / len(debris)) if debris else None,
                       by_kind={k: dict(n=v[0], rejected=v[1]) for k, v in by.items()})
    sm = truth.get("split_members", []) or []
    S["split_members_info"] = dict(n=len(sm), unmatched=sum(1 for d in sm if d not in matched_post),
                                   note="post pieces of loose bundles; matching them to their bundle is accepted")
    # ---------------- E_ax ----------------
    def est(pid, key):
        v = rfib.get(pid)
        return fnum(v.get(key)) if isinstance(v, dict) else None

    r_ok, e_ok, t_ok, tt = [], [], [], []
    for pid in correct:
        e = est(pid, "E_ax")
        tr = fnum(tf.get(pid, {}).get("E_ax"))
        if e is not None and tr is not None:
            r_ok.append(e / tr - 1)
            e_ok.append(e)
            t_ok.append(tr)
            tt.append(fnum(tf[pid].get("t")))
    if e_ok:
        gm = dict(n=len(e_ok), mean_est=rnd(np.mean(e_ok)), mean_truth=rnd(np.mean(t_ok)),
                  rel_error_pct=rnd(100 * (np.mean(e_ok) / np.mean(t_ok) - 1), 4),
                  median_rel_error_pct=rnd(100 * (np.median(e_ok) / np.median(t_ok) - 1), 4))
    else:
        gm = dict(n=0, rel_error_pct=NP)
    gel = result.get("gel") if isinstance(result.get("gel"), dict) else {}
    gmed = fnum(gel.get("E_ax_median"))
    all_paired = [fnum(tf[p].get("E_ax")) for p, q in pairs.items() if q is not None and fnum(tf[p].get("E_ax"))]
    gm["result_gel_E_ax_median"] = rnd(gmed) if gmed is not None else NP
    if gmed is not None and all_paired:
        gm["gel_E_ax_median_rel_error_pct_vs_all_paired"] = rnd(100 * (gmed / np.median(all_paired) - 1), 4)
    S["gel_mean_E_ax"] = gm
    S["E_ax_correct_matches"] = stats(r_ok)
    r_all, nonfib = [], 0
    for pid, v in rfib.items():
        e = fnum(v.get("E_ax")) if isinstance(v, dict) else None
        if e is None:
            continue
        tr = fnum(tf.get(pid, {}).get("E_ax")) if pid in tf else None
        if tr is None:
            nonfib += 1
            continue
        r_all.append(e / tr - 1)
    sa = stats(r_all)
    n_ret = len(r_all) + nonfib
    if n_ret:
        sa["n_returned"] = n_ret
        sa["estimates_for_non_fibrils_or_unknown_ids"] = nonfib
        sa["frac_beyond_2pct_counting_non_fibrils"] = rnd((sum(1 for r in r_all if abs(r) > 0.02) + nonfib) / n_ret)
    S["E_ax_all_returned"] = sa
    S["E_ax_coverage"] = rnd(len(r_ok) / n_true) if n_true else None
    # by region (correct matches)
    byr = {}
    for pid in correct:
        e = est(pid, "E_ax")
        tr = fnum(tf.get(pid, {}).get("E_ax"))
        if e is None or tr is None:
            continue
        key = tf[pid].get("region") or tf[pid].get("kind")
        byr.setdefault(key, []).append(e / tr - 1)
    S["E_ax_correct_by_region"] = {k: stats(v) for k, v in byr.items()}
    # ---------------- E_tr ----------------
    r_tr = []
    for pid in correct:
        e = est(pid, "E_tr")
        tr = fnum(tf.get(pid, {}).get("E_tr"))
        if e is not None and tr is not None:
            r_tr.append(e / tr - 1)
    st = stats(r_tr)
    S["E_tr_correct_matches"] = dict(n=st.get("n", 0), bias=st.get("mean", NP), sd=st.get("sd", NP),
                                     median=st.get("median", NP), robust_sd=st.get("robust_sd", NP))
    # ---------------- defects / flags ----------------
    grid = result.get("grid")
    gc = grid_cells(grid) if isinstance(grid, dict) else None
    if gc is None:
        S["defects"] = NP
        S["false_flags"] = NP
    else:
        X, Y, nx, ny, step = gc
        anyf, used_f, bad_f, per = flag_any(result.get("flags"), nx, ny)
        pts = np.stack([X.ravel(), Y.ravel()], 1)
        dl = []
        dmin = np.full(pts.shape[0], np.inf)
        for d in truth.get("defects", []):
            poly = np.asarray(d["polygon_pre"], float)
            inside = in_poly(pts, poly)
            dmin = np.minimum(dmin, dist_to_poly(pts, poly))
            n_in = int(inside.sum())
            fl = anyf.ravel()[inside]
            ent = dict(kind=d["kind"], cells=n_in, flagged_frac=rnd(fl.mean()) if n_in else "no cells")
            ent["by_flag"] = {k: rnd(v.ravel()[inside].mean()) for k, v in per.items()} if n_in else {}
            dl.append(ent)
        S["defects"] = dict(flags_used=used_f, flags_unusable=bad_f, grid=dict(x0=float(X[0, 0]), y0=float(Y[0, 0]),
                                                                              step=step, nx=nx, ny=ny), per_defect=dl)
        R = float(truth.get("gel_R_pre", 750.0))
        c = truth.get("gel_center_pre", [0.0, 0.0])
        rr = np.hypot(pts[:, 0] - c[0], pts[:, 1] - c[1])
        clean = (rr <= 0.9 * R) & (dmin > 40.0)
        n_clean = int(clean.sum())
        S["false_flags"] = dict(clean_cells=n_clean,
                                false_flag_frac=rnd(anyf.ravel()[clean].mean()) if n_clean else "no cells",
                                by_flag={k: rnd(v.ravel()[clean].mean()) for k, v in per.items()} if n_clean else {})
    # ---------------- anisotropy ----------------
    S["anisotropy"] = score_anisotropy(gel, truth)
    # ---------------- residual drift ----------------
    x, y = [], []
    xd, yd = [], []
    for pid in correct:
        e = est(pid, "E_ax")
        t = tf.get(pid, {})
        tr, ta, tt_ = fnum(t.get("E_ax")), fnum(t.get("E_ax_acq")), fnum(t.get("t"))
        if e is None or tr is None or tt_ is None:
            continue
        x.append(tt_ / 3600.0)
        y.append(e / tr - 1)
        if ta is not None:
            xd.append(tt_ / 3600.0)
            yd.append(ta / tr - 1)
    x, y = np.array(x), np.array(y)
    dr = dict(n=int(x.size))
    if x.size >= 3:
        keep = np.abs(y) < 0.05
        s1, e1 = ols(x[keep], y[keep])
        s2, e2 = ols(x, y)
        s0, e0 = ols(np.array(xd), np.array(yd))
        dr.update(slope_pct_per_h=rnd(100 * s1, 4) if s1 is not None else None,
                  slope_se_pct_per_h=rnd(100 * e1, 4) if e1 is not None else None,
                  n_used=int(keep.sum()), excluded_abs_err_over_5pct=int((~keep).sum()),
                  slope_all_pct_per_h=rnd(100 * s2, 4) if s2 is not None else None,
                  uncorrected_drift_slope_pct_per_h=rnd(100 * s0, 4) if s0 is not None else None)
        bins = np.linspace(x.min(), x.max() + 1e-9, 7)
        dr["binned_median_rel_err_pct"] = [dict(t_h=[rnd(bins[i], 3), rnd(bins[i + 1], 3)],
                                                n=int(np.sum((x >= bins[i]) & (x < bins[i + 1]))),
                                                median=rnd(100 * np.median(y[(x >= bins[i]) & (x < bins[i + 1])]), 4)
                                                if np.any((x >= bins[i]) & (x < bins[i + 1])) else None)
                                           for i in range(6)]
    dr["result_gel_drift_keys"] = sorted(gel.get("drift", {}).keys()) if isinstance(gel.get("drift"), dict) else NP
    S["residual_drift"] = dr
    # ---------------- transform (informational) ----------------
    tr = result.get("transform")
    tt_ = truth.get("transform", {})
    if isinstance(tr, dict) and fnum(tr.get("rotation")) is not None:
        rot_r = fnum(tr.get("rotation"))
        mir = tr.get("mirror")
        out = dict(mirror_result=mir, mirror_truth=tt_.get("mirror"),
                   mirror_correct=(bool(mir) == bool(tt_.get("mirror"))) if mir is not None else NP,
                   scale_result=rnd(fnum(tr.get("scale"))), scale_truth_E0=tt_.get("scale_E0"))
        if rot_r is not None and tt_.get("rotation") is not None:
            # the truth linear part is R(rot) @ diag(1,-1); a result may put the mirror before or after the
            # rotation or mirror the other axis -> report the smallest angular disagreement over conventions
            Rt = rot_mat(tt_["rotation"]) @ np.diag([1.0, -1.0])
            errs = []
            for M in (np.diag([1.0, -1.0]), np.diag([-1.0, 1.0])):
                for A in (rot_mat(rot_r) @ M, M @ rot_mat(rot_r)):
                    Q = A.T @ Rt
                    errs.append(abs(math.degrees(math.atan2(Q[1, 0], Q[0, 0]))) if np.linalg.det(Q) > 0 else 999)
            out["rotation_error_deg_best_convention"] = rnd(min(errs), 4)
        S["transform_info"] = out
    else:
        S["transform_info"] = NP
    return S


def rot_mat(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s], [s, c]])


# ----------------------------------------------------------------------------- report
def fmt(v, pct=False, nd=3):
    if v is None:
        return "-"
    if isinstance(v, str):
        return v
    if isinstance(v, bool):
        return "yes" if v else "no"
    return f"{100 * v:.{nd - 1}f} %" if pct else f"{v:.{nd}f}" if isinstance(v, float) else str(v)


def markdown(S):
    m = S["matching"]
    L = ["| metric | value |", "|---|---|"]
    L.append(f"| matching precision / recall | {fmt(m['precision'])} / {fmt(m['recall'])} "
             f"({m['correct']} of {m['true_pairs']} true pairs; {m['wrong_partner']} wrong, "
             f"{m['matched_but_truly_unpaired']} matched-but-unpaired) |")
    d = S["debris"]
    L.append(f"| debris rejection | {fmt(d['rejection'])} ({d['rejected']} of {d['n']}) |")
    g = S["gel_mean_E_ax"]
    L.append(f"| gel-mean E_ax error (correct matches) | {fmt(g.get('rel_error_pct'))} % (n={g.get('n')}) |")
    a, b = S["E_ax_correct_matches"], S["E_ax_all_returned"]
    L.append(f"| per-fibril E_ax RMS rel. error, correct matches | {fmt(a.get('rms'), True)} "
             f"(beyond +-2 %: {fmt(a.get('frac_beyond_2pct'), True, 2)}, n={a.get('n', 0)}) |")
    L.append(f"| per-fibril E_ax RMS rel. error, all returned | {fmt(b.get('rms'), True)} "
             f"(beyond +-2 %: {fmt(b.get('frac_beyond_2pct_counting_non_fibrils', b.get('frac_beyond_2pct')), True, 2)}, "
             f"n={b.get('n_returned', b.get('n', 0))}) |")
    t = S["E_tr_correct_matches"]
    L.append(f"| E_tr bias / SD (correct matches) | {fmt(t.get('bias'), True)} / {fmt(t.get('sd'), True)} "
             f"(n={t.get('n')}) |")
    if isinstance(S["defects"], dict):
        for e in S["defects"]["per_defect"]:
            L.append(f"| flagged: {e['kind']} | {fmt(e['flagged_frac'])} of {e['cells']} cells |")
        ff = S["false_flags"]
        L.append(f"| false-flag fraction (clean cells) | {fmt(ff['false_flag_frac'])} of {ff['clean_cells']} cells |")
    else:
        L.append(f"| defect flags | {NP} |")
    an = S["anisotropy"]
    if an.get("status") == "scored":
        L.append(f"| anisotropy: estimate (truth) | {fmt(an.get('estimate_in_truth_convention'), nd=5)} "
                 f"({fmt(an.get('truth'), nd=5)}); CI {an.get('ci')}; covers truth: {fmt(an.get('ci_covers_truth'))}; "
                 f"call right: {fmt(an.get('call_right'))} |")
    else:
        L.append(f"| anisotropy | {an.get('status')} (truth {an.get('truth')}) |")
    dr = S["residual_drift"]
    L.append(f"| residual drift slope (correct matches, abs err < 5 %, n={dr.get('n_used', 0)}) | "
             f"{fmt(dr.get('slope_pct_per_h'), nd=4)} +- {fmt(dr.get('slope_se_pct_per_h'), nd=4)} %/h "
             f"(all {dr.get('n', 0)}: {fmt(dr.get('slope_all_pct_per_h'), nd=4)} %/h; uncorrected drift would give "
             f"{fmt(dr.get('uncorrected_drift_slope_pct_per_h'), nd=4)} %/h, see binned residuals in score.json) |")
    return "\n".join(L)


# ----------------------------------------------------------------------------- self-test
def oracle(truth, grid_step=20.0):
    R = 750.0
    n = int(round(2 * R / grid_step)) + 1
    grid = dict(x0=-R, y0=-R, step=grid_step, nx=n, ny=n)
    xs = -R + grid_step * np.arange(n)
    X, Y = np.meshgrid(xs, xs)
    pts = np.stack([X.ravel(), Y.ravel()], 1)
    fl = np.zeros(pts.shape[0], int)
    for d in truth["defects"]:
        fl |= in_poly(pts, d["polygon_pre"]).astype(int)
    tf = truth["fibrils"]
    fib = {p: dict(E_ax=tf[p]["E_ax"], E_tr=tf[p]["E_tr"]) for p, q in truth["pairs"].items() if q is not None}
    a = truth["anisotropy_true"]
    return {"schema": "swell-result/1", "gel_id": truth["gel_id"], "matches": dict(truth["pairs"]),
            "transform": dict(scale=truth["transform"]["scale_E0"], rotation=truth["transform"]["rotation"],
                              mirror=truth["transform"]["mirror"], translation=truth["transform"]["translation"]),
            "fibrils": fib, "gel": {"E_ax_median": float(np.median([v["E_ax"] for v in fib.values()])),
                                    "anisotropy": {"estimate": a, "ci95": [a - 0.001, a + 0.001]}},
            "grid": grid, "flags": {"oracle": fl.reshape(n, n).tolist()}}


def selftest(truth):
    S = score(oracle(truth), truth)
    m = S["matching"]
    checks = [("recall 1", m["recall"] == 1.0), ("precision 1", m["precision"] == 1.0),
              ("debris rejection 1", S["debris"]["rejection"] == 1.0),
              ("gel-mean error 0", abs(S["gel_mean_E_ax"]["rel_error_pct"]) < 1e-6),
              ("E_ax rms 0", S["E_ax_correct_matches"]["rms"] < 1e-6),
              ("E_tr bias 0", abs(S["E_tr_correct_matches"]["bias"]) < 1e-6),
              ("all defects flagged", all(e["flagged_frac"] == 1.0 for e in S["defects"]["per_defect"]
                                          if e["cells"])),
              ("no false flags", S["false_flags"]["false_flag_frac"] == 0.0),
              ("anisotropy covered", S["anisotropy"]["ci_covers_truth"] is True),
              ("anisotropy call right", S["anisotropy"]["call_right"] is True),
              ("residual drift ~0", abs(S["residual_drift"]["slope_pct_per_h"]) < 1e-6)]
    print(markdown(S))
    ok = True
    for name, c in checks:
        print(f"selftest {'PASS' if c else 'FAIL'}: {name}")
        ok &= bool(c)
    S2 = score({"schema": "swell-result/1"}, truth)
    print("empty result scored without crashing:", S2["matching"]["recall"], S2["defects"], S2["anisotropy"]["status"])
    return ok


def main():
    ap = argparse.ArgumentParser(description="score a swell-result/1 file against the S3 truth")
    ap.add_argument("result", nargs="?")
    ap.add_argument("--truth", default=os.path.join(DATA, "truth.json.gz"))
    ap.add_argument("--out", default=os.path.join(DATA, "score.json"))
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    truth = load(args.truth)
    if args.selftest:
        sys.exit(0 if selftest(truth) else 1)
    if not args.result:
        ap.error("RESULT path required (or --selftest)")
    result = load(args.result)
    S = score(result, truth)
    S["result_path"] = os.path.abspath(args.result)
    S["truth_path"] = os.path.abspath(args.truth)
    with open(args.out, "w", encoding="utf-8", newline="\n") as f:
        json.dump(S, f, indent=1)
    print(markdown(S))
    print(f"\nfull score: {args.out}")


if __name__ == "__main__":
    main()
