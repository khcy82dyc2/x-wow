#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Validate the S3 outputs written by s3_gen.py.

    python software/redteam/validate_s3.py [--dir data/sim/S3]

1. schema conformance of obs.json.gz (swell-obs/1) and truth.json.gz (swell-truth/1), field by field;
2. truth consistency (every pre id paired or null, partners exist and are unique, debris unmatched);
3. a naive baseline with ORACLE matching (periodogram peak ratio) by region, to show which planted
   failures bite and that clean striations are visible but not trivially easy;
4. a clock check (similarity fit per visit) against the planted drift;
5. profiles.png: pre/post profiles of six paired objects (no ids, no truth values on the figure).
Exit status 1 if any schema or consistency check fails.
"""
import argparse
import gzip
import json
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.normpath(os.path.join(HERE, "..", "..", "data", "sim", "S3"))


def load(p):
    with gzip.open(p, "rt", encoding="utf-8") as f:
        return json.load(f)


def isnum(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def isnumlist(v, minlen=1):
    return isinstance(v, list) and len(v) >= minlen and all(isnum(x) for x in v)


# ----------------------------------------------------------------------------- schema
def check_obs(obs):
    err = []
    if obs.get("schema") != "swell-obs/1":
        err.append("schema != swell-obs/1")
    for k in ("gel_id", "meta", "pre", "post", "clock"):
        if k not in obs:
            err.append(f"missing top-level key {k}")
    m = obs.get("meta", {})
    req = dict(e_macro=isnum, px_pre_um=isnum, px_post_um=isnum, psf_pre_fwhm_um=isnum, psf_post_fwhm_um=isnum,
               dof_post_um=isnum, gel_radius_pre_um=isnum,
               pre_mode=lambda v: v in ("dpc", "pol"),
               gel_center_post_um=lambda v: isnumlist(v, 2) and len(v) == 2,
               mirror_possible=lambda v: isinstance(v, bool))
    for k, f in req.items():
        if k not in m:
            err.append(f"meta.{k} missing")
        elif not f(m[k]):
            err.append(f"meta.{k} has wrong type/value: {m[k]!r}")
    for lst_name, post in (("pre", False), ("post", True)):
        lst = obs.get(lst_name, [])
        px = m.get("px_post_um" if post else "px_pre_um", 0.1)
        ids = set()
        for o in lst:
            oid = o.get("id")
            if not isinstance(oid, str) or not oid:
                err.append(f"{lst_name}: bad id {oid!r}")
            elif oid in ids:
                err.append(f"{lst_name}: duplicate id {oid}")
            ids.add(oid)
            for k in ("x", "y", "angle", "length"):
                if not isnum(o.get(k)):
                    err.append(f"{lst_name} {oid}: {k} not a finite number")
            a = o.get("angle", -1)
            if isnum(a) and not (0 <= a < math.pi):
                err.append(f"{lst_name} {oid}: angle {a} outside [0, pi)")
            if not isnumlist(o.get("axial"), 2):
                err.append(f"{lst_name} {oid}: axial not a list of >=2 numbers")
            elif isnum(o.get("length")) and abs((len(o["axial"]) - 1) * px - o["length"]) > 1.01 * px:
                err.append(f"{lst_name} {oid}: axial covers {(len(o['axial']) - 1) * px:.2f} um, length {o['length']}")
            c = o.get("cross")
            if not isnumlist(c, 3) or len(c) % 2 != 1:
                err.append(f"{lst_name} {oid}: cross not an odd-length numeric list")
            if not isinstance(o.get("cross_rows"), int) or o["cross_rows"] < 1:
                err.append(f"{lst_name} {oid}: cross_rows not a positive int")
            if post:
                z = o.get("zsum_cross")
                if not isnumlist(z, 3) or len(z) % 2 != 1:
                    err.append(f"post {oid}: zsum_cross not an odd-length numeric list")
                elif c is not None and len(z) != len(c):
                    err.append(f"post {oid}: zsum_cross length differs from cross")
                for k in ("zsum_rows", "zsum_planes", "tile"):
                    if not isinstance(o.get(k), int) or o[k] < 0:
                        err.append(f"post {oid}: {k} not a non-negative int")
                if not isnum(o.get("aspect")) or o["aspect"] <= 0:
                    err.append(f"post {oid}: aspect not positive")
                if not isnum(o.get("t")) or o["t"] < 0:
                    err.append(f"post {oid}: t not a non-negative number")
            extra = set(o) - {"id", "x", "y", "angle", "length", "axial", "cross", "cross_rows", "zsum_cross",
                              "zsum_rows", "zsum_planes", "aspect", "tile", "t"}
            if extra:
                err.append(f"{lst_name} {oid}: unexpected keys {sorted(extra)}")
    pre_ids = {o["id"] for o in obs.get("pre", [])}
    post_ids = {o["id"] for o in obs.get("post", [])}
    if pre_ids & post_ids:
        err.append("pre and post ids overlap (allowed by schema, but S3 promises globally unique ids)")
    cl = obs.get("clock", [])
    ts = []
    for v in cl:
        if not isnum(v.get("t")):
            err.append("clock visit without numeric t")
        ts.append(v.get("t", 0))
        if not isinstance(v.get("objects"), list):
            err.append("clock visit objects not a list")
            continue
        for q in v["objects"]:
            if not (isnum(q.get("x")) and isnum(q.get("y"))):
                err.append("clock object without numeric x/y")
    if ts and ts[0] != min(ts):
        err.append("first clock visit is not the earliest")
    return err


def check_truth(truth, obs):
    err = []
    if truth.get("schema") != "swell-truth/1":
        err.append("truth schema != swell-truth/1")
    pre_ids = {o["id"] for o in obs["pre"]}
    post_ids = {o["id"] for o in obs["post"]}
    pairs = truth.get("pairs", {})
    if set(pairs) != pre_ids:
        err.append(f"pairs keys != pre ids ({len(set(pairs) ^ pre_ids)} differ)")
    partners = [q for q in pairs.values() if q is not None]
    if len(partners) != len(set(partners)):
        err.append("a post id is the partner of two pre ids")
    if not set(partners) <= post_ids:
        err.append("partner ids missing from post list")
    deb = truth.get("debris", [])
    if set(deb) & set(partners):
        err.append("a debris id is also a partner")
    if not set(deb) <= post_ids:
        err.append("debris ids missing from post list")
    sm = set(truth.get("split_members", []))
    if set(deb) | set(partners) | sm != post_ids:
        err.append(f"post ids not covered by partners+debris+split_members: {len(post_ids - (set(deb) | set(partners) | sm))}")
    f = truth.get("fibrils", {})
    if set(f) != pre_ids:
        err.append("fibrils keys != pre ids")
    for pid, t in f.items():
        for k in ("x", "y"):
            if not isnum(t.get(k)):
                err.append(f"fibrils {pid}: {k} missing")
        if pairs.get(pid) is not None and not (isnum(t.get("E_ax")) and isnum(t.get("E_tr")) and isnum(t.get("E_ax_acq"))):
            err.append(f"fibrils {pid}: paired but E_ax/E_tr/E_ax_acq missing")
    for d in truth.get("defects", []):
        if not isinstance(d.get("kind"), str) or len(d.get("polygon_pre", [])) < 3:
            err.append("bad defect polygon")
    if not isnum(truth.get("anisotropy_true")):
        err.append("anisotropy_true missing")
    if not isinstance(truth.get("notes"), str):
        err.append("notes missing")
    return err


# ----------------------------------------------------------------------------- naive baseline
def period(y, px, lo, hi):
    y = np.asarray(y, float)
    n = len(y)
    if n < 8:
        return None
    x = np.arange(n) * px
    y = y - np.polyval(np.polyfit(x, y, 2), x)
    y = y * np.hanning(n)
    nf = 1 << int(math.ceil(math.log2(max(n, 64) * 16)))
    F = np.abs(np.fft.rfft(y, nf)) ** 2
    f = np.fft.rfftfreq(nf, px)
    m = (f > 1 / hi) & (f < 1 / lo)
    if not m.any():
        return None
    idx = np.nonzero(m)[0]
    k = idx[np.argmax(F[idx])]
    if idx[0] < k < idx[-1]:
        a, b, c = np.log(F[k - 1] + 1e-30), np.log(F[k] + 1e-30), np.log(F[k + 1] + 1e-30)
        d = 0.5 * (a - c) / (a - 2 * b + c) if (a - 2 * b + c) != 0 else 0.0
    else:
        d = 0.0
    fk = f[k] + d * (f[1] - f[0])
    return 1 / fk if fk > 0 else None


def baseline(obs, truth):
    m = obs["meta"]
    pre = {o["id"]: o for o in obs["pre"]}
    post = {o["id"]: o for o in obs["post"]}
    em = m["e_macro"]
    rows = {}
    for pid, q in truth["pairs"].items():
        if q is None:
            continue
        t = truth["fibrils"][pid]
        p1 = period(pre[pid]["axial"], m["px_pre_um"], 1.3, 2.4)
        p2 = period(post[q]["axial"], m["px_post_um"], 1.3 * em * 0.9, 2.4 * em * 1.1)
        if p1 is None or p2 is None:
            continue
        e = p2 / p1
        key = t.get("region") or t["kind"]
        rows.setdefault(key, []).append((e / t["E_ax"] - 1, e / t["E_ax_acq"] - 1))
    print("\nNaive baseline (ORACLE matching; E = post periodogram peak / pre periodogram peak):")
    print(f"{'region/kind':<18}{'n':>6}{'median|e|':>11}{'frac>2%':>9}{'rms(|e|<10%)':>14}{'vs E_acq frac>2%':>18}")
    for k in sorted(rows, key=lambda s: -len(rows[s])):
        r = np.array(rows[k])
        e, ea = r[:, 0], r[:, 1]
        sm = e[np.abs(e) < 0.1]
        print(f"{k:<18}{len(e):>6}{np.median(np.abs(e)):>11.4f}{np.mean(np.abs(e) > 0.02):>9.2f}"
              f"{(math.sqrt(np.mean(sm ** 2)) if sm.size else float('nan')):>14.4f}{np.mean(np.abs(ea) > 0.02):>18.2f}")


def clock_check(obs, truth):
    cl = obs["clock"]
    ref = np.array([[q["x"], q["y"]] for q in cl[0]["objects"]])
    d_true = truth.get("drift", {}).get("d_at_visits")
    print("\nClock check (robust similarity fit of each visit to visit 0):")
    print(f"{'visit':>5}{'t [s]':>9}{'n':>4}{'scale-1 [%]':>13}{'truth d [%]':>13}")
    for v, vis in enumerate(cl):
        P = np.array([[q["x"], q["y"]] for q in vis["objects"]])
        if len(P) < 3:
            continue
        sc, tr = 1.0, np.zeros(2)
        tol = 8.0
        for it in range(6):
            Q = (P - tr) / sc
            d = np.linalg.norm(Q[:, None] - ref[None], axis=2)
            j = d.argmin(1)
            ok = d[np.arange(len(P)), j] < tol
            if ok.sum() < 3:
                break
            A, B = ref[j[ok]], P[ok]
            ca, cb = A.mean(0), B.mean(0)
            sc = math.sqrt(np.sum((B - cb) ** 2) / max(np.sum((A - ca) ** 2), 1e-9))
            tr = cb - sc * ca
            res = np.linalg.norm(B - (sc * A + tr), axis=1)
            tol = max(1.5, 3 * np.median(res))
        dt = 100 * d_true[v] if d_true and v < len(d_true) else float("nan")
        print(f"{v:>5}{vis['t']:>9.0f}{len(P):>4}{100 * (sc - 1):>13.3f}{dt:>13.3f}")


# ----------------------------------------------------------------------------- plot
def plot(obs, truth, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    m = obs["meta"]
    pre = {o["id"]: o for o in obs["pre"]}
    post = {o["id"]: o for o in obs["post"]}
    f = truth["fibrils"]
    want = [("fibril", None), ("fibril", None), ("curved", "curved"), ("bundle_tight", "bundled"),
            ("fibril", "z_tilt"), ("fibril", "fold")]
    chosen, used = [], set()
    for kind, region in want:
        best = None
        for pid, q in truth["pairs"].items():
            if q is None or pid in used:
                continue
            t = f[pid]
            if t["kind"] != kind or t.get("region") != region:
                continue
            if 12 <= pre[pid]["length"] <= 30:
                best = pid
                break
        if best:
            chosen.append(best)
            used.add(best)
    fig, axes = plt.subplots(len(chosen), 2, figsize=(14, 2.6 * len(chosen)))
    for r, pid in enumerate(chosen):
        a, b = pre[pid], post[truth["pairs"][pid]]
        ax = axes[r, 0]
        xa = m["px_pre_um"] * np.arange(len(a["axial"]))
        ax.plot(xa, a["axial"], lw=0.8, color="tab:blue")
        ax.set_ylabel("pre DPC", color="tab:blue")
        ax2 = ax.twiny()
        ax3 = ax2.twinx()
        xb = m["px_post_um"] * np.arange(len(b["axial"]))
        ax3.plot(xb, b["axial"], lw=0.8, color="tab:red", alpha=0.8)
        ax3.set_ylabel("post e-", color="tab:red")
        ax2.set_xlim(0, xb[-1])
        ax3.set_xlim(0, xb[-1])
        ax.set_xlim(0, xa[-1])
        ax.set_title(f"pair {chr(65 + r)}: axial profiles (pre bottom axis um; post top axis um, red)", fontsize=9)
        ax = axes[r, 1]
        ca, cb, cz = np.array(a["cross"]), np.array(b["cross"]), np.array(b["zsum_cross"])
        ax.plot(m["px_pre_um"] * (np.arange(len(ca)) - len(ca) // 2), ca, color="tab:blue")
        ax2 = ax.twiny()
        ax3 = ax2.twinx()
        ax3.plot(m["px_post_um"] * (np.arange(len(cb)) - len(cb) // 2), cb, color="tab:red")
        ax3.plot(m["px_post_um"] * (np.arange(len(cz)) - len(cz) // 2), cz / b["zsum_planes"], color="tab:green")
        ax2.set_xlim(m["px_post_um"] * (-(len(cb) // 2)), m["px_post_um"] * (len(cb) // 2))
        ax.set_title(f"pair {chr(65 + r)}: cross (pre blue; post in-focus red; post z-sum / planes green)", fontsize=9)
    plt.tight_layout()
    plt.savefig(path, dpi=80)
    print(f"\nwrote {path}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default=DATA)
    ap.add_argument("--no-plot", action="store_true")
    args = ap.parse_args()
    obs = load(os.path.join(args.dir, "obs.json.gz"))
    truth = load(os.path.join(args.dir, "truth.json.gz"))
    e1 = check_obs(obs)
    e2 = check_truth(truth, obs)
    print(f"obs: {len(obs['pre'])} pre, {len(obs['post'])} post, {len(obs['clock'])} clock visits; "
          f"schema errors: {len(e1)}; truth consistency errors: {len(e2)}")
    for e in (e1 + e2)[:30]:
        print("  ERROR", e)
    c = truth.get("counts", {})
    print("counts:", json.dumps(c))
    print(f"anisotropy_true {truth['anisotropy_true']:+.5f}; gel-mean E_ax {truth.get('E_ax_gel_mean_paired')}; "
          f"e_macro told {obs['meta']['e_macro']}")
    baseline(obs, truth)
    clock_check(obs, truth)
    if not args.no_plot:
        plot(obs, truth, os.path.join(args.dir, "profiles.png"))
    sys.exit(1 if (e1 or e2) else 0)


if __name__ == "__main__":
    main()
