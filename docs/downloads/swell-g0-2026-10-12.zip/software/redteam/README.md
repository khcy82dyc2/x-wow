# S3: red-team synthetic gel for the SWELL ruler

> **Pipeline developers: stop here.** Run your pipeline blind on `data/sim/S3/obs.json.gz` with only
> `docs/design/obs_schema_v1.md`. This file, the code in this folder and `data/sim/S3/truth.json.gz` contain the answers.

S3 is an adversarial but honest test gel for the ruler pipeline. It was built from the data contract
alone (`docs/design/obs_schema_v1.md`) by a separate AI agent (another Claude instance, not a person) that had never seen the pipeline. It plants real-lab failure modes on
top of a physically rendered pair of images: a label-free two-axis DPC pre image and a widefield fluorescence post
z-stack mosaic. An emulated image front-end then turns each rendered object into exactly the profiles the schema
describes. Nothing was tuned to make a pipeline pass or fail. The realism checks (striation contrast, a naive
baseline, the clock) are reported below.

## Run

```
python software/redteam/s3_gen.py                 # writes data/sim/S3/obs.json.gz + truth.json.gz
python software/redteam/validate_s3.py            # schema + truth checks, naive baseline, clock check, profiles.png
python software/redteam/score_s3.py RESULT.json   # writes data/sim/S3/score.json, prints a markdown table
python software/redteam/score_s3.py --selftest    # in-memory oracle must score perfectly; writes nothing
```

- Runtime: about 100 s on this PC (16 cores, 12 worker processes); about 5.3 min (319 s) with `--workers 1`.
- Deterministic: seed 20261010; every object has its own child seed. Output is byte-identical across runs and across
  worker counts (checked by SHA-256 of the decompressed JSON).
- Options: `--out DIR`, `--workers N` (0 = auto), `--quick N` (development only: renders every Nth object).

## Outputs (`data/sim/S3/`)

| file | content |
|---|---|
| `obs.json.gz` | swell-obs/1: 1,210 pre objects, 1,198 post objects, 8 clock visits. Lists shuffled, ids are random 10-character strings (globally unique, no pairing information). |
| `truth.json.gz` | swell-truth/1 plus the extras listed under "Truth file". |
| `profiles.png` | pre and post profiles of six paired objects (no ids, no truth values), to see the striations. |
| `score.json` | written by `score_s3.py` when a pipeline result is scored (not present until then). |

Besides the schema keys, `obs.meta` carries acquisition facts a real front-end would know (the schema allows extra
meta keys; none of them is truth): `gel_center_pre_um` [0, 0], `intensity_units`, `post_axial_plane`,
`post_zstack` (21 planes, 0.75 µm), `post_tile_fov_um`, `post_tile_step_um`, `post_tiles`, `clock_tile`,
`pre_tile_fov_um`, `generator`, `seed`.

## What S3 plants

| planted | where (pre µm, gel centre at 0,0) | numbers | what it does |
|---|---|---|---|
| Unpaired observations | everywhere | 74 of 1,198 fibril objects (6.2 %) lost in post; 12 pre-only objects (coverslip lint, crystals); 63 post debris (5.3 % of post objects), 31 of them fibril-like (18 striated fragments, 13 bead chains with a fibril-like period); 11 split members of loose bundles | pre objects with no partner; post objects with no pre partner, several of them fibril-like |
| Global transform | gel | rotation 2.4517 rad, mirror (diag(1,-1) applied before the rotation), translation ≈ (11873, 7433) post stage µm; mirror_possible = true | the pipeline must find rotation, mirror and translation itself |
| e_macro, gel centre | meta | e_macro 4.37743 (-0.57 % vs the paired gel-mean E_ax); gel_center_post told with ~27 µm error | prior only |
| FOLD | flap beyond the chord n·p = 600 µm, n at 205°; overlap = its mirror image inside the gel | 42 pre objects in the flap; the flap tucked UNDER the gel and lies face to face with the main layer | reflected (locally un-mirrored) fibrils at wrong positions, overlapping main-gel fibrils; crease destroys fibrils |
| BUBBLE | centre (380, 330), r 90 µm | air dome 20 µm high under the gel | core lost or seen through air (demagnified, blurred, dimmed); rim lens displacement, blur, bright ring |
| CURVED | ellipse at (−377, 227), 135 × 95 µm, 20° | 44 objects: C arcs, S shapes, kinks | the front-end samples a straight line through the centroid |
| BUNDLED | ellipse at (−91, −430), 120 × 95 µm, −15° | 23 bundles of 2–3 fibrils (13 tight, 10 loose) + 6 singles | one pre object; tight = one post object, loose = split into members in post |
| Z-TILT | rectangle at (417, −169), 260 × 200 µm, long axis 70° | wrinkled gel surface, slopes up to ~19° | projected periods shrink by cos(tilt); true 3-D E_ax is larger; some fibrils leave the z-stack |
| Expansion drift | the whole post scan | rise to +0.48 %, end +0.21 % (non-linear), 2.02 h scan; 8 clock visits | E_ax measured at acquisition differs from the reference by up to 0.48 % |
| Under-expansion (ordinary) | circle (−60, 120), r 80 µm | −4 % linear at the centre | local E low; shear halo outside |
| Over-expansion (ordinary) | ellipse (60, 470), 134 × 54 µm, −35° | +3.9 % across / +1 % along the long axis | local anisotropic over-expansion |
| Gel in-plane anisotropy | whole gel | ±0.3 % about 30° | orientation-dependent E_ax |
| Intrinsic fibril anisotropy | every fibril | E_tr/E_ax − 1 = −1.0 % − 1.0 %/µm·(d − 1.05 µm) ± 0.4 %; anisotropy_true -0.01187 | E_tr differs from E_ax |
| Imaging | every object | Airy core + Lorentzian halo, defocus, astigmatism, vignetting, read/fixed-pattern noise, background structure | not "Gaussian PSF + pure Poisson" |
| Biology | every fibril | sarcomere spread/jitter, damaged and frayed ends | realistic, imperfect rulers |

## Model details (every choice and number)

### Gel and deformation (pre µm → expanded µm)
`phi(p) = E0 · [A · (p + u_rad + u_rand) + u_def + u_crease]`, local Jacobian by central differences (0.25 µm).
- E0 = 4.383. Realised gel-mean E_ax over paired fibrils 4.4025 (sd 0.037, range 4.254-4.878).
- Nominal radius 750 µm (told); true punch radius 747 µm; fibrils placed within 735 µm.
- `u_rad`: area dilatation 2β(r/R)² with β = 0.006 (radial strain 1.5β = 0.9 %, hoop 0.5β = 0.3 % at the edge).
- `A`: gel in-plane anisotropy, stretch 1 ± 0.003 along/across 30°.
- `u_rand`: 48 random plane-wave displacement modes, wavelengths log-uniform 150–600 µm, scaled to 0.2 % rms axial strain.
- `u_def`: Gaussian dilatation sources, u = δσ²(1 − e^(−r²/2σ²))/r² · (p − c) (dilatation δ e^(−r²/2σ²), linear strain δ/2
  at the centre, pure shear outside). Under-expansion: one source at (−60, 120), δ = −0.08, σ = 40 µm. Over-expansion:
  five sources on a 160 µm line through (60, 470) at −35°, δ = +0.0266, σ = 30 µm (centre strain +3.9 % across, +1 % along).
- `u_crease`: compressive strain along the fold normal, −4 % within 10 µm of the crease, decaying as e^(−(d−10)/12 µm).
  This is a true strain, so it is in the E_ax truth.
- Truth per point k on the centreline: E_ax,k = sqrt(|J t|² + (∇h·t)²), E_tr,k = (1 + a_i)·sqrt(|J n|² + (∇h·n)²), where h is
  the height of the gel's specimen face (wrinkle, bubble dome, fold drape) in post µm. Fibril truth = mean over its
  centreline (arc-length weighted, frayed side strands excluded). Bundle E_tr = post width / pre width of the whole bundle
  (members + gaps) at its centre. E_ax_acq = E_ax·(1 + d(t)) at the partner's tile time.

### Transform and overview camera
- post = translation + R(2.4517) · diag(1, −1) · phi(pre); translation (11873.4, 7432.9) post stage µm (the image of the
  pre origin is (11878.1, 7428.6) because phi(0) ≠ 0).
- Post stage scale errors +0.08 % (x) and −0.05 % (y) relative to stage home (0, 0); pre stage −0.03 %, +0.04 % relative
  to (−5200, 3100). They act on tile positions, not on the pixel-calibrated profiles.
- e_macro = (mean post radius of the unfolded rim) × (gel 5 min before the scan, still swelling) / 750 (nominal) ×
  (1 + 0.15 % camera calibration) = 4.37743, i.e. -0.57 % vs the paired gel-mean E_ax.
- gel_center_post_um = true image of the gel centre + N(0, 30 µm) per axis.

### Myofibrils (biology)
- Diameter lognormal (median 1.05 µm, σ_log 0.25) clipped to 0.7–2.0 µm; height/width U(0.65, 0.95) (flattened on glass);
  length lognormal (median 14 µm, σ_log 0.5) clipped to 5–40 µm (realised mean 15.1 µm, median 13.3 µm).
- Orientation: 60 % uniform, 40 % around 35° (von Mises κ = 2 on 2θ; drop-flow alignment). 30 % of candidates come from
  60 Thomas clusters (σ 22 µm, aligned ±0.25 rad). Minimum surface gap 1 µm (bundles excepted). 1,198 fibril objects.
- Sarcomere length per fibril N(1.72, 0.065) µm clipped to 1.52–2.05; within a fibril AR(1) (φ = 0.8, 1 %) plus
  0.022 µm iid jitter; random phase at the cut.
- Protein density per sarcomere (0.01 µm grid): thick filaments 0.70 over the A-band N(1.60, 0.015) µm (compressed with mass
  conserved if SL < A + Z); thin filaments 0.30 per set over N(1.05, 0.03) µm from each Z (double overlap at short SL);
  Z-disc U(0.07, 0.11) µm wide at U(1.4, 1.7); M-line 0.07 µm at +U(0.2, 0.35). Striation contrast factor U(0.55, 1.0).
  Post (pan-protein stain) Z-discs are 1.25× brighter than in the phase image, so pre and post striation shapes differ.
  The realised mean per-fibril sarcomere length is 1.755 µm (median 1.726; damaged ends stretch the tail).
- Ends: 60 % clean, 25 % frayed (last 1.5–4 µm taper to 45 % width, density ×0.75, striations half-smeared, plus a
  0.3–0.4 µm side strand diverging 8–20°), 15 % damaged (1–3 sarcomeres stretched ×1.2–1.6 or contracted ×0.78–0.9,
  smeared 30–70 %).
- Intrinsic transverse factor (1 + a_i), a_i = −0.010 − 0.010/µm·(d − 1.05 µm) + N(0, 0.004): fibrils follow the gel exactly
  along their axis (a long inclusion is strained by the matrix), but their cross-section swells by its own rule.
  `anisotropy_true` = mean of (E_tr/E_ax − 1) over paired single fibrils outside all defect polygons = -0.01187
  (n = 859). The gel's ±0.3 % in-plane anisotropy combined with the partly aligned orientations contributes about
  −0.15 % of this.

### Defects (polygons in `truth.defects`)
- **fold** (flap polygon) and **fold_overlap** (its mirror image, widened by the drape and clipped to the gel). The flap
  tucked under the main gel when the gel was flipped onto the coverslip (specimen side down). Its specimen face now
  faces the main gel's specimen face, so both layers are in focus together one gel thickness (66 µm pre → 289 µm post)
  above the glass. Flap fibrils are reflected about the crease (G(p_line) + H·(G(p) − G(p_line))), so they appear
  locally un-mirrored at wrong positions. Fibrils within 10 µm of the crease are destroyed (14). The main gel drapes
  back to the glass over 60 µm outside the flap edge (smoothstep), so fibrils there are steeply tilted or out of focus.
  Imaging through the flap adds 0.15 µm blur and 25 % background.
- **bubble**: air dome under the gel at (380, 330), radius 90 µm, 20 µm high at the centre. The core is lifted out of the
  z-stack (lost) unless the tile's autofocus follows the dome. Seen through air, the core is demagnified (a diverging
  lens: −4 % at the centre to +8 % radial at the rim), blurred (1.2 µm extra σ) and dimmed (×0.6). The rim has a 3 µm
  meniscus displacement bump (±4 % radial stretch), up to 0.9 µm extra blur and a +40 % background ring. Polygon radius
  103.5 µm. True E is unaffected by the optics (only by the dome slope).
- **curved**: candidate density about 2× in the ellipse; shapes C arcs (45 %, total bend 0.5–1.5 rad), S (30 %, tangent
  swing ±0.3–0.6 rad), kinks (25 %, 0.3–0.8 rad at 30–70 % of the length); length ≥ 10 µm. Outside the region fibrils are
  only mildly curved (κ ~ N(0, 1/250 µm)). The front-end fits the angle from moments and samples a straight band
  through the centroid, so the fibril leaves the band, the projected period chirps and the DPC edge signal leaks into
  the axial profile.
- **bundled**: 85 % of objects in the ellipse are bundles of 2 (70 %) or 3 (30 %) parallel members: widths 0.7–1.6 µm,
  along-axis offsets ±20 % L, lengths 0.7–1.15 L, angle jitter 0.01 rad, sarcomere lengths = bundle SL × (1 + N(0, 2.5 %)),
  independent phases. Tight (55 %): gaps 0–0.12 µm, one object in pre and post. Loose (45 %): gaps 0.25–0.6 µm, one object
  in pre (DPC cannot resolve it), separate members in post. The truth partner is the widest member; `pairs_alt` lists
  all members (any is scored correct); the others are listed in `split_members`.
- **z_tilt**: excess swelling buckled the gel's specimen face into wrinkles, h = env·10 µm·(1 + sin(2πξ/45 µm + 0.4)),
  with ξ along 70° and a cos² envelope tapering over 25 µm. Height 0–20 µm post, slopes up to ~19°. Projected positions
  are unchanged, but the 3-D length is longer: true E_ax exceeds the projected value by 1.2 % on average (max 3.7 %) for
  fibrils in the zone. The per-tile autofocus sits at the median height, so crests and troughs leave the stack.
- **under_expansion**, **over_expansion**: the Gaussian dilatation sources above.

### Expansion drift and clock
- S(t) = A1(1 − e^(−t/τ1)) + A2 sin(2πt/P2 + φ2) + A3 sign(t)|t/T3|³ with A1 = 0.0072, τ1 = 2600 s, A2 = 0.0009,
  P2 = 2520 s, φ2 = 1.1, A3 = −0.004, T3 = 7200 s. d(t) = (1 + S(t))/(1 + S(t_ref)) − 1 with t_ref = the first clock visit
  (12.8 s). It is a saturating swell plus a 42-min thermal oscillation minus late shrinkage, isotropic about a pivot
  (gel centre + (410, −260) post µm, where the gel sticks to the glass).
- d at the clock visits (t = 13, 1167, 2322, 3484, 4619, 5767, 6951, 7258 s): 0, +0.105, +0.378, +0.369, +0.412, +0.371, +0.189, +0.212 %.
  Range −0.005 … +0.477 %, end of scan +0.212 %.
- Each post tile's part of an object is scaled by its own tile time; objects crossing a seam carry both tiles' drift and
  offsets.
- Clock tile: the most crowded tile within 350 µm (pre) of the centre and >150 µm from every defect (an operator's choice).
  It is visited every 50 tiles and at the end, with a stage-return error of 1 µm per axis per visit and anisotropic
  localisation noise (0.35 µm along / 0.08 µm across the object, growing 10 % per visit from bleaching). Objects
  touching the tile border are dropped, so they come and go. 4 % go missing at random and 0–2 transient extras appear
  per visit. Debris stuck to the glass (lint, bead chains) does not drift. 12–15 objects per visit.

### Pre image: label-free two-axis DPC
- Phase = 0.62 rad/µm × density × projected thickness (elliptical chord) × per-object factor U(0.85, 1.15).
  Background phase: smooth field 0.012 rad (σ 2.5 µm) + dust specks (1 per 300 µm², 0.03–0.15 rad, σ 0.2–0.8 µm).
- OTF: 0.92·Airy-pupil (core FWHM 0.44 µm; told 0.40) + 0.08·exp(−2π·1.2 µm·k) (a 2-D Cauchy halo whose line-spread is a
  Lorentzian), × defocus disc jinc(2πkρ), ρ = |focus error|·0.683, focus error N(0, 0.25 µm) per pre tile.
- DPC: G_x, G_y = 150 × ∂/∂x, ∂/∂y of the blurred phase (units: asymmetry × 1000). Field-dependent offsets
  (6 + 10u − 4v + 5r², −3 + 7v + 3u − 4r²), per-tile offset N(0, 1.5), fixed pattern N(0, 3) per camera pixel, and noise
  18/sqrt(illumination) per pixel, with illumination 1 − 0.30 r² (vignetting).
- Measured: striation modulation of the blurred phase (sd of the periodic part / mean) median 5.4 % (IQR 4.6–6.0 %),
  i.e. "a few percent".

### Post image: pan-protein widefield z-stack
- 3-D slab rendering (0.5 µm slabs, ≤ 40 per object) of elliptical cross-sections: width 2a(1 + a_i)|J n|, height
  2b(1 + a_i)√det J, scaled by the drift. Dye 480 e⁻ per µm of column per unit density × brightness (lognormal σ 0.3).
- OTF per slab: [0.95·Airy-pupil (core FWHM 0.43 µm; told 0.42) + 0.05·exp(−2π·3 µm·k)] × jinc(2πkρ),
  ρ = max(|Δz| − 0.3, 0)·0.683 (NA 0.75 into n = 1.33). The in-focus plane is the stack plane nearest the object's
  mid-height; the z-sum adds all 21 planes (0.75 µm apart) at their true defocus.
- Field-dependent astigmatism: extra Gaussian σ = 0.07 r_f² µm (radial) and 0.20 r_f² µm (tangential), r_f = field radius /
  corner radius, optical axis offset (15, −10) µm. Extra blur in the fold overlap and the bubble (above).
- Illumination (1 − 0.24 r²)(1 + 8 % tilt). Background 380 e⁻ per pixel per plane × (1 + 8 % smooth structure, σ 15 µm).
- Camera: Poisson, read noise 2.0 e⁻, PRNU 1 %, DSNU 1.2 e⁻ + 0.1 % hot pixels (20–80 e⁻), column offsets 0.7 e⁻,
  offset 100 e⁻. The z-sum carries 21× the offsets and √21× the read noise.
- `aspect` (parametric front-end estimate): H/W of the true cross-section over the central 70 % of the measured length,
  widened in quadrature by the centreline's z-spread (tilt) and lateral spread (curvature), plus a residual PSF term
  (0.6 × 2.4 µm axial, 0.6 × told lateral FWHM) and 5 % noise (10 % if defocused). Bundles use the whole bundle width.

### Mosaics, timing, focus
- Post tiles: 2048 × 0.2 µm = 409.6 µm field, 10 % overlap (step 368.64 µm), 19 × 19 grid centred on the told gel centre.
  The 313 tiles that touch the disc of radius 750·e_macro + 150 µm are acquired in raster order (rows of increasing y,
  each left to right). Tile time 20 s + Γ(2, 1 s), with 5 % autofocus retries (+12 s); clock visit 24 s + Γ(2, 1 s);
  scan 2.02 h. `t` = mid-time of the tile holding the centroid.
- Stitching: every tile an object touches renders the whole object with that tile's drift and offset (repeatability
  0.35 µm per axis plus stage scale error), clipped to the tile's mosaic cell. A seam therefore shows a jump (gap or
  repeat), never a doubled intensity. Pre tiles: 204.8 µm field, step 184.32 µm, 0.06 µm stitching residual.
- Per-tile autofocus: the median specimen mid-height over a 9 × 9 grid of the tile, + N(0, 0.4 µm). An object whose
  mid-height lies more than 5 µm beyond the stack is not detected (`out_of_focus`).

### Emulated front-end
- Each object is rendered in its own patch together with every neighbour whose footprint intersects it. Segmentation
  is restricted to the object's own dilated footprint (0.5 µm pre, 2 µm post), so objects merge or split only where
  planted (bundles).
- Pre: Tikhonov reconstruction of the phase from G_x, G_y using the told PSF (α = 0.3), Gaussian smoothing 1 px,
  |φ − median|. Post: Gaussian smoothing 1.5 px, background = 20th percentile.
- Both: threshold 30 % of the 99.5th percentile, binary closing, largest component. Centroid intensity-weighted; angle
  from binary second moments (in [0, π)); length = extent of the mask along the axis; width = area / length.
- `axial`: samples from the smallest projection on (cos angle, sin angle) to the largest, every px, averaged across
  ±width/2 (bilinear). Pre axial = DPC component along the axis; post axial = in-focus plane.
- `cross`: odd length, half-length max(3 µm, 2.2·width) pre and max(12 µm, 2.2·width) post, centred on the axis, averaged
  over `cross_rows` = 50 % of the length (5–101 pre, 5–151 post). Pre cross = DPC component along angle + π/2.
  `zsum_cross` uses the same samples over `zsum_rows` = 70 % of the length (5–251); `zsum_planes` = 21.
- An object is lost (`not_segmented`) if its mask is shorter than 25 % (pre) or 30 % (post) of its expected length.

### Losses and debris
- Lost pre fibrils (no post partner): 74 (6.2 % of 1,198): 49 out of focus (32 at the fold step/drape, 10 on wrinkle crests/troughs, 3 in the bubble core, 4 just outside the fold overlap where the tile focused on the lifted layer), 14 destroyed in the fold crease, 9 detached at random (0.8 %), 2 not segmented. By region: fold 8 of 42, fold_overlap 40 of 93 fibrils, z_tilt 10 of 58, bubble 3 of 28, under_expansion 2 of 14, elsewhere 11 of 870.
- Post debris (no pre partner), 63 detected of 74 planted: 18 striated fragments, 13 bead chains, 12 collagen fibres, 15 lint, 5 gel cracks. Fragments are real striated myofibril
  pieces (4–12 µm, 0.45–0.7 µm wide) that the pre front-end missed. Collagen fibres are 20–60 µm long, 0.3–0.55 µm wide
  and unstriated. Lint on the glass is 40–220 µm post, 3–10 µm wide and 1.5–4× bright. Bead chains on the glass have
  beads every 5.5–9.5 µm post, a fibril-like period. Gel cracks are 80–300 µm post and 0.8–1.8 µm wide.
- Pre-only objects (dust and lint on the coverslip, salt crystals): 7 lint fibres, 5 crystals; `fibrils` lists them with E_ax null.

## Truth file (swell-truth/1 plus extras)
`pairs`, `debris`, `fibrils` (per pre id: `E_ax`, `E_tr`, `E_ax_acq`, `x`, `y` = true pre centroid, `x_post_ref`,
`y_post_ref`, `t`, `tile`, `drift_at_t`, `kind`, `region`, `anisotropy`, `sl_pre`, `width_pre`, `length_pre`, `shape`,
`n_members`, `lost_reason`), `defects`, `anisotropy_true`, `notes`. Extras: `anisotropy_definition`,
`anisotropy_detail`, `pairs_alt`, `split_members`, `debris_kind`, `gel_R_pre`, `gel_center_pre`,
`E_ax_gel_mean_paired`, `E_ax_gel_median_paired`, `transform`, `drift` (parameters, d at every visit), `meta_truth`
(true PSFs, gel centre, e_macro error), `counts`.

## Scoring (`score_s3.py`)
- Matching: recall = correct / pre ids with a true partner. Precision = correct / pre ids the pipeline matched to
  anything (truly unpaired pre ids count against it). A loose bundle matched to any of its members is correct. Also
  reported: wrong partners, matched-but-unpaired, missed, post ids used twice, breakdown by region.
- Debris rejection: fraction of `debris` ids not used as a match value (also by debris kind). Split members are
  reported separately and never penalised.
- Gel-mean E_ax error: mean estimate / mean truth − 1 over correctly matched fibrils with an estimate (plus the median
  version, and `gel.E_ax_median` against the truth median if given).
- Per-fibril E_ax relative error: RMS and the fraction beyond ±2 %, (a) over correct matches, (b) over all returned
  estimates (each pre id's estimate against that pre object's truth, so mismatches count; an estimate for a pre-only
  object counts as beyond 2 %). Also broken down by region.
- E_tr: bias (mean relative error), SD and robust versions over correct matches.
- Defects: for each polygon, the fraction of grid cells whose centre lies inside and that are flagged by ANY flag map
  (with per-flag fractions). False flags: fraction flagged among cells within 0.9 × 750 µm of the centre and more than
  40 µm from every polygon. Flag arrays must be ny × nx (a transposed array is accepted and reported).
- Anisotropy: reads `result.gel.anisotropy` (a number or a dict). It takes the point estimate from the first of
  estimate/value/anisotropy/est/a/delta/mean/median/…, the CI from ci/ci95/interval/lo+hi/ci_lo+ci_hi/… or
  estimate ± 1.96·se, and any call from call/verdict/significant/…. The convention is E_tr/E_ax − 1 (the schema
  example's sign) unless a definition string says E_ax/E_tr or ax − tr, in which case the sign is flipped. Reported:
  error, sign, CI covers truth, CI excludes 0, call right (claims anisotropy with the right sign), and the error under
  the opposite convention.
- Residual drift: OLS slope of (estimate/truth − 1) against the partner's acquisition time over correct matches with
  |error| < 5 % (also on all of them), in % per hour with SE. For reference it gives the slope an uncorrected pipeline
  would see, plus six time-binned median residuals. The planted drift rises and falls, so an uncorrected pipeline shows
  only about 0.08 %/h of linear slope; the binned residuals expose it.
- Transform (informational): mirror right/wrong, scale, and rotation error under the best of the four mirror
  conventions.
- Missing keys are reported as "not provided"; nothing crashes on a partial result (checked by `--selftest`).

## Validation (`validate_s3.py`) and what a naive method gets
Schema conformance: 0 errors (every key, type, odd cross length, zsum_cross length = cross length, angle in [0, π),
axial length consistent with `length`, unique ids, clock format). Truth consistency: 0 errors (every pre id paired or
null, partners unique and present, debris ∪ partners ∪ split members = post ids).

Naive baseline with ORACLE matching (E = post periodogram peak period / pre periodogram peak period, search
1.3–2.4 µm pre):

| region / kind | n | median abs error | beyond +-2 % | rms (abs err < 10 %) |
|---|---|---|---|---|
| clean fibrils | 859 | 0.89 % | 29 % | 2.4 % |
| fold_overlap | 53 | 1.41 % | 47 % | 3.7 % |
| z_tilt | 48 | 1.48 % | 46 % | 2.6 % |
| curved | 44 | 4.65 % | 59 % | 3.4 % |
| fold (flap) | 34 | 1.00 % | 35 % | 2.8 % |
| bundled | 29 | 1.38 % | 41 % | 2.9 % |
| bubble | 25 | 3.08 % | 68 % | 3.8 % |
| over_expansion | 20 | 1.28 % | 35 % | 1.6 % |
| under_expansion | 12 | 1.64 % | 33 % | 2.4 % |

Clean fibrils: median |error| 0.9 %, 29 % beyond ±2 %. The pre striations are visible but noisy (short fibrils are
hard), while the post striations are crisp. Every planted region raises the error.

Clock: a naive robust similarity fit per visit recovers the drift to within ~0.1 %:

| visit | t (s) | objects | naive scale - 1 | truth d |
|---|---|---|---|---|
| 0 | 13 | 13 | 0 | 0 |
| 1 | 1167 | 14 | +0.033 % | +0.105 % |
| 2 | 2322 | 15 | +0.338 % | +0.378 % |
| 3 | 3484 | 13 | +0.368 % | +0.369 % |
| 4 | 4619 | 14 | +0.343 % | +0.412 % |
| 5 | 5767 | 15 | +0.358 % | +0.371 % |
| 6 | 6951 | 13 | +0.161 % | +0.189 % |
| 7 | 7258 | 12 | +0.122 % | +0.212 % |

## Honest simplifications
- The front-end is emulated, not run on full mosaics. Objects never merge or fragment except where planted, `aspect`
  is a parametric model, and illumination and fixed pattern use the tile holding the object's centroid.
- The widefield PSF is an Airy core × geometric defocus disc + halo (no vectorial or spherical-aberration model). DPC is
  the gradient of the blurred phase, not the exact partially coherent transfer function.
- Fibrils follow the gel exactly along their axis (no ruler-vs-gel slip); the intrinsic difference lives in E_tr only.
- Surface tilt changes the projection and focus, but the cross-section is not rotated when the slope runs across the
  fibril. The drift is isotropic in-plane and ignores z.
- Debris lying on the glass keeps its true (unexpanded) size; debris in the gel expands with it.
- Each region holds one failure mode. Outside the regions only mild curvature and the biological imperfections remain,
  so false flags there are genuinely false.

## Files opened while building S3
- `docs/design/obs_schema_v1.md`: the only project file read.
- Own files only otherwise: `software/redteam/` (s3_gen.py, score_s3.py, validate_s3.py, README.md) and `data/sim/S3/`
  (outputs, `profiles.png`, and a development scratch folder `_dev/` that held throw-away check scripts and PNGs and
  was deleted at the end).
- The agent harness pre-loaded the user's and the project's standing instruction files as session
  context (working conventions, nothing about the pipeline). They were not opened, and nothing under
  `software/` (other than this folder), `pm/`, `kit/`, `site/`, `data/` (other than `sim/S3`) or other
  `docs/design/` files was opened or searched.
