"""Pre <-> post matching: find which post-expansion object is which pre-expansion myofibril.

Nothing tells the pipeline the pairing. The steps:
1. Global transform by voting. Each candidate pair (similar length after scaling by e_macro) proposes a rotation
   from its two axis angles; the rotation histogram's peaks are tested by voting on translation; the gel may be
   mirrored (mounted specimen side down), so both handednesses are tried.
2. Iterative closest-candidate assignment with a shrinking gate, refitting a similarity transform each time.
3. Local refinement: each pre object's post position is predicted from an affine fit of its matched neighbours,
   then a one-to-one assignment (Hungarian) settles conflicts. Debris and lost fibrils stay unmatched.
"""
from __future__ import annotations

import math

import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.spatial import cKDTree

BIG = 1e9


def rot(theta: float) -> np.ndarray:
    return np.array([[math.cos(theta), -math.sin(theta)], [math.sin(theta), math.cos(theta)]])


def similarity_fit(src, dst, w=None):
    """Umeyama: dst ≈ s R src + t with a proper rotation R (weighted least squares)."""
    src, dst = np.asarray(src, float), np.asarray(dst, float)
    w = np.ones(len(src)) if w is None else np.asarray(w, float)
    w = w / w.sum()
    ms, md = w @ src, w @ dst
    a, b = src - ms, dst - md
    cov = (b * w[:, None]).T @ a
    u, s, vt = np.linalg.svd(cov)
    d = np.sign(np.linalg.det(u @ vt)) or 1.0
    dm = np.diag([1.0, d])
    r = u @ dm @ vt
    scale = np.trace(np.diag(s) @ dm) / (w @ (a ** 2).sum(1))
    return float(scale), r, md - scale * r @ ms


def mirror_xy(xy, mirror: bool):
    xy = np.asarray(xy, float)
    return xy * np.array([-1.0, 1.0]) if mirror else xy


def mirror_angle(a, mirror: bool):
    a = np.asarray(a, float)
    return np.mod(np.pi - a, np.pi) if mirror else np.mod(a, np.pi)


def _angdiff(a, b):
    """Smallest difference between two undirected axis angles (radians, in [0, π/2])."""
    d = np.mod(a - b, np.pi)
    return np.minimum(d, np.pi - d)


def _global_vote(p_xy, p_ang, p_len, q_xy, q_ang, q_len, e, n_theta_peaks=6):
    """Best (score, theta, t) for one handedness. Votes: rotation first, then translation per rotation peak."""
    ratio = q_len[None, :] / (e * np.maximum(p_len[:, None], 1e-6))
    ii, jj = np.nonzero((ratio > 0.6) & (ratio < 1.7))
    if ii.size == 0:
        return 0, 0.0, np.zeros(2)
    th = np.mod(q_ang[jj] - p_ang[ii], np.pi)
    hist, edges = np.histogram(th, bins=90, range=(0, np.pi))
    sm = hist + 0.5 * (np.roll(hist, 1) + np.roll(hist, -1))
    best = (0, 0.0, np.zeros(2))
    for b in np.argsort(sm)[::-1][:n_theta_peaks]:
        th0 = 0.5 * (edges[b] + edges[b + 1])
        sel = _angdiff(th, th0) < math.radians(3.0)
        for k in (0.0, np.pi):                        # an undirected axis leaves a 180° ambiguity
            r = rot(th0 + k)
            t = q_xy[jj[sel]] - e * p_xy[ii[sel]] @ r.T
            if t.shape[0] == 0:
                continue
            cell = 40.0
            key = np.floor(t / cell).astype(np.int64)
            uniq, inv, cnt = np.unique(key, axis=0, return_inverse=True, return_counts=True)
            m = int(np.argmax(cnt))
            # count the 3x3 neighbourhood of the peak cell, so a peak split across cells is not missed
            near = np.all(np.abs(uniq - uniq[m]) <= 1, axis=1)
            score = int(cnt[near].sum())
            if score > best[0]:
                inside = near[inv.ravel()]
                best = (score, th0 + k, np.median(t[inside], axis=0))
    return best


def _assign(pred, p_ang_pred, p_len_pred, q_xy, q_ang, q_len, gate, sig_d, ang_gate=math.radians(12.0)):
    """One-to-one assignment of predicted pre positions to post objects inside a gate (Hungarian)."""
    tree = cKDTree(q_xy)
    cand = tree.query_ball_point(pred, gate)
    rows, cols, costs = [], [], []
    for i, js in enumerate(cand):
        for j in js:
            da = _angdiff(p_ang_pred[i], q_ang[j])
            if da > ang_gate:
                continue
            lr = math.log(max(q_len[j], 1e-6) / max(p_len_pred[i], 1e-6))
            if abs(lr) > 0.6:
                continue
            d = float(np.hypot(*(pred[i] - q_xy[j])))
            rows.append(i)
            cols.append(j)
            costs.append((d / sig_d) ** 2 + (da / math.radians(4.0)) ** 2 + (lr / 0.25) ** 2)
    match = np.full(len(pred), -1)
    if not rows:
        return match
    ur, ri = np.unique(rows, return_inverse=True)
    uc, ci = np.unique(cols, return_inverse=True)
    cm = np.full((ur.size, uc.size), BIG)
    np.minimum.at(cm, (ri, ci), np.asarray(costs))
    r_ind, c_ind = linear_sum_assignment(cm)
    ok = cm[r_ind, c_ind] < BIG
    match[ur[r_ind[ok]]] = uc[c_ind[ok]]
    return match


def _local_predict(p_xy, q_xy, match, k=12, radius=150.0):
    """Predicted post position of every pre object from an affine fit to its matched neighbours (leave-one-out)."""
    ok = np.where(match >= 0)[0]
    pred = np.full((len(p_xy), 2), np.nan)
    if ok.size < 6:
        return pred
    tree = cKDTree(p_xy[ok])
    for i in range(len(p_xy)):
        kk = min(k + 1, ok.size)
        dist, idx = tree.query(p_xy[i], kk)
        idx = np.atleast_1d(idx)
        dist = np.atleast_1d(dist)
        idx = idx[(dist <= radius) & (ok[idx] != i)]
        if idx.size < 6:
            idx = np.atleast_1d(tree.query(p_xy[i], min(7, ok.size))[1])
            idx = idx[ok[idx] != i][:6]
        src = p_xy[ok[idx]]
        dst = q_xy[match[ok[idx]]]
        x1 = np.c_[src, np.ones(len(src))]
        coef, *_ = np.linalg.lstsq(x1, dst, rcond=None)
        pred[i] = np.r_[p_xy[i], 1.0] @ coef
    return pred


def match_objects(pre_xy, pre_ang, pre_len, post_xy, post_ang, post_len, e_macro, mirror_possible=True):
    """Match pre objects to post objects. Returns (match array: post index or -1 per pre object, info dict)."""
    pre_xy, post_xy = np.asarray(pre_xy, float), np.asarray(post_xy, float)
    pre_ang, post_ang = np.mod(np.asarray(pre_ang, float), np.pi), np.mod(np.asarray(post_ang, float), np.pi)
    pre_len, post_len = np.asarray(pre_len, float), np.asarray(post_len, float)
    best = None
    for mirror in ((False, True) if mirror_possible else (False,)):
        p_xy, p_ang = mirror_xy(pre_xy, mirror), mirror_angle(pre_ang, mirror)
        score, th, t = _global_vote(p_xy, p_ang, pre_len, post_xy, post_ang, post_len, e_macro)
        if best is None or score > best[0]:
            best = (score, th, t, mirror)
    score, th, t, mirror = best
    p_xy, p_ang = mirror_xy(pre_xy, mirror), mirror_angle(pre_ang, mirror)
    s, r = e_macro, rot(th)
    match = np.full(len(pre_xy), -1)
    for gate in (120.0, 60.0, 30.0):
        pred = s * p_xy @ r.T + t
        ang_pred = np.mod(p_ang + math.atan2(r[1, 0], r[0, 0]), np.pi)
        match = _assign(pred, ang_pred, s * pre_len, post_xy, post_ang, post_len, gate, sig_d=gate / 3)
        ok = match >= 0
        if ok.sum() < 6:
            break
        s, r, t = similarity_fit(p_xy[ok], post_xy[match[ok]])
        res = np.linalg.norm(post_xy[match[ok]] - (s * p_xy[ok] @ r.T + t), axis=1)
        keep = res < np.median(res) + 4 * 1.4826 * np.median(np.abs(res - np.median(res))) + 1e-9
        s, r, t = similarity_fit(p_xy[ok][keep], post_xy[match[ok]][keep])
    rot_angle = math.atan2(r[1, 0], r[0, 0])
    ang_pred = np.mod(p_ang + rot_angle, np.pi)
    # local refinement: neighbours predict each object's place, which follows non-rigid gel deformation
    for _ in range(2):
        pred = _local_predict(p_xy, post_xy, match)
        bad = ~np.isfinite(pred).all(1)
        pred[bad] = s * p_xy[bad] @ r.T + t
        ok = match >= 0
        if ok.sum() >= 6:
            res = np.linalg.norm(post_xy[match[ok]] - pred[ok], axis=1)
            sig = max(1.4826 * float(np.median(res)), 0.5)
        else:
            sig = 10.0
        match = _assign(pred, ang_pred, s * pre_len, post_xy, post_ang, post_len, gate=max(6 * sig, 4.0),
                        sig_d=max(sig, 0.3))
    info = {"scale": float(s), "rotation": float(rot_angle), "mirror": bool(mirror),
            "translation": [float(t[0]), float(t[1])], "vote_score": int(score),
            "n_matched": int((match >= 0).sum()), "n_pre": int(len(pre_xy)), "n_post": int(len(post_xy))}
    return match, info
