"""The ruler pipeline: observations (swell-obs/1) in, result (swell-result/1) out.

Steps: clock-tile drift correction -> pre/post matching -> per-myofibril rulers (axial period ratio, transverse
width ratio) -> landmark local affine -> maps and flags -> gel-level calls. Nothing here reads a truth file.
"""
from __future__ import annotations

import math
import time

import numpy as np

from . import __version__
from .drift import clock_scales, correct_post
from .matching import match_objects, mirror_angle, mirror_xy
from .profiles import S2F, axial_factor, centred_axis, fit_shape_post, fit_width_post, fit_width_pre
from .strainmap import anisotropy_call, build_maps, distortion_curve, orientation_call, robust_sd

NOTES = {
    "flags": {
        "local_E": "local axial expansion (period ratio) or local area change (landmarks) differs from the gel median "
                   "by more than max(1%, 4 standard errors)",
        "fibril_vs_gel": "the myofibrils' own axial factor differs from the gel's local factor (under-digestion, slipping)",
        "gel_stretch": "the landmark map is locally anisotropic (the gel was stretched)",
        "non_affine": "neighbours' positions fit no local affine map: tear, fold or shear",
        "coverage_hole": "most pre objects here have no partner in the post image: bubble, lost region or fold",
    },
    "maps": "local_E, anisotropy, fibril_vs_gel, landmark_anisotropy, landmark_area: fractions relative to the gel "
            "median; fit_residual_um, distortion_um: pre-expansion µm; unmatched_fraction: 0-1",
    "calls": "anisotropy: 'anisotropic' if the 95% CI lies beyond ±1%, 'isotropic' if the 90% CI lies inside ±1%; "
             "orientation: 'stretched' if the 95% CI of the amplitude lies above 0.5%",
}


def _arr(o, key):
    return np.asarray(o.get(key, []), float)


def _grid_list(v, gmeta):
    a = np.asarray(v, float).reshape(gmeta["ny"], gmeta["nx"])
    return [[None if not np.isfinite(x) else round(float(x), 6) for x in row] for row in a]


def run(obs: dict, verbose: bool = False) -> dict:
    t0 = time.time()
    meta = obs["meta"]
    pre = obs["pre"]
    post = [dict(o) for o in obs["post"]]
    e_macro = float(meta["e_macro"])
    px_pre, px_post = float(meta["px_pre_um"]), float(meta["px_post_um"])
    sig_pre = float(meta["psf_pre_fwhm_um"]) / S2F
    sig_post = float(meta["psf_post_fwhm_um"]) / S2F
    dof = float(meta.get("dof_post_um", 1.64))
    mode = meta.get("pre_mode", "dpc")

    # 1. drift: the clock tile gives s(t); every post object goes back to the reference time
    ts, ss, ns = clock_scales(obs.get("clock") or [])
    if ts.size >= 2:
        correct_post(post, meta, ts, ss)
    drift = {"clock_visits": int(ts.size), "t": ts.tolist(), "scale": ss.tolist(),
             "span_pct": float(100 * (ss.max() - ss.min())) if ss.size else 0.0}

    # 2. matching
    pre_xy = np.array([[o["x"], o["y"]] for o in pre], float)
    pre_ang = np.array([o["angle"] for o in pre], float)
    pre_len = np.array([o["length"] for o in pre], float)
    post_xy = np.array([[o["x"], o["y"]] for o in post], float)
    post_ang = np.array([o["angle"] for o in post], float)
    post_len = np.array([o["length"] for o in post], float)
    match, info = match_objects(pre_xy, pre_ang, pre_len, post_xy, post_ang, post_len, e_macro,
                                bool(meta.get("mirror_possible", True)))
    if verbose:
        print(f"  matched {info['n_matched']} of {info['n_pre']} (mirror {info['mirror']}) in {time.time() - t0:.0f} s")

    # 3. rulers per matched myofibril
    mi = np.where(match >= 0)[0]
    n = mi.size
    e_ax = np.full(n, np.nan)
    e_tr = np.full(n, np.nan)
    diag = []
    for k, i in enumerate(mi):
        o, q = pre[i], post[match[i]]
        pscale = q.get("_px_scale", 1.0)
        a_pre = mirror_angle(np.array([o["angle"]]), info["mirror"])[0] + info["rotation"]
        d_pre = np.array([math.cos(a_pre), math.sin(a_pre)])
        d_post = np.array([math.cos(q["angle"]), math.sin(q["angle"])])
        y_pre, y_post = _arr(o, "axial"), _arr(q, "axial")
        u_pre = centred_axis(y_pre.size, px_pre)
        u_post = centred_axis(y_post.size, px_post * pscale)
        if d_pre @ d_post < 0:                      # the post profile runs the other way: reverse it
            y_post = y_post[::-1]
        ax = axial_factor(u_pre, y_pre, u_post, y_post, e_macro)
        e_ax[k] = ax["E"]
        try:
            asp = float(q.get("aspect", 1.0))
            w_z, n_shape = fit_shape_post(_arr(q, "zsum_cross"), px_post * pscale, sig_post)
            w_post = fit_width_post(_arr(q, "cross"), px_post * pscale, sig_post, asp, n_shape, dof, w_guess=w_z)
            w_pre = fit_width_pre(_arr(o, "cross"), px_pre, sig_pre, asp, n_shape, mode,
                                  w_guess=float(np.clip(w_z / e_macro, 0.4, 3.0)))
            e_tr[k] = w_post / w_pre
        except (ValueError, np.linalg.LinAlgError):
            pass
        diag.append({"r2": ax["r2"], "n_discs": ax["n_discs"], "modulation": ax["modulation"],
                     "q": ax.get("q")})      # q = m/σ from the fit's own residuals: gain-free (D-46 go/no-go)
    # QC: an axial fit whose pre profile follows the post ladder far worse than the gel's typical fit is rejected
    # (wrong partner, damaged fragment, debris overlap). Relative to this gel's own R² spread, so it adapts to
    # the pre-image contrast instead of assuming one.
    r2 = np.array([d["r2"] for d in diag], float)
    okr = np.isfinite(e_ax)
    rejected = 0
    if okr.sum() >= 20:
        med = float(np.median(r2[okr]))
        sd = robust_sd(r2[okr])
        bad = okr & (r2 < med - 4 * max(sd, 0.02))
        rejected = int(bad.sum())
        e_ax[bad] = np.nan
        for k in np.where(bad)[0]:
            diag[k]["rejected"] = "low R² for this gel"
    if verbose:
        print(f"  rulers: {np.isfinite(e_ax).sum()} axial ({rejected} rejected), {np.isfinite(e_tr).sum()} "
              f"transverse in {time.time() - t0:.0f} s")

    # 4. landmarks, maps, flags (maps in pre coordinates; the similarity part uses the un-mirrored frame)
    matched = match >= 0
    p_m = pre_xy[mi]
    q_m = post_xy[match[mi]]
    phi = pre_ang[mi]
    grid, gmeta, maps, flags, per, sup = build_maps(pre_xy, matched, p_m, q_m, phi, e_ax, e_tr, info["scale"],
                                                    mirror=info["mirror"])
    floor = float(np.median(per["res_rms"])) * math.sqrt(16 / 13)
    curve = distortion_curve(mirror_xy(p_m, info["mirror"]), per["resid"], floor)

    # 5. gel-level calls
    t_post = np.array([post[j].get("t", 0.0) for j in match[mi]], float)
    fvg = e_ax / per["e_land_ax"] - 1
    okd = np.isfinite(fvg)
    drift_slope = None
    if okd.sum() > 20 and np.ptp(t_post[okd]) > 0:
        b = np.polyfit(t_post[okd] / 3600.0, fvg[okd], 1)
        drift_slope = float(100 * b[0])
    gel = {
        "E_ax_median": float(np.nanmedian(e_ax)) if np.isfinite(e_ax).any() else None,
        "E_ax_mean": float(np.nanmean(e_ax)) if np.isfinite(e_ax).any() else None,
        "E_tr_median": float(np.nanmedian(e_tr)) if np.isfinite(e_tr).any() else None,
        "E_land_median": float(np.median(per["e_land_ax"])),
        "n_pre": int(len(pre)), "n_post": int(len(post)), "n_matched": int(n),
        "n_axial": int(np.isfinite(e_ax).sum()), "n_transverse": int(np.isfinite(e_tr).sum()),
        "n_axial_rejected_low_r2": rejected,
        "anisotropy": anisotropy_call(e_ax, e_tr, e_land_tr=per["e_land_tr"]),
        "orientation": orientation_call(e_ax, phi),
        "drift": dict(drift, residual_slope_pct_per_h=drift_slope),
        "distortion_curve": curve, "localisation_floor_um": floor,
        "flagged_fraction": {k: float(v[sup["support_all"] >= 3].mean()) if (sup["support_all"] >= 3).any() else 0.0
                             for k, v in flags.items()},
        "per_fibril_spread": {"E_ax_robust_sd": robust_sd(e_ax / np.nanmedian(e_ax) - 1)
                              if np.isfinite(e_ax).any() else None},
    }
    fibrils = {}
    for k, i in enumerate(mi):
        fibrils[pre[i]["id"]] = {
            "post_id": post[match[i]]["id"],
            "E_ax": None if not np.isfinite(e_ax[k]) else float(e_ax[k]),
            "E_tr": None if not np.isfinite(e_tr[k]) else float(e_tr[k]),
            "E_land_ax": float(per["e_land_ax"][k]), "E_land_tr": float(per["e_land_tr"][k]),
            "fit_residual_um": float(per["res_rms"][k]), **diag[k]}
    result = {
        "schema": "swell-result/1", "gel_id": obs.get("gel_id"), "software": f"swell_ruler {__version__}",
        "matches": {o["id"]: (post[match[i]]["id"] if match[i] >= 0 else None) for i, o in enumerate(pre)},
        "transform": {"scale": info["scale"], "rotation": info["rotation"], "mirror": info["mirror"],
                      "translation": info["translation"]},
        "fibrils": fibrils, "gel": gel, "grid": gmeta,
        "flags": {k: [[int(x) for x in row] for row in np.asarray(v).reshape(gmeta["ny"], gmeta["nx"])]
                  for k, v in flags.items()},
        "maps": {k: _grid_list(v, gmeta) for k, v in maps.items()},
        "notes": NOTES, "runtime_s": round(time.time() - t0, 1),
    }
    return result
