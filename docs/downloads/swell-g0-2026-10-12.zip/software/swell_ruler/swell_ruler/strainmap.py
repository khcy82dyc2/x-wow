"""Whole-gel maps, QC flags and gel-level statistics (D-34), computed from matched objects only.

Maps live on a grid in pre coordinates. Flags (1 = QC flagged this place):
  local_E        local axial expansion (period ratio) or local area change (landmarks) off the gel median
  fibril_vs_gel  the fibrils' own axial factor disagrees with the gel's local factor (under-digestion)
  gel_stretch    the landmark map is locally anisotropic (the gel was stretched)
  non_affine     neighbours' positions cannot be explained by any local affine map (tear, fold, shear)
  coverage_hole  most pre objects here found no partner in the post image (bubble, lost region, fold)
Gel-level calls use effect sizes, not "the confidence interval excludes 0": with hundreds of fibrils, a
-0.1% bias is statistically significant and practically meaningless (fresh AI review, 2026-10-09).
"""
from __future__ import annotations

import math

import numpy as np
from scipy import stats
from scipy.spatial import cKDTree

GRID_STEP, KERNEL = 20.0, 45.0
FLOOR = 0.01              # 1% local deviation (the 4-SE term dominates where fibrils are sparse)
ANISO_SESOI = 0.01        # smallest axial-vs-transverse anisotropy worth reporting (≈ transverse calibration bias, D-32)
ANISO_GATE = 0.03         # D-32 gel-level isotropy gate (95% CI within ±3%)
ORIENT_SESOI = 0.005      # smallest orientation amplitude (gel stretch) worth reporting
ORIENT_GATE = 0.02        # Order 7 gate: orientation amplitude ≤ 2%


def robust_sd(x):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return float("nan")
    return 1.4826 * float(np.median(np.abs(x - np.median(x))))


def local_affine(pre, post, scale, radius=100.0, k_min=10):
    """Local deformation gradient per object: affine fit of its neighbours' centroids (within 100 µm, ≥ 10).
    The fit residual (pre µm) exposes tears and folds, which no affine map can follow."""
    tree = cKDTree(pre)
    a_loc = np.zeros((len(pre), 2, 2))
    res_rms = np.zeros(len(pre))
    for i in range(len(pre)):
        idx = tree.query_ball_point(pre[i], radius)
        if len(idx) < k_min:
            idx = tree.query(pre[i], min(k_min, len(pre)))[1]
        idx = np.atleast_1d(np.asarray(idx))
        x1 = np.c_[pre[idx], np.ones(idx.size)]
        coef, *_ = np.linalg.lstsq(x1, post[idx], rcond=None)
        a_loc[i] = coef[:2].T
        res_rms[i] = np.sqrt(np.mean(np.sum((x1 @ coef - post[idx]) ** 2, axis=1))) / scale
    return a_loc, res_rms


def smooth_map(pos, val, grid, robust=True):
    """Gaussian-kernel local average on the grid. robust=True (period-ratio maps only) adds two biweight passes
    against each object's own local value with a wide cut (9 robust SD), so a failed fit cannot paint a fake defect
    while a real -4% patch survives. Landmark maps are smooth and precise and are never robustified."""
    ok = np.isfinite(val)
    p, v = pos[ok], val[ok]
    if p.shape[0] == 0:
        return np.full(len(grid), np.nan), np.zeros(len(grid))
    w = np.exp(-((grid[:, None, :] - p[None, :, :]) ** 2).sum(-1) / (2 * KERNEL ** 2))
    sw = w.sum(1)
    b = np.ones(v.size)
    if robust:
        wf = np.exp(-((p[:, None, :] - p[None, :, :]) ** 2).sum(-1) / (2 * KERNEL ** 2))
        for _ in range(2):
            loc = (wf @ (b * v)) / np.maximum(wf @ b, 1e-12)
            r = v - loc
            sc = max(robust_sd(r), 1e-9)
            b = np.where(np.abs(r) < 9.0 * sc, (1 - (r / (9.0 * sc)) ** 2) ** 2, 0.0)
    return (w @ (b * v)) / np.maximum(w @ b, 1e-12), sw


def make_grid(pre_xy, step=GRID_STEP):
    lo = np.floor((pre_xy.min(0) - 2 * step) / step) * step
    hi = np.ceil((pre_xy.max(0) + 2 * step) / step) * step
    gx = np.arange(lo[0], hi[0] + step / 2, step)
    gy = np.arange(lo[1], hi[1] + step / 2, step)
    xx, yy = np.meshgrid(gx, gy)
    return np.c_[xx.ravel(), yy.ravel()], {"x0": float(gx[0]), "y0": float(gy[0]), "step": float(step),
                                           "nx": int(gx.size), "ny": int(gy.size)}


RULER_AGREE = 0.03   # transverse width ratio vs the landmark ruler across fibrils: beyond this, no anisotropy call


def anisotropy_call(e_ax, e_tr, seed=1, e_land_tr=None):
    """Intrinsic anisotropy E_ax/E_tr - 1: median of per-fibril log ratios with bootstrap CIs, and a call:
    'anisotropic' when the 95% CI lies entirely beyond ±SESOI; 'isotropic' when the 90% CI lies inside ±SESOI
    (two one-sided tests at 5%); otherwise 'inconclusive'. The D-32 gate is reported separately.
    Guard (after red-team gel S3): if the transverse width ratio and the calibration-free landmark ruler disagree
    by more than RULER_AGREE (median over fibrils), the width ratio is not trusted and the call is 'blocked'."""
    ok = np.isfinite(e_ax) & np.isfinite(e_tr) & (e_tr > 0)
    la = np.log(e_ax[ok] / e_tr[ok])
    if la.size < 20:
        return {"n": int(la.size), "call": "too few fibrils"}
    if e_land_tr is not None:
        okl = ok & np.isfinite(e_land_tr) & (e_land_tr > 0)
        if okl.sum() >= 20:
            dis = float(np.expm1(np.median(np.log(e_tr[okl] / e_land_tr[okl]))))
            if abs(dis) > RULER_AGREE:
                return {"n": int(la.size), "est": float(np.expm1(np.median(la))), "call": "blocked",
                        "why": f"transverse ruler disagrees with the landmark ruler by {100 * dis:+.1f}% "
                               f"(limit ±{100 * RULER_AGREE:.0f}%)", "tr_vs_landmark": dis,
                        "sesoi": ANISO_SESOI, "gate_D32_pass": False}
    boot = np.median(np.random.default_rng(seed).choice(la, (2000, la.size)), axis=1)
    est = float(np.expm1(np.median(la)))
    ci95 = [float(np.expm1(np.percentile(boot, 2.5))), float(np.expm1(np.percentile(boot, 97.5)))]
    ci90 = [float(np.expm1(np.percentile(boot, 5))), float(np.expm1(np.percentile(boot, 95)))]
    if ci95[0] > ANISO_SESOI or ci95[1] < -ANISO_SESOI:
        call = "anisotropic"
    elif ci90[0] > -ANISO_SESOI and ci90[1] < ANISO_SESOI:
        call = "isotropic"
    else:
        call = "inconclusive"
    return {"n": int(la.size), "est": est, "ci95": ci95, "ci90": ci90, "sesoi": ANISO_SESOI, "call": call,
            "gate_D32_pass": bool(ci95[0] > -ANISO_GATE and ci95[1] < ANISO_GATE)}


def orientation_call(e_ax, phi, seed=2):
    """Gel stretch from the orientation dependence of E_ax: log E_ax = b0 + b1 cos 2φ + b2 sin 2φ. Amplitude
    2·hypot(b1, b2) with a bootstrap CI; 'stretched' when the CI's lower end exceeds SESOI; the Order 7 gate
    passes when the upper end is ≤ 2%."""
    ok = np.isfinite(e_ax)
    if ok.sum() < 20:
        return {"n": int(ok.sum()), "call": "too few fibrils"}
    lv = np.log(e_ax[ok] / np.median(e_ax[ok]))
    ph = phi[ok]
    xmat = np.c_[np.ones(ph.size), np.cos(2 * ph), np.sin(2 * ph)]
    beta, *_ = np.linalg.lstsq(xmat, lv, rcond=None)
    rss1 = float(np.sum((lv - xmat @ beta) ** 2))
    rss0 = float(np.sum((lv - lv.mean()) ** 2))
    fstat = ((rss0 - rss1) / 2) / max(rss1 / (lv.size - 3), 1e-30)
    rng = np.random.default_rng(seed)
    amps = []
    for _ in range(1000):
        i = rng.integers(0, lv.size, lv.size)
        b, *_ = np.linalg.lstsq(xmat[i], lv[i], rcond=None)
        amps.append(2 * math.hypot(b[1], b[2]))
    ci = [float(np.percentile(amps, 2.5)), float(np.percentile(amps, 97.5))]
    amp = float(2 * math.hypot(beta[1], beta[2]))
    return {"n": int(ok.sum()), "amplitude": amp, "ci95": ci,
            "axis_deg": float(math.degrees(0.5 * math.atan2(beta[2], beta[1])) % 180),
            "p": float(stats.f.sf(fstat, 2, lv.size - 3)), "sesoi": ORIENT_SESOI,
            "call": "stretched" if ci[0] > ORIENT_SESOI else ("unstretched" if ci[1] < ORIENT_SESOI else "inconclusive"),
            "gate_pass": bool(ci[1] <= ORIENT_GATE)}


def build_maps(pre_xy_all, matched, pre_xy, post_xy, phi, e_ax, e_tr, scale, mirror=False):
    """Maps and flags. pre_xy_all: every pre object (for coverage); matched: bool per pre object; the rest are
    arrays over matched objects only (pre position, post position in a frame where the gel is not mirrored)."""
    grid, gmeta = make_grid(pre_xy_all)
    a_loc, res_rms = local_affine(pre_xy, post_xy, scale)
    u = np.c_[np.cos(phi), np.sin(phi)]
    v = np.c_[-np.sin(phi), np.cos(phi)]
    e_land_ax = np.linalg.norm(np.einsum("nij,nj->ni", a_loc, u), axis=1)
    e_land_tr = np.linalg.norm(np.einsum("nij,nj->ni", a_loc, v), axis=1)
    sv = np.linalg.svd(a_loc, compute_uv=False)
    land_aniso = sv[:, 0] / sv[:, 1] - 1
    liso = np.sqrt(np.abs(np.linalg.det(a_loc)))
    med_ax = float(np.nanmedian(e_ax)) if np.isfinite(e_ax).any() else float("nan")

    m_ax, sw = smooth_map(pre_xy, e_ax / med_ax - 1, grid)
    aniso_fib = e_ax / e_tr - 1
    m_an, _ = smooth_map(pre_xy, aniso_fib - np.nanmedian(aniso_fib), grid)
    fvg = e_ax / e_land_ax - 1
    m_fvg, _ = smooth_map(pre_xy, fvg - np.nanmedian(fvg), grid)
    m_lan, sw_all_m = smooth_map(pre_xy, land_aniso - np.median(land_aniso), grid, robust=False)
    m_liso, _ = smooth_map(pre_xy, liso / np.median(liso) - 1, grid, robust=False)
    m_res, _ = smooth_map(pre_xy, res_rms, grid, robust=False)
    from .matching import mirror_xy
    src = mirror_xy(pre_xy, mirror)                 # a mirrored gel needs the mirrored frame for a similarity fit
    s_fit = similarity_core(src, post_xy)
    resid = (post_xy - (s_fit[0] * src @ s_fit[1].T + s_fit[2])) @ s_fit[1] / s_fit[0]
    m_disp, _ = smooth_map(pre_xy, np.linalg.norm(resid, axis=1), grid, robust=False)
    unmatched = (~matched).astype(float)
    m_un, sw_all = smooth_map(pre_xy_all, unmatched, grid, robust=False)

    sup = sw >= 3
    sup_all = sw_all >= 3

    def se(x, w):
        return robust_sd(x) / np.sqrt(np.maximum(w, 1e-9))

    rel_ax = e_ax / med_ax - 1
    flags = {
        "local_E": sup & ((np.abs(m_ax) > np.maximum(FLOOR, 4 * se(rel_ax, sw)))
                          | (np.abs(m_liso) > np.maximum(FLOOR, 4 * se(liso / np.median(liso) - 1, sw_all_m)))),
        "fibril_vs_gel": sup & (np.abs(m_fvg) > np.maximum(FLOOR, 4 * se(fvg, sw))),
        "gel_stretch": (sw_all_m >= 3) & (m_lan > np.maximum(FLOOR, 4 * se(land_aniso, sw_all_m))),
        "non_affine": (sw_all_m >= 3) & (m_res > max(2 * float(np.median(res_rms)), 0.3)),
        "coverage_hole": sup_all & (m_un > 0.5),
    }
    maps = {"local_E": m_ax, "anisotropy": m_an, "fibril_vs_gel": m_fvg, "landmark_anisotropy": m_lan,
            "landmark_area": m_liso, "fit_residual_um": m_res, "distortion_um": m_disp,
            "unmatched_fraction": m_un}
    per = {"e_land_ax": e_land_ax, "e_land_tr": e_land_tr, "res_rms": res_rms, "land_aniso": land_aniso,
           "resid": resid, "a_loc": a_loc}
    return grid, gmeta, maps, flags, per, {"support": sw, "support_all": sw_all}


def similarity_core(src, dst):
    from .matching import similarity_fit
    s, r, t = similarity_fit(src, dst)
    for _ in range(2):
        res = np.linalg.norm(dst - (s * src @ r.T + t), axis=1)
        keep = res < np.median(res) + 4 * 1.4826 * np.median(np.abs(res - np.median(res))) + 1e-12
        s, r, t = similarity_fit(src[keep], dst[keep])
    return s, r, t


def distortion_curve(pre_xy, resid, floor_um, seed=3):
    """RMS length-measurement error vs length after the similarity fit (pre µm), with the localisation floor
    (from the local-affine residuals) removed in quadrature."""
    rng = np.random.default_rng(seed)
    n = len(pre_xy)
    i1, i2 = rng.integers(0, n, 30000), rng.integers(0, n, 30000)
    l_pre = np.linalg.norm(pre_xy[i1] - pre_xy[i2], axis=1)
    reg = pre_xy + resid
    err = np.linalg.norm(reg[i1] - reg[i2], axis=1) - l_pre
    bins = np.array([10, 25, 50, 100, 200, 400, 800, 1400])
    curve = []
    for lo, hi in zip(bins[:-1], bins[1:]):
        m = (l_pre >= lo) & (l_pre < hi)
        if m.sum() > 50:
            rms = float(np.sqrt(np.mean(err[m] ** 2)))
            curve.append({"l_mid": float(np.sqrt(lo * hi)), "rms": rms,
                          "rms_corrected": float(math.sqrt(max(rms ** 2 - floor_um ** 2, 0.0)))})
    return curve
