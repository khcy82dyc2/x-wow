"""A synthetic image pair for trying the tool without a microscope.

Renders a pre-expansion polarised-light image of ~24 isolated myofibrils (bright birefringent A-bands on a dark
field) and the matching post-expansion fluorescence image: expanded 4.5×, rotated, shifted, with a planted patch
that expanded 3% less. Truth comes back with the images, so the demo can score itself.
"""
from __future__ import annotations

import math

import numpy as np
from scipy import ndimage as ndi


def _place(rng, n, field, min_sep, margin):
    pts = []
    tries = 0
    while len(pts) < n and tries < 20000:
        tries += 1
        p = rng.uniform(margin, field - margin, 2)
        if all(np.hypot(*(p - q)) >= min_sep for q in pts):
            pts.append(p)
    return np.array(pts)


def _local(xx, yy, c, ang):
    u = np.array([math.cos(ang), math.sin(ang)])
    t = (xx - c[0]) * u[0] + (yy - c[1]) * u[1]
    n = -(xx - c[0]) * u[1] + (yy - c[1]) * u[0]
    return t, n


def make_pair(seed=0, n_fibrils=24, field_um=120.0, px=0.194, e=4.5, rot=0.5, defect_drop=0.03):
    rng = np.random.default_rng(seed)
    cen = _place(rng, n_fibrils, field_um, 22.0, 14.0)
    n_f = len(cen)
    ang = rng.uniform(0, np.pi, n_f)
    length = rng.uniform(14.0, 22.0, n_f)
    width = np.clip(rng.normal(1.2, 0.15, n_f), 0.9, 1.6)
    sl = rng.normal(1.69, 0.05, n_f)
    defect_c = np.array([0.72, 0.72]) * field_um
    in_defect = np.hypot(*(cen - defect_c).T) < 32.0
    e_local = e * (1 - defect_drop * in_defect)

    npx = int(field_um / px)
    yy, xx = (np.mgrid[0:npx, 0:npx] + 0.0) * px
    pre = np.full((npx, npx), 40.0)
    for i in range(n_f):
        t, nn = _local(xx, yy, cen[i], ang[i])
        inside = (np.abs(t) < length[i] / 2) & (np.abs(nn) < width[i] / 2)
        if not inside.any():
            continue
        thick = np.sqrt(np.clip(1 - (2 * nn / width[i]) ** 2, 0, None)) * width[i]
        ph = (t + length[i] / 2) / sl[i] + rng.uniform(0, 1)
        stri = 1 + 0.25 * (0.7 * np.cos(2 * np.pi * ph) + 0.3 * np.cos(4 * np.pi * ph))
        pre += np.where(np.abs(t) < length[i] / 2, 900.0 * thick ** 2 * stri, 0.0)
    pre = ndi.gaussian_filter(pre, 0.55 / 2.3548 / px)
    pre = rng.poisson(np.clip(pre, 0, None)).astype(np.float32)

    # post: similarity transform of the centres plus the local defect, then render expanded fluorescence
    r = np.array([[math.cos(rot), -math.sin(rot)], [math.sin(rot), math.cos(rot)]])
    centre = np.array([field_um / 2, field_um / 2])
    post_field = field_um * e * 1.05
    shift = np.array([post_field / 2, post_field / 2])
    pc = (cen - centre) @ r.T * e + shift
    # the defect pulls fibrils towards its centre: local scale e_local about the defect centre
    dc = (defect_c - centre) @ r.T * e + shift
    pc = np.where(in_defect[:, None], dc + (pc - dc) * (e_local[:, None] / e), pc)
    pang = (ang + rot) % np.pi
    npx2 = int(post_field / px)
    post = np.full((npx2, npx2), 30.0, np.float32)
    for i in range(n_f):
        ei = e_local[i]
        hl, hw = length[i] * ei / 2, width[i] * ei / 2
        x0, x1 = int(max((pc[i, 0] - hl - 6) / px, 0)), int(min((pc[i, 0] + hl + 6) / px, npx2))
        y0, y1 = int(max((pc[i, 1] - hl - 6) / px, 0)), int(min((pc[i, 1] + hl + 6) / px, npx2))
        sy, sx = np.mgrid[y0:y1, x0:x1]
        t, nn = _local(sx * px, sy * px, pc[i], pang[i])
        along = (t + hl) / (sl[i] * ei)
        f = along - np.floor(along)
        zd = np.exp(-0.5 * ((np.minimum(f, 1 - f) * sl[i] * ei) / (0.05 * ei)) ** 2)
        aband = (np.abs(f - 0.5) * sl[i] * ei < 1.6 * ei / 2) * 0.6
        prof = (zd + aband) * (np.abs(t) < hl) * (np.abs(nn) < hw)
        post[y0:y1, x0:x1] += (300.0 * prof).astype(np.float32)
    post = ndi.gaussian_filter(post, 0.41 / 2.3548 / px)
    post = rng.poisson(np.clip(post, 0, None)).astype(np.float32)
    truth = {"E": e, "E_local": e_local.tolist(), "in_defect": in_defect.tolist(), "pre_centres": cen.tolist(),
             "rotation": rot, "defect_centre_pre": defect_c.tolist(), "defect_radius_pre": 32.0,
             "defect_drop": defect_drop}
    return pre, post, truth
