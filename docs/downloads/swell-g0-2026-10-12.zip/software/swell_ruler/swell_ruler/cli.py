"""Command line: swell-ruler images | obs | demo.

  swell-ruler images PRE.tif POST.tif --px-pre 0.194 --px-post 0.194 --e-macro 4.5 [--pre-mode pol] [--out DIR]
  swell-ruler obs OBS.json[.gz] [--out DIR]
  swell-ruler demo [--out DIR]
  swell-ruler stripes IMAGE.tif --px 0.16 [--mode bf]      (evidence-ladder rungs 2 and 3: no expansion needed)
Each writes DIR/result.json (swell-result/1), DIR/summary.md and, if matplotlib is installed, DIR/strain_map.png.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

from . import __version__
from .io import load, save, validate_obs
from .pipeline import run


def read_image(path):
    """Any TIFF, PNG or JPEG as a 2-D float image. Colour images (phone and eyepiece cameras) become grey by
    averaging the colour channels; an alpha channel is dropped."""
    p = Path(path)
    a = None
    if p.suffix.lower() in (".tif", ".tiff"):
        try:
            import tifffile
            a = np.asarray(tifffile.imread(p), float)
        except ImportError:
            pass
    if a is None:
        from PIL import Image
        a = np.asarray(Image.open(p), float)
    if a.ndim == 3 and a.shape[-1] in (3, 4):
        a = a[..., :3].mean(axis=-1)
    if a.ndim != 2 and not (a.ndim == 3 and p.suffix.lower() in (".tif", ".tiff")):
        raise SystemExit(f"{p}: expected a 2-D image, got shape {a.shape}")
    return a


def summary(res) -> str:
    g = res["gel"]
    an, orr = g["anisotropy"], g["orientation"]
    lines = [f"# swell_ruler {__version__} result: {res.get('gel_id')}", "",
             f"- matched {g['n_matched']} of {g['n_pre']} pre-expansion myofibrils "
             f"({g['n_post']} post objects; mirror {res['transform']['mirror']})",
             f"- axial expansion (period ratio): median {g['E_ax_median']:.4f} over {g['n_axial']} myofibrils"
             if g["E_ax_median"] else "- axial expansion: no myofibril long enough (≥ 8 sarcomeres)",
             f"- transverse expansion (width ratio): median {g['E_tr_median']:.4f} over {g['n_transverse']}"
             if g["E_tr_median"] else "- transverse expansion: not measured",
             f"- landmark expansion (positions): median {g['E_land_median']:.4f}",
             f"- anisotropy E_ax/E_tr − 1: {an.get('call')}"
             + (f", {100 * an['est']:+.2f}% (95% CI {100 * an['ci95'][0]:+.2f}% to {100 * an['ci95'][1]:+.2f}%)"
                if "est" in an else ""),
             f"- gel stretch (orientation test): {orr.get('call')}"
             + (f", amplitude {100 * orr['amplitude']:.2f}%" if "amplitude" in orr else ""),
             "- flagged area: " + ", ".join(f"{k.replace('_', ' ')} {100 * v:.1f}%" for k, v in g["flagged_fraction"].items()),
             "", "This tool has been tested on synthetic gels only, never on real images, and a result says nothing about "
             "your chemistry. Flags mark places to look at, not verdicts."]
    return "\n".join(lines) + "\n"


def figure(res, obs, path, note=None):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        from matplotlib.collections import LineCollection
    except ImportError:
        return False
    pre = {o["id"]: o for o in obs["pre"]}
    ids = list(pre)
    pos = np.array([[pre[k]["x"], pre[k]["y"]] for k in ids])
    ang = np.array([pre[k]["angle"] for k in ids])
    half = np.array([pre[k]["length"] for k in ids]) / 2
    d = np.c_[np.cos(ang), np.sin(ang)] * half[:, None]
    segs = np.stack([pos - d, pos + d], axis=1)
    e = np.array([np.nan if (res["fibrils"].get(k) or {}).get("E_ax") is None else res["fibrils"][k]["E_ax"] for k in ids])
    land = np.array([np.nan if k not in res["fibrils"] else res["fibrils"][k]["E_land_ax"] for k in ids])
    fig, axs = plt.subplots(1, 2, figsize=(11, 5), constrained_layout=True)
    for ax, val, title in ((axs[0], e, "axial E (sarcomere period ratio) vs median, %"),
                           (axs[1], land, "landmark E (neighbour positions) vs median, %")):
        ok = np.isfinite(val)
        ax.add_collection(LineCollection(segs[~ok], colors="0.75", linewidths=1.5))
        if ok.any():
            lc = LineCollection(segs[ok], array=100 * (val[ok] / np.nanmedian(val) - 1), cmap="RdBu_r", linewidths=3)
            lc.set_clim(-5, 5)
            ax.add_collection(lc)
            fig.colorbar(lc, ax=ax, shrink=0.8)
        ax.set_xlim(pos[:, 0].min() - 15, pos[:, 0].max() + 15)
        ax.set_ylim(pos[:, 1].min() - 15, pos[:, 1].max() + 15)
        ax.set_aspect("equal")
        ax.set_title(title, fontsize=10)
        ax.set_xlabel("µm (pre-expansion)")
    if note:   # the demo's figure is synthetic: say so on the image and in the file
        fig.suptitle(note, fontsize=11, color="#b8860b", fontweight="bold")
    fig.savefig(path, dpi=110, metadata={"Description": note} if note else None)
    plt.close(fig)
    return True


def finish(obs, res, out: Path, note=None):
    out.mkdir(parents=True, exist_ok=True)
    save(res, out / "result.json")
    (out / "summary.md").write_text(summary(res), encoding="utf-8", newline="\n")
    drew = figure(res, obs, out / "strain_map.png", note)
    print(summary(res))
    written = [out / "result.json", out / "summary.md"] + ([out / "strain_map.png"] if drew else [])
    print("written: " + ", ".join(str(p) for p in written))
    if not drew:
        print(SKIP_FIG.format(out / "strain_map.png"))


SKIP_FIG = 'skipped {}: matplotlib is not installed (pip install "swell-ruler[figures]" to draw figures)'
SKIP_TIF = 'skipped {}: tifffile is not installed (pip install "swell-ruler[images]" to write TIFF files)'
DEMO_NOTE = "SIMULATION · synthetic demo data, not a measurement"

Q_GO = 1.2          # docs/design/preimage_v1.md: q = m·√N for 1% per-fibril error at 10 sarcomeres (D-46)
PX_REF = 0.194      # µm per pixel at which Q_GO was calibrated; q is rescaled to this sampling before the test
PX_OK = (0.10, 0.30)  # outside this pixel-size range the test is outside what was simulated: warn
LONG_FRACTION = 0.40  # rung 3 pass mark: the v2 simulation assumed 44% of fragments with ≥ 8 whole sarcomeres


def stripes(img, px, mode, out: Path):
    """Rungs 2 and 3 of the evidence ladder: unexpanded myofibrils under any microscope."""
    from .frontend import detect, sample_band
    from .profiles import centred_axis, period_fit
    rows = []
    for (cx, cy), ang, length, width in detect(img, px, mode):
        n = max(int(length / px) | 1, 9)
        along = centred_axis(n, px)
        half_w = max(width / 2 - px, px)
        band = np.arange(-half_w, half_w + px / 2, px)
        prof = sample_band(img, px, (cx, cy), ang, along, band).mean(0)
        if np.ptp(along) < 5.0:
            continue
        f = period_fit(along, prof)
        rows.append({"x": cx, "y": cy, "length_um": length, **f})
    out.mkdir(parents=True, exist_ok=True)
    sl = np.array([r["period"] for r in rows])
    ns = np.array([r["n_sarc"] for r in rows])
    # q is per sample: at coarser pixels each sarcomere has fewer samples, so the same q carries less information.
    # Rescale to the sampling the pass mark was calibrated at (PX_REF): q_ref = q * sqrt(PX_REF / px).
    q = np.array([r["q"] for r in rows]) * np.sqrt(PX_REF / px)
    long10 = ns >= 10
    res = {"n_fibrils": len(rows), "sarcomere_length_um": {"median": float(np.median(sl)) if rows else None,
           "iqr": [float(np.percentile(sl, 25)), float(np.percentile(sl, 75))] if rows else None},
           "fraction_8_or_more": float(np.mean(ns >= 8)) if rows else None,
           "n_10_or_more": int(long10.sum()),
           "median_q_10_or_more": float(np.median(q[long10])) if long10.any() else None,
           "q_go": Q_GO, "q_rescaled_to_px_um": PX_REF, "px_um": px,
           "px_in_tested_range": bool(PX_OK[0] <= px <= PX_OK[1]),
           "long_fraction_pass": LONG_FRACTION, "fibrils": rows}
    res["rung2_pass"] = bool(res["n_10_or_more"] >= 10 and res["median_q_10_or_more"] >= Q_GO)
    res["rung3_pass"] = bool(rows and res["fraction_8_or_more"] >= LONG_FRACTION)
    (out / "stripes.json").write_text(json.dumps(res, indent=1), encoding="utf-8", newline="\n")
    lines = ["# swell-ruler stripes", "",
             f"- myofibrils found: {res['n_fibrils']}",
             f"- sarcomere length: median {res['sarcomere_length_um']['median']:.3f} µm" if rows else "- no myofibrils found",
             f"- rung 2 (see the stripes): median q {res['median_q_10_or_more']:.2f} over {res['n_10_or_more']} fibrils "
             f"with ≥ 10 sarcomeres; pass mark q ≥ {Q_GO} on ≥ 10 fibrils: {'PASS' if res['rung2_pass'] else 'not yet'}"
             if res["median_q_10_or_more"] is not None else "- rung 2: no fibril with ≥ 10 sarcomeres yet",
             f"- rung 3 (fragment lengths): {100 * res['fraction_8_or_more']:.0f}% of fragments have ≥ 8 sarcomeres; "
             f"pass mark {100 * LONG_FRACTION:.0f}%: {'PASS' if res['rung3_pass'] else 'not yet'}" if rows else "",
             "" if res["px_in_tested_range"] else
             f"- WARNING: {px} µm per pixel is outside the tested range {PX_OK[0]}-{PX_OK[1]} µm; the q test may mislead",
             "", f"q = striation modulation ÷ noise, both from the fit, rescaled to {PX_REF} µm pixels "
             "(q × √(0.194 ÷ your pixel size)). Denoised, sharpened or JPEG-compressed images understate the noise "
             "and overstate q: use raw or PNG frames."]
    (out / "stripes.md").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(6, 3.6), constrained_layout=True)
        ax.hist(ns, bins=np.arange(0, max(ns.max() if rows else 10, 10) + 2), color="#4fd8ff", edgecolor="#05080d")
        ax.axvline(8, color="#ffb547", ls="--")
        ax.set_xlabel("fragment length, sarcomeres")
        ax.set_ylabel("myofibrils")
        ax.set_title("Fragment lengths (rung 3): the ruler needs ≥ 8 sarcomeres", fontsize=9)
        fig.savefig(out / "fragments.png", dpi=110)
        plt.close(fig)
    except ImportError:
        print(SKIP_FIG.format(out / "fragments.png"))
    print("\n".join(lines))
    return res


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):  # Windows consoles and pipes may not take µ, ≥, −
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    ap = argparse.ArgumentParser(prog="swell-ruler", description=__doc__.split("\n")[0])
    ap.add_argument("--version", action="version", version=f"swell_ruler {__version__}")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("images", help="run on one pre-expansion and one post-expansion image")
    a.add_argument("pre")
    a.add_argument("post")
    a.add_argument("--post-stack", help="optional post z-stack (z, y, x) TIFF; its sum gives the cross-section shape")
    a.add_argument("--px-pre", type=float, required=True, help="pre image pixel size, µm at the sample")
    a.add_argument("--px-post", type=float, required=True, help="post image pixel size, µm at the sample")
    a.add_argument("--e-macro", type=float, required=True, help="overall expansion factor (gel diameter ratio)")
    a.add_argument("--pre-mode", default="dpc", choices=["dpc", "pol"], help="how the pre image was made")
    a.add_argument("--psf-pre", type=float, default=0.55, help="pre image PSF FWHM, µm (bead-calibrated)")
    a.add_argument("--psf-post", type=float, default=0.41, help="post image lateral PSF FWHM, µm")
    a.add_argument("--out", default="swell_ruler_out")
    o = sub.add_parser("obs", help="run on an observation file (swell-obs/1)")
    o.add_argument("path")
    o.add_argument("--out", default="swell_ruler_out")
    st = sub.add_parser("stripes", help="evidence-ladder rungs 2-3: striations and fragment lengths in one image")
    st.add_argument("image")
    st.add_argument("--px", type=float, required=True, help="pixel size at the sample, µm")
    st.add_argument("--mode", default="bf", choices=["bf", "dpc", "pol"], help="how the image was made")
    st.add_argument("--out", default="swell_ruler_stripes")
    d = sub.add_parser("demo", help="make a synthetic image pair, run on it and score it against its truth")
    d.add_argument("--out", default="swell_ruler_demo")
    d.add_argument("--seed", type=int, default=0)
    args = ap.parse_args(argv)
    out = Path(args.out)
    if args.cmd == "stripes":
        stripes(read_image(args.image), args.px, args.mode, out)
        return
    if args.cmd == "obs":
        obs = load(args.path)
        problems = validate_obs(obs)
        if problems:
            sys.exit("observation file problems: " + "; ".join(problems))
        finish(obs, run(obs), out)
    elif args.cmd == "images":
        from .frontend import observations
        stack = read_image(args.post_stack) if args.post_stack else None
        obs = observations(read_image(args.pre), read_image(args.post), args.px_pre, args.px_post, args.e_macro,
                           args.pre_mode, args.psf_pre, args.psf_post, post_stack=stack,
                           gel_id=Path(args.pre).stem)
        finish(obs, run(obs), out)
    else:
        from .demo import make_pair
        from .frontend import observations
        pre, post, truth = make_pair(seed=args.seed)
        out.mkdir(parents=True, exist_ok=True)
        try:
            import tifffile
            tifffile.imwrite(out / "demo_pre.tif", pre)
            tifffile.imwrite(out / "demo_post.tif", post)
        except ImportError:
            print(SKIP_TIF.format(f"{out / 'demo_pre.tif'} and {out / 'demo_post.tif'}"))
        obs = observations(pre, post, 0.194, 0.194, truth["E"], "pol", 0.55, 0.41, gel_id="demo")
        res = run(obs)
        finish(obs, res, out, note=DEMO_NOTE)
        score = demo_score(res, obs, truth)
        (out / "demo_score.json").write_text(json.dumps(score, indent=2), encoding="utf-8", newline="\n")
        print("demo score:", json.dumps(score, ensure_ascii=False))
        for k, v in score["checks"].items():
            print(f"  {'PASS' if v['pass'] else 'FAIL'}  {k}: {v['value']} (pass mark {v['mark']})")


def demo_score(res, obs, truth):
    """Score the demo against its truth: axial factor, transverse factor and the planted patch, each PASS/FAIL."""
    e = truth["E"]
    e_ax = [f["E_ax"] for f in res["fibrils"].values() if f["E_ax"] is not None]
    e_tr = [f["E_tr"] for f in res["fibrils"].values() if f["E_tr"] is not None]
    ax_err = float(np.median(e_ax)) / e - 1 if e_ax else None
    tr_err = float(np.median(e_tr)) / e - 1 if e_tr else None
    g = res["grid"]
    cx, cy = truth["defect_centre_pre"]
    r = truth["defect_radius_pre"]
    xs = g["x0"] + g["step"] * np.arange(g["nx"])
    ys = g["y0"] + g["step"] * np.arange(g["ny"])
    inside = np.hypot(*np.meshgrid(xs - cx, ys - cy)) < r
    flagged = np.zeros_like(inside)
    for v in res["flags"].values():
        flagged |= np.asarray(v, bool)
    patch = float(flagged[inside].mean()) if inside.any() else None
    checks = {
        "axial factor (gel median)": {"value": f"{100 * ax_err:+.2f}%" if ax_err is not None else "none",
                                      "mark": "within ±1%", "pass": ax_err is not None and abs(ax_err) <= 0.01},
        "transverse factor (gel median)": {"value": f"{100 * tr_err:+.1f}%" if tr_err is not None else "none",
                                           "mark": "within ±3%", "pass": tr_err is not None and abs(tr_err) <= 0.03},
        "planted 3% patch flagged": {"value": f"{100 * patch:.0f}% of its area" if patch is not None else "none",
                                     "mark": "at least 50%", "pass": patch is not None and patch >= 0.5},
    }
    return {"truth_E": e, "median_E_ax": float(np.median(e_ax)) if e_ax else None,
            "median_E_tr": float(np.median(e_tr)) if e_tr else None, "n_axial": len(e_ax),
            "n_pre_found": len(obs["pre"]), "n_post_found": len(obs["post"]), "n_matched": res["gel"]["n_matched"],
            "planted": f"{100 * truth['defect_drop']:.0f}% less expansion inside a {r:.0f} µm circle",
            "anisotropy_call": res["gel"]["anisotropy"].get("call"), "checks": checks,
            "all_pass": all(v["pass"] for v in checks.values())}


if __name__ == "__main__":
    main()
