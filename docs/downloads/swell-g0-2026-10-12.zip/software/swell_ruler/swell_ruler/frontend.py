"""Image front-end: find myofibrils in a pre-expansion and a post-expansion image and write them as observations
(swell-obs/1) for the ruler pipeline.

Kept deliberately simple and dependency-light (NumPy + SciPy):
  detect   smooth the structure signal, threshold it (Otsu), label connected regions, keep elongated ones
  measure  centroid, axis angle and length from second moments; sample a straight band along the axis
           (axial profile) and across it (cross profile) with bilinear interpolation
Each image is in its own stage coordinates: x = column × pixel size, y = row × pixel size.
"""
from __future__ import annotations

import math

import numpy as np
from scipy import ndimage as ndi


def otsu(values: np.ndarray, bins: int = 256) -> float:
    v = values[np.isfinite(values)].ravel()
    hist, edges = np.histogram(v, bins=bins)
    mids = 0.5 * (edges[:-1] + edges[1:])
    w0 = np.cumsum(hist)
    w1 = w0[-1] - w0
    m0 = np.cumsum(hist * mids) / np.maximum(w0, 1)
    m1 = (np.sum(hist * mids) - np.cumsum(hist * mids)) / np.maximum(w1, 1)
    between = w0 * w1 * (m0 - m1) ** 2
    return float(mids[int(np.argmax(between))])


def structure_map(img: np.ndarray, px: float, mode: str) -> np.ndarray:
    """A map that is high on myofibrils. Fluorescence: the smoothed intensity. Label-free (dpc/pol/bf): the local
    deviation from the background, smoothed over ~0.6 µm, so phase edges and striations both count."""
    img = np.asarray(img, float)
    if mode == "fluor":
        return ndi.gaussian_filter(img, 0.3 / px)
    bg = ndi.gaussian_filter(img, 6.0 / px)
    return ndi.gaussian_filter(np.abs(img - bg), 0.6 / px)


def detect(img, px, mode, min_len_um=4.0, min_elong=2.5, max_width_um=None):
    """Elongated regions: [(centroid_xy_um, angle_rad, length_um, width_um, label_mask_slice)]."""
    s = structure_map(img, px, mode)
    mask = s > otsu(s)
    mask = ndi.binary_opening(mask, iterations=1)
    lab, n = ndi.label(mask)
    out = []
    for i, sl in enumerate(ndi.find_objects(lab), start=1):
        if sl is None:
            continue
        sub = lab[sl] == i
        if sub.sum() < 8:
            continue
        rr, cc = np.nonzero(sub)
        y = (rr + sl[0].start) * px
        x = (cc + sl[1].start) * px
        cx, cy = x.mean(), y.mean()
        cov = np.cov(np.vstack([x - cx, y - cy]))
        evals, evecs = np.linalg.eigh(cov)
        major = evecs[:, 1]
        ang = math.atan2(major[1], major[0]) % np.pi
        # length and width from the extent along and across the axis (more robust than moments for rods)
        t = (x - cx) * math.cos(ang) + (y - cy) * math.sin(ang)
        n_ = -(x - cx) * math.sin(ang) + (y - cy) * math.cos(ang)
        length = float(np.ptp(t) + px)
        width = float(np.ptp(n_) + px)
        if length < min_len_um or length / max(width, px) < min_elong:
            continue
        if max_width_um and width > max_width_um:
            continue
        out.append(((cx, cy), ang, length, width))
    return out


def sample_band(img, px, centre, ang, along, across):
    """Bilinear samples at centre + along·û + across·v̂ (µm); returns an (len(across), len(along)) array."""
    u = np.array([math.cos(ang), math.sin(ang)])
    v = np.array([-math.sin(ang), math.cos(ang)])
    a, b = np.meshgrid(along, across)
    xs = centre[0] + a * u[0] + b * v[0]
    ys = centre[1] + a * u[1] + b * v[1]
    return ndi.map_coordinates(np.asarray(img, float), [ys / px, xs / px], order=1, mode="nearest")


def objects_from_image(img, px, mode, ids_prefix, zsum=None, height_um=None):
    """Observation objects (schema swell-obs/1) for every elongated region in an image."""
    objs = []
    for k, ((cx, cy), ang, length, width) in enumerate(detect(img, px, mode)):
        n_ax = max(int(length / px) | 1, 9)
        along = (np.arange(n_ax) - (n_ax - 1) / 2) * px
        half_w = max(width / 2 - px, px)
        across_band = np.arange(-half_w, half_w + px / 2, px)
        axial = sample_band(img, px, (cx, cy), ang, along, across_band).mean(0)
        n_cr = 2 * int((width / 2 + 2.0) / px) + 1
        across = (np.arange(n_cr) - (n_cr - 1) / 2) * px
        rows = max(int(0.5 * length / px), 1)
        along_c = (np.arange(rows) - (rows - 1) / 2) * px
        cross = sample_band(img, px, (cx, cy), ang + np.pi / 2, across, along_c).mean(0)
        # sample_band with the axes swapped: the "along" coordinate is now across the fibril
        o = {"id": f"{ids_prefix}{k:05d}", "x": float(cx), "y": float(cy), "angle": float(ang),
             "length": float(length), "axial": axial.round(4).tolist(), "cross": cross.round(5).tolist(),
             "cross_rows": int(rows)}
        if zsum is not None:
            zc = sample_band(zsum, px, (cx, cy), ang + np.pi / 2, across, along_c).mean(0)
            o.update({"zsum_cross": zc.round(5).tolist(), "zsum_rows": int(rows), "zsum_planes": 1,
                      "aspect": float(height_um / width) if height_um else 1.0, "tile": 0, "t": 0.0})
        objs.append(o)
    return objs


def observations(pre_img, post_img, px_pre, px_post, e_macro, pre_mode="dpc", psf_pre_fwhm=0.55,
                 psf_post_fwhm=0.41, dof_post=1.64, post_stack=None, gel_id="image-pair"):
    """Build a swell-obs/1 dict from one pre-expansion image and one post-expansion image (or z-stack).

    post_stack: optional (z, y, x) array; its sum gives zsum_cross and post_img should then be its best plane."""
    zsum = np.asarray(post_stack, float).sum(0) if post_stack is not None else np.asarray(post_img, float)
    pre = objects_from_image(pre_img, px_pre, pre_mode, "p")
    post = objects_from_image(post_img, px_post, "fluor", "q", zsum=zsum)
    h, w = np.asarray(post_img).shape[:2]
    return {"schema": "swell-obs/1", "gel_id": gel_id,
            "meta": {"e_macro": float(e_macro), "px_pre_um": float(px_pre), "px_post_um": float(px_post),
                     "psf_pre_fwhm_um": float(psf_pre_fwhm), "psf_post_fwhm_um": float(psf_post_fwhm),
                     "dof_post_um": float(dof_post), "pre_mode": pre_mode,
                     "gel_center_post_um": [w * px_post / 2, h * px_post / 2], "gel_radius_pre_um": 750.0,
                     "mirror_possible": True, "generator": "swell_ruler.frontend"},
            "pre": pre, "post": post, "clock": []}
