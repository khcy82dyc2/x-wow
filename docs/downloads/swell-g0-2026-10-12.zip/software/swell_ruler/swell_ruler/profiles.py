"""1-D estimators: the Z-disc ladder (axial factor) and the width fits (transverse factor).

Every function here works on a single object's profiles. Coordinates are micrometres in the image's own units
(pre-expansion µm for the pre image, post stage µm for the post image).
"""
from __future__ import annotations

import math

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.optimize import least_squares
from scipy.signal import find_peaks
from scipy.special import erf

S2F = 2.0 * math.sqrt(2.0 * math.log(2.0))   # FWHM / sigma for a Gaussian

# Ladder settings (D-33, revised in Life 5 after the fresh AI review). Not tuned on any test gel.
EDGE_PERIODS = 0.35      # a Z-disc closer than this to a profile end is truncated or frayed: not used
MIN_SPAN = 8             # the usable ladder must span at least 8 sarcomeres (v1 rule, D-33)
WINDOW = 0.10            # search E within e_macro ± 10%
OFFSET_PERIODS = 0.0     # no offset search: the free harmonic phases absorb centring shifts; a search
                         # jumped whole sarcomeres on ~1% of fibrils (Life 5 diagnostic: 0.27% vs 0.16% RMS)
HARMONICS = (1, 2, 3)


def centred_axis(n: int, px: float) -> np.ndarray:
    """Sample coordinates measured from the profile's midpoint (the object's centroid)."""
    return (np.arange(n) - (n - 1) / 2.0) * px


def smooth_trend(y: np.ndarray, px: float, scale_um: float) -> np.ndarray:
    """Local mean by normalised Gaussian smoothing, valid up to the profile ends (no padding artefacts)."""
    sig = max(scale_um / px, 1e-6)
    num = gaussian_filter1d(y, sig, mode="constant")
    den = gaussian_filter1d(np.ones_like(y), sig, mode="constant")
    return num / np.maximum(den, 1e-12)


def flatten(y, px: float, period: float) -> np.ndarray:
    """Remove slow illumination changes from a striation profile.

    The local mean over 1.5 sarcomeres carries no striation (its transfer at the fundamental is e^-44), so it is
    pure illumination and background. Positive images (brightfield-like, polarised, fluorescent) are divided by it,
    which removes slopes, vignetting and amplitude ramps; signed images (a DPC difference) have it subtracted."""
    y = np.asarray(y, float)
    trend = smooth_trend(y, px, 1.5 * period)
    level = float(np.median(trend))
    spread = float(np.percentile(y, 95) - np.percentile(y, 5))
    if level > 3.0 * spread and level > 0:       # positive image: flat-field
        return y / np.maximum(trend, 1e-12) - 1.0
    return y - trend                              # signed image: subtract


def z_ladder(y, x, p_expected: float, edge_periods: float = EDGE_PERIODS):
    """Z-disc positions in a post-expansion striation profile, and their sarcomere index (gaps counted).

    Peaks: the brightest narrow maxima at least 0.6 periods apart, refined to sub-pixel by a parabola. A disc whose
    centre lies within `edge_periods` of either end of the profile is dropped: its peak is truncated by the end of
    the object (or frayed by the break), and the v1 ladder kept it, which pulled the end discs inwards and biased
    E_ax low by about 0.05-0.1% (fresh AI review, 2026-10-09)."""
    y = np.asarray(y, float)
    x = np.asarray(x, float)
    if y.size < 8:
        return np.array([]), np.array([])
    dx = x[1] - x[0]
    ys = gaussian_filter1d(y, 0.15 / dx, mode="nearest")
    span = np.percentile(ys, 95) - np.percentile(ys, 5)
    if span <= 0:
        return np.array([]), np.array([])
    pk, _ = find_peaks(ys, distance=max(int(0.6 * p_expected / dx), 1), prominence=0.25 * span)
    pk = pk[(pk > 0) & (pk < ys.size - 1)]
    if pk.size == 0:
        return np.array([]), np.array([])
    y0, y1, y2 = ys[pk - 1], ys[pk], ys[pk + 1]
    den = y0 - 2 * y1 + y2
    pos = x[pk] + dx * np.where(den < 0, 0.5 * (y0 - y2) / np.where(den < 0, den, -1), 0.0)
    margin = edge_periods * p_expected
    pos = pos[(pos - x[0] >= margin) & (x[-1] - pos >= margin)]
    if pos.size < 3:
        return np.array([]), np.array([])
    step = np.median(np.diff(pos))
    idx = np.concatenate([[0], np.cumsum(np.maximum(np.round(np.diff(pos) / step), 1))])
    return pos, idx


def _rss_grid(phase_fn, xs, ys, es, offsets, harmonics, nuisance):
    """Residual sum of squares of the harmonic model for every (E, offset) pair. Vectorised normal equations."""
    tss = float(ys @ ys)
    out = np.empty((offsets.size, es.size))
    for k, d in enumerate(offsets):
        ph = phase_fn(np.outer(es, xs) + d)                       # (nE, n)
        cols = [f(h * ph) for h in harmonics for f in (np.cos, np.sin)]
        cols += [np.broadcast_to(c, ph.shape) for c in nuisance]
        a = np.stack(cols, axis=-1)                               # (nE, n, p)
        g = np.einsum("fni,fnj->fij", a, a)
        b = np.einsum("fni,n->fi", a, ys)
        coef = np.linalg.solve(g + 1e-12 * np.eye(g.shape[-1]), b[..., None])[..., 0]
        out[k] = tss - np.einsum("fi,fi->f", b, coef)
    return out, tss


def axial_factor(u_pre, y_pre, u_post, y_post, e_c: float, p_pre: float = 1.69, window: float = WINDOW,
                 harmonics=HARMONICS, offset_periods: float = OFFSET_PERIODS, edge_periods: float = EDGE_PERIODS):
    """E_ax for one matched myofibril (Z-disc ladder template, D-33).

    u_pre, u_post: sample coordinates measured from each object's centroid, in each image's own units, with the
    post profile already oriented the same way as the pre profile. The post image's Z-discs define a sarcomere
    phase (2πk at the k-th disc, linear in between), so the template carries the real sarcomere-to-sarcomere
    jitter. The flattened pre profile is fitted with 3 harmonics of that phase (plus a constant and a slope) at
    u_post = E·u_pre + d, over E in e_c ± window and a centring offset d within ± offset_periods sarcomeres (the
    two centroids need not mark the same point of a broken fragment).

    Returns a dict: E (nan if the ladder is too short), r2 (pre variance explained), n_discs, n_samples,
    modulation (fundamental amplitude of the flattened pre profile) and offset (µm, post units)."""
    out = {"E": float("nan"), "r2": 0.0, "n_discs": 0, "n_samples": 0, "modulation": float("nan"),
           "offset": float("nan")}
    u_pre, y_pre = np.asarray(u_pre, float), np.asarray(y_pre, float)
    u_post, y_post = np.asarray(u_post, float), np.asarray(y_post, float)
    if u_pre.size < 8 or u_post.size < 8:
        return out
    p_post = p_pre * e_c
    zpos, zidx = z_ladder(y_post, u_post, p_post, edge_periods)
    out["n_discs"] = int(zpos.size)
    if zpos.size < 2 or zidx[-1] - zidx[0] < MIN_SPAN:
        return out
    pt = 2 * np.pi * zidx
    emin, emax = e_c * (1 - window), e_c * (1 + window)
    dmax = offset_periods * p_post
    # pre samples that map inside the ladder for every trial (E, d): a fixed sample set keeps the RSS comparable
    lo, hi = zpos[0] + dmax, zpos[-1] - dmax
    sel = np.ones(u_pre.size, bool)
    for e in (emin, emax):
        m = e * u_pre
        sel &= (m >= lo) & (m <= hi)
    if sel.sum() < 8:          # short fragment: shrink the offset search rather than give up
        dmax = 0.25 * p_post
        lo, hi = zpos[0] + dmax, zpos[-1] - dmax
        sel = np.ones(u_pre.size, bool)
        for e in (emin, emax):
            m = e * u_pre
            sel &= (m >= lo) & (m <= hi)
        if sel.sum() < 8:
            return out
    yn = flatten(y_pre, abs(u_pre[1] - u_pre[0]), p_pre)
    xs, ys = u_pre[sel], yn[sel] - yn[sel].mean()
    nuisance = [np.ones_like(xs), (xs - xs.mean()) / max(np.ptp(xs), 1e-9)]

    def phase(xp):
        return np.interp(xp, zpos, pt)

    offsets = np.linspace(-dmax, dmax, 2 * int(round(dmax / (0.25 * p_post))) + 1)
    coarse = np.linspace(emin, emax, 121)
    rss, tss = _rss_grid(phase, xs, ys, coarse, offsets, harmonics, nuisance)
    k, i = np.unravel_index(int(np.argmin(rss)), rss.shape)
    d = float(offsets[k])
    fine = np.linspace(coarse[max(i - 1, 0)], coarse[min(i + 1, coarse.size - 1)], 41)
    r, _ = _rss_grid(phase, xs, ys, fine, np.array([d]), harmonics, nuisance)
    r = r[0]
    j = int(np.clip(np.argmin(r), 1, fine.size - 2))
    den = r[j - 1] - 2 * r[j] + r[j + 1]
    shift = 0.5 * (r[j - 1] - r[j + 1]) / den if den > 0 else 0.0
    e_hat = float(fine[j] + shift * (fine[1] - fine[0]))
    # fundamental amplitude of the flattened pre profile at the best fit (a measured contrast, for the go/no-go)
    ph = phase(e_hat * xs + d)
    a = np.stack([np.cos(ph), np.sin(ph)] + nuisance, axis=-1)
    coef, *_ = np.linalg.lstsq(a, ys, rcond=None)
    n_par = 2 * len(harmonics) + len(nuisance)
    sigma = math.sqrt(max(r[j], 0.0) / max(xs.size - n_par, 1))
    m1 = float(math.hypot(coef[0], coef[1]))
    out.update({"E": e_hat, "r2": float(1 - r[j] / tss) if tss > 0 else 0.0, "n_samples": int(sel.sum()),
                "modulation": m1, "offset": d, "q": m1 / sigma if sigma > 0 else float("nan")})
    return out


def period_fit(u, y, p_lo=1.3, p_hi=2.3, harmonics=HARMONICS):
    """Free-frequency striation fit of one profile (no partner image): period, fundamental modulation m,
    residual noise σ (both relative to the local mean) and q = m/σ. The window 1.3-2.3 µm keeps the fit off the
    half- and double-period harmonics (Life 1 lesson). Used by the 'stripes' rung of the evidence ladder."""
    u, y = np.asarray(u, float), np.asarray(y, float)
    px = abs(u[1] - u[0])
    yn = flatten(y, px, 0.5 * (p_lo + p_hi))
    ys = yn - yn.mean()
    nuis = [np.ones_like(u), (u - u.mean()) / max(np.ptp(u), 1e-9)]

    def rss(periods):
        ph = 2 * np.pi * np.outer(1 / periods, u)
        a = np.stack([f(h * ph) for h in harmonics for f in (np.cos, np.sin)]
                     + [np.broadcast_to(c, ph.shape) for c in nuis], axis=-1)
        g = np.einsum("fni,fnj->fij", a, a)
        b = np.einsum("fni,n->fi", a, ys)
        coef = np.linalg.solve(g + 1e-12 * np.eye(g.shape[-1]), b[..., None])[..., 0]
        return float(ys @ ys) - np.einsum("fi,fi->f", b, coef), coef
    grid = np.linspace(p_lo, p_hi, 201)
    r, _ = rss(grid)
    i = int(np.argmin(r))
    fine = np.linspace(grid[max(i - 1, 0)], grid[min(i + 1, grid.size - 1)], 41)
    rf, cf = rss(fine)
    j = int(np.argmin(rf))
    n_par = 2 * len(harmonics) + len(nuis)
    sigma = math.sqrt(max(rf[j], 0.0) / max(u.size - n_par, 1))
    m1 = float(math.hypot(cf[j][0], cf[j][1]))
    tss = float(ys @ ys)
    return {"period": float(fine[j]), "modulation": m1, "sigma": sigma, "q": m1 / sigma if sigma > 0 else float("nan"),
            "r2": float(1 - rf[j] / tss) if tss > 0 else 0.0, "n_sarc": float(np.ptp(u) / fine[j])}


# ------------------------------------------------------------------------------------------------- widths (D-32)
def _gauss_blur(prof, dx, sigma):
    return gaussian_filter1d(np.asarray(prof, float), sigma / dx, mode="constant", truncate=4.0)


def chord(xf, w, asp, n=2.0):
    """Projected thickness across a fibril of width w and height asp*w with a super-ellipse cross-section of
    exponent n (2 = ellipse; larger = boxier)."""
    return asp * w * np.clip(1 - np.abs(2 * xf / w) ** n, 0, None) ** (1.0 / n)


def pre_cross_model(x, w, amp, x0, bg, sigma, asp, mode, n=2.0):
    """Label-free pre-image across a fibril. dpc: ∝ d/dx(PSF ⊗ thickness); pol: ∝ PSF ⊗ thickness²."""
    dx = 0.005
    xf = np.arange(x.min() - 2.0, x.max() + 2.0, dx)
    t = chord(xf - x0, w, asp, n)
    prof = _gauss_blur(t ** 2, dx, sigma) if mode == "pol" else np.gradient(_gauss_blur(t, dx, sigma), dx)
    return bg + amp * np.interp(x, xf, prof)


def post_cross_model(x, w, a1, a2, x0, bg, sigma, asp, dof, n=2.0):
    """Post fluorescence at mid-height: in-focus band (rect ⊗ PSF) + out-of-focus pedestal (thickness ⊗ a broad
    defocus kernel of width ~ DOF)."""
    inf = 0.5 * (erf((x - x0 + w / 2) / (sigma * math.sqrt(2))) - erf((x - x0 - w / 2) / (sigma * math.sqrt(2))))
    dx = 0.02
    xf = np.arange(x.min() - 4.0, x.max() + 4.0, dx)
    t = chord(xf - x0, w, asp, n)
    ped = _gauss_blur(t / max(t.max(), 1e-9), dx, max(dof, 0.3) * 0.6)
    return bg + a1 * inf + a2 * np.interp(x, xf, ped)


def zsum_model(x, w, n, amp, x0, bg, sigma):
    dx = 0.02
    xf = np.arange(x.min() - 2.0, x.max() + 2.0, dx)
    return bg + amp * np.interp(x, xf, _gauss_blur(chord(xf - x0, w, 1.0, n), dx, sigma))


def _fwhm_guess(x, y):
    y = np.asarray(y, float)
    base = np.percentile(y, 10)
    top = y.max()
    above = np.where(y - base >= 0.5 * (top - base))[0]
    return float(x[above[-1]] - x[above[0]]) if above.size > 1 else float(np.ptp(x) / 4)


def fit_shape_post(zsum, px, sigma, w_guess=None):
    """Width and super-ellipse exponent of a post cross-section from the z-stack sum (∝ projected thickness)."""
    y = np.asarray(zsum, float)
    x = centred_axis(y.size, px)
    w0 = w_guess or max(_fwhm_guess(x, y), 0.6)
    ymax = max(float(y.max() - np.percentile(y, 5)), 1e-9)
    sol = least_squares(lambda p: zsum_model(x, *p, sigma) - y,
                        [w0, 2.5, ymax / max(w0, 1e-3), 0.0, float(np.percentile(y, 5))],
                        bounds=([0.3, 1.5, 0, -2, -np.inf], [40, 8, np.inf, 2, np.inf]))
    return float(sol.x[0]), float(sol.x[1])


def fit_width_post(cross, px, sigma, asp, n_shape, dof, w_guess=None):
    y = np.asarray(cross, float)
    x = centred_axis(y.size, px)
    w0 = w_guess or max(_fwhm_guess(x, y), 0.6)
    top = max(float(y.max() - np.percentile(y, 5)), 1e-9)
    t_exp = asp * w0
    a2 = max(t_exp / max(dof, 1e-3) - 1.0, 0.0)
    sol = least_squares(lambda p: post_cross_model(x, p[0], p[1], p[2], p[3], p[4], sigma, asp, dof, n_shape) - y,
                        [w0, top / (1 + a2), top * a2 / (1 + a2), 0.0, float(np.percentile(y, 5))],
                        bounds=([0.3, 0, 0, -2, -np.inf], [40, np.inf, np.inf, 2, np.inf]))
    return float(sol.x[0])


def fit_width_pre(cross, px, sigma, asp, n_shape, mode, w_guess=1.2):
    y = np.asarray(cross, float)
    x = centred_axis(y.size, px)
    bg0 = float(np.median(np.r_[y[:3], y[-3:]]))
    rng = float(np.ptp(y)) or 1.0
    if mode == "pol":
        p0 = [w_guess, rng / max((asp * w_guess) ** 2, 1e-6), 0.0, bg0]
    else:
        p0 = [w_guess, rng / max(asp * w_guess, 1e-6) / 2, 0.0, bg0]
    sol = least_squares(lambda p: pre_cross_model(x, p[0], p[1], p[2], p[3], sigma, asp, mode, n_shape) - y, p0,
                        bounds=([0.3, -np.inf, -0.5, -np.inf], [3.5, np.inf, 0.5, np.inf]),
                        x_scale=[0.3, abs(p0[1]) + 1e-9, 0.1, rng])
    return float(sol.x[0])
