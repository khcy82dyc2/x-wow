"""Read and write swell-obs/1, swell-truth/1 and swell-result/1 files (plain or gzipped JSON)."""
from __future__ import annotations

import gzip
import json
import math
from pathlib import Path

REQUIRED_META = ("e_macro", "px_pre_um", "px_post_um", "psf_pre_fwhm_um", "psf_post_fwhm_um")
REQUIRED_OBJ = ("id", "x", "y", "angle", "length", "axial", "cross")
REQUIRED_POST = ("zsum_cross",)


def load(path) -> dict:
    p = Path(path)
    raw = p.read_bytes()
    if raw[:2] == b"\x1f\x8b":
        raw = gzip.decompress(raw)
    return json.loads(raw.decode("utf-8"))


def clean(x):
    """Strict JSON: non-finite numbers become null (the schema's 'not measured'); numpy scalars become Python."""
    if isinstance(x, dict):
        return {k: clean(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [clean(v) for v in x]
    if hasattr(x, "item") and not isinstance(x, (str, bytes)):
        x = x.item()
    if isinstance(x, float) and not math.isfinite(x):
        return None
    return x


def save(obj: dict, path) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    data = json.dumps(clean(obj), separators=(",", ":"), allow_nan=False).encode("utf-8")
    if p.suffix == ".gz":
        data = gzip.compress(data, compresslevel=6, mtime=0)
    p.write_bytes(data)


def validate_obs(obs: dict) -> list[str]:
    """Problems that would stop the pipeline (empty list = fine)."""
    out = []
    if obs.get("schema") != "swell-obs/1":
        out.append(f"schema is {obs.get('schema')!r}, expected 'swell-obs/1'")
    meta = obs.get("meta", {})
    out += [f"meta.{k} missing" for k in REQUIRED_META if k not in meta]
    for side, extra in (("pre", ()), ("post", REQUIRED_POST)):
        objs = obs.get(side) or []
        if not objs:
            out.append(f"no {side} objects")
            continue
        for k in REQUIRED_OBJ + extra:
            miss = sum(1 for o in objs if k not in o)
            if miss:
                out.append(f"{miss} {side} objects lack {k}")
        ids = [o.get("id") for o in objs]
        if len(set(ids)) != len(ids):
            out.append(f"{side} ids are not unique")
    return out
