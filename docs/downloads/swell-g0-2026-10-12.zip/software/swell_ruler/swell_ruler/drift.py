"""Scan-time drift: the gel keeps swelling or shrinking while the post mosaic is acquired (about 2 h at Track A).

A "clock tile" is re-imaged every ~50 tiles. Its objects are matched to the first visit and a similarity fit gives
the apparent scale of the gel at each visit. Every post object is then brought back to the reference time
(the first visit): positions are scaled about the gel centre and profile sampling steps are divided by s(t).
"""
from __future__ import annotations

import numpy as np
from scipy.spatial import cKDTree

from .matching import similarity_fit


def clock_scales(visits):
    """Scale of each clock visit relative to the first. Returns (t, s, n_matched) arrays."""
    if not visits or len(visits) < 2:
        return np.array([]), np.array([]), np.array([])
    ref = np.array([[o["x"], o["y"]] for o in visits[0]["objects"]], float)
    tree = cKDTree(ref)
    ts, ss, ns = [float(visits[0]["t"])], [1.0], [len(ref)]
    for v in visits[1:]:
        cur = np.array([[o["x"], o["y"]] for o in v["objects"]], float)
        if len(cur) < 3 or len(ref) < 3:
            continue
        # translation first (stage drift), then nearest neighbours, then a similarity fit; two passes
        shift = np.zeros(2)
        for gate in (20.0, 5.0):
            d, j = tree.query(cur - shift, distance_upper_bound=gate)
            ok = np.isfinite(d)
            if ok.sum() < 3:
                break
            shift = np.median(cur[ok] - ref[j[ok]], axis=0)
        if ok.sum() < 3:
            continue
        s, _, _ = similarity_fit(ref[j[ok]], cur[ok])
        ts.append(float(v["t"]))
        ss.append(float(s))
        ns.append(int(ok.sum()))
    return np.array(ts), np.array(ss), np.array(ns)


def scale_at(t, ts, ss):
    """s(t) by linear interpolation between clock visits; held flat outside them."""
    if ts.size == 0:
        return np.ones_like(np.asarray(t, float))
    order = np.argsort(ts)
    return np.interp(np.asarray(t, float), ts[order], ss[order])


def correct_post(post, meta, ts, ss):
    """Bring every post object back to the reference time. Returns per-object scale factors used."""
    centre = np.asarray(meta.get("gel_center_post_um", [0.0, 0.0]), float)
    t = np.array([o.get("t", 0.0) for o in post], float)
    s = scale_at(t, ts, ss)
    for o, si in zip(post, s):
        o["x"] = float(centre[0] + (o["x"] - centre[0]) / si)
        o["y"] = float(centre[1] + (o["y"] - centre[1]) / si)
        o["length"] = float(o["length"] / si)
        o["_px_scale"] = float(1.0 / si)     # multiply post sampling steps by this
    return s
