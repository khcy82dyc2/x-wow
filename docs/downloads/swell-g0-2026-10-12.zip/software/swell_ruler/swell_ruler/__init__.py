"""swell_ruler: a proposed ruler for expansion-microscopy gels from the sarcomeres of chicken muscle.

Give it a pre-expansion and a post-expansion image of the same myofibrils (or observation files in the
swell-obs/1 format) and it returns each myofibril's axial and transverse expansion factor, a whole-gel strain
map with QC flags, and gel-level calls. Tested on synthetic gels only, never on real images. Part of SWELL, X-WOW
invention #1. CC0 1.0; the X-WOW name and logo are trade marks and not covered.
"""
__version__ = "0.1.2"

from .pipeline import run  # noqa: E402,F401
