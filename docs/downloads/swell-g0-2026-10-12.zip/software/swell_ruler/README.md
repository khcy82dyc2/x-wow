# swell-ruler: a proposed chicken-muscle ruler for expansion-microscopy gels (untested on real images)

Part of SWELL, X-WOW invention #1 (https://x-wow.com/swell/). CC0 1.0: copy it, change it, sell it. The X-WOW
name and logo are not covered: they are trade marks, and the logo is a registered UK trade mark (UK00003425680).

Expansion microscopy (ExM) swells a specimen in a gel, and every claim then rests on knowing how much each part
of it expanded. Muscle carries its own ruler: sarcomeres repeat every ~1.7 µm and Z-discs are sharp lines.
Sheard et al. (ACS Nano 2019) used sarcomere periodicity as an intrinsic reporter of local expansion, and GelMap
(Damstra et al. 2023), nuclear pores and photobleached patterns are other in-gel rulers; this is one more member of
that family, not a new kind of QC. Imaging the same specimen before and after expansion goes back to Chen, Tillberg &
Boyden (Science 2015), and maps of local expansion error are not new either (Chen 2015; GelMap). What it tries to add,
as narrowed in SWELL's prior-art notes: chicken myofibrils spread through the gel as a free reference, each long
fibril's sarcomere period read twice (label-free before expansion, stained after), giving that fibril its own axial
expansion factor without lithography, a pre-label or a super-resolution pre-image. Untested on real gels.

**What it is today:** tested on synthetic gels only. On the red-team gel S3 (built by a separate AI agent from the
data format alone) the gel-level axial factor held, but the transverse ruler was biased by about −18% and the
anisotropy call it produced was wrong; the per-fibril axial error was 1.8% RMS on the pairs that got a ratio.
The anisotropy call is now blocked whenever the transverse ruler and the landmark ruler disagree by more than 3%.
It has never been run on a real micrograph. The image front-end is deliberately simple (threshold, label,
straight-line profiles), so check its detections.

## Install

```
python -m pip install "swell-ruler[images,figures] @ https://x-wow.com/downloads/swell_ruler-0.1.2-py3-none-any.whl"
python -m pip install ./software/swell_ruler              # or from the unzipped SWELL package
```

It is not on PyPI (X-WOW keeps no accounts there), so `pip install swell-ruler` would fetch nothing, or someone
else's package. Needs Python 3.9+, NumPy, SciPy and Pillow; tifffile reads TIFF stacks; matplotlib draws figures.
If `swell-ruler` is not on your PATH (common on Windows), use `python -m swell_ruler` instead. Without
matplotlib it writes no figures, and without tifffile the demo writes no TIFF files; it says so when it skips one.

## Use

```
swell-ruler demo                                          # synthetic image pair: run, score, PASS/FAIL per check
swell-ruler images pre.tif post.tif --px-pre 0.194 --px-post 0.194 --e-macro 4.5 --pre-mode dpc \
            --psf-pre 0.55 --psf-post 0.41                # measure your own PSFs with beads
swell-ruler obs observations.json.gz                      # observations in the swell-obs/1 format
swell-ruler stripes myofibrils.png --px 0.16 --mode bf    # no expansion: striation contrast and fragment lengths
```

- `images`: one pre-expansion image (label-free: `dpc` or `pol`) and one post-expansion fluorescence image (or
  `--post-stack` for a z-stack) of the same field. Pixel sizes are at the sample. `--e-macro` is the overall
  expansion factor (gel diameter after ÷ before, photographed on a millimetre grid); it only centres the search
  window (± 10%). The PSF defaults are SWELL's design values, not yours: the transverse ruler needs your measured
  PSFs, and even then S3 showed that an unmodelled blur shape can bias it.
- Output: `result.json` (swell-result/1: per-myofibril axial and transverse factors, landmark factors, maps and
  flags), `summary.md`, `strain_map.png`.
- `stripes`: rungs 2 and 3 of the SWELL evidence ladder. Colour photos are fine (they are averaged to grey). It
  reports q = striation modulation ÷ noise for each myofibril, rescaled to 0.194 µm pixels (the sampling the pass
  mark was simulated at; it warns outside 0.10–0.30 µm), and the fraction of fragments with ≥ 8 sarcomeres. The
  go/no-go for the label-free ruler is a median q ≥ 1.2 over myofibrils with ≥ 10 sarcomeres. Use raw or PNG
  frames: denoising, sharpening and JPEG hide noise and inflate q.

## What it measures

| ruler | from | note |
|---|---|---|
| E_ax | post ÷ pre sarcomere period, Z-disc ladder fit | needs a ladder spanning ≥ 8 sarcomeres; Z-discs at broken ends are ignored |
| E_tr | post ÷ pre myofibril width, forward-model fit | needs measured PSFs; biased on S3 by a blur shape it does not model |
| E_land | affine map of neighbouring myofibril positions | calibration-free; sees the gel, not the fibril |

Gel-level calls use effect sizes: anisotropy is reported only beyond ±1%, a gel is called isotropic when its 90% CI
sits inside ±1%, and no call is made while E_tr and E_land disagree by more than 3%. Flags: local E, fibril vs gel,
gel stretch, non-affine (tear, fold), coverage hole.

## Tests

```
cd software/swell_ruler && python -m pytest -q
```

Written by an AI (Claude by Anthropic, via Claude Code) at the X-WOW owner's direction; its checks were run by AI,
not by an independent person.
