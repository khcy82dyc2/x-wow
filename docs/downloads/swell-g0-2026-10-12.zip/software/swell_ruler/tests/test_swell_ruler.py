"""Tests for swell_ruler. Run from software/swell_ruler:  python -m pytest -q"""
import math

import numpy as np
import pytest

from swell_ruler import profiles as pr
from swell_ruler import run
from swell_ruler.drift import clock_scales
from swell_ruler.matching import match_objects
from swell_ruler.strainmap import anisotropy_call

PX = 0.194


def striated_pair(rng, n_s=12, e=4.5, m=0.15, photons=5000.0, slope=0.0, cut_at_discs=False):
    """Pre (label-free) and post (Z-disc + A-band) profiles of one myofibril fragment, centred on its midpoint."""
    sl = 1.69
    seq = sl * (1 + 0.03 * rng.normal(size=n_s))
    z = np.concatenate([[0.0], np.cumsum(seq)])
    a0, a1 = (0.0, 0.0) if cut_at_discs else tuple(rng.uniform(0.3, 1.0, 2) * sl)
    lo, hi = -a0, z[-1] + a1
    mid = 0.5 * (lo + hi)
    zz = np.concatenate([[z[0] - seq[0]], z, [z[-1] + seq[-1]]])

    def phase(xq):
        k = np.clip(np.searchsorted(zz, xq, side="right") - 1, 0, zz.size - 2)
        return (k - 1) + (xq - zz[k]) / (zz[k + 1] - zz[k])
    n_pre = int((hi - lo) / PX) | 1
    xq = mid + pr.centred_axis(n_pre, PX)
    ph = phase(xq)
    pre = 1 + m * (0.7 * np.cos(2 * np.pi * ph) + 0.3 * np.cos(4 * np.pi * ph))
    pre *= 1 + slope * (xq - xq.mean()) / np.ptp(xq)
    y_pre = rng.poisson(pre * photons).astype(float)
    n_post = int((hi - lo) * e / PX) | 1
    xp = mid + pr.centred_axis(n_post, PX) / e
    f = phase(xp) - np.floor(phase(xp))
    dzz = np.minimum(f, 1 - f) * sl * e
    prof = np.exp(-0.5 * (dzz / (0.05 * e)) ** 2) + 0.6 * (np.abs(f - 0.5) * sl * e < 0.8 * e)
    prof = prof * ((xp >= lo) & (xp <= hi))
    prof = pr._gauss_blur(prof, PX, 0.412 / pr.S2F) + 0.2
    y_post = rng.poisson(prof / prof.max() * 400).astype(float)
    return pr.centred_axis(n_pre, PX), y_pre, pr.centred_axis(n_post, PX), y_post


def test_axial_factor_is_unbiased_and_precise():
    rng = np.random.default_rng(1)
    errs = []
    for _ in range(80):
        e = 4.5 * (1 + rng.normal(0, 0.01))
        a = striated_pair(rng, n_s=12, e=e)
        errs.append(pr.axial_factor(*a, e_c=4.5 * (1 + rng.normal(0, 0.005)))["E"] / e - 1)
    errs = np.array(errs)
    assert abs(errs.mean()) < 0.001
    assert np.sqrt(np.mean(errs ** 2)) < 0.005


def test_end_discs_do_not_bias_fragments_cut_at_a_disc():
    """Fragments that end exactly at a Z-disc (truncated end peaks) biased the v1 ladder low."""
    rng = np.random.default_rng(2)
    errs = [pr.axial_factor(*striated_pair(rng, n_s=12, cut_at_discs=True), e_c=4.5)["E"] / 4.5 - 1
            for _ in range(80)]
    assert abs(np.nanmean(errs)) < 0.001


def test_illumination_slope_is_flattened():
    rng = np.random.default_rng(3)
    errs = [pr.axial_factor(*striated_pair(rng, n_s=10, m=0.05, slope=0.3), e_c=4.5)["E"] / 4.5 - 1
            for _ in range(80)]
    assert np.sqrt(np.nanmean(np.square(errs))) < 0.006


def test_short_ladders_are_refused():
    rng = np.random.default_rng(4)
    assert math.isnan(pr.axial_factor(*striated_pair(rng, n_s=5), e_c=4.5)["E"])


@pytest.mark.parametrize("mirror", [False, True])
def test_matching_finds_partners_with_debris_and_losses(mirror):
    rng = np.random.default_rng(5)
    n = 300
    pre = rng.uniform(-700, 700, (n, 2))
    ang = rng.uniform(0, np.pi, n)
    ln = rng.uniform(6, 30, n)
    th, e, t = 1.1, 4.5, np.array([300.0, -200.0])
    r = np.array([[math.cos(th), -math.sin(th)], [math.sin(th), math.cos(th)]])
    src = pre * np.array([-1.0, 1.0]) if mirror else pre
    a_src = (np.pi - ang) % np.pi if mirror else ang
    post = e * src @ r.T + t + rng.normal(0, 0.4, (n, 2))
    pang = (a_src + th + rng.normal(0, 0.01, n)) % np.pi
    plen = ln * e * (1 + rng.normal(0, 0.03, n))
    keep = rng.uniform(size=n) > 0.05                       # 5% lost
    deb = 15
    post_all = np.vstack([post[keep], rng.uniform(-3500, 3500, (deb, 2)) + t])
    pang_all = np.r_[pang[keep], rng.uniform(0, np.pi, deb)]
    plen_all = np.r_[plen[keep], rng.uniform(20, 120, deb)]
    perm = rng.permutation(len(post_all))
    match, info = match_objects(pre, ang, ln, post_all[perm], pang_all[perm], plen_all[perm], 4.5 * 1.004)
    truth = np.full(n, -1)
    truth[np.where(keep)[0]] = np.argsort(perm)[: keep.sum()]
    good = (match == truth) & (truth >= 0)
    assert info["mirror"] == mirror
    assert good.sum() / keep.sum() > 0.99
    assert np.sum((match >= 0) & (match != truth)) <= 2


def test_clock_recovers_scale():
    rng = np.random.default_rng(6)
    ref = rng.uniform(-100, 100, (200, 2))        # a clock tile holds hundreds of Z-discs or beads
    visits = [{"t": float(k * 500), "objects": [{"x": float(x), "y": float(y)}
                                                for x, y in ref * (1 + 0.001 * k) + rng.normal(0, 0.05, ref.shape)]}
              for k in range(5)]
    ts, ss, _ = clock_scales(visits)
    assert np.allclose(ss, 1 + 0.001 * np.arange(5), atol=2e-4)


def test_anisotropy_call_uses_effect_size():
    rng = np.random.default_rng(7)
    e_tr = 4.5 * (1 + rng.normal(0, 0.005, 600))
    small = anisotropy_call(e_tr * (1 - 0.001) * (1 + rng.normal(0, 0.003, 600)), e_tr)
    big = anisotropy_call(e_tr * (1 - 0.02) * (1 + rng.normal(0, 0.003, 600)), e_tr)
    assert small["call"] == "isotropic"          # -0.1% is significant at n = 600 but not worth reporting
    assert big["call"] == "anisotropic"


def test_demo_image_pair_end_to_end(tmp_path):
    from swell_ruler.demo import make_pair
    from swell_ruler.frontend import observations
    pre, post, truth = make_pair(seed=0)
    obs = observations(pre, post, 0.194, 0.194, truth["E"], "pol", 0.55, 0.41)
    assert len(obs["pre"]) >= 15 and len(obs["post"]) >= 15
    res = run(obs)
    assert res["gel"]["n_matched"] >= 15
    e = [f["E_ax"] for f in res["fibrils"].values() if f["E_ax"] is not None]
    assert len(e) >= 8
    assert abs(np.median(e) / truth["E"] - 1) < 0.01
