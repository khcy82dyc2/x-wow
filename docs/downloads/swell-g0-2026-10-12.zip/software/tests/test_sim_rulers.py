"""Fast checks of the ruler estimators used by the G0 simulations (D-32, D-33, D-34).

Run:  .venv/Scripts/python.exe -m pytest software/tests -q
These move with the estimators into the swell.qc package in Order 7.
"""
import math
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "sim"))
import strain_map_sim as sm  # noqa: E402
from design_calc import _fit_period  # noqa: E402


def test_vectorised_period_fit_matches_reference():
    rng = np.random.default_rng(5)
    for _ in range(5):
        seq = 1.69 * (1 + 0.03 * rng.normal(size=12))
        xa, ya, xb, yb = sm.pre_post_profiles(rng, seq, 4.5)
        assert sm.fit_period(ya, xa, 1.69) == pytest.approx(_fit_period(ya - ya.mean(), xa, 1.69), rel=1e-12)
        assert sm.fit_period(yb, xb, 7.6) == pytest.approx(_fit_period(yb - yb.mean(), xb, 7.6), rel=1e-12)


@pytest.mark.parametrize("sl", [1.60, 1.69, 1.80])
def test_ladder_recovers_axial_factor_under_jitter(sl):
    """3% sarcomere jitter, 0.3 µm registration error, 12 sarcomeres: median error ≤ 0.5%, none beyond 2%."""
    rng = np.random.default_rng(int(sl * 100))
    errs = []
    for _ in range(40):
        e = 4.5 * (1 + rng.normal(0, 0.02))
        seq = sl * (1 + 0.03 * rng.normal(size=12))
        xa, ya, xb, yb = sm.pre_post_profiles(rng, seq, e)
        xb = xb + e * rng.normal(0, 0.3)
        e_hat, r2 = sm.period_ratio_ladder(xa, ya, xb, yb, 4.5 * (1 + rng.normal(0, 0.005)))
        errs.append(e_hat / e - 1)
    errs = np.abs(np.array(errs))
    assert np.median(errs) <= 0.005
    assert errs.max() <= 0.02


@pytest.mark.parametrize("mode", ["dpc", "pol"])
def test_width_ratio_unbiased_when_calibrated(mode):
    rng = np.random.default_rng(11)
    errs = []
    for _ in range(25):
        w, asp, e = 1.2, 1.0, 4.5
        n_rows = int(10.0 / sm.PX)
        wp = sm.measure_width_pre(rng, w, asp, n_rows, mode, sm.FWHM_PRE / sm.S2F, sm.FWHM_PRE / sm.S2F, asp)
        wq = sm.measure_width_post(rng, w * e, asp, int(n_rows * e), sm.FWHM_POST / sm.S2F, sm.FWHM_POST / sm.S2F, asp)
        errs.append(wq / wp / e - 1)
    assert abs(np.mean(errs)) <= 0.005
    assert np.std(errs) <= 0.015


def test_width_ratio_bias_from_psf_miscalibration_is_visible():
    """A pre-image PSF assumed 5% too wide must bias E_tr upwards (why G1 calibrates to ±2%, D-32)."""
    rng = np.random.default_rng(12)
    errs = []
    for _ in range(25):
        n_rows = int(10.0 / sm.PX)
        wp = sm.measure_width_pre(rng, 1.2, 1.0, n_rows, "pol", sm.FWHM_PRE / sm.S2F, 1.05 * sm.FWHM_PRE / sm.S2F, 1.0)
        wq = sm.measure_width_post(rng, 5.4, 1.0, int(n_rows * 4.5), sm.FWHM_POST / sm.S2F, sm.FWHM_POST / sm.S2F, 1.0)
        errs.append(wq / wp / 4.5 - 1)
    assert np.mean(errs) > 0.01


def test_similarity_fit_is_exact_without_noise():
    rng = np.random.default_rng(3)
    src = rng.uniform(-700, 700, (200, 2))
    th, s, t = 0.35, 4.5, np.array([150.0, -90.0])
    r = np.array([[math.cos(th), -math.sin(th)], [math.sin(th), math.cos(th)]])
    dst = s * src @ r.T + t
    s_hat, r_hat, t_hat = sm.similarity_fit(src, dst)
    assert s_hat == pytest.approx(s, rel=1e-12)
    assert np.allclose(r_hat, r) and np.allclose(t_hat, t)


def test_local_affine_flags_a_tear_but_not_a_smooth_gel():
    sc_tear = sm.Scenario("t", "tear only", radial=0.0, tear_open=3.0)
    sc_flat = sm.Scenario("f", "flat", radial=0.0)
    rng = np.random.default_rng(4)
    pts = sm.R_GEL * 0.9 * np.sqrt(rng.uniform(0, 1, 800))[:, None] * np.c_[np.cos(a := rng.uniform(0, 2 * np.pi, 800)), np.sin(a)]
    _, res_flat = sm.local_affine(pts, sm.deform(pts, sc_flat), sm.E0)
    _, res_tear = sm.local_affine(pts, sm.deform(pts, sc_tear), sm.E0)
    assert res_flat.max() < 1e-6
    assert res_tear.max() > 0.5


@pytest.mark.parametrize("mode", ["dpc", "pol"])
def test_boxy_sections_need_the_post_measured_shape(mode):
    """A boxy (n = 4) cross-section fitted as an ellipse biases E_tr by -9 to -15%; with the shape measured from the
    post z-projection the bias is below 1% (D-32)."""
    rng = np.random.default_rng(21)
    n_rows = int(10.0 / sm.PX)
    assumed, measured = [], []
    for _ in range(15):
        n_hat = sm.measure_shape_post(rng, 5.4, 1.0, int(n_rows * 4.5), 4.0, sm.FWHM_POST / sm.S2F)
        for fit_n, out in ((2.0, assumed), (n_hat, measured)):
            wp = sm.measure_width_pre(rng, 1.2, 1.0, n_rows, mode, sm.FWHM_PRE / sm.S2F, sm.FWHM_PRE / sm.S2F, 1.0,
                                      true_n=4.0, fit_n=fit_n)
            wq = sm.measure_width_post(rng, 5.4, 1.0, int(n_rows * 4.5), sm.FWHM_POST / sm.S2F, sm.FWHM_POST / sm.S2F,
                                       1.0, true_n=4.0, fit_n=fit_n)
            out.append(wq / wp / 4.5 - 1)
    assert np.mean(assumed) < -0.05
    assert abs(np.mean(measured)) < 0.01
