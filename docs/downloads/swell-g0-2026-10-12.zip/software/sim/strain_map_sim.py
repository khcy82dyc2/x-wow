"""SWELL whole-gel strain map: per-myofibril local expansion factors and a distortion heatmap (G0, D-34).

A synthetic Track A gel (1.5 mm punch, E 4.5) holds 1,200 isolated myofibrils with real sarcomere sequences. It is
given a known pre -> post deformation (global similarity + planted non-rigid defects) and known intra-myofibril
factors. Every myofibril is then measured the way the pipeline will measure it (D-4, D-32, D-33):

  axial       E_ax  = SL_post / SL_pre    period ratio, Z-disc ladder estimator (D-33), segments of >= 8 sarcomeres
  transverse  E_tr  = W_post / W_pre      width ratio: forward-model fit with the bead PSF, the z-stack aspect and the
                                          cross-section shape measured from the post z-projection
  landmark    F     = local affine map of myofibril centroids (blur-free), giving E along and across each fibril

Per-myofibril values become kernel-smoothed heatmaps: local E, anisotropy (E_ax / E_tr), fibril-vs-gel
(E_ax / E_land,ax) and distortion (residual displacement after the global similarity fit). Flags are scored against
the planted truth. Development gels S0 (good), S1 (planted defects), S2 (2% anisotropies) share seed 7; S1b is
the blind gel (seed 99, defects moved and resized, nothing tuned against it).

Run:  .venv/Scripts/python.exe software/sim/strain_map_sim.py
Out:  docs/design/strain_map_v1.md, strain_map_v1.json, figs/strain_map_S*.png; per-fibril CSVs in data/sim/
"""
from __future__ import annotations

import json
import math
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
from scipy import stats
from scipy.ndimage import gaussian_filter1d
from scipy.optimize import least_squares
from scipy.signal import find_peaks
from scipy.spatial import cKDTree
from scipy.special import erf

sys.path.insert(0, str(Path(__file__).resolve().parent))
from design_calc import _fit_period  # noqa: E402  reference estimator (equivalence check)

ROOT = Path(__file__).resolve().parents[2]
PX = 0.194                 # µm/pixel at the sample (optics_v1: 40x/0.65 + f100 tube lens at 25 mm)
FWHM_POST = 0.412          # µm, Gibson-Lanni lateral FWHM of the 40x/0.65 into water (optics_v1)
FWHM_PRE = 0.55            # µm, effective resolution of the label-free (oblique/DPC) pre-image (assumption; P1 measures)
DOF_UM = 1.64              # µm, depth of field in water at NA 0.65 (calc_v0)
S2F = 2.0 * math.sqrt(2.0 * math.log(2.0))
E0 = 4.5                   # global expansion factor
R_GEL = 750.0              # µm, pre-expansion radius of the 1.5 mm punch
MIN_SARC = 8               # period ratio only on segments of ≥ 8 sarcomeres (Order 7 specifies 10-sarcomere segments)


@dataclass
class Scenario:
    name: str
    label: str
    radial: float = 0.01            # extra radial strain at the rim (gel edge effect)
    hotspot: float = 0.0            # isotropic under-expansion at the hotspot centre
    hotspot_c: tuple = (-320.0, 180.0)
    hotspot_sigma: float = 70.0
    band: float = 0.0               # gel stretched along the band axis inside a band
    band_angle: float = 0.6
    band_offset: float = -260.0
    band_width: float = 140.0
    band_half_length: float = 220.0
    tear_open: float = 0.0          # µm (pre-coordinates) opening across a crack
    tear_a: tuple = (60.0, 330.0)
    tear_b: tuple = (420.0, 120.0)
    tear_decay: float = 60.0
    undig: float = 0.0              # intrinsic axial under-expansion of myofibrils inside a patch
    undig_c: tuple = (260.0, -360.0)
    undig_r: float = 130.0
    ax_aniso: float = 0.0           # intrinsic E_ax / E_tr - 1 of every myofibril
    gel_stretch: float = 0.0        # gel-level stretch along gel_psi (orientation test)
    gel_psi: float = 0.4
    seed: int = 7


SCENARIOS = [
    Scenario("S0", "good gel: 1% radial edge gradient only"),
    Scenario("S1", "planted defects: −5% hotspot, +3% stretched patch, 2 µm tear, −4% under-digested patch, 2% radial",
             radial=0.02, hotspot=0.05, band=0.03, tear_open=2.0, undig=0.04),
    Scenario("S1b", "blind rerun: new gel (seed 99); −4% hotspot, +2.5% patch, 1.5 µm tear, −3% under-digested patch, "
             "all moved and resized; detectors untouched",
             radial=0.015, hotspot=0.04, hotspot_c=(330.0, 260.0), hotspot_sigma=60.0, band=0.025, band_angle=-0.9,
             band_offset=180.0, band_half_length=180.0, tear_open=1.5, tear_a=(-480.0, -150.0), tear_b=(-200.0, -420.0),
             undig=0.03, undig_c=(-250.0, 330.0), undig_r=110.0, seed=99),
    Scenario("S2", "anisotropy: every myofibril 2% shorter axially than transversely; gel stretched 2% along 23°",
             ax_aniso=-0.02, gel_stretch=0.02),
]


# ----------------------------------------------------------------------------------------------------------------
# Deformation
# ----------------------------------------------------------------------------------------------------------------
def _crack_frame(sc):
    a, b = np.array(sc.tear_a), np.array(sc.tear_b)
    t = (b - a) / np.linalg.norm(b - a)
    return a, t, np.array([-t[1], t[0]]), float(np.linalg.norm(b - a))


def delta(x, sc):
    """Non-rigid displacement (pre-coordinates, µm) at pre points x (N, 2)."""
    d = np.zeros_like(x)
    r2 = (x ** 2).sum(1, keepdims=True)
    d += sc.radial / 3.0 * x * r2 / R_GEL ** 2
    if sc.hotspot:
        dx = x - np.array(sc.hotspot_c)
        d += -sc.hotspot * dx * np.exp(-(dx ** 2).sum(1, keepdims=True) / (2 * sc.hotspot_sigma ** 2))
    if sc.band:
        e1 = np.array([math.cos(sc.band_angle), math.sin(sc.band_angle)])
        e2 = np.array([-e1[1], e1[0]])
        xi, eta = x @ e1, x @ e2 - sc.band_offset
        w = 0.5 * (np.tanh((eta + sc.band_width / 2) / 20.0) - np.tanh((eta - sc.band_width / 2) / 20.0))
        wx = 0.5 * (np.tanh((xi + sc.band_half_length) / 30.0) - np.tanh((xi - sc.band_half_length) / 30.0))
        d += (sc.band * xi * w * wx)[:, None] * e1
    if sc.tear_open:
        a, t, n, lc = _crack_frame(sc)
        s, h = (x - a) @ t, (x - a) @ n
        taper = np.where((s > 0) & (s < lc), np.sin(np.pi * np.clip(s, 0, lc) / lc), 0.0)
        d += (sc.tear_open / 2 * taper * np.sign(h) * np.exp(-np.abs(h) / sc.tear_decay))[:, None] * n
    if sc.gel_stretch:
        e = np.array([math.cos(sc.gel_psi), math.sin(sc.gel_psi)])
        d += (sc.gel_stretch * (x @ e))[:, None] * e
    return d


THETA0, T0 = 0.35, np.array([150.0, -90.0])
ROT0 = np.array([[math.cos(THETA0), -math.sin(THETA0)], [math.sin(THETA0), math.cos(THETA0)]])


def deform(x, sc):
    return E0 * (x + delta(x, sc)) @ ROT0.T + T0


def jacobian(x, sc, h=0.25):
    j = np.zeros((x.shape[0], 2, 2))
    for k in range(2):
        e = np.zeros(2)
        e[k] = h
        j[:, :, k] = (delta(x + e, sc) - delta(x - e, sc)) / (2 * h)
    return E0 * np.einsum("ij,njk->nik", ROT0, np.eye(2) + j)


# ----------------------------------------------------------------------------------------------------------------
# Estimators (these move into the swell.qc package in Order 7)
# ----------------------------------------------------------------------------------------------------------------
def fit_period(y, x, p_expected, harmonics=(1, 2, 3), window=0.15):
    """Same estimator as design_calc._fit_period (3-harmonic least squares inside a ±15% prior window, coarse 121 ->
    fine 41 grid, parabolic refinement), vectorised over trial frequencies via the normal equations."""
    y = y - y.mean()
    yy = float(y @ y)

    def rss(freqs):
        ph = 2 * np.pi * np.outer(freqs, x)
        a = np.stack([f(h * ph) for h in harmonics for f in (np.cos, np.sin)], axis=-1)
        g = np.einsum("fni,fnj->fij", a, a)
        b = np.einsum("fni,n->fi", a, y)
        coef = np.linalg.solve(g, b[..., None])[..., 0]
        return yy - np.einsum("fi,fi->f", b, coef)

    coarse = np.linspace(1 - window, 1 + window, 121) / p_expected
    i = int(np.argmin(rss(coarse)))
    fine = np.linspace(coarse[max(i - 1, 0)], coarse[min(i + 1, coarse.size - 1)], 41)
    r = rss(fine)
    j = int(np.clip(np.argmin(r), 1, fine.size - 2))
    den = r[j - 1] - 2 * r[j] + r[j + 1]
    shift = 0.5 * (r[j - 1] - r[j + 1]) / den if den > 0 else 0.0
    return 1.0 / (fine[j] + shift * (fine[1] - fine[0]))


def _gauss_blur(prof, dx, sigma):
    """Gaussian blur with zero padding; output always has the input's length."""
    return gaussian_filter1d(np.asarray(prof, float), sigma / dx, mode="constant", truncate=4.0)


def z_ladder(y, x, p_expected):
    """Z-disc positions in a post-expansion striation profile: the brightest narrow peaks, at least 0.6 periods
    apart, refined to sub-pixel by a parabola. Returns positions and their sarcomere index (gaps are counted)."""
    dx = x[1] - x[0]
    ys = gaussian_filter1d(np.asarray(y, float), 0.15 / dx)
    span = np.percentile(ys, 95) - np.percentile(ys, 5)
    pk, _ = find_peaks(ys, distance=max(int(0.6 * p_expected / dx), 1), prominence=0.25 * span)
    pk = pk[(pk > 0) & (pk < ys.size - 1)]
    if pk.size < 3:
        return np.array([]), np.array([])
    y0, y1, y2 = ys[pk - 1], ys[pk], ys[pk + 1]
    den = y0 - 2 * y1 + y2
    pos = x[pk] + dx * np.where(den < 0, 0.5 * (y0 - y2) / np.where(den < 0, den, -1), 0.0)
    step = np.median(np.diff(pos))
    idx = np.concatenate([[0], np.cumsum(np.maximum(np.round(np.diff(pos) / step), 1))])
    return pos, idx


def period_ratio_ladder(x_pre, y_pre, x_post, y_post, e_c, harmonics=(1, 2, 3), window=0.10, p0=1.69):
    """E_ax for one myofibril. The post image's own Z-disc ladder defines a sarcomere coordinate (phase 2πk at the
    k-th Z-disc, linear in between), so the template carries the sarcomere-to-sarcomere jitter. The pre profile is
    fitted with harmonics of that phase at x_post = E * x_pre for trial E in E_macro ± 10%.
    Why not a free-frequency fit: with jitter, or when the I-band dips cancel the Z-disc in the fundamental
    (SL ≈ 1.8 µm), it locks onto sidelobes at ±1/N. Returns (E, R²); R² = pre-profile variance explained (QC)."""
    zpos, zidx = z_ladder(y_post, x_post, p0 * e_c)
    if zpos.size < 4:
        return float("nan"), 0.0
    xt, pt = zpos, 2 * np.pi * zidx
    emin, emax = e_c * (1 - window), e_c * (1 + window)
    sel = (x_pre >= xt[0] / emin) & (x_pre <= xt[-1] / emax)
    if sel.sum() < 8:
        return float("nan"), 0.0
    xs, ys = x_pre[sel], y_pre[sel] - y_pre[sel].mean()
    tss = float(ys @ ys)

    def rss(es):
        ph = np.interp(np.outer(es, xs), xt, pt)
        a = np.stack([f(h * ph) for h in harmonics for f in (np.cos, np.sin)], axis=-1)
        g = np.einsum("fni,fnj->fij", a, a)
        b = np.einsum("fni,n->fi", a, ys)
        coef = np.linalg.solve(g, b[..., None])[..., 0]
        return tss - np.einsum("fi,fi->f", b, coef)

    coarse = np.linspace(emin, emax, 121)
    i = int(np.argmin(rss(coarse)))
    fine = np.linspace(coarse[max(i - 1, 0)], coarse[min(i + 1, coarse.size - 1)], 41)
    r = rss(fine)
    j = int(np.clip(np.argmin(r), 1, fine.size - 2))
    den = r[j - 1] - 2 * r[j] + r[j + 1]
    shift = 0.5 * (r[j - 1] - r[j + 1]) / den if den > 0 else 0.0
    return float(fine[j] + shift * (fine[1] - fine[0])), float(1 - r[j] / tss)


def _ellipse_chord(xf, w, asp, n=2.0):
    """Projected thickness across a myofibril of width w and height asp*w, for a super-ellipse cross-section with
    exponent n (2 = ellipse; larger = boxier, as polygonal myofibrils can be)."""
    return asp * w * np.clip(1 - np.abs(2 * xf / w) ** n, 0, None) ** (1.0 / n)


def measure_shape_post(rng, w_post, asp, n_rows, true_n, sigma, photons=400.0, planes=10):
    """Cross-section shape from the post z-stack: the sum over planes is proportional to projected thickness, and it
    is resolved ~4.5x better relative to the myofibril than in the pre-image. Fit width and super-ellipse exponent;
    returns the exponent."""
    half = w_post / 2 + 3.0
    x = np.arange(-half, half, PX)
    dx = 0.02

    def model(p):
        xf = np.arange(x.min() - 2.0, x.max() + 2.0, dx)
        t = _ellipse_chord(xf - p[3], p[0], 1.0, p[1])
        return p[4] + p[2] * np.interp(x, xf, _gauss_blur(t, dx, sigma))
    clean = model([w_post, true_n, 1.0 / w_post, 0.0, 0.05])
    scale = photons / clean.max() * n_rows * planes
    y = rng.poisson(clean * scale) / scale
    sol = least_squares(lambda p: model(p) - y, [w_post * rng.uniform(0.95, 1.05), 2.5, 1.0 / w_post, 0.0, 0.05],
                        bounds=([0.5, 1.5, 0, -2, 0], [30, 8, 10, 2, 2]))
    return float(sol.x[1])


def pre_width_model(x, w, amp, x0, bg, sigma, asp, mode, n=2.0):
    """Label-free pre-image cross-profile of a myofibril (elliptical cross-section, width w, height asp*w).
    dpc: phase-gradient image ∝ d/dx(PSF ⊗ thickness); pol: crossed polarisers ∝ PSF ⊗ thickness²."""
    dx = 0.005
    xf = np.arange(x.min() - 2.0, x.max() + 2.0, dx)
    t = _ellipse_chord(xf - x0, w, asp, n)
    if mode == "pol":
        prof = _gauss_blur(t ** 2, dx, sigma)
    else:
        prof = np.gradient(_gauss_blur(t, dx, sigma), dx)
    return bg + amp * np.interp(x, xf, prof)


def post_width_model(x, w, a1, a2, x0, bg, sigma, asp, sigma_d=1.0, n=2.0):
    """Post-expansion fluorescence at mid-height focus: in-focus band (rect ⊗ PSF) + out-of-focus pedestal
    (projected thickness ⊗ a broad defocus kernel)."""
    inf = 0.5 * (erf((x - x0 + w / 2) / (sigma * math.sqrt(2))) - erf((x - x0 - w / 2) / (sigma * math.sqrt(2))))
    dx = 0.02
    xf = np.arange(x.min() - 4.0, x.max() + 4.0, dx)
    t = _ellipse_chord(xf - x0, w, asp, n)
    ped = _gauss_blur(t / max(t.max(), 1e-9), dx, sigma_d)
    return bg + a1 * inf + a2 * np.interp(x, xf, ped)


def measure_width_pre(rng, w, asp, n_rows, mode, sigma_true, sigma_fit, asp_fit, photons=5000.0, true_n=2.0, fit_n=2.0):
    x = np.arange(-2.6, 2.6, PX)
    if mode == "pol":
        clean = pre_width_model(x, w, 0.5 / max(asp * w, 1e-9) ** 2, 0.0, 0.05, sigma_true, asp, "pol", true_n)
        y = rng.poisson(clean * photons * n_rows) / (photons * n_rows)
        p0 = [1.2, 0.5 / 1.44, 0.0, 0.05]
    else:
        clean = pre_width_model(x, w, 0.08 / max(asp * w, 1e-9), 0.0, 0.0, sigma_true, asp, "dpc", true_n)
        y = clean + rng.normal(0, 1 / math.sqrt(photons * n_rows), x.size)
        p0 = [1.2, 0.08 / 1.2, 0.0, 0.0]

    def res(p):
        return pre_width_model(x, p[0], p[1], p[2], p[3], sigma_fit, asp_fit, mode, fit_n) - y
    sol = least_squares(res, p0, bounds=([0.3, 0, -0.5, -1], [3.0, 50, 0.5, 1]), x_scale=[0.3, 0.05, 0.1, 0.01])
    return float(sol.x[0])


def measure_width_post(rng, w_post, asp, n_rows, sigma_true, sigma_fit, asp_fit, photons=400.0, true_n=2.0, fit_n=2.0):
    half = w_post / 2 + 4.0
    x = np.arange(-half, half, PX)
    t_exp = asp * w_post
    a2 = max(t_exp / DOF_UM - 1.0, 0.0)
    clean = post_width_model(x, w_post, 1.0, a2, 0.0, 0.1, sigma_true, asp, n=true_n)
    scale = photons / clean.max() * n_rows
    y = rng.poisson(clean * scale) / scale

    def res(p):
        return post_width_model(x, p[0], p[1], p[2], p[3], p[4], sigma_fit, asp_fit, n=fit_n) - y
    p0 = [w_post * rng.uniform(0.9, 1.1), 1.0, a2, 0.0, 0.1]
    sol = least_squares(res, p0, bounds=([0.5, 0, 0, -2, 0], [30, 5, 20, 2, 2]))
    return float(sol.x[0])


def pre_post_profiles(rng, sl_seq, e_ax, m_pre=0.15, photons_pre=5000.0, photons_post=400.0):
    """1-D striation profiles of the same sarcomere sequence before and after axial expansion e_ax."""
    z = np.concatenate([[0.0], np.cumsum(sl_seq)])
    x_pre = np.arange(0, z[-1], PX)
    k = np.clip(np.searchsorted(z, x_pre, side="right") - 1, 0, sl_seq.size - 1)
    phi = k + (x_pre - z[k]) / sl_seq[k]
    ph0 = rng.uniform(0, 1)
    pre = 1 + m_pre * (0.7 * np.cos(2 * np.pi * (phi + ph0)) + 0.3 * np.cos(4 * np.pi * (phi + ph0)))
    y_pre = rng.poisson(pre * photons_pre).astype(float)
    x_post = np.arange(0, z[-1] * e_ax, PX)
    xp = x_post / e_ax
    k = np.clip(np.searchsorted(z, xp, side="right") - 1, 0, sl_seq.size - 1)
    f = (xp - z[k]) / sl_seq[k]
    p_post = sl_seq[k] * e_ax
    dz = np.minimum(f, 1 - f) * p_post
    a_half = np.minimum(1.6 * e_ax / 2, p_post / 2)
    prof = 0.6 * (np.abs(f - 0.5) * p_post < a_half) + np.exp(-0.5 * (dz / (0.05 * e_ax)) ** 2)
    prof = _gauss_blur(prof, PX, FWHM_POST / S2F) + 0.2
    y_post = rng.poisson(prof / prof.max() * photons_post).astype(float)
    return x_pre, y_pre, x_post, y_post


def similarity_fit(src, dst, w=None):
    """Umeyama: dst ≈ s R src + t (weighted)."""
    w = np.ones(len(src)) if w is None else w
    w = w / w.sum()
    ms, md = w @ src, w @ dst
    a, b = src - ms, dst - md
    cov = (b * w[:, None]).T @ a
    u, s, vt = np.linalg.svd(cov)
    d = np.sign(np.linalg.det(u @ vt))
    dm = np.diag([1, d])
    r = u @ dm @ vt
    scale = np.trace(np.diag(s) @ dm) / (w @ (a ** 2).sum(1))
    return scale, r, md - scale * r @ ms


# ----------------------------------------------------------------------------------------------------------------
# One gel
# ----------------------------------------------------------------------------------------------------------------
def run_gel(sc: Scenario, n_fibrils=1200, seed=7, pre_mode="dpc"):
    rng = np.random.default_rng(seed)
    rr = R_GEL * np.sqrt(rng.uniform(0, 0.92 ** 2, n_fibrils))
    th = rng.uniform(0, 2 * np.pi, n_fibrils)
    c = np.c_[rr * np.cos(th), rr * np.sin(th)]
    phi = rng.uniform(0, np.pi, n_fibrils)
    length = np.clip(np.exp(rng.normal(math.log(14.0), 0.5, n_fibrils)), 6.0, 40.0)
    width = np.clip(rng.normal(1.2, 0.2, n_fibrils), 0.7, 2.0)
    asp = np.clip(rng.normal(1.0, 0.1, n_fibrils), 0.7, 1.3)
    sl = rng.normal(1.69, 0.08, n_fibrils)
    shape_n = np.random.default_rng(seed + 1000).uniform(2.0, 3.5, n_fibrils)  # ellipse ... rounded polygon
    u = np.c_[np.cos(phi), np.sin(phi)]
    v = np.c_[-np.sin(phi), np.cos(phi)]

    f_true = jacobian(c, sc)
    e_gel_ax = np.linalg.norm(np.einsum("nij,nj->ni", f_true, u), axis=1)
    e_gel_tr = np.linalg.norm(np.einsum("nij,nj->ni", f_true, v), axis=1)
    k_ax = rng.normal(0, 0.002, n_fibrils) + sc.ax_aniso
    k_tr = rng.normal(0, 0.002, n_fibrils)
    if sc.undig:
        k_ax -= sc.undig * (np.linalg.norm(c - np.array(sc.undig_c), axis=1) < sc.undig_r)
    e_ax = e_gel_ax * (1 + k_ax)
    e_tr = e_gel_tr * (1 + k_tr)

    # Measurements
    e_macro = E0 * (1 + rng.normal(0, 0.005))              # overview camera (D-13), sets the post prior window
    e_ax_hat = np.full(n_fibrils, np.nan)
    r2 = np.zeros(n_fibrils)
    e_tr_hat = np.full(n_fibrils, np.nan)
    n_sarc = np.minimum((length / sl).astype(int), 20)
    for i in range(n_fibrils):
        if n_sarc[i] >= MIN_SARC:
            seq = sl[i] * (1 + 0.03 * rng.normal(size=n_sarc[i]))      # 3% sarcomere-to-sarcomere jitter
            xa, ya, xb, yb = pre_post_profiles(rng, seq, e_ax[i])
            xb = xb + e_ax[i] * rng.normal(0, 0.3)                       # 0.3 µm (pre) registration error of the fibril origin
            e_ax_hat[i], r2[i] = period_ratio_ladder(xa, ya, xb, yb, e_macro)
        n_rows = max(int(length[i] / PX), 1)
        asp_fit = asp[i] * (1 + rng.normal(0, 0.03))      # cross-section aspect from the post z-stack
        n_fit = measure_shape_post(rng, width[i] * e_tr[i], asp[i], int(n_rows * e_ax[i]), shape_n[i],
                                   FWHM_POST / S2F)                 # cross-section shape from the post z-projection
        w_pre = measure_width_pre(rng, width[i], asp[i], n_rows, pre_mode, FWHM_PRE / S2F, FWHM_PRE / S2F, asp_fit,
                                  true_n=shape_n[i], fit_n=n_fit)
        w_post = measure_width_post(rng, width[i] * e_tr[i], asp[i], int(n_rows * e_ax[i]),
                                    FWHM_POST / S2F, FWHM_POST / S2F, asp_fit, true_n=shape_n[i], fit_n=n_fit)
        e_tr_hat[i] = w_post / w_pre

    pre_m = c + u * rng.normal(0, 0.15, (n_fibrils, 1)) + v * rng.normal(0, 0.05, (n_fibrils, 1))
    post_true = deform(c, sc)
    ur, vr = u @ ROT0.T, v @ ROT0.T
    post_m = post_true + ur * rng.normal(0, 0.30, (n_fibrils, 1)) + vr * rng.normal(0, 0.10, (n_fibrils, 1))
    phi_m = phi + rng.normal(0, math.radians(1.0), n_fibrils)
    u_m, v_m = np.c_[np.cos(phi_m), np.sin(phi_m)], np.c_[-np.sin(phi_m), np.cos(phi_m)]

    # Global similarity (robust: two passes) and residual distortion
    s_hat, r_hat, t_hat = similarity_fit(pre_m, post_m)
    for _ in range(2):
        res = np.linalg.norm(post_m - (s_hat * pre_m @ r_hat.T + t_hat), axis=1)
        keep = res < np.median(res) + 4 * 1.4826 * np.median(np.abs(res - np.median(res)))
        s_hat, r_hat, t_hat = similarity_fit(pre_m[keep], post_m[keep])
    resid = (post_m - (s_hat * pre_m @ r_hat.T + t_hat)) @ r_hat / s_hat       # back in pre-coordinates (µm)
    s_true, r_true, t_true = similarity_fit(c, post_true)
    resid_true = (post_true - (s_true * c @ r_true.T + t_true)) @ r_true / s_true

    a_loc, res_rms = local_affine(pre_m, post_m, s_hat)
    _, res_rms_true = local_affine(c, post_true, s_true)
    e_land_ax = np.linalg.norm(np.einsum("nij,nj->ni", a_loc, u_m), axis=1)
    e_land_tr = np.linalg.norm(np.einsum("nij,nj->ni", a_loc, v_m), axis=1)
    sv = np.linalg.svd(a_loc, compute_uv=False)
    sv_true = np.linalg.svd(f_true, compute_uv=False)

    fib = {"c": c, "phi": phi, "length": length, "width": width, "n_sarc": n_sarc, "r2": r2,
           "e_ax": e_ax, "e_tr": e_tr, "e_gel_ax": e_gel_ax, "e_gel_tr": e_gel_tr,
           "e_ax_hat": e_ax_hat, "e_tr_hat": e_tr_hat, "e_land_ax": e_land_ax, "e_land_tr": e_land_tr,
           "land_aniso": sv[:, 0] / sv[:, 1] - 1, "land_aniso_true": sv_true[:, 0] / sv_true[:, 1] - 1,
           "res_rms": res_rms, "res_rms_true": res_rms_true, "resid": resid, "resid_true": resid_true,
           "pre_m": pre_m, "post_m": post_m, "post_true": post_true, "s_hat": s_hat, "s_true": s_true,
           "e_macro": e_macro, "a_loc": a_loc, "liso_true": np.sqrt(np.abs(np.linalg.det(f_true)))}
    return fib


def local_affine(pre, post, scale, radius=100.0, k_min=10):
    """Local deformation gradient per myofibril: affine fit of its neighbours' centroids (within 100 µm, ≥ 10).
    The fit residual (pre-expansion µm) exposes tears and folds, which no affine map can follow."""
    tree = cKDTree(pre)
    a_loc = np.zeros((len(pre), 2, 2))
    res_rms = np.zeros(len(pre))
    for i in range(len(pre)):
        idx = tree.query_ball_point(pre[i], radius)
        if len(idx) < k_min:
            idx = tree.query(pre[i], k_min)[1]
        idx = np.asarray(idx)
        x1 = np.c_[pre[idx], np.ones(idx.size)]
        coef, *_ = np.linalg.lstsq(x1, post[idx], rcond=None)
        a_loc[i] = coef[:2].T
        res_rms[i] = np.sqrt(np.mean(np.sum((x1 @ coef - post[idx]) ** 2, axis=1))) / scale
    return a_loc, res_rms


# ----------------------------------------------------------------------------------------------------------------
# Maps, flags, scores
# ----------------------------------------------------------------------------------------------------------------
GRID_STEP, KERNEL = 20.0, 45.0


def smooth_map(pos, val, grid, robust=True):
    """Gaussian-kernel local average of per-myofibril values on the grid. robust=True (period-ratio maps only)
    adds two biweight passes against each fibril's own local value with a wide cut (9 robust SD), so a failed fit
    cannot paint a fake defect while a real -4% patch survives. Landmark maps are already smooth and precise,
    so they are never robustified (a tight cut would erase real small defects)."""
    ok = np.isfinite(val)
    p, v = pos[ok], val[ok]
    w = np.exp(-((grid[:, None, :] - p[None, :, :]) ** 2).sum(-1) / (2 * KERNEL ** 2))
    sw = w.sum(1)
    b = np.ones(v.size)
    if robust:
        wf = np.exp(-((p[:, None, :] - p[None, :, :]) ** 2).sum(-1) / (2 * KERNEL ** 2))
        for _ in range(2):
            loc = (wf @ (b * v)) / np.maximum(wf @ b, 1e-12)
            r = v - loc
            sc = max(robust_sd(r), 1e-9)
            b = np.where(np.abs(r) < 9.0 * sc, (1 - (r / (9.0 * sc)) ** 2) ** 2, 0.0)
    return (w @ (b * v)) / np.maximum(w @ b, 1e-12), sw


def robust_sd(x):
    x = x[np.isfinite(x)]
    return 1.4826 * float(np.median(np.abs(x - np.median(x))))


def neighbourhoods(sc, grid):
    """Generous areas around each planted defect (scoring only; the truth maps decide where a signal exists)."""
    out = {}
    if sc.hotspot:
        out["hotspot"] = np.linalg.norm(grid - np.array(sc.hotspot_c), axis=1) < 2.0 * sc.hotspot_sigma
    if sc.band:
        e1 = np.array([math.cos(sc.band_angle), math.sin(sc.band_angle)])
        eta = grid @ np.array([-e1[1], e1[0]]) - sc.band_offset
        xi = grid @ e1
        out["stretched patch"] = (np.abs(eta) < sc.band_width / 2 + 20) & (np.abs(xi) < sc.band_half_length + 40)
    if sc.tear_open:
        a, t, n, lc = _crack_frame(sc)
        s = np.clip((grid - a) @ t, 0, lc)
        out["tear"] = np.linalg.norm(grid - (a + s[:, None] * t), axis=1) < 60
    if sc.undig:
        out["under-digested patch"] = np.linalg.norm(grid - np.array(sc.undig_c), axis=1) < sc.undig_r + 20
    return out


def analyse(sc, fib):
    g = np.arange(-R_GEL, R_GEL + 1, GRID_STEP)
    gx, gy = np.meshgrid(g, g)
    grid = np.c_[gx.ravel(), gy.ravel()]
    inside = np.linalg.norm(grid, axis=1) < 0.9 * R_GEL
    pos, c = fib["pre_m"], fib["c"]
    ok = np.isfinite(fib["e_ax_hat"])
    med_hat = float(np.nanmedian(fib["e_ax_hat"]))
    med_true = float(np.median(fib["e_ax"][ok]))

    def only_ok(a):
        return np.where(ok, a, np.nan)

    # Measured maps (robust) and truth maps (same kernel, true positions and values)
    m_ax, sw = smooth_map(pos, fib["e_ax_hat"] / med_hat - 1, grid)
    t_ax, _ = smooth_map(c, only_ok(fib["e_ax"] / med_true - 1), grid, robust=False)
    aniso_fib = fib["e_ax_hat"] / fib["e_tr_hat"] - 1
    m_an, _ = smooth_map(pos, aniso_fib - np.nanmedian(aniso_fib), grid)
    fvg = fib["e_ax_hat"] / fib["e_land_ax"] - 1
    m_fvg, _ = smooth_map(pos, fvg - np.nanmedian(fvg), grid)
    fvg_t = fib["e_ax"] / fib["e_gel_ax"] - 1
    t_fvg, _ = smooth_map(c, only_ok(fvg_t - np.median(fvg_t[ok])), grid, robust=False)
    m_lan, _ = smooth_map(pos, fib["land_aniso"] - np.median(fib["land_aniso"]), grid, robust=False)
    t_lan, _ = smooth_map(c, fib["land_aniso_true"] - np.median(fib["land_aniso_true"]), grid, robust=False)
    liso = np.sqrt(np.abs(np.linalg.det(fib["a_loc"])))
    m_liso, _ = smooth_map(pos, liso / np.median(liso) - 1, grid, robust=False)
    t_liso, _ = smooth_map(c, fib["liso_true"] / np.median(fib["liso_true"]) - 1, grid, robust=False)
    m_res, _ = smooth_map(pos, fib["res_rms"], grid, robust=False)
    t_res, _ = smooth_map(c, fib["res_rms_true"], grid, robust=False)
    m_disp, _ = smooth_map(pos, np.linalg.norm(fib["resid"], axis=1), grid, robust=False)

    sup = inside & (sw >= 3)

    def se(x):
        return robust_sd(x) / np.sqrt(np.maximum(sw, 1e-9))

    floor = 0.01  # 1% local deviation; the 4-SE term dominates where fibrils are sparse
    flag_ax = sup & ((np.abs(m_ax) > np.maximum(floor, 4 * se(fib["e_ax_hat"] / med_hat - 1)))
                     | (np.abs(m_liso) > np.maximum(floor, 4 * se(liso / np.median(liso) - 1))))
    flag_fvg = sup & (np.abs(m_fvg) > np.maximum(floor, 4 * se(fvg)))
    flag_lan = sup & (m_lan > np.maximum(floor, 4 * se(fib["land_aniso"])))
    flag_tear = sup & (m_res > max(2 * float(np.median(fib["res_rms"])), 0.3))  # 2x the localisation-noise residual

    nb = neighbourhoods(sc, grid)
    signal = {"hotspot": (np.abs(t_ax) > 0.015) | (np.abs(t_liso) > 0.015), "stretched patch": t_lan > 0.015, "tear": t_res > 0.3,
              "under-digested patch": np.abs(t_fvg) > 0.015}
    detector = {"hotspot": flag_ax, "stretched patch": flag_lan, "tear": flag_tear, "under-digested patch": flag_fvg}
    det, det_any, masks = {}, {}, {}
    any_flag = flag_ax | flag_fvg | flag_lan | flag_tear
    for k, m in nb.items():
        mm = m & signal[k] & sup
        masks[k] = mm
        det_any[k] = float((any_flag & mm).sum() / mm.sum()) if mm.any() else None
        det[k] = float((detector[k] & mm).sum() / mm.sum()) if mm.any() else None  # None: no true signal above threshold
    any_nb = np.zeros(grid.shape[0], bool)
    for m in nb.values():
        any_nb |= m
    quiet = ((np.abs(t_ax) < 0.0075) & (np.abs(t_liso) < 0.0075) & (t_lan < 0.0075) & (t_res < 0.15)
             & (np.abs(t_fvg) < 0.0075))
    normal = sup & ~any_nb & quiet
    flags_any = flag_ax | flag_fvg | flag_lan | flag_tear
    false_rate = float((flags_any & normal).sum() / max(normal.sum(), 1))

    rel_err = fib["e_ax_hat"][ok] / fib["e_ax"][ok] - 1
    tr_err = fib["e_tr_hat"] / fib["e_tr"] - 1
    map_rms = float(np.sqrt(np.mean((m_ax[sup] - t_ax[sup]) ** 2)))

    # Intrinsic anisotropy (median of per-fibril log ratios, bootstrap CI) and the orientation test on E_ax
    both = ok & np.isfinite(fib["e_tr_hat"])
    la = np.log(fib["e_ax_hat"][both] / fib["e_tr_hat"][both])
    boot = np.median(np.random.default_rng(1).choice(la, (2000, la.size)), axis=1)
    aniso = {"n": int(both.sum()), "est": float(np.expm1(np.median(la))),
             "ci": [float(np.expm1(np.percentile(boot, 2.5))), float(np.expm1(np.percentile(boot, 97.5)))],
             "truth": float(np.median(fib["e_ax"][both] / fib["e_tr"][both]) - 1)}
    lv = np.log(fib["e_ax_hat"][ok] / med_hat)
    ph = fib["phi"][ok]
    xmat = np.c_[np.ones(ph.size), np.cos(2 * ph), np.sin(2 * ph)]
    beta, *_ = np.linalg.lstsq(xmat, lv, rcond=None)
    rss1 = float(np.sum((lv - xmat @ beta) ** 2))
    rss0 = float(np.sum((lv - lv.mean()) ** 2))
    fstat = ((rss0 - rss1) / 2) / (rss1 / (lv.size - 3))
    orient = {"n": int(ok.sum()), "amplitude": float(2 * math.hypot(beta[1], beta[2])),
              "axis_deg": float(math.degrees(0.5 * math.atan2(beta[2], beta[1])) % 180),
              "p": float(stats.f.sf(fstat, 2, lv.size - 3))}

    # Distortion curve: RMS length-measurement error vs length after the similarity fit
    rng = np.random.default_rng(3)
    i1, i2 = rng.integers(0, len(pos), 30000), rng.integers(0, len(pos), 30000)
    l_pre = np.linalg.norm(pos[i1] - pos[i2], axis=1)
    reg = fib["pre_m"] + fib["resid"]
    err = np.linalg.norm(reg[i1] - reg[i2], axis=1) - l_pre
    l_true = np.linalg.norm(c[i1] - c[i2], axis=1)
    regt = c + fib["resid_true"]
    err_t = np.linalg.norm(regt[i1] - regt[i2], axis=1) - l_true
    floor2 = 2 * (0.15 ** 2 + 0.05 ** 2) / 2 + 2 * ((0.30 ** 2 + 0.10 ** 2) / 2) / fib["s_hat"] ** 2
    bins = np.array([10, 25, 50, 100, 200, 400, 800, 1400])
    curve = []
    for lo, hi in zip(bins[:-1], bins[1:]):
        m = (l_pre >= lo) & (l_pre < hi)
        mt = (l_true >= lo) & (l_true < hi)
        if m.sum() > 50:
            rms = float(np.sqrt(np.mean(err[m] ** 2)))
            curve.append({"l_mid": float(np.sqrt(lo * hi)), "rms": rms,
                          "rms_corrected": float(math.sqrt(max(rms ** 2 - floor2, 0.0))),
                          "rms_truth": float(np.sqrt(np.mean(err_t[mt] ** 2)))})
    dc_dev = max(abs(cv["rms_corrected"] - cv["rms_truth"]) / cv["l_mid"] for cv in curve if cv["l_mid"] >= 25)

    return {"grid": grid, "sup": sup, "maps": {"truth_ax": t_ax, "ax": m_ax, "aniso": m_an, "fvg": m_fvg,
                                               "lan": m_lan, "liso": m_liso, "res": m_res, "disp": m_disp},
            "flags": {"ax": flag_ax, "fvg": flag_fvg, "lan": flag_lan, "tear": flag_tear}, "masks": masks,
            "neighbourhoods": nb,
            "metrics": {
                "n_fibrils": int(len(pos)), "n_period": int(ok.sum()),
                "gel_mean_E_err": float(np.nanmean(fib["e_ax_hat"]) / np.mean(fib["e_ax"][ok]) - 1),
                "global_scale_err": float(fib["s_hat"] / fib["s_true"] - 1),
                "per_fibril_Eax_rms": float(np.sqrt(np.mean(rel_err ** 2))),
                "per_fibril_Eax_outliers_2pct": float(np.mean(np.abs(rel_err) > 0.02)),
                "per_fibril_Etr_bias": float(np.mean(tr_err)), "per_fibril_Etr_sd": float(np.std(tr_err)),
                "per_fibril_Eland_ax_rms": float(np.sqrt(np.mean((fib["e_land_ax"] / fib["e_gel_ax"] - 1) ** 2))),
                "map_rms_vs_truth": map_rms, "detection": det, "detection_any_flag": det_any,
                "false_flag_rate": false_rate, "anisotropy": aniso, "orientation": orient,
                "distortion_curve": curve, "distortion_curve_max_dev": float(dc_dev)}}


def width_mc(n=150, seed=11):
    """Per-myofibril transverse-factor error (10 µm fibril) for each pre-image mode, under calibration errors and
    cross-section shapes. 'nominal' is only an internal-consistency check (fit model = generator). The shape rows
    are the real test: a boxy cross-section fitted as an ellipse is badly biased, so the pipeline measures each
    myofibril's shape from its post z-projection and fits the pre-image with it."""
    rng = np.random.default_rng(seed)
    cases = {"nominal (fit model = generator)": (0.0, 0.0, 2.0, "assume"),
             "PSF calibrated 2% wide (G1 target)": (0.02, 0.0, 2.0, "assume"),
             "PSF calibrated 5% wide": (0.05, 0.0, 2.0, "assume"),
             "aspect 10% high": (0.0, 0.10, 2.0, "assume"), "aspect 10% low": (0.0, -0.10, 2.0, "assume"),
             "boxy section (n = 4) assumed elliptical": (0.0, 0.0, 4.0, "assume"),
             "boxy section (n = 4), shape from post z-projection": (0.0, 0.0, 4.0, "post"),
             "rounded-polygon section (n = 3), shape from post": (0.0, 0.0, 3.0, "post"),
             "ellipse, shape from post (no-harm check)": (0.0, 0.0, 2.0, "post")}
    out = {}
    for mode in ("dpc", "pol"):
        for name, (psf_err, asp_err, n_true, how) in cases.items():
            errs = []
            for _ in range(n):
                w, asp, e = rng.normal(1.2, 0.2), rng.normal(1.0, 0.08), 4.5
                w = float(np.clip(w, 0.8, 1.8))
                n_rows = int(10.0 / PX)
                n_fit = (measure_shape_post(rng, w * e, asp, int(n_rows * e), n_true, FWHM_POST / S2F)
                         if how == "post" else 2.0)
                wp = measure_width_pre(rng, w, asp, n_rows, mode, FWHM_PRE / S2F, FWHM_PRE / S2F * (1 + psf_err),
                                       asp * (1 + asp_err), true_n=n_true, fit_n=n_fit)
                wq = measure_width_post(rng, w * e, asp, int(n_rows * e), FWHM_POST / S2F,
                                        FWHM_POST / S2F * (1 + psf_err), asp * (1 + asp_err), true_n=n_true,
                                        fit_n=n_fit)
                errs.append(wq / wp / e - 1)
            errs = np.array(errs)
            out[f"{mode} | {name}"] = {"bias": float(errs.mean()), "sd": float(errs.std())}
    return out


def figure(sc, fib, an, path):
    """Row 1: the per-myofibril maps (every myofibril drawn as a stick at its place and angle, coloured by its own
    axial or transverse factor) and the smoothed axial map vs the truth. Row 2: anisotropy, fibril vs gel,
    distortion, and the flags with each planted defect outlined (solid = caught, dashed = missed or below limit)."""
    import textwrap

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.collections import LineCollection
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch
    g = an["grid"]
    n = int(round(math.sqrt(g.shape[0])))
    ext = [g[:, 0].min(), g[:, 0].max(), g[:, 1].min(), g[:, 1].max()]
    gx, gy = g[:, 0].reshape(n, n), g[:, 1].reshape(n, n)

    def img(v):
        return np.where(an["sup"], v, np.nan).reshape(n, n)

    def frame(ax, title):
        ax.set_title(title, fontsize=9.5)
        ax.set_aspect("equal")
        ax.add_patch(plt.Circle((0, 0), R_GEL, fill=False, lw=0.8, color="0.4"))
        ax.set_xlim(-R_GEL * 1.02, R_GEL * 1.02)
        ax.set_ylim(-R_GEL * 1.02, R_GEL * 1.02)
        ax.set_xticks([])
        ax.set_yticks([])

    fig, axs = plt.subplots(2, 4, figsize=(21, 10.8), constrained_layout=True)
    pos, phi = fib["pre_m"], fib["phi"]
    half = 1.5 * np.maximum(fib["length"], 8.0)
    d = np.c_[np.cos(phi), np.sin(phi)] * half[:, None]
    segs = np.stack([pos - d, pos + d], axis=1)
    for ax, key, title in ((axs[0, 0], "e_ax_hat", "each myofibril: axial E (period ratio) vs gel median, %"),
                           (axs[0, 1], "e_tr_hat", "each myofibril: transverse E (width ratio) vs gel median, %")):
        frame(ax, title)
        val = fib[key] / np.nanmedian(fib[key]) - 1
        ok = np.isfinite(val)
        ax.add_collection(LineCollection(segs[~ok], colors="0.82", linewidths=0.8))
        lc = LineCollection(segs[ok], array=100 * val[ok], cmap="RdBu_r", linewidths=1.3)
        lc.set_clim(-6, 6)
        ax.add_collection(lc)
        fig.colorbar(lc, ax=ax, shrink=0.75)
    for ax, val, title in ((axs[0, 2], an["maps"]["truth_ax"], "truth: local axial E, smoothed, %"),
                           (axs[0, 3], an["maps"]["ax"], "measured: local axial E, smoothed, %")):
        frame(ax, title)
        im = ax.imshow(img(100 * val), origin="lower", extent=ext, cmap="RdBu_r", vmin=-6, vmax=6)
        fig.colorbar(im, ax=ax, shrink=0.75)
    for ax, val, title, cmap, lim in (
            (axs[1, 0], 100 * an["maps"]["aniso"], "anisotropy: E_ax / E_tr minus median, %", "PuOr_r", (-4, 4)),
            (axs[1, 1], 100 * an["maps"]["fvg"], "fibril vs gel: E_ax / E_land,ax minus median, %", "PiYG", (-6, 6)),
            (axs[1, 2], an["maps"]["disp"], "distortion: residual after the similarity fit, µm", "magma", (0, None))):
        frame(ax, title)
        vmax = lim[1] if lim[1] is not None else np.nanpercentile(val[an["sup"]], 99)
        im = ax.imshow(img(val), origin="lower", extent=ext, cmap=cmap, vmin=lim[0], vmax=vmax)
        fig.colorbar(im, ax=ax, shrink=0.75)
    ax = axs[1, 3]
    frame(ax, "flags (filled) vs planted defects (solid = caught, dashed = missed)")
    cols = {"ax": "#d7301f", "lan": "#fdae61", "fvg": "#1a9850", "tear": "#2c7fb8"}
    names = {"ax": "local E", "lan": "gel stretch", "fvg": "fibril vs gel", "tear": "non-affine (tear, fold, shear)"}
    for k, c in cols.items():
        f = np.where(an["sup"], an["flags"][k], False).reshape(n, n).astype(float)
        if f.any():
            ax.contourf(gx, gy, f, levels=[0.5, 1.5], colors=[c], alpha=0.45)
    det_any = an["metrics"]["detection_any_flag"]
    for k, nbm in an["neighbourhoods"].items():
        caught = det_any.get(k) is not None and det_any[k] >= 0.8
        m = an["masks"][k] if an["masks"][k].any() else (nbm & an["sup"])
        if m.any():
            ax.contour(gx, gy, m.reshape(n, n).astype(float), [0.5], colors="k", linewidths=1.2,
                       linestyles="solid" if caught else "dashed")
    if sc.tear_open:
        caught = (det_any.get("tear") or 0) >= 0.8
        ax.plot([sc.tear_a[0], sc.tear_b[0]], [sc.tear_a[1], sc.tear_b[1]], color="k", lw=2,
                ls="solid" if caught else "dashed")
    handles = [Patch(color=c, alpha=0.6, label=names[k]) for k, c in cols.items()]
    handles += [Line2D([], [], color="k", label="planted, caught"),
                Line2D([], [], color="k", ls="--", label="planted, missed or below limit")]
    ax.legend(handles=handles, loc="lower left", fontsize=7, frameon=False)
    m = an["metrics"]
    title = (f"SWELL synthetic gel {sc.name}: {sc.label}. {m['n_period']} of {m['n_fibrils']} myofibrils are long enough "
             "for an axial ratio (grey sticks: too short); sticks are drawn 3x long.")
    fig.suptitle("\n".join(textwrap.wrap(title, 175)), fontsize=11)
    fig.savefig(path, dpi=100)
    plt.close(fig)
    from simlabel import label_png   # the SIMULATION strip and metadata (A-11)
    label_png(path, source="software/sim/strain_map_sim.py")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    out = {"constants": {"PX_um": PX, "FWHM_post_um": FWHM_POST, "FWHM_pre_um": FWHM_PRE, "E0": E0,
                         "kernel_um": KERNEL, "grid_um": GRID_STEP}}

    # 0. The vectorised estimator equals the reference one.
    rng = np.random.default_rng(5)
    diffs = []
    for _ in range(20):
        seq = 1.69 * (1 + 0.03 * rng.normal(size=12))
        xa, ya, xb, yb = pre_post_profiles(rng, seq, 4.5)
        diffs.append(abs(fit_period(ya, xa, 1.69) / _fit_period(ya - ya.mean(), xa, 1.69) - 1))
        diffs.append(abs(fit_period(yb, xb, 7.6) / _fit_period(yb - yb.mean(), xb, 7.6) - 1))
    out["estimator_equivalence_max_rel_diff"] = float(max(diffs))

    figdir = ROOT / "docs" / "design" / "figs"
    figdir.mkdir(parents=True, exist_ok=True)
    simdir = ROOT / "data" / "sim"
    simdir.mkdir(parents=True, exist_ok=True)
    res = {}
    for sc in SCENARIOS:
        fib = run_gel(sc, seed=sc.seed)
        an = analyse(sc, fib)
        figure(sc, fib, an, figdir / f"strain_map_{sc.name}.png")
        res[sc.name] = {"scenario": asdict(sc), "metrics": an["metrics"]}
        cols = ["x_pre", "y_pre", "phi", "length", "width", "E_ax_true", "E_ax_hat", "E_tr_true", "E_tr_hat",
                "E_land_ax", "E_land_tr", "fit_residual_um"]
        arr = np.c_[fib["c"], fib["phi"], fib["length"], fib["width"], fib["e_ax"], fib["e_ax_hat"], fib["e_tr"],
                    fib["e_tr_hat"], fib["e_land_ax"], fib["e_land_tr"], fib["res_rms"]]
        np.savetxt(simdir / f"strain_map_{sc.name}_fibrils.csv", arr, delimiter=",", header=",".join(cols),
                   comments="", fmt="%.6g")
        print(sc.name, json.dumps(an["metrics"], default=float)[:600])
    out["scenarios"] = res
    out["width_mc"] = width_mc()
    print(json.dumps(out["width_mc"], indent=1))
    (ROOT / "docs" / "design" / "strain_map_v1.json").write_text(json.dumps(out, indent=2, default=float), encoding="utf-8")
    write_report(out)


def write_report(out):
    s0, s1, s1b, s2 = (out["scenarios"][k]["metrics"] for k in ("S0", "S1", "S1b", "S2"))
    pct = lambda x: f"{100 * x:+.2f}%"  # noqa: E731
    ab = lambda x: f"{100 * x:.2f}%"  # noqa: E731
    wm = out["width_mc"]
    worst_tr = max(abs(v["bias"]) for v in wm.values())
    boxy_post = max(abs(wm[f"{m} | boxy section (n = 4), shape from post z-projection"]["bias"]) for m in ("dpc", "pol"))
    g1_rows = ("PSF calibrated 2% wide (G1 target)", "boxy section (n = 4), shape from post z-projection",
               "rounded-polygon section (n = 3), shape from post")
    worst_g1 = max(abs(wm[f"{m} | {r}"]["bias"]) for m in ("dpc", "pol") for r in g1_rows)
    a2, o2 = s2["anisotropy"], s2["orientation"]
    checks = []
    for name, m in (("S0", s0), ("S1", s1), ("S1b", s1b), ("S2", s2)):
        checks += [(f"{name}: gel-mean E within ±0.5%", abs(m["gel_mean_E_err"]) <= 0.005, pct(m["gel_mean_E_err"])),
                   (f"{name}: per-myofibril E_ax RMS error ≤ 1% (segments of 8–20 sarcomeres)", m["per_fibril_Eax_rms"] <= 0.01,
                    f"{ab(m['per_fibril_Eax_rms'])}; {m['n_period']} of {m['n_fibrils']} myofibrils long enough; "
                    f"{ab(m['per_fibril_Eax_outliers_2pct'])} beyond ±2%"),
                   (f"{name}: local E map RMS error ≤ 1% (vs truth, same kernel)", m["map_rms_vs_truth"] <= 0.01, ab(m["map_rms_vs_truth"])),
                   (f"{name}: distortion curve within ±0.5% of truth (≥ 25 µm, noise floor removed)",
                    m["distortion_curve_max_dev"] <= 0.005, ab(m["distortion_curve_max_dev"])),
                   (f"{name}: false flags ≤ 5% of defect-free gel area (outside planted-defect zones)",
                    m["false_flag_rate"] <= 0.05, ab(m["false_flag_rate"]))]
    for name, m in (("S1", s1), ("S1b", s1b)):
        for k, v in m["detection"].items():
            if v is None:
                checks.append((f"{name}: planted {k} flagged over ≥ 80% of its area", None,
                               "below detection limit: its true signal never crosses the detector threshold"))
            else:
                checks.append((f"{name}: planted {k} flagged over ≥ 80% of its area", v >= 0.8, f"{100 * v:.0f}%"))
    checks += [("S2: intrinsic 2% axial anisotropy detected (95% CI excludes 0, n ≥ 200)",
                a2["n"] >= 200 and (a2["ci"][1] < 0 or a2["ci"][0] > 0), f"{pct(a2['est'])} [{pct(a2['ci'][0])}, {pct(a2['ci'][1])}], n = {a2['n']}"),
               ("S2: anisotropy estimate within ±0.5% of truth", abs(a2["est"] - a2["truth"]) <= 0.005,
                f"truth {pct(a2['truth'])}"),
               ("S2: 2% gel stretch found by the orientation test (p < 0.05)", o2["p"] < 0.05,
                f"amplitude {ab(o2['amplitude'])} at {o2['axis_deg']:.0f}° (truth 2.00% at 23°), p = {o2['p']:.1e}"),
               ("Transverse ruler, boxy (n = 4) sections with the shape from the post z-projection: |bias| ≤ 1%",
                boxy_post <= 0.01, ab(boxy_post)),
               ("D-32 gate (±3%) ≥ 1% + worst transverse bias at the G1 calibration target (PSF 2%) and with real shapes",
                0.01 + worst_g1 <= 0.03, f"1% + {ab(worst_g1)} = {ab(0.01 + worst_g1)}")]
    npass = sum(ok is True for _, ok, _ in checks)
    nfail = sum(ok is False for _, ok, _ in checks)
    nlim = sum(ok is None for _, ok, _ in checks)
    bd, bda = s1b["detection"], s1b["detection_any_flag"]

    def dtxt(k):
        o, a = bd[k], bda[k]
        if o is None:
            return f"{k}: below the detection limit"
        return f"{k}: {100 * o:.0f}% by its own detector, {100 * a:.0f}% by any"
    L = ["# SWELL whole-gel strain map v1: per-myofibril expansion factors and distortion heatmap (synthetic)", "",
         "**Blind test first (S1b: a new gel, defects moved and resized, nothing tuned against it):** "
         f"gel-mean E {pct(s1b['gel_mean_E_err'])}, local E map {ab(s1b['map_rms_vs_truth'])} RMS from truth, "
         f"false flags {ab(s1b['false_flag_rate'])} of the defect-free area. Planted defects: "
         + "; ".join(dtxt(k) for k in bd) + ".", "",
         f"**All checks: {npass} of {len(checks)} pass, {nfail} fail, {nlim} below the detection limit.** S0, S1 and S2 "
         "are development gels (seed 7; the detectors were fixed while looking at S1), so S1b is the only blind test "
         "from our own generator (v2 adds red-team gel S3, built by a separate AI agent). Every myofibril gets landmark and transverse factors; only those with ≥ 8 sarcomeres get an axial "
         "period ratio (about half here; it depends on the prep, R31).", "",
         "Generated by `software/sim/strain_map_sim.py` (G0 deliverable D-34; rulers D-4, D-32, D-33). Synthetic Track A gel: "
         f"1.5 mm punch, E {E0}, 1,200 isolated myofibrils (3% sarcomere-to-sarcomere jitter, 0.3 µm registration error), pixel {PX} µm, "
         f"label-free pre-image (oblique/DPC, "
         f"effective resolution {FWHM_PRE} µm, assumed until P1), pan-stained post-image (FWHM {FWHM_POST} µm). Maps use a "
         f"{KERNEL:.0f} µm Gaussian kernel on a {GRID_STEP:.0f} µm grid. Synthetic data tests the pipeline against our "
         "own assumptions, not the chemistry: G1–G3 would repeat every check on real gels.", "",
         "Figures: `docs/design/figs/strain_map_S1b.png` (blind), `strain_map_S0.png`, "
         "`strain_map_S1.png`, `strain_map_S2.png`. Per-myofibril tables: "
         "`data/sim/strain_map_S*_fibrils.csv` (regenerated by the command above).", "",
         "**How the detectors were set (honest note):** the first run failed 15 checks. Fixes, each from a stated "
         "cause, not tuned per defect: a Z-disc-ladder period estimator (the free-frequency fit locked onto "
         "±1/N sidelobes under 3% sarcomere jitter and at SL ≈ 1.8 µm); period ratios only on segments of "
         "≥ 8 sarcomeres (Order 7 specifies 10); robust smoothing only on period maps, with a wide cut; tear "
         "threshold = 2 × the gel's median localisation residual; a 1% map floor. The planted band became a finite "
         "patch (an unbounded band displaced the gel edge by 20 µm). **S1b is the blind check:** new gel, "
         "defects moved and resized, nothing retuned after it ran.", "",
         "| check | result | value |", "|---|---|---|"]
    L += [f"| {c} | {'PASS' if ok else ('BELOW LIMIT' if ok is None else 'FAIL')} | {v} |" for c, ok, v in checks]
    L += ["", "## Planted defects: flagged by their own detector vs by any detector", "",
          "The strict checks above credit only the detector named for each defect type. A region flagged by another "
          "detector is still flagged, but carries the wrong label.", "",
          "| scenario | defect | own detector | any detector |", "|---|---|---|---|"]
    for name, m in (("S1", s1), ("S1b", s1b)):
        for k in m["detection"]:
            o, a = m["detection"][k], m["detection_any_flag"][k]
            L.append(f"| {name} | {k} | {'below limit' if o is None else f'{100 * o:.0f}%'} | "
                     f"{'below limit' if a is None else f'{100 * a:.0f}%'} |")
    L += ["", "## Axial vs transverse factors, reported separately", "",
          "| scenario | E_ax per-fibril RMS error | E_tr per-fibril bias ± SD | E_land,ax per-fibril RMS error | global scale (landmarks) error |",
          "|---|---|---|---|---|"]
    for name, m in (("S0", s0), ("S1", s1), ("S1b", s1b), ("S2", s2)):
        L.append(f"| {name} | {ab(m['per_fibril_Eax_rms'])} | {pct(m['per_fibril_Etr_bias'])} ± {ab(m['per_fibril_Etr_sd'])} | "
                 f"{ab(m['per_fibril_Eland_ax_rms'])} | {pct(m['global_scale_err'])} |")
    L += ["", "## Transverse ruler: width-ratio error per myofibril (10 µm long, 150 trials each)", "",
          "The width ratio depends on a model of each image (cross-section shape, PSF), so calibration and shape errors "
          "become biases. 'Nominal' is only an internal-consistency check, because there the fit model equals the "
          "generator.", "",
          "| pre-image mode | calibration case | bias | SD |", "|---|---|---|---|"]
    for k, v in wm.items():
        mode, case = k.split(" | ")
        L.append(f"| {'oblique/DPC' if mode == 'dpc' else 'crossed polarisers'} | {case} | {pct(v['bias'])} | {ab(v['sd'])} |")
    L += ["", f"Worst bias in the table: {ab(worst_tr)}. That is the boxy section assumed elliptical, which the pipeline never "
          "does: it measures each cross-section's shape from the post z-projection. The D-32 gate is checked above "
          "against the G1 calibration target and real shapes. Not yet simulated: nuclear diameter ratios, irregular "
          "(non-super-ellipse) sections and bundles (resolved and excluded in the post image), so Order 7 adds them.", "",
          "## Distortion curves (RMS length error after the similarity fit; µm, pre-expansion units)", "",
          "| length bin (µm) | S0 truth | S0 measured (noise-corrected) | S1 truth | S1 measured (noise-corrected) |",
          "|---|---|---|---|---|"]
    for a, b in zip(s0["distortion_curve"], s1["distortion_curve"]):
        L.append(f"| {a['l_mid']:.0f} | {a['rms_truth']:.3f} | {a['rms_corrected']:.3f} | {b['rms_truth']:.3f} | {b['rms_corrected']:.3f} |")
    L += ["", "Tests: `software/tests/test_sim_rulers.py` covers the ladder estimator, the width ratio, the similarity "
          "fit and the local affine. The free-frequency estimator is kept only as the Life 1 reference (no longer used "
          f"for E_ax); its vectorised copy matches `design_calc._fit_period` to {out['estimator_equivalence_max_rel_diff']:.1e}."]
    (ROOT / "docs" / "design" / "strain_map_v1.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n".join(L[:len(checks) + 12]))


if __name__ == "__main__":
    main()
