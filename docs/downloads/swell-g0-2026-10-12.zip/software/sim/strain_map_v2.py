"""SWELL whole-gel strain map v2 (Life 5): the swell_ruler pipeline run blind on every synthetic gel, then scored.

v1 (strain_map_sim.py, 2026-10-09) handed the pipeline the pre<->post pairing and generated, measured and scored
inside one function. v2 separates the three, as the fresh AI review asked:
  generators  gen_dev.py (development gels S0, S1, S1b, S2, S4) and software/redteam/s3_gen.py (S3, written by a
              separate agent that never saw the pipeline)  ->  data/sim/<gel>/obs.json.gz + truth.json.gz
  pipeline    software/swell_ruler (unchanged across gels; reads only obs)   ->  data/sim/<gel>/result.json.gz
  scoring     this file for the development gels; software/redteam/score_s3.py for S3 (the red team's own scorer)

Run:  .venv/Scripts/python.exe software/sim/strain_map_v2.py            (all gels; S3 if its obs file exists)
Out:  docs/design/strain_map_v2.md + .json, docs/design/figs/strain_map_v2_<gel>.png
"""
from __future__ import annotations

import json
import math
import subprocess
import sys
import time
from dataclasses import asdict, replace
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ROOT / "software" / "swell_ruler"))
import gen_dev  # noqa: E402
import strain_map_sim as v1  # noqa: E402
from swell_ruler import __version__ as RULER_VERSION  # noqa: E402
from swell_ruler import run  # noqa: E402
from swell_ruler.io import load, save, validate_obs  # noqa: E402
from swell_ruler.strainmap import KERNEL, local_affine, smooth_map  # noqa: E402

DATA = ROOT / "data" / "sim"
FIGS = ROOT / "docs" / "design" / "figs"
PY = sys.executable

S4 = replace(v1.SCENARIOS[0], name="S4", seed=41,
             label="drift: a good gel (new seed) that keeps swelling by 0.5% during the 2.2 h post scan, in raster "
                   "order, with a clock tile re-imaged every 50 tiles")
DEV = list(v1.SCENARIOS) + [S4]
DRIFT = {"S4": 0.005}
OWN = {"hotspot": "local_E", "stretched patch": "gel_stretch", "tear": "non_affine",
       "under-digested patch": "fibril_vs_gel"}


def grid_points(g):
    gx = g["x0"] + g["step"] * np.arange(g["nx"])
    gy = g["y0"] + g["step"] * np.arange(g["ny"])
    xx, yy = np.meshgrid(gx, gy)
    return np.c_[xx.ravel(), yy.ravel()]


def as_array(rows):
    return np.array([[np.nan if v is None else v for v in r] for r in rows], float).ravel()


def score_dev(sc, obs, truth, res):
    """v1's checks, recomputed from the result file and the truth file only."""
    tf = truth["fibrils"]
    pairs = truth["pairs"]
    matches = res["matches"]
    n_true = sum(1 for v in pairs.values() if v is not None)
    n_match = sum(1 for v in matches.values() if v is not None)
    correct = [k for k, v in matches.items() if v is not None and pairs.get(k) == v]
    ids = [k for k in correct if res["fibrils"][k]["E_ax"] is not None]
    e_hat = np.array([res["fibrils"][k]["E_ax"] for k in ids])
    e_tru = np.array([tf[k]["E_ax"] for k in ids])
    rel = e_hat / e_tru - 1
    tr_ids = [k for k in correct if res["fibrils"][k]["E_tr"] is not None]
    tr_err = np.array([res["fibrils"][k]["E_tr"] / tf[k]["E_tr"] - 1 for k in tr_ids])
    land = np.array([res["fibrils"][k]["E_land_ax"] / tf[k]["E_gel_ax"] - 1 for k in correct])
    eligible = sum(1 for k in correct if tf[k]["n_sarc"] >= 8)

    # truth maps on the pipeline's grid (same kernel), as in v1
    grid = grid_points(res["grid"])
    pre_by_id = {o["id"]: o for o in obs["pre"]}
    pos_all = np.array([[pre_by_id[k]["x"], pre_by_id[k]["y"]] for k in pre_by_id])
    c_all = np.array([[tf[k]["x"], tf[k]["y"]] for k in pre_by_id])
    pos_e = np.array([[pre_by_id[k]["x"], pre_by_id[k]["y"]] for k in ids])
    c_e = np.array([[tf[k]["x"], tf[k]["y"]] for k in ids])
    inside = np.linalg.norm(grid, axis=1) < 0.9 * v1.R_GEL
    _, sw = smooth_map(pos_e, np.zeros(len(pos_e)), grid, robust=False)
    sup = inside & (sw >= 3)
    t_ax, _ = smooth_map(c_e, e_tru / np.median(e_tru) - 1, grid, robust=False)
    f_true = v1.jacobian(c_all, sc)
    liso_t = np.sqrt(np.abs(np.linalg.det(f_true)))
    svt = np.linalg.svd(f_true, compute_uv=False)
    t_liso, _ = smooth_map(c_all, liso_t / np.median(liso_t) - 1, grid, robust=False)
    t_lan, _ = smooth_map(c_all, svt[:, 0] / svt[:, 1] - 1 - np.median(svt[:, 0] / svt[:, 1] - 1), grid, robust=False)
    post_true = v1.deform(c_all, sc)
    _, res_t = local_affine(c_all, post_true, v1.E0)
    t_res, _ = smooth_map(c_all, res_t, grid, robust=False)
    fvg_t = np.array([tf[k]["E_ax"] / tf[k]["E_gel_ax"] - 1 for k in ids])
    t_fvg, _ = smooth_map(c_e, fvg_t - np.median(fvg_t), grid, robust=False)
    m_ax = as_array(res["maps"]["local_E"])
    okm = sup & np.isfinite(m_ax)
    map_rms = float(np.sqrt(np.mean((m_ax[okm] - t_ax[okm]) ** 2)))

    flags = {k: as_array(v).astype(bool) for k, v in res["flags"].items()}
    any_flag = np.zeros(len(grid), bool)
    for f in flags.values():
        any_flag |= f
    nb = v1.neighbourhoods(sc, grid)
    signal = {"hotspot": (np.abs(t_ax) > 0.015) | (np.abs(t_liso) > 0.015), "stretched patch": t_lan > 0.015,
              "tear": t_res > 0.3, "under-digested patch": np.abs(t_fvg) > 0.015}
    det, det_any = {}, {}
    for k, m in nb.items():
        mm = m & signal[k] & sup
        det[k] = float((flags[OWN[k]] & mm).sum() / mm.sum()) if mm.any() else None
        det_any[k] = float((any_flag & mm).sum() / mm.sum()) if mm.any() else None
    any_nb = np.zeros(len(grid), bool)
    for m in nb.values():
        any_nb |= m
    quiet = ((np.abs(t_ax) < 0.0075) & (np.abs(t_liso) < 0.0075) & (t_lan < 0.0075) & (t_res < 0.15)
             & (np.abs(t_fvg) < 0.0075))
    normal = sup & ~any_nb & quiet
    false_rate = float((any_flag & normal).sum() / max(normal.sum(), 1))

    # distortion curve: the pipeline's noise-corrected curve vs the truth curve on the same fibrils and pairs
    mids = [k for k in pre_by_id if matches.get(k) is not None]
    c_m = np.array([[tf[k]["x"], tf[k]["y"]] for k in mids])
    pt = v1.deform(c_m, sc)
    s_t, r_t, t_t = v1.similarity_fit(c_m, pt)
    resid_t = (pt - (s_t * c_m @ r_t.T + t_t)) @ r_t / s_t
    rng = np.random.default_rng(3)
    i1, i2 = rng.integers(0, len(c_m), 30000), rng.integers(0, len(c_m), 30000)
    l_t = np.linalg.norm(c_m[i1] - c_m[i2], axis=1)
    err_t = np.linalg.norm((c_m + resid_t)[i1] - (c_m + resid_t)[i2], axis=1) - l_t
    dev = 0.0
    for cv in res["gel"]["distortion_curve"]:
        lo, hi = cv["l_mid"] / 1.5, cv["l_mid"] * 1.5
        m = (l_t >= lo) & (l_t < hi)
        if cv["l_mid"] >= 25 and m.sum() > 50:
            dev = max(dev, abs(cv["rms_corrected"] - float(np.sqrt(np.mean(err_t[m] ** 2)))) / cv["l_mid"])

    # time dependence of the axial error (drift check)
    post_t = {o["id"]: o.get("t", 0.0) for o in obs["post"]}
    tt = np.array([post_t[matches[k]] for k in ids])
    slope = float(100 * np.polyfit(tt / 3600, rel, 1)[0]) if np.ptp(tt) > 0 else 0.0
    an = res["gel"]["anisotropy"]
    an_true = float(np.median([tf[k]["E_ax"] / tf[k]["E_tr"] for k in ids]) - 1)
    return {"n_fibrils": len(pairs), "match_precision": len(correct) / max(n_match, 1),
            "match_recall": len(correct) / max(n_true, 1), "n_axial": len(ids), "n_eligible": eligible,
            "gel_mean_E_err": float(e_hat.mean() / e_tru.mean() - 1),
            "per_fibril_Eax_rms": float(np.sqrt(np.mean(rel ** 2))), "per_fibril_Eax_bias": float(rel.mean()),
            "per_fibril_Eax_outliers_2pct": float(np.mean(np.abs(rel) > 0.02)),
            "per_fibril_Etr_bias": float(tr_err.mean()), "per_fibril_Etr_sd": float(tr_err.std()),
            "per_fibril_Eland_ax_rms": float(np.sqrt(np.mean(land ** 2))),
            "map_rms_vs_truth": map_rms, "detection": det, "detection_any_flag": det_any,
            "false_flag_rate": false_rate, "distortion_curve_max_dev": dev,
            "anisotropy": dict(an, truth=an_true), "orientation": res["gel"]["orientation"],
            "drift_slope_pct_per_h": slope, "transform": res["transform"], "axial_rejected": res["gel"].get(
                "n_axial_rejected_low_r2", 0)}


def figure(name, label, obs, truth, res, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.collections import LineCollection
    g = res["grid"]
    ext = [g["x0"] - g["step"] / 2, g["x0"] + g["step"] * (g["nx"] - 0.5),
           g["y0"] - g["step"] / 2, g["y0"] + g["step"] * (g["ny"] - 0.5)]
    pre = {o["id"]: o for o in obs["pre"]}
    fig, axs = plt.subplots(2, 3, figsize=(16.5, 10.5), constrained_layout=True)
    ids = list(pre)
    pos = np.array([[pre[k]["x"], pre[k]["y"]] for k in ids])
    ang = np.array([pre[k]["angle"] for k in ids])
    half = 1.5 * np.maximum([pre[k]["length"] for k in ids], 8.0)
    d = np.c_[np.cos(ang), np.sin(ang)] * half[:, None]
    segs = np.stack([pos - d, pos + d], axis=1)
    eax = np.array([np.nan if res["fibrils"].get(k, {}).get("E_ax") is None else res["fibrils"][k]["E_ax"]
                    for k in ids])
    matched = np.array([res["matches"].get(k) is not None for k in ids])
    ax = axs[0, 0]
    ok = np.isfinite(eax)
    ax.add_collection(LineCollection(segs[matched & ~ok], colors="0.8", linewidths=0.8))
    ax.add_collection(LineCollection(segs[~matched], colors="k", linewidths=1.2))
    lc = LineCollection(segs[ok], array=100 * (eax[ok] / np.nanmedian(eax) - 1), cmap="RdBu_r", linewidths=1.3)
    lc.set_clim(-6, 6)
    ax.add_collection(lc)
    fig.colorbar(lc, ax=ax, shrink=0.75)
    ax.set_title("each myofibril: axial E vs gel median, % (black: no partner found)", fontsize=9.5)
    for ax, key, title, cmap, lim in ((axs[0, 1], "local_E", "measured: local axial E, smoothed, %", "RdBu_r", 6),
                                      (axs[0, 2], "anisotropy", "anisotropy E_ax/E_tr minus median, %", "PuOr_r", 4),
                                      (axs[1, 0], "fibril_vs_gel", "fibril vs gel, %", "PiYG", 6),
                                      (axs[1, 1], "unmatched_fraction", "no partner in the post image (fraction)",
                                       "Greys", None)):
        arr = np.array([[np.nan if v is None else v for v in row] for row in res["maps"][key]], float)
        if lim is None:
            im = ax.imshow(arr, origin="lower", extent=ext, cmap=cmap, vmin=0, vmax=1)
        else:
            im = ax.imshow(100 * arr, origin="lower", extent=ext, cmap=cmap, vmin=-lim, vmax=lim)
        fig.colorbar(im, ax=ax, shrink=0.75)
        ax.set_title(title, fontsize=9.5)
    ax = axs[1, 2]
    cols = {"local_E": "#d7301f", "gel_stretch": "#fdae61", "fibril_vs_gel": "#1a9850", "non_affine": "#2c7fb8",
            "coverage_hole": "#6a3d9a"}
    xx = np.linspace(ext[0], ext[1], g["nx"])
    yy = np.linspace(ext[2], ext[3], g["ny"])
    for k, col in cols.items():
        f = np.array(res["flags"][k], float)
        if f.any():
            ax.contourf(xx, yy, f, levels=[0.5, 1.5], colors=[col], alpha=0.45)
    for dd in truth.get("defects", []):
        poly = np.array(dd["polygon_pre"] + [dd["polygon_pre"][0]])
        ax.plot(poly[:, 0], poly[:, 1], "k-", lw=1.0)
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(color=c, alpha=0.6, label=k.replace("_", " ")) for k, c in cols.items()],
              loc="lower left", fontsize=7, frameon=False)
    ax.set_title("QC flags (black outlines: planted defects, where the generator lists them)", fontsize=9.5)
    for a in axs.ravel():
        a.set_aspect("equal")
        a.set_xlim(ext[0], ext[1])
        a.set_ylim(ext[2], ext[3])
        a.set_xticks([])
        a.set_yticks([])
    import textwrap
    fig.suptitle("\n".join(textwrap.wrap(f"SWELL synthetic gel {name}: {label}", 160)), fontsize=11)
    fig.savefig(path, dpi=90)
    plt.close(fig)
    from simlabel import label_png   # the SIMULATION strip and metadata (A-11)
    label_png(path, source="software/sim/strain_map_v2.py")


def dev_polygons(sc):
    """Planted-defect outlines for the figures (pre coordinates)."""
    out = []
    th = np.linspace(0, 2 * np.pi, 60)
    if sc.hotspot:
        out.append({"kind": "hotspot", "polygon_pre": (np.array(sc.hotspot_c) + 2 * sc.hotspot_sigma * np.c_[
            np.cos(th), np.sin(th)]).tolist()})
    if sc.undig:
        out.append({"kind": "under-digested patch", "polygon_pre": (np.array(sc.undig_c) + sc.undig_r * np.c_[
            np.cos(th), np.sin(th)]).tolist()})
    if sc.band:
        e1 = np.array([math.cos(sc.band_angle), math.sin(sc.band_angle)])
        e2 = np.array([-e1[1], e1[0]])
        hw, hl = sc.band_width / 2, sc.band_half_length
        corners = [(-hl, -hw), (hl, -hw), (hl, hw), (-hl, hw)]
        out.append({"kind": "stretched patch", "polygon_pre": [(a * e1 + (b + sc.band_offset) * e2).tolist()
                                                              for a, b in corners]})
    if sc.tear_open:
        a, t, n, lc = v1._crack_frame(sc)
        out.append({"kind": "tear", "polygon_pre": [(a - 5 * n).tolist(), (a + lc * t - 5 * n).tolist(),
                                                    (a + lc * t + 5 * n).tolist(), (a + 5 * n).tolist()]})
    return out


def run_dev(sc, drift_amp=0.0, tag=None):
    tag = tag or sc.name
    d = DATA / tag
    obs, truth = gen_dev.generate(sc, drift_amp=drift_amp)
    truth["defects"] = dev_polygons(sc)
    problems = validate_obs(obs)
    if problems:
        raise SystemExit(f"{tag}: {problems}")
    save(obs, d / "obs.json.gz")
    save(truth, d / "truth.json.gz")
    t0 = time.time()
    res = run(obs)
    save(res, d / "result.json.gz")
    m = score_dev(sc, obs, truth, res)
    m["runtime_s"] = round(time.time() - t0, 1)
    figure(tag, sc.label, obs, truth, res, FIGS / f"strain_map_v2_{tag}.png")
    print(tag, json.dumps({k: m[k] for k in ("match_recall", "gel_mean_E_err", "per_fibril_Eax_rms",
                                             "map_rms_vs_truth", "false_flag_rate", "detection")}, default=float))
    return m


def run_s3():
    d = DATA / "S3"
    if not (d / "obs.json.gz").exists():
        return None
    obs = load(d / "obs.json.gz")
    problems = validate_obs(obs)
    t0 = time.time()
    res = run(obs)
    save(res, d / "result.json.gz")
    out = {"problems": problems, "runtime_s": round(time.time() - t0, 1), "gel": {
        k: res["gel"][k] for k in ("n_pre", "n_post", "n_matched", "n_axial", "anisotropy", "orientation", "drift",
                                   "flagged_fraction")}, "transform": res["transform"]}
    scorer = ROOT / "software" / "redteam" / "score_s3.py"
    if scorer.exists():
        p = subprocess.run([PY, str(scorer), str(d / "result.json.gz")], capture_output=True, text=True,
                           encoding="utf-8", cwd=str(ROOT))
        out["scorer_stdout"] = p.stdout[-6000:].replace(str(ROOT) + "\\", "").replace(str(ROOT).replace("\\", "/") + "/", "")
        out["scorer_returncode"] = p.returncode
        if (d / "score.json").exists():
            out["score"] = json.loads((d / "score.json").read_text(encoding="utf-8"))
    truth_path = d / "truth.json.gz"
    if truth_path.exists():
        figure("S3", "red-team gel, rerun with the current pipeline (development)", obs, load(truth_path), res, FIGS / "strain_map_v2_S3_rerun.png")
    return out


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    FIGS.mkdir(parents=True, exist_ok=True)
    res = {}
    for sc in DEV:
        res[sc.name] = {"scenario": asdict(sc), "metrics": run_dev(sc, DRIFT.get(sc.name, 0.0))}
    # S4 again with its clock removed: what the drift does when nobody corrects it
    obs = load(DATA / "S4" / "obs.json.gz")
    truth = load(DATA / "S4" / "truth.json.gz")
    obs["clock"] = []
    r_nc = run(obs)
    res["S4_no_clock"] = {"scenario": asdict(S4), "metrics": score_dev(S4, obs, truth, r_nc)}
    frozen = json.loads((ROOT / "docs" / "design" / "s3_frozen_68194b0.json").read_text(encoding="utf-8"))
    # "S3" stays the published, as-scored result of the frozen pipeline; "S3_rerun" is the current pipeline on the
    # same (now seen) gel: a development run, never a blind result
    out = {"ruler_version": RULER_VERSION, "dev": res, "S3": frozen["S3"], "S3_rerun": run_s3()}
    (ROOT / "docs" / "design" / "strain_map_v2.json").write_text(json.dumps(out, indent=2, default=float),
                                                                 encoding="utf-8", newline="\n")
    write_report(out)


def pct(x):
    return "n/a" if x is None else f"{100 * x:+.2f}%"


def ab(x):
    return "n/a" if x is None else f"{100 * x:.2f}%"


def write_report(out):
    dev = out["dev"]
    checks = []
    for name in ("S0", "S1", "S1b", "S2", "S4"):
        m = dev[name]["metrics"]
        checks += [
            (f"{name}: pre↔post matching recall ≥ 99% and precision ≥ 99% (pairing not given)",
             m["match_recall"] >= 0.99 and m["match_precision"] >= 0.99,
             f"recall {ab(m['match_recall'])}, precision {ab(m['match_precision'])}"),
            (f"{name}: gel-mean E within ±0.5%", abs(m["gel_mean_E_err"]) <= 0.005, pct(m["gel_mean_E_err"])),
            (f"{name}: per-myofibril E_ax RMS error ≤ 1% (ladders spanning ≥ 8 sarcomeres)",
             m["per_fibril_Eax_rms"] <= 0.01, f"{ab(m['per_fibril_Eax_rms'])} (bias {pct(m['per_fibril_Eax_bias'])}); "
             f"{m['n_axial']} measured of {m['n_eligible']} with ≥ 8 whole sarcomeres; "
             f"{ab(m['per_fibril_Eax_outliers_2pct'])} beyond ±2%"),
            (f"{name}: local E map RMS error ≤ 1% (vs truth, same kernel)", m["map_rms_vs_truth"] <= 0.01,
             ab(m["map_rms_vs_truth"])),
            (f"{name}: distortion curve within ±0.5% of truth (≥ 25 µm, noise floor removed)",
             m["distortion_curve_max_dev"] <= 0.005, ab(m["distortion_curve_max_dev"])),
            (f"{name}: false flags ≤ 5% of defect-free gel area", m["false_flag_rate"] <= 0.05,
             ab(m["false_flag_rate"])),
        ]
        a = m["anisotropy"]
        want = "anisotropic" if abs(a["truth"]) >= 0.01 else "isotropic"
        checks.append((f"{name}: anisotropy call right (effect size ±1%, not 'CI excludes 0')", a["call"] == want,
                       f"{a['call']}: {pct(a['est'])} [{pct(a['ci95'][0])}, {pct(a['ci95'][1])}], truth {pct(a['truth'])}"))
    for name in ("S1", "S1b"):
        m = dev[name]["metrics"]
        for k, v in m["detection"].items():
            if v is None:
                checks.append((f"{name}: planted {k} flagged over ≥ 80% of its area", None,
                               "below detection limit: its true signal never crosses the detector threshold"))
            else:
                checks.append((f"{name}: planted {k} flagged over ≥ 80% of its area (own detector)", v >= 0.8,
                               f"{100 * v:.0f}% own, {100 * m['detection_any_flag'][k]:.0f}% any"))
    a2 = dev["S2"]["metrics"]["anisotropy"]
    o2 = dev["S2"]["metrics"]["orientation"]
    checks += [("S2: anisotropy estimate within ±0.5% of truth", abs(a2["est"] - a2["truth"]) <= 0.005,
                f"{pct(a2['est'])} vs truth {pct(a2['truth'])}"),
               ("S2: 2% gel stretch found by the orientation test (95% CI of the amplitude above 0.5%)",
                o2["call"] == "stretched", f"amplitude {ab(o2['amplitude'])} [{ab(o2['ci95'][0])}, {ab(o2['ci95'][1])}]"
                f" at {o2['axis_deg']:.0f}° (truth 2.00% at 23°)")]
    for name in ("S0", "S1b", "S4"):
        o = dev[name]["metrics"]["orientation"]
        checks.append((f"{name}: no gel stretch reported on a gel without one", o["call"] != "stretched",
                       f"{o['call']}: amplitude {ab(o['amplitude'])} [{ab(o['ci95'][0])}, {ab(o['ci95'][1])}]"))
    m4, m4n = dev["S4"]["metrics"], dev["S4_no_clock"]["metrics"]
    checks += [("S4: clock tile removes the scan-time drift (|error slope| ≤ 0.05% per hour)",
                abs(m4["drift_slope_pct_per_h"]) <= 0.05,
                f"{m4['drift_slope_pct_per_h']:+.3f}%/h with the clock; {m4n['drift_slope_pct_per_h']:+.3f}%/h without; "
                f"gel-mean E {pct(m4['gel_mean_E_err'])} with, {pct(m4n['gel_mean_E_err'])} without")]
    npass = sum(ok is True for _, ok, _ in checks)
    nfail = sum(ok is False for _, ok, _ in checks)
    nlim = sum(ok is None for _, ok, _ in checks)
    out["checks"] = [{"check": c, "result": "pass" if ok else ("below limit" if ok is None else "fail"), "value": v}
                     for c, ok, v in checks]
    (ROOT / "docs" / "design" / "strain_map_v2.json").write_text(json.dumps(out, indent=2, default=float),
                                                                 encoding="utf-8", newline="\n")
    s3 = out.get("S3")
    L = ["# SWELL whole-gel strain map v2: blind pipeline, red-team gel from a separate AI agent (synthetic)", ""]
    if s3 and s3.get("score"):
        L += ["**Red-team test first (S3, a gel built by a separate AI agent, another Claude instance, that never saw the pipeline; "
              "scored by the red team's own script):**", "", "```",
              s3.get("scorer_stdout", "").replace(str(ROOT) + "\\", "").strip(), "```", ""]   # frozen: drop the root
    else:
        L += ["**S3 (red-team gel): not run in this build.**", ""]
    L += [f"**Development and blind gels: {npass} of {len(checks)} checks pass, {nfail} fail, {nlim} below the "
          "detection limit.** S0, S1, S2 share seed 7 and were used to develop the detectors in v1; S1b (seed 99) was "
          "v1's blind gel; S4 (seed 41) is new and tests drift. In v2 the pipeline is never told the pairing, every "
          "fragment breaks at a random point, and the end-disc fix, the R² gate and the effect-size calls were set "
          "on isolated profiles before any gel was rerun.", "",
          "Generated by `software/sim/strain_map_v2.py` with `swell_ruler` "
          f"{out['ruler_version']}. Pipeline input format: `docs/design/obs_schema_v1.md`. Synthetic data tests the "
          "pipeline against our own assumptions, not the chemistry.", "",
          "| check | result | value |", "|---|---|---|"]
    L += [f"| {c} | {'PASS' if ok else ('BELOW LIMIT' if ok is None else 'FAIL')} | {v} |" for c, ok, v in checks]
    L += ["", "## Per-gel numbers", "",
          "| gel | matched (recall / precision) | gel-mean E error | E_ax RMS (bias) | E_tr bias ± SD | E_land,ax RMS | map RMS | false flags | runtime |",
          "|---|---|---|---|---|---|---|---|---|"]
    for name in ("S0", "S1", "S1b", "S2", "S4", "S4_no_clock"):
        m = dev[name]["metrics"]
        L.append(f"| {name} | {ab(m['match_recall'])} / {ab(m['match_precision'])} | {pct(m['gel_mean_E_err'])} | "
                 f"{ab(m['per_fibril_Eax_rms'])} ({pct(m['per_fibril_Eax_bias'])}) | {pct(m['per_fibril_Etr_bias'])} ± "
                 f"{ab(m['per_fibril_Etr_sd'])} | {ab(m['per_fibril_Eland_ax_rms'])} | {ab(m['map_rms_vs_truth'])} | "
                 f"{ab(m['false_flag_rate'])} | {m.get('runtime_s', '')} s |")
    L += ["", "## What changed from v1 (fresh AI review, 2026-10-09)", "",
          "- **Blind ≠ independent:** S3 comes from a separate AI agent (another Claude instance, so it may share our blind spots) that read only the observation format. The "
          "pipeline is no longer given the pairing: it matches pre to post objects itself (rotation and translation "
          "voting, mirror check, local-affine refinement, one-to-one assignment), so lost fibrils and debris are possible.",
          "- **Fragment ends:** Z-discs within 0.35 sarcomere of a profile end are not used (truncated or frayed peaks "
          "pulled the v1 ladder low). Fragments now break at random points. On isolated profiles the v2 ladder has "
          "bias −0.01% and 0.16% RMS against v1's −0.03% and 0.18% (Life 5 diagnostic).",
          "- **Detrending:** each pre profile is divided by its own local mean over 1.5 sarcomeres (or has it "
          "subtracted, for signed images), and the fit carries a constant and a slope.",
          "- **Effect sizes:** anisotropy is called only beyond ±1% (95% CI outside ±1%), and a gel is called "
          "isotropic when its 90% CI sits inside ±1%. 'CI excludes 0' called a −0.12% bias on a perfect gel a finding.",
          "- **Drift:** a clock tile re-imaged every 50 tiles gives the gel's scale during the scan; every post object "
          "is brought back to the reference time before any ruler runs.",
          "- **QC:** axial fits far below the gel's own R² spread are rejected (relative, so it adapts to contrast)."]
    (ROOT / "docs" / "design" / "strain_map_v2.md").write_text("\n".join(L) + "\n", encoding="utf-8", newline="\n")
    print("\n".join(L[:12 + len(checks)]))


if __name__ == "__main__":
    main()
