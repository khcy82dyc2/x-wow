"""SWELL labelling v1 (Life 5): how many amines must carry a dye for SNR 10, and how many 20 µg/mL NHS ester labels.

R30 (optics_v1): at 0.5% labelled amines a 2 µm myofibril needs 3.2× today's dose for SNR 10 once the
widefield out-of-focus pedestal is counted. The fresh AI review (item e) asked for the minimum labelling fraction
that reaches SNR 10 at today's dose, compared with what pan-ExM's stain (20 µg/mL NHS ester, 100 mM bicarbonate,
1.5 h at room temperature; F-18) actually labels.

1. Minimum fraction: the optics_v1 photon model (signal ∝ labelled fraction), the pedestal (thickness ÷ DOF - 1),
   background and read noise at gain 4×; solved for SNR = 10 at 100 ms (today) and 200 ms (Order 12's limit).
2. pan-ExM's fraction: no paper reports it (searched 2026-10-10), so it is estimated with a two-step kinetic model,
   NHS-ester aminolysis competing with hydrolysis, whose rate constant is calibrated on standard antibody labelling
   (a known degree of labelling at a known dye excess). Every input is a range and is marked ASSUMPTION.

Run:  .venv/Scripts/python.exe software/sim/labelling_v1.py   ->  docs/design/labelling_v1.md + .json
"""
from __future__ import annotations

import itertools
import json
import math
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
from design_calc import Params, dof, snr_first_pass  # noqa: E402

READ_G4 = 2.3          # e-, effective read noise at gain 4× incl. 10-bit quantisation (optics_v1)
FOV_AREA = 283 * 211   # µm², Track A field (optics_v1, d = 25 mm)

# Antibody labelling used to calibrate the aminolysis rate (ASSUMPTION: typical vendor-protocol outcomes)
IGG = {"mg_ml": (1.0, 2.0), "kda": 150.0, "amines": 84.0,              # ~80 Lys + 4 N-termini per IgG
       "molar_excess": (10.0, 20.0), "dol": (3.0, 8.0), "t_s": 3600.0}
# pan-ExM stain (F-18, verified): 20 µg/mL NHS ester, 100 mM bicarbonate, 1.5 h, room temperature
PANEXM = {"ug_ml": 20.0, "t_s": 5400.0, "dye_mw": (643.4, 981.0)}   # Alexa Fluor 488 NHS / ATTO 488 NHS (g/mol)
TAU_HALF_MIN = (10.0, 60.0)    # NHS-ester hydrolysis half-life at pH 8.3, RT (ASSUMPTION: 1 h at pH 8, 10 min at pH 8.6)


def snr(signal, thick_um, t_scale=1.0, f_scale=1.0, bg=0.0):
    p = Params()
    d = dof(p.lam_em, p.na_4x, p.n_water)
    s = signal * t_scale * f_scale
    ped = s * max(thick_um * 4.5 / d - 1.0, 0.0)
    return s / math.sqrt(s + ped + bg * t_scale + READ_G4 ** 2)


def min_fraction():
    """Labelled-amine fraction that gives SNR 10, by bisection on the optics_v1 model (signal ∝ fraction)."""
    p = Params()
    base = snr_first_pass(p, FOV_AREA)
    row = next(r for r in base["rows"] if abs(r["f_lab"] - 0.005) < 1e-9)
    s05, bg = row["signal_e"], row["bg_cheap_e"]
    out = {}
    for t_ms in (100, 200):
        for thick in (1.0, 2.0):
            lo, hi = 1e-5, 0.5
            for _ in range(60):
                mid = math.sqrt(lo * hi)
                if snr(s05, thick, t_ms / 100, mid / 0.005, bg) >= 10:
                    hi = mid
                else:
                    lo = mid
            out[f"{t_ms} ms | {thick:.0f} µm myofibril"] = hi
    return out, s05


def k_from_igg(mg, ex, dol, tau_half_min):
    """Per-amine aminolysis rate (M⁻¹ s⁻¹) implied by one antibody-labelling outcome: f = 1 - exp(-k ∫[dye]dt),
    with the dye decaying by hydrolysis (half-life tau) and partly consumed by labelling."""
    igg_m = mg / IGG["kda"] / 1e3                        # mol/L
    dye0 = ex * igg_m
    tau = tau_half_min * 60 / math.log(2)
    f = dol / IGG["amines"]
    consumed = dol * igg_m
    integ = (dye0 - consumed / 2) * tau * (1 - math.exp(-IGG["t_s"] / tau))
    return -math.log(1 - f) / integ


def f_panexm(k, tau_half_min, mw):
    dye0 = PANEXM["ug_ml"] * 1e-3 / mw                  # mol/L (µg/mL = mg/L)
    tau = tau_half_min * 60 / math.log(2)
    integ = dye0 * tau * (1 - math.exp(-PANEXM["t_s"] / tau))   # dye in large excess over the gel's amines
    return 1 - math.exp(-k * integ)


def panexm_range():
    """The same hydrolysis half-life is used to calibrate k on antibodies and to predict pan-ExM, so the two
    assumptions stay consistent. Returns (min, central, max, k range)."""
    fs, ks = [], []
    for mg, ex, dol, th, mw in itertools.product(IGG["mg_ml"], IGG["molar_excess"], IGG["dol"], TAU_HALF_MIN,
                                                  PANEXM["dye_mw"]):
        k = k_from_igg(mg, ex, dol, th)
        ks.append(k)
        fs.append(f_panexm(k, th, mw))
    th_c = math.sqrt(TAU_HALF_MIN[0] * TAU_HALF_MIN[1])
    k_c = k_from_igg(1.5, 15.0, 5.0, th_c)
    central = f_panexm(k_c, th_c, 800.0)
    return min(fs), central, max(fs), (min(ks), max(ks), k_c)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    fmin, s05 = min_fraction()
    f_lo, f_c, f_hi, (k_lo, k_hi, k_c) = panexm_range()
    pan = (f_lo, f_hi)
    kit = (f_lo * 2 / 20, f_hi * 2 / 20)                # the kit's 2 µg/mL stain: 10x less dye, f ∝ dye when f is small
    res = {"signal_e_at_0.5pct_100ms": s05, "min_fraction_snr10": fmin, "k_aminolysis_M_s": [k_lo, k_c, k_hi],
           "panexm_20ug_ml_fraction": [f_lo, f_c, f_hi], "kit_2ug_ml_fraction": list(kit),
           "inputs": {"igg": IGG, "panexm": PANEXM, "tau_half_min": TAU_HALF_MIN}}
    worst_today = fmin["100 ms | 2 µm myofibril"]
    best_200 = fmin["200 ms | 1 µm myofibril"]
    res["verdict"] = ("open: the estimated pan-ExM labelling straddles the minimum, so it is settled by the E-17 dye "
                      "titration on the first gels" if pan[0] < worst_today < pan[1] or pan[0] < best_200 < pan[1]
                      else ("closed on paper: pan-ExM-level staining clears the minimum" if pan[0] >= worst_today
                            else "fails on paper: even pan-ExM-level staining falls short"))
    (ROOT / "docs" / "design" / "labelling_v1.json").write_text(json.dumps(res, indent=2), encoding="utf-8",
                                                               newline="\n")
    L = ["# SWELL labelling v1: the dye density SNR 10 needs vs what an NHS-ester stain gives (R30)", "",
         f"**Answer:** at today's dose (100 ms, 1 W/cm², gain 4×) SNR 10 needs **{100 * fmin['100 ms | 1 µm myofibril']:.2f}%** "
         f"of amines labelled for a 1 µm myofibril and **{100 * worst_today:.2f}%** for a 2 µm one (the pedestal of "
         f"out-of-focus light grows with thickness). At 200 ms (Order 12's limit): {100 * best_200:.2f}% and "
         f"{100 * fmin['200 ms | 2 µm myofibril']:.2f}%.", "",
         f"pan-ExM's stain (20 µg/mL NHS ester, 1.5 h, pH 8.3) is estimated to label **about {100 * f_c:.1f}%** of amines "
         f"(range {100 * pan[0]:.2f}–{100 * pan[1]:.1f}% over every input range); the kit's 2 µg/mL stain, ten times "
         f"less dye, about {100 * f_c / 10:.2f}%. "
         f"**Verdict: {res['verdict']}.**", "",
         "Generated by `software/sim/labelling_v1.py`. No published measurement of the labelled fraction in pan-ExM "
         "was found (search 2026-10-10), so the fraction is a model estimate, not a measurement.", "",
         "## 1. Minimum labelled-amine fraction for SNR 10 (optics_v1 photon model, pedestal included)", "",
         "| exposure | myofibril Ø (pre) | minimum fraction |", "|---|---|---|"]
    for k, v in fmin.items():
        t, d = k.split(" | ")
        L.append(f"| {t} | {d.replace(' myofibril', '')} | {100 * v:.2f}% |")
    L += ["", "## 2. What 20 µg/mL NHS ester labels: a kinetic estimate", "",
          "- NHS esters label amines while they hydrolyse. The labelled fraction is 1 − exp(−k∫[dye]dt).",
          f"- k is calibrated on antibody labelling (IgG {IGG['mg_ml'][0]:.0f}–{IGG['mg_ml'][1]:.0f} mg/mL, "
          f"{IGG['molar_excess'][0]:.0f}–{IGG['molar_excess'][1]:.0f}× dye excess, 1 h, giving {IGG['dol'][0]:.0f}–"
          f"{IGG['dol'][1]:.0f} dyes per antibody of ~84 amines; ASSUMPTION): k = {k_lo:.2f}–{k_hi:.2f} M⁻¹s⁻¹ "
          f"(central {k_c:.2f}). The same hydrolysis half-life is used for the calibration and the prediction.",
          f"- Hydrolysis half-life at pH 8.3 and room temperature: {TAU_HALF_MIN[0]:.0f}–{TAU_HALF_MIN[1]:.0f} min (ASSUMPTION).",
          f"- Dye: 20 µg/mL is {20e3 / PANEXM['dye_mw'][1]:.0f}–{20e3 / PANEXM['dye_mw'][0]:.0f} µM (molecular weight "
          f"{PANEXM['dye_mw'][0]:.0f}–{PANEXM['dye_mw'][1]:.0f}). It stays in large excess over the gel's amines, so only "
          "hydrolysis depletes it.",
          f"- Result: about {100 * f_c:.1f}% of amines (central inputs), {100 * pan[0]:.2f}–{100 * pan[1]:.1f}% over every "
          "combination of the input ranges.", "",
          "## 3. What follows", "",
          "- Stain at pan-ExM strength (20 µg/mL), not the kit's 2 µg/mL: the E-17 titration (2 / 6 / 20 µg/mL) on the "
          "first gels measures the real fraction from intensity, and decides.",
          "- Use the 200 ms exposure Order 12 allows; the dose budget (bleaching) is checked at P1.",
          "- If the titration lands below the minimum: more irradiance (bleaching permitting), a brighter dye, or "
          "deconvolution of the pedestal (it is a smooth background, but its shot noise stays).",
          "- R30 stays open until the titration; this file gives it numbers."]
    (ROOT / "docs" / "design" / "labelling_v1.md").write_text("\n".join(L) + "\n", encoding="utf-8", newline="\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
