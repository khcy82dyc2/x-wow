"""S3 rerun with the TRUE blur widths (development only: S3 has been seen).

Question it answers: was the transverse ruler's -17.8% bias on red-team gel S3 caused by the wrong blur
calibration the red team gave it (pre 0.40 / post 0.42 µm), or by the blur SHAPE the pipeline does not model?
It reruns the current pipeline on S3 with the red team's true core widths (0.44 / 0.43 µm, from its truth file),
then measures the transverse bias the same way the red team's scorer does (median E_tr / true E - 1 over the
correct matches). Writes docs/design/s3_true_psf.json.

Run: .venv/Scripts/python.exe software/sim/s3_true_psf.py
"""
import gzip
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "software" / "swell_ruler"))
from swell_ruler.pipeline import run  # noqa: E402

S3 = ROOT / "data" / "sim" / "S3"


def load(p):
    return json.loads(gzip.decompress(p.read_bytes()).decode("utf-8"))


def tr_bias(res, truth):
    true_e = {k: v["E_tr"] for k, v in truth["fibrils"].items() if v.get("kind") == "fibril" and "E_tr" in v}
    pairs = truth["pairs"]
    rel = []
    for pid, f in res["fibrils"].items():
        if f.get("E_tr") is None or pid not in pairs or pairs[pid] != f["post_id"]:
            continue
        if pid in true_e:
            rel.append(f["E_tr"] / true_e[pid] - 1)
    return (float(np.median(rel)) if rel else None), len(rel)


def main():
    obs, truth = load(S3 / "obs.json.gz"), load(S3 / "truth.json.gz")
    mt = truth["meta_truth"]
    told = {"pre": obs["meta"]["psf_pre_fwhm_um"], "post": obs["meta"]["psf_post_fwhm_um"]}
    obs["meta"]["psf_pre_fwhm_um"] = mt["psf_pre_true_core_fwhm"]
    obs["meta"]["psf_post_fwhm_um"] = mt["psf_post_true_core_fwhm"]
    res = run(obs)
    bias, n = tr_bias(res, truth)
    a = res["gel"]["anisotropy"]
    out = {"what": "S3 rerun with the true blur widths (development; S3 has been seen)",
           "psf_told_um": told, "psf_true_core_um": {"pre": mt["psf_pre_true_core_fwhm"], "post": mt["psf_post_true_core_fwhm"]},
           "transverse_bias_median": bias, "n_correct_with_E_tr": n,
           "anisotropy_call": a.get("call"), "anisotropy_est": a.get("est"), "tr_vs_landmark": a.get("tr_vs_landmark"),
           "conclusion": "the bias stays with the true widths, so it comes from the blur shape, not the calibration"
           if bias is not None and abs(bias) > 0.1 else "the bias mostly goes away with the true widths"}
    f = ROOT / "docs" / "design" / "s3_true_psf.json"
    f.write_text(json.dumps(out, indent=1) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
