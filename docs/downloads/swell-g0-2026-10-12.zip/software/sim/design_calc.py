"""SWELL design calculator v0 (Life 1, audit evidence).

Every number quoted in pm/AUDIT.md comes from this file. Re-run with:
    .venv/Scripts/python.exe software/sim/design_calc.py
It writes docs/design/calc_v0.md and docs/design/calc_v0.json.

Units: lengths in micrometres unless a name says otherwise. Inputs marked (verify) are not yet confirmed
against a primary source; they are parameters, so Order 2 / Order 12 can replace them and re-run.
"""
from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]


@dataclass
class Params:
    lam_em: float = 0.52          # emission wavelength (AF488/ATTO488-class NHS dye); kit placeholder was 0.55
    na_4x: float = 0.65           # Track A objective
    na_10x: float = 0.40          # Track B objective
    e_4x: tuple = (4.0, 4.5, 4.8)  # U-ExM-type range (4.8 = upper tail)
    e_10x: float = 10.0
    n_water: float = 1.333
    cam_px: float = 3.45          # IMX296 pixel pitch
    cam_w: int = 1456
    cam_h: int = 1088
    bytes_per_px: int = 2         # 10-bit raw stored as uint16
    overlap: float = 0.10         # tile overlap fraction per edge
    xy_step_nm: float = 70.0      # OFM XY step (Collins et al. 2020, v6)
    z_step_nm: float = 50.0       # OFM Z step (Collins et al. 2020, v6)
    step_rate: tuple = (500.0, 1000.0)  # steps/s, 28BYJ-48 practical range (verify on hardware)
    settle_s: float = 0.3         # flexure settle after an XY move (verify)
    exposure_s: float = 0.10
    readout_s: float = 0.02
    usable_travel_mm: float = 10.0  # users measure ~10 mm of the nominal 12 mm
    centring_tol_mm: float = 0.5    # dish/holder centring tolerance (per side)
    gel_thickness_cast: float = 150.0
    myofibril_thickness: tuple = (1.0, 2.0)
    a_band: float = 1.60          # thick-filament length (verify for chicken pectoralis)
    sl_breast_mean: float = 1.69  # normal broiler pectoralis SL by laser diffraction (vs 1.91 in wooden breast)
    sl_breast_sd: float = 0.08    # within-sample spread (assumption; replace with our own pre-image survey)
    zdisc_width_nm: tuple = (30.0, 50.0, 80.0, 140.0)  # 30-140 nm across muscles/species
    overview_wd_mm: float = 100.0   # overview camera working distance (design value)
    water_depth_mm: float = 3.0
    illum_area_factor: tuple = (1.0, 3.0)  # illuminated area / camera FOV: with field stop vs flooded
    n_af_exposures: int = 0          # per-tile autofocus exposures (focus-map default = 0)


def fwhm_lat(lam, na):
    return 0.51 * lam / na


def rayleigh(lam, na):
    return 0.61 * lam / na


def nyquist_px(lam, na):
    return lam / (4 * na)


def dof(lam, na, n):
    return lam * n / na ** 2


def focal_shift(na, n2, n1=1.0):
    """Ratio of real focal displacement in medium n2 to nominal objective displacement (dry objective)."""
    paraxial = n2 / n1
    th1 = math.asin(na / n1)
    th2 = math.asin(na / n2)
    marginal = math.tan(th1) / math.tan(th2)
    return paraxial, marginal


def axial_nyquist(lam, na, n):
    alpha = math.asin(na / n)
    return lam / (2 * n * (1 - math.cos(alpha)))


def tiles_for_disk(diam_um, fov_w, fov_h, overlap):
    """Count grid tiles (with overlap) whose footprint intersects a disk of the given diameter."""
    sx, sy = fov_w * (1 - overlap), fov_h * (1 - overlap)
    r = diam_um / 2
    nx, ny = math.ceil(diam_um / sx) + 1, math.ceil(diam_um / sy) + 1
    count = 0
    for i in range(nx):
        for j in range(ny):
            cx = -r + (i + 0.5) * sx
            cy = -r + (j + 0.5) * sy
            dx = max(abs(cx) - fov_w / 2, 0)
            dy = max(abs(cy) - fov_h / 2, 0)
            if dx * dx + dy * dy <= r * r:
                count += 1
    return count


def finite_tube_lens_mag(m_obj, f_tube_mm, d_mm, image_dist_mm=150.0):
    """Thin-lens estimate: lens of focal f placed d mm behind a 160 mm-tube RMS objective (converging beam).

    The objective alone images at ~image_dist_mm; the lens sees a virtual object (image_dist - d) beyond it.
    Returns total magnification and the sensor distance behind the lens.
    """
    s = image_dist_mm - d_mm
    s_img = 1.0 / (1.0 / f_tube_mm + 1.0 / s)
    return m_obj * s_img / s, s_img


def period_ruler_precision(n_sarc, sl=1.69, e=4.5, px=0.2, photons=400, n_trials=300, seed=0):
    """Monte Carlo: relative error of sarcomere-period estimation from a blurred, noisy striation profile.

    Profile = bright Z-lines + A-band plateau, blurred by the expanded-space PSF, Poisson noise.
    Estimator: FFT peak refined by least-squares sinusoid fit around it (blur-invariant period).
    """
    rng = np.random.default_rng(seed)
    period = sl * e
    length = n_sarc * period
    x = np.arange(0, length, px)
    sigma = fwhm_lat(0.52, 0.65) / 2.355
    phase = x % period
    a_half = min(1.6 * e / 2, period / 2)
    prof = 0.6 * (np.abs(phase - period / 2) < a_half) + 1.0 * np.exp(-0.5 * (np.minimum(phase, period - phase) / (0.05 * e)) ** 2)
    k = np.exp(-0.5 * ((np.arange(-30, 31) * px) / sigma) ** 2)
    prof = np.convolve(prof, k / k.sum(), mode="same") + 0.2
    errs = []
    # Prior: the pipeline knows SL_pre (pre-expansion image) and E_macro (overview camera) to ~±15%, so the
    # search window [0.85, 1.15] x expected period excludes harmonics. Model = 3 harmonics, linear in amplitudes.
    grid = np.linspace(0.85, 1.15, 601) / period
    for _ in range(n_trials):
        y = rng.poisson(prof / prof.max() * photons).astype(float)
        y -= y.mean()
        rss = np.empty(grid.size)
        for i, ff in enumerate(grid):
            cols = []
            for h in (1, 2, 3):
                cols += [np.cos(2 * np.pi * h * ff * x), np.sin(2 * np.pi * h * ff * x)]
            a = np.vstack(cols).T
            coef, *_ = np.linalg.lstsq(a, y, rcond=None)
            rss[i] = np.sum((y - a @ coef) ** 2)
        i = int(np.clip(np.argmin(rss), 1, grid.size - 2))
        y0, y1, y2 = rss[i - 1], rss[i], rss[i + 1]
        denom = y0 - 2 * y1 + y2
        shift = 0.5 * (y0 - y2) / denom if denom > 0 else 0.0  # parabolic refinement of the RSS minimum
        f_hat = grid[i] + shift * (grid[1] - grid[0])
        errs.append(abs(1.0 / f_hat - period) / period)
    return float(np.sqrt(np.mean(np.square(errs))))


def _fit_period(y, x, p_expected, harmonics=(1, 2, 3)):
    """Least-squares harmonic fit; coarse-to-fine search inside a ±15% prior window; parabolic refinement."""
    def rss(ff):
        cols = []
        for h in harmonics:
            cols += [np.cos(2 * np.pi * h * ff * x), np.sin(2 * np.pi * h * ff * x)]
        a = np.vstack(cols).T
        coef, *_ = np.linalg.lstsq(a, y, rcond=None)
        return float(np.sum((y - a @ coef) ** 2))
    coarse = np.linspace(0.85, 1.15, 121) / p_expected
    i = int(np.argmin([rss(f) for f in coarse]))
    lo, hi = coarse[max(i - 1, 0)], coarse[min(i + 1, coarse.size - 1)]
    fine = np.linspace(lo, hi, 41)
    r = np.array([rss(f) for f in fine])
    j = int(np.clip(np.argmin(r), 1, fine.size - 2))
    d = r[j - 1] - 2 * r[j] + r[j + 1]
    shift = 0.5 * (r[j - 1] - r[j + 1]) / d if d > 0 else 0.0
    return 1.0 / (fine[j] + shift * (fine[1] - fine[0]))


def period_ratio_precision(n_sarc, m_pre, photons_pre, sl=1.69, e=4.5, px=0.2, photons_post=400,
                           n_trials=200, seed=1):
    """Monte Carlo: relative RMS error of E_local = SL_post / SL_pre for one myofibril segment of n_sarc sarcomeres.

    Pre-image: label-free (oblique/DPC or crossed polarisers), same camera and pixel (0.2 µm), unexpanded period
    1.69 µm (8.5 px). Modelled as a mean level with striation modulation m_pre (after optical blur) split 70/30
    between the fundamental and the 2nd harmonic, Poisson noise at photons_pre per pixel.
    Post-image: pan-stained expanded myofibril, same model as period_ruler_precision.
    The prior window comes from E_macro (overview camera) times SL_pre.
    """
    rng = np.random.default_rng(seed)
    p_pre, p_post = sl, sl * e
    x_pre = np.arange(0, n_sarc * p_pre, px)
    x_post = np.arange(0, n_sarc * p_post, px)
    sigma = fwhm_lat(0.52, 0.65) / 2.355
    phase = x_post % p_post
    a_half = min(1.6 * e / 2, p_post / 2)
    prof_post = 0.6 * (np.abs(phase - p_post / 2) < a_half) + np.exp(-0.5 * (np.minimum(phase, p_post - phase) / (0.05 * e)) ** 2)
    k = np.exp(-0.5 * ((np.arange(-30, 31) * px) / sigma) ** 2)
    prof_post = np.convolve(prof_post, k / k.sum(), mode="same") + 0.2
    errs = []
    for _ in range(n_trials):
        ph0 = rng.uniform(0, 2 * np.pi)
        pre = 1 + m_pre * (0.7 * np.cos(2 * np.pi * x_pre / p_pre + ph0) + 0.3 * np.cos(4 * np.pi * x_pre / p_pre + 2 * ph0))
        y_pre = rng.poisson(pre * photons_pre).astype(float)
        y_post = rng.poisson(prof_post / prof_post.max() * photons_post).astype(float)
        pre_hat = _fit_period(y_pre - y_pre.mean(), x_pre, p_pre * rng.uniform(0.95, 1.05))
        post_hat = _fit_period(y_post - y_post.mean(), x_post, p_post * rng.uniform(0.9, 1.1))
        errs.append(post_hat / pre_hat / e - 1)
    return float(np.sqrt(np.mean(np.square(errs))))


def snr_first_pass(p: Params, fov_area_um2: float, e: float = 4.5, irr_w_cm2: float = 1.0, t_s: float = 0.1):
    """Order-of-magnitude photon budget for a pan-stained expanded myofibril, one pixel, one exposure."""
    avogadro, h, c = 6.022e23, 6.626e-34, 2.998e8
    amine_mol_per_g = 0.08 / 110.0                 # 8% of residues (Lys + N-termini), mean residue mass 110 Da
    protein_g_per_ml = 0.15
    px = nyquist_px(p.lam_em, p.na_4x)
    voxel_l = px * px * dof(p.lam_em, p.na_4x, p.n_water) * 1e-15   # µm³ -> L; myofibril (4.5–9 µm) fills the DOF
    sigma = 3.82e-21 * 73000 * 0.55               # cm², AF488 at a 470 nm LED (55% of peak absorbance)
    flux = irr_w_cm2 / (h * c / 470e-9)           # photons cm^-2 s^-1
    emit_per_mol = sigma * flux * 0.92            # quantum yield 0.92
    theta = math.asin(p.na_4x / p.n_water)
    collect = (1 - math.cos(theta)) / 2 * 0.9 * 0.8 * 0.9 * 0.9 * 0.6   # Fresnel, objective, emission, dichroic, QE
    # bleed-through: 4% of the illuminated power returns, spread over the sensor after filter suppression
    power_w = irr_w_cm2 * fov_area_um2 * 1e-8
    back_photons = 0.04 * power_w / (h * c / 470e-9) * t_s
    n_px = p.cam_w * p.cam_h
    rows = []
    for f_lab in (0.005, 0.02, 0.05):
        conc_m = protein_g_per_ml * 1e3 * amine_mol_per_g * f_lab / e ** 3   # mol/L
        n_mol = conc_m * voxel_l * avogadro
        signal = n_mol * emit_per_mol * collect * t_s
        bg_cheap = back_photons * 1e-2 * 1e-3 * 0.6 / n_px
        bg_good = back_photons * 1e-3 * 1e-6 * 0.6 / n_px
        read = 2.2
        rows.append({"f_lab": f_lab, "dye_uM": conc_m * 1e6, "signal_e": signal, "bg_cheap_e": bg_cheap,
                     "bg_good_e": bg_good, "snr_cheap": signal / math.sqrt(signal + bg_cheap + read ** 2),
                     "snr_good": signal / math.sqrt(signal + bg_good + read ** 2)})
    return {"irradiance_W_cm2": irr_w_cm2, "exposure_s": t_s, "collection_efficiency": collect, "rows": rows}


def main():
    p = Params()
    out: dict = {"params": asdict(p)}
    lines = ["# SWELL design calculations v0 (Life 1)", "",
             "Generated by `software/sim/design_calc.py`. Inputs marked (verify) in the source are parameters "
             "until confirmed. Units µm unless stated.", ""]

    # 1. Resolution and sampling
    res = {}
    for label, na, e in [("4x", p.na_4x, 4.5), ("10x", p.na_10x, p.e_10x)]:
        r = {"rayleigh_nm": 1e3 * rayleigh(p.lam_em, na) / e, "fwhm_nm": 1e3 * fwhm_lat(p.lam_em, na) / e,
             "nyquist_px_um": nyquist_px(p.lam_em, na), "dof_water_um": dof(p.lam_em, na, p.n_water),
             "axial_nyquist_um": axial_nyquist(p.lam_em, na, p.n_water)}
        r["mag_required"] = p.cam_px / r["nyquist_px_um"]
        r["focal_shift_paraxial"], r["focal_shift_marginal"] = focal_shift(na, p.n_water)
        res[label] = r
    out["resolution"] = res
    lines += ["## 1. Resolution, sampling, focal shift (λem = %.2f µm)" % p.lam_em, "",
              "| track | Rayleigh /E (nm) | FWHM /E (nm) | Nyquist pixel (µm) | M needed for 3.45 µm px | DOF in water (µm) | axial Nyquist (µm) | focal shift paraxial–marginal |",
              "|---|---|---|---|---|---|---|---|"]
    for k, r in res.items():
        lines.append(f"| {k} | {r['rayleigh_nm']:.0f} | {r['fwhm_nm']:.0f} | {r['nyquist_px_um']:.3f} | {r['mag_required']:.1f}× | "
                     f"{r['dof_water_um']:.2f} | {r['axial_nyquist_um']:.2f} | {r['focal_shift_paraxial']:.2f}–{r['focal_shift_marginal']:.2f} |")

    # 2. Optics: magnification options
    mag = {}
    for f in (40.0, 50.0, 75.0, 100.0):
        for d in (10.0, 30.0):
            m, s_img = finite_tube_lens_mag(40, f, d)
            mag[f"finite_f{int(f)}_d{int(d)}"] = {"M": m, "sensor_dist_mm": s_img, "px_um": p.cam_px / m}
    for f in (75.0, 100.0, 125.0):
        m = f / (200.0 / 40)  # infinity 40x objective, Nikon-style 200 mm reference -> f_obj = 5 mm
        mag[f"infinity_f{int(f)}"] = {"M": m, "px_um": p.cam_px / m}
    out["magnification_options"] = mag
    lines += ["", "## 2. Magnification options for a 40× objective and 3.45 µm pixels",
              "Finite (160 mm RMS) with a short tube lens, thin-lens estimate; infinity objective with tube lens f. "
              f"Target pixel ≈ {res['4x']['nyquist_px_um']:.3f} µm (Nyquist).", "",
              "| option | total M | sample pixel (µm) | sampling vs Nyquist |", "|---|---|---|---|"]
    for k, v in mag.items():
        lines.append(f"| {k} | {v['M']:.1f} | {v['px_um']:.3f} | {res['4x']['nyquist_px_um'] / v['px_um']:.2f}× |")

    # 3. Tiles, data and scan time
    px_s = res["4x"]["nyquist_px_um"]
    fov_w, fov_h = p.cam_w * px_s, p.cam_h * px_s
    scan = {}
    for punch_mm in (2.0, 1.5):
        for e in p.e_4x:
            diam = punch_mm * 1e3 * e
            n_t = tiles_for_disk(diam, fov_w, fov_h, p.overlap)
            zrange = max(p.myofibril_thickness) * e + 4.0  # specimen + ±2 µm focus-map margin
            nz = math.ceil(zrange / res["4x"]["axial_nyquist_um"]) + 1
            move_um = fov_w * (1 - p.overlap)
            t_tile = []
            for rate in p.step_rate:
                t_xy = move_um / (p.xy_step_nm / 1e3) / rate + p.settle_s
                t_z = 2 * zrange / (p.z_step_nm / 1e3) / rate
                t_tile.append(t_xy + t_z + nz * (p.exposure_s + p.readout_s))
            gb = n_t * nz * p.cam_w * p.cam_h * p.bytes_per_px / 1e9
            scan[f"punch{punch_mm}mm_E{e}"] = {"diam_mm": diam / 1e3, "tiles_per_plane": n_t, "z_planes": nz,
                                               "raw_GB": gb, "hours": [n_t * t / 3600 for t in t_tile],
                                               "travel_needed_mm": diam / 1e3 + 2 * p.centring_tol_mm - fov_w / 1e3}
    for punch_mm in (1.0, 0.75):
        e = p.e_10x
        px10 = res["10x"]["nyquist_px_um"]
        diam = punch_mm * 1e3 * e
        n_t = tiles_for_disk(diam, p.cam_w * px10, p.cam_h * px10, p.overlap)
        scan[f"punch{punch_mm}mm_E10"] = {"diam_mm": diam / 1e3, "tiles_per_plane": n_t,
                                          "travel_needed_mm": diam / 1e3 + 2 * p.centring_tol_mm - p.cam_w * px10 / 1e3}
    out["scan"] = scan
    lines += ["", f"## 3. Tiles, data, scan time (FOV {fov_w:.0f} × {fov_h:.0f} µm at Nyquist, {p.overlap:.0%} overlap)", "",
              "| case | expanded Ø (mm) | tiles/plane | z-planes | raw GB | scan h (fast–slow motors) | travel needed (mm) vs usable 10 |",
              "|---|---|---|---|---|---|---|"]
    for k, v in scan.items():
        hrs = v.get("hours")
        lines.append(f"| {k} | {v['diam_mm']:.1f} | {v['tiles_per_plane']} | {v.get('z_planes', '—')} | "
                     f"{v.get('raw_GB', float('nan')):.1f} | {(f'{min(hrs):.1f}–{max(hrs):.1f}' if hrs else '—')} | "
                     f"{v['travel_needed_mm']:.1f} {'OK' if v['travel_needed_mm'] <= p.usable_travel_mm else 'FAILS'} |")

    # 4. Rulers: I-band visibility and Z-disc width bias
    rul = {}
    fw4 = fwhm_lat(p.lam_em, p.na_4x)
    fw10 = fwhm_lat(p.lam_em, p.na_10x)
    for label, e, fw in [("4x", 4.5, fw4), ("10x", 10.0, fw10)]:
        sl_min = p.a_band + 2 * fw / e
        frac = 0.5 * math.erfc((sl_min - p.sl_breast_mean) / (p.sl_breast_sd * math.sqrt(2)))
        rul[label] = {"sl_min_for_iband_um": sl_min, "fraction_usable_normal_breast": frac,
                      "iband_each_side_at_mean_nm": 1e3 * (p.sl_breast_mean - p.a_band) / 2}
        rul[label]["zdisc_measured_fwhm_nm"] = {str(w): math.hypot(1e3 * fw / e, w) for w in p.zdisc_width_nm}
    out["rulers"] = rul
    lines += ["", "## 4. Built-in rulers on supermarket breast (SL mean %.2f µm, SD %.2f assumed)" % (p.sl_breast_mean, p.sl_breast_sd), "",
              "| track | I-band per side at mean SL (nm) | min SL for a resolvable I-band (µm) | fraction of sarcomeres usable for the A-band ruler | measured Z-disc FWHM for true width 30/50/80/140 nm (nm) |",
              "|---|---|---|---|---|"]
    for k, v in rul.items():
        z = "/".join(f"{x:.0f}" for x in v["zdisc_measured_fwhm_nm"].values())
        lines.append(f"| {k} | {v['iband_each_side_at_mean_nm']:.0f} | {v['sl_min_for_iband_um']:.2f} | {v['fraction_usable_normal_breast']:.0%} | {z} |")

    prec = {n: period_ruler_precision(n) for n in (3, 5, 10, 20)}
    out["period_ruler_rel_error"] = prec
    lines += ["", "Period ruler (Fourier + sinusoid fit, Poisson noise, blur from the 4× PSF): relative RMS error of the "
              "sarcomere period from one myofibril segment:", "",
              "| sarcomeres in segment | relative error |", "|---|---|"]
    lines += [f"| {n} | {v:.3%} |" for n, v in prec.items()]

    cases = {"DPC/oblique, 5% modulation, 5,000 e⁻/px": (0.05, 5000),
             "DPC/oblique, 15% modulation, 5,000 e⁻/px": (0.15, 5000),
             "crossed polarisers, 50% modulation, 300 e⁻/px": (0.5, 300)}
    ratio = {c: {n: period_ratio_precision(n, m, ph) for n in (5, 10, 20)} for c, (m, ph) in cases.items()}
    out["period_ratio_rel_error"] = ratio
    lines += ["", "**E_local = SL_post / SL_pre (the ruler that matters):** relative RMS error of the ratio for one myofibril "
              "segment. The pre-image is label-free (same camera and 0.2 µm pixel, 8.5 px per sarcomere). The contrast cases "
              "are assumptions until P1 measures the real ones (R21).", "",
              "| pre-image contrast case | 5 sarcomeres | 10 sarcomeres | 20 sarcomeres |", "|---|---|---|---|"]
    for c, row in ratio.items():
        lines.append(f"| {c} | {row[5]:.2%} | {row[10]:.2%} | {row[20]:.2%} |")

    # 5. Gel, overview camera, bleaching multiplicity
    misc = {"gel_volume_12mm_150um_uL": math.pi * 6 ** 2 * 0.150,
            "overview_scale_bias_pct": 100 * p.water_depth_mm * (1 - 1 / p.n_water) / p.overview_wd_mm}
    nz = scan["punch1.5mm_E4.5"]["z_planes"]
    misc["dose_multiplicity"] = {str(k): nz * k * (1 + p.overlap) ** 2 + p.n_af_exposures for k in p.illum_area_factor}
    misc["dose_multiplicity_with_per_tile_AF5"] = nz * max(p.illum_area_factor) * (1 + p.overlap) ** 2 + 5 * max(p.illum_area_factor)
    out["misc"] = misc
    lines += ["", "## 5. Gel, overview camera, photon dose", "",
              f"- Gel volume, 12 mm coverslip, 150 µm spacer: **{misc['gel_volume_12mm_150um_uL']:.1f} µL**.",
              f"- Overview camera: {p.water_depth_mm} mm of water at {p.overview_wd_mm:.0f} mm working distance shifts apparent "
              f"scale by **{misc['overview_scale_bias_pct']:.2f}%** unless pre and post images share geometry or carry an in-plane scale.",
              f"- Exposures each gel point receives ({nz} z-planes, {p.overlap:.0%} overlap): **{misc['dose_multiplicity']['1.0']:.1f}** with a field stop "
              f"(illuminated area = FOV), **{misc['dose_multiplicity']['3.0']:.1f}** if the LED floods 3× the FOV, "
              f"**{misc['dose_multiplicity_with_per_tile_AF5']:.1f}** if it also runs a 5-image autofocus per tile."]

    # 6. First-pass SNR and bleed-through (assumptions marked; Order 12 replaces this with the full budget)
    snr = snr_first_pass(p, fov_w * fov_h)
    out["snr_first_pass"] = snr
    lines += ["", "## 6. First-pass signal and background per pixel (100 ms, 1 W/cm², AF488-class dye, E 4.5)",
              "Assumptions (to replace in Order 12): myofibril protein 0.15 g/mL; 8% of residues carry an amine; "
              "labelled fraction of amines 0.5–5%; 4% of excitation reflected at the dish's air–glass face returns "
              "into the objective; read noise 2.2 e⁻; QE 0.6; objective T 0.8. Out-of-focus light and "
              "autofluorescence are not yet included.", "",
              "| labelled amines | dye in expanded myofibril (µM) | signal e⁻/px | bleed-through e⁻/px: cheap (dichroic OD2 + emission OD3) / good (OD3 + OD6) | SNR cheap / good |",
              "|---|---|---|---|---|"]
    for r in snr["rows"]:
        lines.append(f"| {r['f_lab']:.1%} | {r['dye_uM']:.0f} | {r['signal_e']:.0f} | {r['bg_cheap_e']:.1f} / {r['bg_good_e']:.4f} | "
                     f"{r['snr_cheap']:.1f} / {r['snr_good']:.1f} |")

    (ROOT / "docs" / "design").mkdir(parents=True, exist_ok=True)
    (ROOT / "docs" / "design" / "calc_v0.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (ROOT / "docs" / "design" / "calc_v0.json").write_text(json.dumps(out, indent=2, default=float), encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
