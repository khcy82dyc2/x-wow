"""Mark a simulation figure as a simulation, on the image itself and in its file metadata.

    python software/sim/simlabel.py docs/design/figs/*.png       (the simulation scripts also call label_png)

Adds a strip ABOVE the figure saying "SIMULATION · synthetic data, not a measurement" (plus an optional note), and
the same words in the PNG's text chunks (Description, Comment). The figure's own pixels are not covered or changed,
and the file stays a lossless PNG. A figure that already carries the label is left alone, so this can run any number
of times. Needs Pillow, which comes with matplotlib. Added 2026-10-10 (audit A-11).
"""
from __future__ import annotations

import sys
import textwrap
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, PngImagePlugin

MARK = "SIMULATION"
TEXT = "SIMULATION · synthetic data, not a measurement"
BG, FG = (5, 8, 13), (255, 181, 71)


def _font(size: int):
    for name in ("DejaVuSans-Bold.ttf", "arialbd.ttf", "segoeuib.ttf", "Helvetica.ttc"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    try:
        return ImageFont.load_default(size=size)      # Pillow >= 10.1
    except TypeError:
        return ImageFont.load_default()


def is_labelled(path) -> bool:
    with Image.open(path) as im:
        return str(im.info.get("Description", "")).startswith(MARK)


def label_png(path, source: str = "", note: str = "") -> str:
    """Add the label strip and metadata to one PNG, in place. Returns what it did."""
    path = Path(path)
    with Image.open(path) as im:
        if str(im.info.get("Description", "")).startswith(MARK):
            return "already labelled"
        kept = {k: v for k, v in getattr(im, "text", {}).items() if k not in ("Description", "Comment")}
        dpi = im.info.get("dpi")
        rgb = im.convert("RGB")
    w, h = rgb.size
    size = max(13, round(w * 0.016))
    font = _font(size)
    pad = round(size * 0.6)
    probe = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    lines = [TEXT]
    if note:
        width_chars = max(20, int((w - 2 * pad) / max(probe.textlength("n", font=font), 1)))
        lines += textwrap.wrap(note, width_chars)
    line_h = round(size * 1.35)
    strip = 2 * pad + line_h * len(lines)
    out = Image.new("RGB", (w, h + strip), BG)
    out.paste(rgb, (0, strip))
    d = ImageDraw.Draw(out)
    for i, ln in enumerate(lines):
        d.text((pad, pad + i * line_h), ln, font=font, fill=FG)
    desc = (f"{TEXT}. Synthetic data from SWELL's simulation, never measured on a real gel or instrument."
            + (f" Source: {source}." if source else "") + (f" Note: {note}" if note else "")
            + " Label strip added above the figure by software/sim/simlabel.py; the figure itself is unchanged.")
    info = PngImagePlugin.PngInfo()
    for k, v in kept.items():
        info.add_text(k, str(v))
    info.add_text("Description", desc)
    info.add_text("Comment", TEXT)
    out.save(path, "PNG", pnginfo=info, **({"dpi": dpi} if dpi else {}))
    return "labelled"


def main(paths: list[str]) -> int:
    if not paths:
        print(__doc__)
        return 2
    for p in paths:
        print(f"{label_png(p)}: {p}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
