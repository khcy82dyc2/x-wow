"""Development-gel generator v2 (Life 5): the v1 physics (strain_map_sim.py) written out as observations.

What changed from v1, after the fresh AI review (2026-10-09):
- Observations follow docs/design/obs_schema_v1.md: shuffled lists, opaque ids, no pairing given. The pipeline
  must match pre to post itself (matching.py), so S0-S2 and S1b now test the matcher too.
- Fragments break at random points, not exactly at Z-discs: each end carries 0-1 sarcomere of extra material.
  Profiles are sampled from each object's own (noisy) centroid, so centring errors arise naturally.
- Full fragment lengths (v1 capped the profiles at 20 sarcomeres).
- S4 (new, development): the S0 gel with expansion drift during the post scan, plus a clock tile re-imaged every
  50 tiles.
The truth stays in a separate file the pipeline never reads.
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import strain_map_sim as v1  # noqa: E402  (v1 physics: deformation, width models, constants)

PX = v1.PX
FOV = (283.0, 211.0)             # post tile field of view (µm), optics_v1 at d = 25 mm
OVERLAP = 0.10
T_TILE = 2.2 * 3600 / 804        # s per tile: Track A, E 4.5, slow motors (optics_v1)
CLOCK_EVERY = 50


def _ids(rng, n, prefix):
    return [f"{prefix}{x:08x}" for x in rng.choice(2 ** 31, n, replace=False)]


def _centred(n, px):
    return (np.arange(n) - (n - 1) / 2.0) * px


def _ladder(seq, a0, a1):
    """Z-disc positions of a fragment (pre µm, first disc at 0) and its extent [-a0, z_last + a1]."""
    z = np.concatenate([[0.0], np.cumsum(seq)])
    return z, -a0, z[-1] + a1


def _phase(xq, z, seq):
    """Sarcomere phase (0 at each Z-disc, +1 per sarcomere) at pre positions xq, extending the end sarcomeres."""
    zz = np.concatenate([[z[0] - seq[0]], z, [z[-1] + seq[-1]]])
    k = np.clip(np.searchsorted(zz, xq, side="right") - 1, 0, zz.size - 2)
    return (k - 1) + (xq - zz[k]) / (zz[k + 1] - zz[k])


def pre_axial(rng, xq, z, seq, lo, hi, m_pre, photons, ph0, slope=0.0):
    """Label-free pre profile at pre positions xq (v1 model: 1 + m(0.7 cos 2πφ + 0.3 cos 4πφ) on the fibril)."""
    phi = _phase(xq, z, seq) + ph0
    inside = (xq >= lo) & (xq <= hi)
    pre = 1 + m_pre * inside * (0.7 * np.cos(2 * np.pi * phi) + 0.3 * np.cos(4 * np.pi * phi))
    pre = pre * (1 + slope * (xq - xq.mean()) / max(np.ptp(xq), 1e-9))
    return rng.poisson(np.clip(pre, 0, None) * photons).astype(float)


def post_axial(rng, xq_post, z, seq, lo, hi, e, photons):
    """Post profile (v1 model: Z-disc line + A-band block, blurred) at post positions measured along the fibril
    in post units from the fragment's first Z-disc."""
    dx = 0.02
    xf = np.arange(xq_post.min() - 3.0, xq_post.max() + 3.0, dx)
    xp = xf / e
    zz = np.concatenate([[z[0] - seq[0]], z, [z[-1] + seq[-1]]])
    sl = np.diff(zz)
    k = np.clip(np.searchsorted(zz, xp, side="right") - 1, 0, sl.size - 1)
    f = (xp - zz[k]) / sl[k]
    p_post = sl[k] * e
    dz = np.minimum(f, 1 - f) * p_post
    a_half = np.minimum(1.6 * e / 2, p_post / 2)
    prof = 0.6 * (np.abs(f - 0.5) * p_post < a_half) + np.exp(-0.5 * (dz / (0.05 * e)) ** 2)
    prof = prof * ((xp >= lo) & (xp <= hi))
    prof = v1._gauss_blur(prof, dx, v1.FWHM_POST / v1.S2F) + 0.2
    clean = np.interp(xq_post, xf, prof)
    return rng.poisson(clean / prof.max() * photons).astype(float)


def raster_tiles(post_xy, centre, radius_post):
    """Tile index (raster order, row by row) and tile origin for each post position."""
    step = np.array(FOV) * (1 - OVERLAP)
    origin = centre - radius_post
    ij = np.floor((post_xy - origin) / step).astype(int)
    ncol = int(math.ceil(2 * radius_post / step[0])) + 1
    return ij[:, 1] * ncol + ij[:, 0], ncol, step, origin


def drift_s(t, total_s, amp):
    """S4 drift: the gel keeps swelling (+amp over the scan) with a slow wobble on top."""
    u = np.asarray(t, float) / total_s
    return 1 + amp * (0.8 * u + 0.2 * np.sin(2 * np.pi * 1.5 * u))


def generate(sc, n_fibrils=1200, drift_amp=0.0, m_pre=0.15, photons_pre=5000.0, photons_post=400.0,
             pre_mode="dpc"):
    seed = sc.seed
    rng = np.random.default_rng(seed)
    rr = v1.R_GEL * np.sqrt(rng.uniform(0, 0.92 ** 2, n_fibrils))
    th = rng.uniform(0, 2 * np.pi, n_fibrils)
    c = np.c_[rr * np.cos(th), rr * np.sin(th)]
    phi = rng.uniform(0, np.pi, n_fibrils)
    length = np.clip(np.exp(rng.normal(math.log(14.0), 0.5, n_fibrils)), 6.0, 40.0)
    width = np.clip(rng.normal(1.2, 0.2, n_fibrils), 0.7, 2.0)
    asp = np.clip(rng.normal(1.0, 0.1, n_fibrils), 0.7, 1.3)
    sl = rng.normal(1.69, 0.08, n_fibrils)
    shape_n = np.random.default_rng(seed + 1000).uniform(2.0, 3.5, n_fibrils)
    u = np.c_[np.cos(phi), np.sin(phi)]
    v = np.c_[-np.sin(phi), np.cos(phi)]

    f_true = v1.jacobian(c, sc)
    e_gel_ax = np.linalg.norm(np.einsum("nij,nj->ni", f_true, u), axis=1)
    e_gel_tr = np.linalg.norm(np.einsum("nij,nj->ni", f_true, v), axis=1)
    k_ax = rng.normal(0, 0.002, n_fibrils) + sc.ax_aniso
    k_tr = rng.normal(0, 0.002, n_fibrils)
    if sc.undig:
        k_ax -= sc.undig * (np.linalg.norm(c - np.array(sc.undig_c), axis=1) < sc.undig_r)
    e_ax = e_gel_ax * (1 + k_ax)
    e_tr = e_gel_tr * (1 + k_tr)

    post_c = v1.deform(c, sc)
    centre = v1.deform(np.zeros((1, 2)), sc)[0]
    u_post = np.einsum("nij,nj->ni", f_true, u)
    u_post /= np.linalg.norm(u_post, axis=1, keepdims=True)
    v_post = np.c_[-u_post[:, 1], u_post[:, 0]]
    tile, ncol, step, origin = raster_tiles(post_c, centre, v1.E0 * v1.R_GEL)
    order = np.unique(tile)
    rank = {t: i for i, t in enumerate(order)}
    tile_rank = np.array([rank[t] for t in tile])
    t_acq = tile_rank * T_TILE
    total = (order.size - 1) * T_TILE
    s_acq = drift_s(t_acq, total, drift_amp) if drift_amp else np.ones(n_fibrils)

    e_macro = v1.E0 * (1 + rng.normal(0, 0.005))
    pre_objs, post_objs, fib_truth = [], [], {}
    pre_ids, post_ids = _ids(rng, n_fibrils, "p"), _ids(rng, n_fibrils, "q")
    sig_pre_true = v1.FWHM_PRE / v1.S2F
    sig_post_true = v1.FWHM_POST / v1.S2F
    for i in range(n_fibrils):
        # fragment: whole sarcomeres between two Z-discs, plus 0-1 sarcomere of broken material at each end
        a0, a1 = rng.uniform(0, 1, 2) * sl[i]
        n_s = max(int((length[i] - a0 - a1) / sl[i]), 1)
        seq = sl[i] * (1 + 0.03 * rng.normal(size=n_s))
        z, lo, hi = _ladder(seq, a0, a1)
        mid_true = 0.5 * (lo + hi)                    # fragment midpoint, in fragment coordinates (pre µm)
        frag_len = hi - lo
        # pre object
        e_along, e_across = rng.normal(0, 0.15), rng.normal(0, 0.05)
        cen_pre = c[i] + u[i] * e_along + v[i] * e_across
        ang_pre = (phi[i] + rng.normal(0, math.radians(1.0))) % np.pi
        len_pre = max(frag_len + rng.normal(0, 0.3), 2.0)
        n_pre = max(int(len_pre / PX) | 1, 9)
        sgn_pre = 1.0 if u[i] @ np.array([math.cos(ang_pre), math.sin(ang_pre)]) >= 0 else -1.0
        xq = mid_true + e_along + sgn_pre * _centred(n_pre, PX)
        ax_pre = pre_axial(rng, xq, z, seq, lo, hi, m_pre, photons_pre, rng.uniform(0, 1))
        n_rows = max(int(length[i] / PX), 1)
        xc = _centred(27, PX)
        if pre_mode == "pol":
            clean = v1.pre_width_model(xc, width[i], 0.5 / max(asp[i] * width[i], 1e-9) ** 2, 0.0, 0.05,
                                       sig_pre_true, asp[i], "pol", shape_n[i])
            cross_pre = rng.poisson(clean * photons_pre * n_rows) / (photons_pre * n_rows)
        else:
            clean = v1.pre_width_model(xc, width[i], 0.08 / max(asp[i] * width[i], 1e-9), 0.0, 0.0,
                                       sig_pre_true, asp[i], "dpc", shape_n[i])
            cross_pre = clean + rng.normal(0, 1 / math.sqrt(photons_pre * n_rows), xc.size)
        pre_objs.append({"id": pre_ids[i], "x": float(cen_pre[0]), "y": float(cen_pre[1]), "angle": float(ang_pre),
                         "length": float(len_pre), "axial": np.round(ax_pre, 3).tolist(),
                         "cross": np.round(cross_pre, 6).tolist(), "cross_rows": int(n_rows)})
        # post object (at its acquisition time: drift scales lengths and positions about the gel centre)
        sa = s_acq[i]
        e_i = e_ax[i] * sa
        w_post = width[i] * e_tr[i] * sa
        p_along, p_across = rng.normal(0, 0.30), rng.normal(0, 0.10)
        cen_post = centre + sa * (post_c[i] - centre) + u_post[i] * p_along + v_post[i] * p_across
        ang_post_true = math.atan2(u_post[i, 1], u_post[i, 0]) % np.pi
        ang_post = (ang_post_true + rng.normal(0, math.radians(1.0))) % np.pi
        len_post = max(frag_len * e_i + rng.normal(0, 0.6), 4.0)
        n_post = max(int(len_post / PX) | 1, 9)
        dvec = np.array([math.cos(ang_post), math.sin(ang_post)])
        sgn = 1.0 if u_post[i] @ dvec >= 0 else -1.0   # schema: sample 0 at the end with the smaller projection
        xq_post = mid_true * e_i + p_along + sgn * _centred(n_post, PX)
        ax_post = post_axial(rng, xq_post, z, seq, lo, hi, e_i, photons_post)
        rows_post = int(n_rows * e_i)
        xpc = _centred(2 * int((w_post / 2 + 4.0) / PX) + 1, PX)
        t_exp = asp[i] * w_post
        a2 = max(t_exp / v1.DOF_UM - 1.0, 0.0)
        clean = v1.post_width_model(xpc, w_post, 1.0, a2, 0.0, 0.1, sig_post_true, asp[i], n=shape_n[i])
        sc_p = photons_post / clean.max() * rows_post
        cross_post = rng.poisson(clean * sc_p) / sc_p
        xz = _centred(2 * int((w_post / 2 + 3.0) / PX) + 1, PX)
        dxf = 0.02
        xf = np.arange(xz.min() - 2.0, xz.max() + 2.0, dxf)
        cz = 0.05 + (1.0 / w_post) * np.interp(xz, xf, v1._gauss_blur(v1._ellipse_chord(xf, w_post, 1.0, shape_n[i]),
                                                                      dxf, sig_post_true))
        sc_z = photons_post / cz.max() * rows_post * 10
        zsum = rng.poisson(cz * sc_z) / sc_z
        post_objs.append({"id": post_ids[i], "x": float(cen_post[0]), "y": float(cen_post[1]),
                          "angle": float(ang_post), "length": float(len_post),
                          "axial": np.round(ax_post, 3).tolist(), "cross": np.round(cross_post, 6).tolist(),
                          "cross_rows": rows_post, "zsum_cross": np.round(zsum, 6).tolist(), "zsum_rows": rows_post,
                          "zsum_planes": 10, "aspect": float(asp[i] * (1 + rng.normal(0, 0.03))),
                          "tile": int(tile_rank[i]), "t": float(t_acq[i])})
        fib_truth[pre_ids[i]] = {"E_ax": float(e_ax[i]), "E_tr": float(e_tr[i]), "E_ax_acq": float(e_i),
                                 "E_gel_ax": float(e_gel_ax[i]), "E_gel_tr": float(e_gel_tr[i]),
                                 "x": float(c[i, 0]), "y": float(c[i, 1]), "phi": float(phi[i]),
                                 "n_sarc": int(n_s), "length": float(frag_len), "post": post_ids[i]}
    clock = []
    if drift_amp:
        # clock tile: one tile near the gel centre, re-imaged every CLOCK_EVERY tiles. A real tile holds hundreds of
        # Z-discs (and beads, if the gel carries them); 40 localised features stand in for them here.
        fx = centre + rng.uniform(-0.5, 0.5, (40, 2)) * np.array(FOV) * (1 - OVERLAP)
        for k in range(0, order.size, CLOCK_EVERY):
            tk = k * T_TILE
            sk = drift_s(tk, total, drift_amp)
            pts = centre + sk * (fx - centre) + rng.normal(0, 0.10, fx.shape)
            clock.append({"t": float(tk), "objects": [{"x": float(a), "y": float(b)} for a, b in pts]})
    perm_pre, perm_post = rng.permutation(n_fibrils), rng.permutation(n_fibrils)
    obs = {"schema": "swell-obs/1", "gel_id": sc.name,
           "meta": {"e_macro": float(e_macro), "px_pre_um": PX, "px_post_um": PX, "psf_pre_fwhm_um": v1.FWHM_PRE,
                    "psf_post_fwhm_um": v1.FWHM_POST, "dof_post_um": v1.DOF_UM, "pre_mode": pre_mode,
                    "gel_center_post_um": [float(centre[0]), float(centre[1])], "gel_radius_pre_um": v1.R_GEL,
                    "mirror_possible": True, "generator": "software/sim/gen_dev.py (development gel)"},
           "pre": [pre_objs[i] for i in perm_pre], "post": [post_objs[i] for i in perm_post], "clock": clock}
    truth = {"schema": "swell-truth/1", "gel_id": sc.name, "pairs": {pre_ids[i]: post_ids[i] for i in range(n_fibrils)},
             "debris": [], "fibrils": fib_truth, "defects": [], "anisotropy_true": float(np.median(e_ax / e_tr) - 1),
             "drift_amp": drift_amp, "notes": sc.label}
    return obs, truth
