"""SWELL pre-image v1 (Life 5): how much label-free contrast the axial ruler needs, and which pre-image mode gives it.

Fresh AI review (2026-10-09; another Claude instance, not a person), item b: the axial ruler (R21) is load-bearing and its precision depends on the
pre-image's striation contrast, which v1 simply assumed (5-50%). This script:
 1. measures the per-myofibril E_ax error of the v2 ladder against q = m·√N (m: fundamental striation modulation
    of the flattened pre profile; N: detected photo-electrons per 0.194 µm sample along the fibril, summed
    across its width) for 8-20 sarcomeres, and sets the go/no-go q;
 2. shows the illumination-slope failure of v1 (mean removal only) and the v2 fix (flat-field + slope term);
 3. works out m and N for each pre-image mode with the specified parts, from sarcomere structure:
    crossed linear polarisers (A-band birefringence, film extinction, depolarisation at NA, sin²2φ),
    circular polarisers, DPC with 2 or 4 oblique LEDs, and a fluorescent pre-label;
 4. chooses a mode.
Inputs marked ASSUMPTION are not verified against a primary source; the go/no-go is what P1 measures on day 1.

Run:  .venv/Scripts/python.exe software/sim/preimage_v1.py   ->  docs/design/preimage_v1.md + .json + figs/preimage_q.png
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ROOT / "software" / "swell_ruler"))
import gen_dev  # noqa: E402
import strain_map_sim as v1  # noqa: E402
from swell_ruler import profiles as pr  # noqa: E402

PX = v1.PX
LAM = 0.52            # µm, green LED for the pre-image (DPC and polarisers)
NA_OBJ = 0.65         # Motic PL 40X/0.65 (D-29)
WIDTH_PX = 5          # a 1.0-1.2 µm myofibril spans ~5 pixels of 0.194 µm: the samples summed across its width
HALF_WELL = 5000.0    # e-, IMX296 at gain 1 (full well 10,000 e-, F-23 unverified)

# Sarcomere structure (pre-expansion). Sources: thick filament 1.6 µm (vertebrate; F-17 open for chicken),
# supermarket breast SL 1.69 µm and wooden breast 1.91 µm (laser diffraction, D-4/W-12), Z-disc 30-140 nm (F-11).
STRUCT = {"thick_um": 1.60, "thin_um": 1.00, "z_um": 0.06,          # thin filament length: ASSUMPTION (0.95-1.10)
          "protein_g_ml": 0.15,                                      # myofibril protein (design_calc assumption)
          "f_myosin": 0.45, "f_actin": 0.22, "f_alpha_actinin": 0.02,  # mass fractions: ASSUMPTION (textbook ranges)
          "dn_dc_ml_g": 0.185}                                       # refractive increment of protein (standard)
BIREF = {"dn_A": 2.0e-3, "dn_thin": 0.3e-3}                         # ASSUMPTION: A band ~1e-3 order (Colby 1971 not read)
FILM_EXT = {"cheap film (measured often ~300:1)": 1 / 300, "good film (spec 8,000:1)": 1 / 8000}
EPS_NA_REF = (1e-3, 1.25)   # ASSUMPTION: ~1e-3 leakage at NA 1.25 without rectifiers, scaling as NA^4 (Inoué)


# ------------------------------------------------------------------------------------------------ 1. precision vs q
def precision_grid(ms=(0.005, 0.01, 0.02, 0.03, 0.05, 0.1, 0.15), ns=(1000.0, 5000.0, 25000.0, 100000.0),
                   n_sarcs=(8, 10, 15, 20), trials=160, seed=21):
    rng = np.random.default_rng(seed)
    rows = []
    for n_s in n_sarcs:
        for m in ms:
            for n_ph in ns:
                errs = []
                for _ in range(trials):
                    errs.append(one_fibril(rng, n_s, m, n_ph))
                errs = np.array(errs)
                ok = np.isfinite(errs)
                rows.append({"n_sarc": n_s, "m": m, "N": n_ph, "q": m * math.sqrt(n_ph),
                             "rms": float(np.sqrt(np.mean(errs[ok] ** 2))) if ok.any() else None,
                             "measured_fraction": float(ok.mean()),
                             "beyond_2pct": float(np.mean(np.abs(errs[ok]) > 0.02)) if ok.any() else None})
    return rows


def one_fibril(rng, n_s, m, n_ph, slope=0.0, estimator="v2"):
    sl = rng.normal(1.69, 0.08)
    e = 4.5 * (1 + rng.normal(0, 0.01))
    seq = sl * (1 + 0.03 * rng.normal(size=n_s + 2))
    a0, a1 = rng.uniform(0.3, 1, 2) * sl                 # whole sarcomeres n_s+2 plus broken ends: n_s usable
    z, lo, hi = gen_dev._ladder(seq, a0, a1)
    mid = 0.5 * (lo + hi)
    L = hi - lo
    e_al = rng.normal(0, 0.15)
    n_pre = max(int((L + rng.normal(0, 0.3)) / PX) | 1, 9)
    xq = mid + e_al + gen_dev._centred(n_pre, PX)
    ypre = gen_dev.pre_axial(rng, xq, z, seq, lo, hi, m, n_ph, rng.uniform(0, 1), slope=slope)
    n_post = max(int((L * e + rng.normal(0, 0.6)) / PX) | 1, 9)
    xqp = mid * e + rng.normal(0, 0.3) + gen_dev._centred(n_post, PX)
    ypost = gen_dev.post_axial(rng, xqp, z, seq, lo, hi, e, 400.0)
    ec = 4.5 * (1 + rng.normal(0, 0.005))
    if estimator == "v1":
        c0 = a0 + 2.0
        est, _ = v1.period_ratio_ladder(xq + c0, ypre, xqp + e * c0, ypost, ec)
    else:
        est = pr.axial_factor(pr.centred_axis(ypre.size, PX), ypre, pr.centred_axis(ypost.size, PX), ypost, ec)["E"]
    return est / e - 1


def q_threshold(rows, n_s, target):
    """Smallest q where the RMS error falls to `target` (log-log interpolation over the pooled curve)."""
    pts = sorted((r["q"], r["rms"]) for r in rows if r["n_sarc"] == n_s and r["rms"] is not None)
    qs = np.array([p[0] for p in pts])
    rm = np.array([p[1] for p in pts])
    # pooled curve: median RMS per q value (different m, N with the same q)
    uq = np.unique(np.round(qs, 3))
    med = np.array([np.median(rm[np.isclose(np.round(qs, 3), u)]) for u in uq])
    for i in range(1, uq.size):
        if med[i - 1] > target >= med[i]:
            f = (math.log(target) - math.log(med[i - 1])) / (math.log(med[i]) - math.log(med[i - 1]))
            return float(math.exp(math.log(uq[i - 1]) + f * (math.log(uq[i]) - math.log(uq[i - 1]))))
    return None


def slope_demo(trials=300, seed=5):
    rng = np.random.default_rng(seed)
    out = {}
    for slope in (0.0, 0.2, 0.4):
        for est in ("v1", "v2"):
            errs = np.array([one_fibril(rng, 10, 0.05, 5000.0, slope=slope, estimator=est) for _ in range(trials)])
            ok = np.isfinite(errs)
            out[f"slope {int(100 * slope)}% | {est}"] = float(np.sqrt(np.mean(errs[ok] ** 2)))
    return out


# ------------------------------------------------------------------------------------------------ 3. physics
def sarcomere_profiles(sl, s=STRUCT, b=BIREF, dx=0.002):
    """Protein density (g/mL) and birefringence along one sarcomere (Z-disc at 0 and sl), filament overlap model."""
    x = np.arange(0, sl, dx)
    centre = sl / 2
    thick = np.abs(x - centre) <= s["thick_um"] / 2
    d_left, d_right = x, sl - x                         # distance from each Z-disc
    n_thin = (d_left <= s["thin_um"]).astype(float) + (d_right <= s["thin_um"]).astype(float)
    zdisc = (d_left <= s["z_um"] / 2) | (d_right <= s["z_um"] / 2)
    rho0 = s["protein_g_ml"]
    other = rho0 * (1 - s["f_myosin"] - s["f_actin"] - s["f_alpha_actinin"])
    myo = rho0 * s["f_myosin"] * sl / s["thick_um"]
    act = rho0 * s["f_actin"] * sl / (2 * s["thin_um"])
    aa = rho0 * s["f_alpha_actinin"] * sl / s["z_um"]
    rho = other + myo * thick + act * n_thin + aa * zdisc
    dn = b["dn_A"] * thick + b["dn_thin"] * np.minimum(n_thin, 1) * ~thick
    return x, rho, dn


def fundamental(x, y, period):
    c = np.mean(y * np.cos(2 * np.pi * x / period))
    s_ = np.mean(y * np.sin(2 * np.pi * x / period))
    return 2 * math.hypot(c, s_), float(np.mean(y))


def coherent_filter(y, dx, cutoff):
    f = np.fft.rfftfreq(y.size, dx)
    return np.fft.irfft(np.fft.rfft(y) * (f <= cutoff), y.size)


def periodic(xs, ys, sl, reps=8):
    """Tile one sarcomere into a periodic profile so Fourier filtering has no edge effects."""
    x = np.concatenate([xs + k * sl for k in range(reps)])
    return x, np.tile(ys, reps)


def mtf_incoherent(u, na=NA_OBJ, lam=LAM):
    v = u / (2 * na / lam)
    return float((2 / np.pi) * (np.arccos(v) - v * np.sqrt(1 - v * v))) if v < 1 else 0.0


def physics(sl, path_um):
    x, rho, dn = sarcomere_profiles(sl)
    dx = x[1] - x[0]
    out = {"sl_um": sl, "path_um": path_um}
    # density: DPC phase and fluorescent pan-label
    r1, r0 = fundamental(x, rho, sl)
    out["density_fundamental_g_ml"] = r1
    out["density_mean_g_ml"] = r0
    phi1 = 2 * np.pi * STRUCT["dn_dc_ml_g"] * r1 * path_um / LAM
    out["phase_fundamental_rad"] = phi1
    # pan-protein fluorescent pre-label (incoherent): m = ρ1/ρ0 × MTF at the striation frequency
    out["m_fluor_pan"] = r1 / r0 * mtf_incoherent(1 / sl)
    # Z-disc label (e.g. an α-actinin label): narrow lines, m ≈ 2 × MTF
    out["m_fluor_zdisc"] = 2 * mtf_incoherent(1 / sl)
    # crossed linear polarisers: amplitude ∝ sin(πΓ/λ) sin2φ, coherent imaging (low-NA illumination), I = |a|² + ε
    xp, dnp = periodic(x, dn, sl)
    gam = dnp * path_um                                       # retardance, µm
    amp = np.sin(np.pi * gam / LAM)
    a_f = coherent_filter(amp, dx, NA_OBJ / LAM)
    out["pol_A_band_retardance_nm"] = float(1e3 * BIREF["dn_A"] * path_um)
    out["pol_signal_peak"] = float(np.max(a_f ** 2))          # at sin²2φ = 1, as a fraction of parallel-polariser light
    pol = {}
    for film, eps_f in FILM_EXT.items():
        for na_ill in (0.25, 0.55):
            eps = eps_f + EPS_NA_REF[0] * (na_ill / EPS_NA_REF[1]) ** 4
            for s2 in (1.0, 0.5, 0.1):
                inten = s2 * a_f ** 2 + eps
                m1, mean = fundamental(xp, inten, sl)
                pol[f"{film} | NA_ill {na_ill} | sin²2φ {s2}"] = {"m": m1 / mean, "T": mean, "eps": eps}
    out["pol"] = pol
    # circular polarisers: no sin²2φ loss; leakage from the λ/4 films' retardance error at the LED wavelength
    for film, eps_f in FILM_EXT.items():
        err_waves = 0.25 * (560 / 520) - 0.25                # λ/4 film designed for 560 nm, used at 520 nm (ASSUMPTION)
        eps = eps_f + math.sin(math.pi * err_waves) ** 2 * 2 + EPS_NA_REF[0] * (0.25 / EPS_NA_REF[1]) ** 4
        inten = a_f ** 2 + eps                               # circular: full signal at every orientation
        m1, mean = fundamental(xp, inten, sl)
        out.setdefault("circ", {})[film] = {"m": m1 / mean, "T": mean, "eps": eps}
    return out


def pol_amplitude2(sl, path_um):
    """|coherently filtered polariser amplitude|² along the periodic sarcomere at sin²2φ = 1."""
    x, rho, dn = sarcomere_profiles(sl)
    dx = x[1] - x[0]
    xp, dnp = periodic(x, dn, sl)
    a_f = coherent_filter(np.sin(np.pi * dnp * path_um / LAM), dx, NA_OBJ / LAM)
    return xp, a_f ** 2, sl


def pol_m_T(amp2, s2, eps):
    xp, a2, sl = amp2
    inten = s2 * a2 + eps
    m1, mean = fundamental(xp, inten, sl)
    return m1 / mean, mean


def dpc_orientation(sigma, sl, n_axes):
    """Fraction of fibril orientations with full phase transfer (point-LED model): exactly one sideband of the
    striation frequency inside the pupil. With 2 LEDs one axis; with 4 LEDs the better of two orthogonal axes."""
    uc = NA_OBJ / LAM
    us, u = sigma * uc, 1 / sl
    al = np.linspace(0, np.pi / 2, 2001)

    def ok(a):
        plus = us ** 2 + u ** 2 + 2 * us * u * np.cos(a)
        minus = us ** 2 + u ** 2 - 2 * us * u * np.cos(a)
        return ((plus > uc ** 2) & (minus < uc ** 2)) | ((plus < uc ** 2) & (minus > uc ** 2))
    good = ok(al) if n_axes == 1 else (ok(al) | ok(np.pi / 2 - al))
    return float(good.mean())


def photons(mode, t_frame_ms, frames, pol_T=None):
    """Detected e- per sample along the fibril (summed across its width), per pre-image.
    Brightfield reaches half-well in about 1 ms with the transmitted LED (ASSUMPTION); polariser films pass 35% of
    the light between parallel polarisers (ASSUMPTION), and a pre-image frame is capped at 1 s."""
    if mode == "dpc":
        return HALF_WELL * WIDTH_PX * 2 * frames                       # two half-well images per frame pair
    full = HALF_WELL * (t_frame_ms / 1.0) * 0.35 * pol_T              # e- per pixel per frame
    return min(full, HALF_WELL) * WIDTH_PX * frames


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    out = {"inputs": {"structure": STRUCT, "birefringence": BIREF, "film_extinction": FILM_EXT, "lambda_um": LAM,
                      "na_obj": NA_OBJ, "width_px": WIDTH_PX, "half_well_e": HALF_WELL}}
    rows = precision_grid()
    out["precision_grid"] = rows
    out["q_go"] = {f"{n}": {"rms_1pct": q_threshold(rows, n, 0.01), "rms_0.5pct": q_threshold(rows, n, 0.005)}
                   for n in (8, 10, 15, 20)}
    out["slope_demo"] = slope_demo()
    out["physics"] = {f"SL {sl}": {f"{d} µm path": physics(sl, d) for d in (0.6, 0.94, 1.6)} for sl in (1.69, 1.91)}
    out["dpc_orientation"] = {f"sigma {s}": {"2 LEDs": dpc_orientation(s, 1.69, 1), "4 LEDs": dpc_orientation(s, 1.69, 2)}
                              for s in (0.5, 0.7, 0.85, 0.95)}
    q_go = out["q_go"]["10"]["rms_1pct"]
    # q per mode at SL 1.69, typical myofibril (1.2 µm wide: mean path 0.94 µm), with practical acquisitions.
    # "covered" = fraction of fibril orientations (uniform) whose q reaches the go threshold.
    ph = out["physics"]["SL 1.69"]["0.94 µm path"]
    q_dpc = ph["phase_fundamental_rad"] * math.sqrt(photons("dpc", None, 4))
    modes = {}
    for leds, key in ((4, "4 LEDs"), (2, "2 LEDs")):
        cov = out["dpc_orientation"]["sigma 0.85"][key] if q_dpc >= (q_go or 0) else 0.0
        modes[f"DPC, {leds} oblique LEDs (σ 0.85), 4 frame pairs"] = {
            "m_best": ph["phase_fundamental_rad"], "N_best": photons("dpc", None, 4), "q_best": q_dpc,
            "covered": cov}
    amp2 = pol_amplitude2(1.69, 0.94)
    phis = np.linspace(0, np.pi / 2, 721)[1:-1]
    for film, eps_f in FILM_EXT.items():
        eps = eps_f + EPS_NA_REF[0] * (0.25 / EPS_NA_REF[1]) ** 4
        qs = []
        for phi in phis:
            m1, t1 = pol_m_T(amp2, np.sin(2 * phi) ** 2, eps)
            qs.append(m1 * math.sqrt(photons("pol", 1000.0, 4, t1)))
        qs = np.array(qs)
        best = int(np.argmax(qs))
        m_b, t_b = pol_m_T(amp2, 1.0, eps)
        modes[f"crossed linear polarisers, {film}, NA_ill 0.25, 4 × 1 s frames"] = {
            "m_best": m_b, "N_best": photons("pol", 1000.0, 4, t_b), "q_best": float(qs[best]),
            "covered": float(np.mean(qs >= (q_go or 0)))}
        for lam4, err in (("generic λ/4 film (560 nm design)", 0.25 * 560 / 520 - 0.25),
                          ("λ/4 matched to the LED (±0.005 wave)", 0.005)):
            eps_c = eps + 2 * math.sin(math.pi * err) ** 2
            m_c, t_c = pol_m_T(amp2, 1.0, eps_c)
            q_c = m_c * math.sqrt(photons("pol", 1000.0, 4, t_c))
            modes[f"circular polarisers, {film}, {lam4}, 4 × 1 s frames"] = {
                "m_best": m_c, "N_best": photons("pol", 1000.0, 4, t_c), "q_best": q_c,
                "covered": 1.0 if q_c >= (q_go or 0) else 0.0}
    modes["fluorescent pan-protein pre-label (pre-gel NHS dye), 1 frame at 2,500 e-/px"] = {
        "m_best": ph["m_fluor_pan"], "N_best": 2500 * WIDTH_PX,
        "q_best": ph["m_fluor_pan"] * math.sqrt(2500 * WIDTH_PX), "covered": 1.0}
    for v in modes.values():
        v["go"] = bool(v["covered"] >= 0.9)
    out["modes"] = modes
    out["decision"] = ("DPC with 4 oblique LEDs at σ ≈ 0.85 (illumination NA ≈ 0.55), green, 4 frame pairs per field; "
                       "fallbacks: circular polarisers with a matched λ/4 pair and good film, then a fluorescent "
                       "pre-label")
    (ROOT / "docs" / "design" / "preimage_v1.json").write_text(json.dumps(out, indent=2, default=float, ensure_ascii=False),
                                                               encoding="utf-8", newline="\n")
    figure(rows, q_go)
    write_report(out)


def figure(rows, q_go):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7.5, 5.0), constrained_layout=True)
    for n_s, col in zip((8, 10, 15, 20), ("#d7301f", "#2c7fb8", "#1a9850", "#6a3d9a")):
        pts = sorted((r["q"], r["rms"]) for r in rows if r["n_sarc"] == n_s and r["rms"] is not None)
        ax.scatter([p[0] for p in pts], [100 * p[1] for p in pts], s=14, color=col, alpha=0.75,
                   label=f"{n_s} sarcomeres")
    ax.axhline(1.0, color="0.3", lw=0.8, ls="--")
    if q_go:
        ax.axvline(q_go, color="0.3", lw=0.8, ls=":")
        ax.text(q_go * 1.05, 6, f"go: q ≥ {q_go:.1f}\n(1% at 10 sarcomeres)", fontsize=8)
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("q = m·√N  (striation modulation × √photons per sample)")
    ax.set_ylabel("per-myofibril E_ax RMS error, %")
    ax.set_title("Axial ruler precision vs pre-image contrast (v2 ladder, synthetic)", fontsize=10)
    ax.legend(fontsize=8, frameon=False)
    fig.savefig(ROOT / "docs" / "design" / "figs" / "preimage_q.png", dpi=110)
    plt.close(fig)
    from simlabel import label_png   # the SIMULATION strip and metadata (A-11)
    label_png(ROOT / "docs" / "design" / "figs" / "preimage_q.png", source="software/sim/preimage_v1.py")


def write_report(out):
    qg = out["q_go"]
    L = ["# SWELL pre-image v1: the contrast the axial ruler needs, and the mode that gives it (synthetic + physics)", "",
         f"**Go/no-go (P1, day 1):** measure q = m·√N on real myofibrils. **Go if the median myofibril with ≥ 10 "
         f"sarcomeres reaches q ≥ {qg['10']['rms_1pct']:.1f}** (1% per-fibril E_ax error); q ≥ "
         f"{qg['10']['rms_0.5pct']:.1f} gives 0.5%. m is the fundamental striation modulation of the flattened pre "
         "profile and N the photo-electrons per 0.194 µm sample along the fibril, summed across its width. The "
         "pipeline reports m (and q, when the profile is in counts) for every myofibril.", "",
         f"**Mode chosen:** {out['decision']}.", "",
         "Generated by `software/sim/preimage_v1.py`. Inputs marked ASSUMPTION in the source are unverified; the "
         "physics ranks the modes and sizes the margins, and the day-1 measurement decides.", "",
         "## 1. Precision vs q (v2 ladder, 160 synthetic myofibrils per point, 3% jitter, broken ends)", "",
         "| sarcomeres | q for 1% | q for 0.5% |", "|---|---|---|"]
    for n, v in qg.items():
        L.append(f"| {n} | {v['rms_1pct']:.2f} | {v['rms_0.5pct']:.2f} |" if v["rms_1pct"] and v["rms_0.5pct"]
                 else f"| {n} | {v['rms_1pct']} | {v['rms_0.5pct']} |")
    L += ["", "Points with the same q but different m and N fall on one curve (figs/preimage_q.png), so q is the "
          "number to measure. The fresh AI review's v1 numbers (m 0.15 → 0.37% … m 0.02 → 1.45% at 5,000 e⁻) sit on "
          "the same curve.", "",
          "## 2. Illumination slope: v1 removed only the mean (m = 0.05, 5,000 e⁻, 10 sarcomeres)", "",
          "| case | RMS error |", "|---|---|"]
    L += [f"| {k} | {100 * v:.2f}% |" for k, v in out["slope_demo"].items()]
    L += ["", "v2 divides each pre profile by its own local mean over 1.5 sarcomeres (which carries no striation) and "
          "fits a constant and a slope with the harmonics.", "",
          "## 3. Physics of each mode (SL 1.69 µm, typical myofibril: mean optical path 0.94 µm)", "",
          "At SL 1.69 µm the thin filaments overlap in the middle of the sarcomere and the I-band is only "
          f"{1.69 - STRUCT['thick_um']:.2f} µm wide, so label-free striation contrast is small in every mode. "
          "Density model: myosin only in the A-band, actin along 1.0 µm thin filaments from each Z-disc (double "
          "density where they overlap), α-actinin in a 60 nm Z-disc, the rest uniform.", ""]
    ph = out["physics"]["SL 1.69"]["0.94 µm path"]
    L += [f"- Density fundamental {ph['density_fundamental_g_ml']:.4f} g/mL on a mean of {ph['density_mean_g_ml']:.3f} g/mL "
          f"→ phase fundamental {1e3 * ph['phase_fundamental_rad']:.1f} mrad (DPC contrast m ≈ φ₁ when exactly one "
          "side-band of the striation frequency passes the pupil).",
          f"- A-band retardance {ph['pol_A_band_retardance_nm']:.2f} nm; peak crossed-polariser signal "
          f"{ph['pol_signal_peak']:.1e} of the parallel-polariser light, against film leakage of 1/300 to 1/8,000.",
          f"- Fluorescent pan-protein pre-label: m ≈ {100 * ph['m_fluor_pan']:.1f}%; a Z-disc label: m ≈ "
          f"{100 * ph['m_fluor_zdisc']:.0f}%.", "",
          "| mode (practical acquisition per field) | m (best orientation) | N per sample | q (best) | orientations reaching the go q | go? (≥ 90% covered) |",
          "|---|---|---|---|---|---|"]
    for k, v in out["modes"].items():
        L.append(f"| {k} | {100 * v['m_best']:.2f}% | {v['N_best']:,.0f} | {v['q_best']:.2f} | "
                 f"{100 * v['covered']:.0f}% | {'GO' if v['go'] else 'no'} |")
    L += ["", "DPC orientation coverage (point-LED model, SL 1.69 µm):", "",
          "| σ (illumination NA ÷ 0.65) | 2 LEDs | 4 LEDs |", "|---|---|---|"]
    for k, v in out["dpc_orientation"].items():
        L.append(f"| {k.split()[1]} | {100 * v['2 LEDs']:.0f}% | {100 * v['4 LEDs']:.0f}% |")
    L += ["", "## 4. Decision (D-46)", "",
          "- **Primary: DPC with 4 oblique green LEDs at σ ≈ 0.85** (BOM H-14 already carries the 4-quadrant LEDs). "
          "Photons are cheap in brightfield, so averaging 4 frame pairs buys q; 4 LEDs cover every orientation.",
          "- **Crossed linear polarisers come second:** the sin²2φ factor blanks fibrils near 0° and 90°, and with "
          "cheap film the leakage swamps a ~10⁻⁴ signal. Good film at low illumination NA passes for most "
          "orientations (table), so the film pair stays as a cross-check, not the ruler.",
          "- **Fallback 1: circular polarisers** (no orientation loss) only work with good film and a λ/4 pair matched "
          "to the LED wavelength: a generic 560 nm film used at 520 nm leaks too much (table).",
          "- **Fallback 2: a fluorescent pre-label** (pan-protein NHS dye before gelation, or a Z-disc label): "
          "contrast is high but it adds chemistry and must survive gelation.",
          "- **Day 1 of P1:** image supermarket myofibrils in all three label-free modes, compute q per fibril with "
          "the pipeline, and apply the go/no-go above. Also measure the pre-image PSF with beads (±2%, D-32)."]
    (ROOT / "docs" / "design" / "preimage_v1.md").write_text("\n".join(L) + "\n", encoding="utf-8", newline="\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
