# SWELL isolated environment (bash). Source it: `source tools/env.sh`
# Everything lives under D:/SWELL/.tools and D:/SWELL/.venv. Nothing global is changed:
# PATH is prepended for this shell only, and no installer touches the registry or system PATH.
export SWELL_ROOT="/d/SWELL"
export SWELL_TOOLS="$SWELL_ROOT/.tools"
export UV_CACHE_DIR="D:/SWELL/.tools/uv-cache"
export UV_PYTHON_INSTALL_DIR="D:/SWELL/.tools/python"
export UV_PYTHON_PREFERENCE="only-managed"
export UV_TOOL_DIR="D:/SWELL/.tools/uv-tools"
export UV_LINK_MODE="copy"
export MPLCONFIGDIR="D:/SWELL/.tools/cfg/matplotlib"
export NUMBA_CACHE_DIR="D:/SWELL/.tools/cfg/numba"
export NAPARI_CONFIG="D:/SWELL/.tools/cfg/napari/settings.yaml"
export PIP_DISABLE_PIP_VERSION_CHECK=1
export PYTHONUTF8=1
export PATH="$SWELL_TOOLS/uv:$SWELL_ROOT/.venv/Scripts:$SWELL_TOOLS/pandoc:$SWELL_TOOLS/typst:$SWELL_TOOLS/graphviz/bin:$SWELL_TOOLS/openscad:$SWELL_TOOLS/prusaslicer:$PATH"
# FreeCAD keeps its user config inside the project, not in %APPDATA%
export FREECAD_USER_HOME="D:/SWELL/.tools/cfg/freecad"
export FREECAD_USER_DATA="D:/SWELL/.tools/cfg/freecad/data"
export FREECAD_USER_TEMP="D:/SWELL/.tools/cfg/freecad/tmp"
