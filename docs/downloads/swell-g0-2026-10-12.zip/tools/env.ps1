# SWELL isolated environment (PowerShell). Dot-source it: `. .\tools\env.ps1`
# Session-only: nothing here writes the registry, the user PATH or the system PATH.
$env:SWELL_ROOT = "D:\SWELL"
$env:SWELL_TOOLS = "D:\SWELL\.tools"
$env:UV_CACHE_DIR = "D:\SWELL\.tools\uv-cache"
$env:UV_PYTHON_INSTALL_DIR = "D:\SWELL\.tools\python"
$env:UV_PYTHON_PREFERENCE = "only-managed"
$env:UV_TOOL_DIR = "D:\SWELL\.tools\uv-tools"
$env:UV_LINK_MODE = "copy"
$env:MPLCONFIGDIR = "D:\SWELL\.tools\cfg\matplotlib"
$env:NUMBA_CACHE_DIR = "D:\SWELL\.tools\cfg\numba"
$env:NAPARI_CONFIG = "D:\SWELL\.tools\cfg\napari\settings.yaml"
$env:PIP_DISABLE_PIP_VERSION_CHECK = "1"
$env:PYTHONUTF8 = "1"
$t = $env:SWELL_TOOLS
$env:PATH = "$t\uv;D:\SWELL\.venv\Scripts;$t\pandoc;$t\typst;$t\graphviz\bin;$t\openscad;$t\prusaslicer;" + $env:PATH
# FreeCAD keeps its user config inside the project, not in %APPDATA%
$env:FREECAD_USER_HOME = "D:\SWELL\.tools\cfg\freecad"
$env:FREECAD_USER_DATA = "D:\SWELL\.tools\cfg\freecad\data"
$env:FREECAD_USER_TEMP = "D:\SWELL\.tools\cfg\freecad\tmp"
