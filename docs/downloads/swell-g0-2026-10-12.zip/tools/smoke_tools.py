"""SWELL toolchain smoke test: proves each tool works by doing real work, and that the run leaves no trace.

Run inside the project env:  source tools/env.sh && python tools/smoke_tools.py
Writes .tools/smoke_report.json and prints a table. Each check is labelled:
  work         - the tool did a real job (registered, rendered, sliced, resolved, compiled...) and the result was checked
  import-only  - only importable here, and the reason is stated (e.g. no device attached until P1)
After the run it checks for leaks (INV-17): new folders in %APPDATA% / %LOCALAPPDATA% / home dotfiles, and new
HKCU\\Software\\JavaSoft keys (Java apps keep preferences in the registry on Windows). Java keys created by the run
are removed. Exit code 0 only if every check passes and nothing leaked.
"""
from __future__ import annotations

import importlib.metadata as md
import json
import os
import subprocess
import sys
import tempfile
import time
import traceback
import winreg
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
T = ROOT / ".tools"
TMP = Path(tempfile.mkdtemp(prefix="swell_smoke_"))
CHECKS: list[tuple[str, str, object]] = []


def check(name: str, kind: str = "work"):
    def deco(fn):
        CHECKS.append((name, kind, fn))
        return fn
    return deco


def ver(pkg: str) -> str:
    return md.version(pkg)


def run(cmd: list[str], timeout: int = 300) -> str:
    out = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if out.returncode != 0:
        raise RuntimeError(f"exit {out.returncode}: {(out.stderr or out.stdout).strip()[-300:]}")
    txt = (out.stdout or out.stderr).strip()
    return txt.splitlines()[0] if txt else "ok"


# ---------------------------------------------------------------- leak guards
JAVA = r"Software\JavaSoft"


def java_keys() -> set[str]:
    keys: set[str] = set()

    def walk(path):
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, path) as k:
                keys.add(path)
                for i in range(winreg.QueryInfoKey(k)[0]):
                    walk(path + "\\" + winreg.EnumKey(k, i))
        except FileNotFoundError:
            pass
    walk(JAVA)
    return keys


def remove_new_java_keys(before: set[str]) -> list[str]:
    new = sorted(java_keys() - before, key=lambda p: p.count("\\"), reverse=True)
    for p in new:
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, p)
        except OSError:
            pass
    return new


def user_dirs() -> set[str]:
    home = Path.home()
    out: set[str] = set()
    for base in (home / "AppData" / "Roaming", home / "AppData" / "Local", home):
        try:
            out |= {str(p) for p in base.iterdir() if p.is_dir()}
        except OSError:
            pass
    return out


# ---------------------------------------------------------------- checks
@check("python + numpy/scipy")
def _():
    import numpy as np
    from scipy import ndimage
    a = ndimage.gaussian_filter(np.random.default_rng(0).random((64, 64)), 2)
    assert a.shape == (64, 64)
    return f"python {sys.version.split()[0]}, numpy {np.__version__}, scipy {ver('scipy')}"


@check("scikit-image phase correlation (registration)")
def _():
    import numpy as np
    from skimage.registration import phase_cross_correlation
    img = np.random.default_rng(1).random((128, 128))
    shift, _, _ = phase_cross_correlation(img, np.roll(img, (5, -3), axis=(0, 1)))
    assert tuple(np.round(shift).astype(int)) == (-5, 3), shift
    return f"scikit-image {ver('scikit-image')}: recovered shift {shift.tolist()}"


def _blobs():
    import numpy as np
    yy, xx = np.mgrid[0:96, 0:96]
    f = np.exp(-((xx - 48) ** 2 + (yy - 40) ** 2) / 200.0).astype(np.float32)
    m = np.exp(-((xx - 51) ** 2 + (yy - 43) ** 2) / 200.0).astype(np.float32)
    return f, m


@check("SimpleITK translation registration")
def _():
    import SimpleITK as sitk
    f, m = _blobs()
    reg = sitk.ImageRegistrationMethod()
    reg.SetMetricAsMeanSquares()
    reg.SetOptimizerAsRegularStepGradientDescent(1.0, 1e-4, 200)
    reg.SetInitialTransform(sitk.TranslationTransform(2))
    reg.SetInterpolator(sitk.sitkLinear)
    p = reg.Execute(sitk.GetImageFromArray(f), sitk.GetImageFromArray(m)).GetParameters()
    assert abs(p[0] - 3) < 0.3 and abs(p[1] - 3) < 0.3, p
    return f"SimpleITK {sitk.Version_VersionString()}: translation {tuple(round(v, 2) for v in p)} (truth 3, 3)"


@check("itk-elastix translation registration")
def _():
    import itk
    f, m = _blobs()
    po = itk.ParameterObject.New()
    po.AddParameterMap(po.GetDefaultParameterMap("translation"))
    po.SetParameter(0, "WriteResultImage", "false")
    _, tp = itk.elastix_registration_method(itk.image_view_from_array(f), itk.image_view_from_array(m),
                                            parameter_object=po, log_to_console=False, output_directory=str(TMP))
    p = [float(v) for v in tp.GetParameter(0, "TransformParameters")]
    assert abs(p[0] - 3) < 0.2 and abs(p[1] - 3) < 0.2, p
    return f"itk-elastix {ver('itk-elastix')}: translation ({p[0]:.2f}, {p[1]:.2f}) (truth 3, 3)"


@check("multiview-stitcher two-tile registration")
def _():
    import numpy as np
    from scipy import ndimage
    from multiview_stitcher import msi_utils, registration, spatial_image_utils as si
    img = ndimage.gaussian_filter(np.random.default_rng(0).random((200, 300)), 3) * 1000
    sa = si.get_sim_from_array(img[:, 0:160], dims=["y", "x"], translation={"y": 0, "x": 0}, transform_key="affine_metadata")
    sb = si.get_sim_from_array(img[:, 120:280], dims=["y", "x"], translation={"y": 0, "x": 125}, transform_key="affine_metadata")
    ma, mb = (msi_utils.get_msim_from_sim(s, scale_factors=[]) for s in (sa, sb))
    registration.register([ma, mb], transform_key="affine_metadata", new_transform_key="registered", reg_channel_index=0)
    corr = float(np.asarray(msi_utils.get_transform_from_msim(mb, "registered")).squeeze()[1, 2])
    assert abs(corr - (-5.0)) < 1.5, corr
    return f"multiview-stitcher {ver('multiview-stitcher')}: 5 px placement error corrected by {corr:.1f} px"


@check("OME-Zarr write + read round trip")
def _():
    import numpy as np
    import zarr
    from ome_zarr.io import parse_url
    from ome_zarr.reader import Reader
    from ome_zarr.writer import write_image
    data = (np.random.default_rng(2).random((3, 64, 64)) * 1000).astype("uint16")
    path = TMP / "t.ome.zarr"
    write_image(data, zarr.group(store=parse_url(str(path), mode="w").store), axes="zyx")
    back = np.asarray(list(Reader(parse_url(str(path)))())[0].data[0])
    assert np.array_equal(back, data)
    return f"ome-zarr {ver('ome-zarr')}, zarr {ver('zarr')}: bit-identical round trip"


@check("tifffile OME-TIFF round trip")
def _():
    import numpy as np
    import tifffile
    data = (np.random.default_rng(1).random((48, 80)) * 1000).astype("uint16")
    tifffile.imwrite(TMP / "t.ome.tif", data, ome=True)
    assert np.array_equal(tifffile.imread(TMP / "t.ome.tif"), data)
    return f"tifffile {ver('tifffile')}"


@check("napari render + screenshot (hidden window)")
def _():
    import numpy as np
    import napari
    v = napari.Viewer(show=False)
    v.add_image(np.random.default_rng(0).random((64, 64)))
    shot = v.screenshot(canvas_only=True, flash=False)
    v.close()
    assert shot.ndim == 3 and shot.mean() > 0
    from qtpy import API_NAME
    return f"napari {ver('napari')} on {API_NAME}: rendered {shot.shape[1]}x{shot.shape[0]} screenshot"


@check("MicroscPSF-Py Gibson-Lanni PSF (dry 0.65 NA into water)")
def _():
    import numpy as np
    import microscPSF.microscPSF as msPSF
    mp = msPSF.m_params.copy()
    mp.update({"NA": 0.65, "ni": 1.0, "ni0": 1.0, "ns": 1.33, "M": 40, "zd0": 160e3})
    psf = msPSF.gLXYZFocalScan(mp, 0.05, 41, np.arange(-4.0, 4.01, 0.25), pz=5.0, wvl=0.55)
    assert np.isfinite(psf).all()
    return f"MicroscPSF-Py {ver('MicroscPSF-Py')}: PSF stack {psf.shape} at 5 µm depth"


@check("pyotf pupil PSF")
def _():
    from pyotf.otf import HanserPSF
    psf = HanserPSF(wl=0.55, na=0.65, ni=1.0, res=0.05, size=64, zsize=16, zres=0.25)
    assert psf.PSFi.shape == (16, 64, 64)
    return f"pyotf {ver('pyotf')}: intensity PSF {psf.PSFi.shape}"


@check("rayoptics paraxial model")
def _():
    from rayoptics.environment import OpticalModel
    opm = OpticalModel()
    opm.radius_mode = True
    sm = opm.seq_model
    sm.gaps[0].thi = 1e10
    sm.add_surface([25.8, 3.0, 1.5168, 64.2])
    sm.add_surface([-25.8, 47.0])
    opm.update_model()
    try:
        efl = opm["analysis_results"]["parax_data"].fod.efl
    except Exception:
        efl = opm.optical_spec.parax_data.fod.efl
    assert 20 < efl < 40, efl
    return f"rayoptics {ver('rayoptics')}: BK7 singlet efl {efl:.2f} mm"


@check("CadQuery solid + STEP/STL export")
def _():
    import cadquery as cq
    part = cq.Workplane("XY").box(20, 20, 5).faces(">Z").hole(6)
    cq.exporters.export(part, str(TMP / "t.step"))
    cq.exporters.export(part, str(TMP / "t.stl"))
    vol = part.val().Volume()
    assert abs(vol - (20 * 20 * 5 - 3.14159 * 9 * 5)) < 1.0, vol
    return f"cadquery {ver('cadquery')}: volume {vol:.1f} mm³"


@check("trimesh + manifold3d interference volume")
def _():
    import trimesh
    a, b = trimesh.creation.box((10, 10, 10)), trimesh.creation.box((10, 10, 10))
    b.apply_translation((8, 0, 0))
    inter = a.intersection(b, engine="manifold")
    assert abs(inter.volume - 200.0) < 1e-6, inter.volume
    return f"trimesh {ver('trimesh')}, manifold3d {ver('manifold3d')}: overlap {inter.volume:.1f} mm³ (exact 200)"


@check("statsmodels mixed-effects model")
def _():
    import numpy as np
    import pandas as pd
    import statsmodels.formula.api as smf
    rng = np.random.default_rng(3)
    prep = np.repeat(np.arange(4), 30)
    y = 4.3 + rng.normal(0, 0.05, 4)[prep] + rng.normal(0, 0.03, prep.size)
    fit = smf.mixedlm("y ~ 1", pd.DataFrame({"y": y, "prep": prep}), groups="prep").fit()
    return f"statsmodels {ver('statsmodels')}: intercept {fit.params['Intercept']:.3f} (truth ~4.3)"


@check("FastAPI hardware-service stack")
def _():
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    app = FastAPI()

    @app.get("/ping")
    def ping():
        return {"ok": True}

    assert TestClient(app).get("/ping").json() == {"ok": True}
    return f"fastapi {ver('fastapi')}, uvicorn {ver('uvicorn')}"


@check("Manubot resolves a DOI to CSL (network)")
def _():
    exe = ROOT / ".venv" / "Scripts" / "manubot.exe"
    out = subprocess.run([str(exe), "cite", "--format=csljson", "doi:10.1126/science.1260088"],
                         capture_output=True, text=True, timeout=120)
    d = json.loads(out.stdout)[0]
    assert d["title"].lower().startswith("expansion microscopy"), d.get("title")
    return f"manubot {ver('manubot')}: '{d['title']}', {d.get('container-title')} {d['issued']['date-parts'][0][0]}"


@check("mpremote (MicroPython device tool)", kind="import-only")
def _():
    import mpremote  # noqa: F401 - no Pico attached until P1, so there is nothing to talk to yet
    return f"mpremote {ver('mpremote')}: import only (no device until P1)"


@check("pandoc markdown -> docx")
def _():
    src = TMP / "t.md"
    src.write_text("# SWELL\n\nA paragraph.\n", encoding="utf-8")
    run([str(T / "pandoc" / "pandoc.exe"), str(src), "-o", str(TMP / "t.docx")])
    assert (TMP / "t.docx").stat().st_size > 1000
    return run([str(T / "pandoc" / "pandoc.exe"), "--version"])


@check("typst PDF compile")
def _():
    src = TMP / "t.typ"
    src.write_text("= SWELL\nA test page with $E = L_\"post\" / L_\"pre\"$.\n", encoding="utf-8")
    exe = next((T / "typst").rglob("typst.exe"))
    run([str(exe), "compile", str(src), str(TMP / "t.pdf")])
    assert (TMP / "t.pdf").stat().st_size > 1000
    return run([str(exe), "--version"])


@check("OpenSCAD STL export")
def _():
    exe = next((T / "openscad").rglob("openscad.com"), None) or next((T / "openscad").rglob("openscad.exe"))
    src = TMP / "t.scad"
    src.write_text("difference(){cube(10,center=true);cylinder(d=4,h=12,center=true,$fn=32);}", encoding="utf-8")
    run([str(exe), "-o", str(TMP / "t_scad.stl"), str(src)])
    assert (TMP / "t_scad.stl").stat().st_size > 1000
    return run([str(exe), "--version"])


@check("PrusaSlicer CLI slice -> G-code")
def _():
    exe = next((T / "prusaslicer").rglob("prusa-slicer-console.exe"))
    out = TMP / "t.gcode"
    run([str(exe), "--export-gcode", "--output", str(out), str(TMP / "t.stl")])
    est = [ln for ln in out.read_text(errors="ignore").splitlines() if "estimated printing time" in ln]
    assert est, "no estimate in G-code"
    return est[0].strip("; ")


@check("Graphviz dot (for WireViz)")
def _():
    exe = next((T / "graphviz").rglob("dot.exe"))
    src = TMP / "t.dot"
    src.write_text("digraph{Pi->Pico->ULN2003->Motor}", encoding="utf-8")
    run([str(exe), "-Tsvg", str(src), "-o", str(TMP / "t.svg")])
    assert (TMP / "t.svg").stat().st_size > 200
    return run([str(exe), "-V"])


@check("Fiji (ImageJ) headless macro")
def _():
    macro = TMP / "t.ijm"
    macro.write_text('newImage("t","16-bit black",64,64,1); print("fiji-ok "+getVersion());', encoding="utf-8")
    out = subprocess.run([str(T / "fiji" / "ImageJ-win64.exe"), "--headless", "--console", "-batch", str(macro)],
                         capture_output=True, text=True, timeout=300)
    hits = [ln for ln in (out.stdout + out.stderr).splitlines() if "fiji-ok" in ln]
    assert hits, (out.stdout + out.stderr)[-300:]
    return hits[0]


@check("QuPath headless script reads an OME-TIFF")
def _():
    script = TMP / "t.groovy"
    script.write_text('def s = getCurrentServer()\nprintln "qupath-ok " + s.getWidth() + "x" + s.getHeight()\n', encoding="utf-8")
    exe = T / "qupath" / "QuPath-0.7.0 (console).exe"
    out = subprocess.run([str(exe), "script", f"--image={TMP / 't.ome.tif'}", str(script)],
                         capture_output=True, text=True, timeout=300)
    hits = [ln for ln in (out.stdout + out.stderr).splitlines() if "qupath-ok" in ln]
    assert hits and "80x48" in hits[0], (out.stdout + out.stderr)[-300:]
    return f"QuPath 0.7.0: {hits[0].strip()}"


@check("FreeCAD headless (FreeCADCmd)")
def _():
    exe = next((T / "freecad").rglob("FreeCADCmd.exe"))
    script = TMP / "t_fc.py"
    script.write_text("import FreeCAD, Part\nb=Part.makeBox(10,10,10)\nprint('fc-ok', FreeCAD.Version()[:3], round(b.Volume))\n",
                      encoding="utf-8")
    out = subprocess.run([str(exe), str(script)], capture_output=True, text=True, timeout=300)
    hits = [ln for ln in (out.stdout + out.stderr).splitlines() if "fc-ok" in ln]
    assert hits, (out.stdout + out.stderr)[-300:]
    return hits[0]


def main() -> int:
    java_before, dirs_before = java_keys(), user_dirs()
    results = []
    for name, kind, fn in CHECKS:
        t0 = time.time()
        try:
            detail, ok = fn(), True
        except Exception as e:  # noqa: BLE001 - report every failure
            detail, ok = f"{type(e).__name__}: {e}", False
            traceback.print_exc()
        results.append({"tool": name, "kind": kind, "ok": ok, "detail": str(detail)[:220],
                        "seconds": round(time.time() - t0, 2)})
    removed = remove_new_java_keys(java_before)
    new_dirs = sorted(user_dirs() - dirs_before)
    width = max(len(r["tool"]) for r in results)
    for r in results:
        print(f"{'PASS' if r['ok'] else 'FAIL'}  {r['kind']:<11}  {r['tool']:<{width}}  {r['detail']}")
    n_ok = sum(r["ok"] for r in results)
    n_work = sum(r["ok"] and r["kind"] == "work" for r in results)
    print(f"\n{n_ok}/{len(results)} passed ({n_work} doing real work, {n_ok - n_work} import-only)")
    print(f"leak check: Java registry keys created and removed: {len(removed)}; new user folders: {new_dirs or 'none'}")
    (T / "smoke_report.json").write_text(json.dumps({"results": results, "java_keys_removed": removed,
                                                     "new_user_dirs": new_dirs}, indent=2), encoding="utf-8")
    return 0 if n_ok == len(results) and not new_dirs else 1


if __name__ == "__main__":
    sys.exit(main())
