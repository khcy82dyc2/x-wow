#!/usr/bin/env bash
# SWELL: reproducible, isolated toolchain installer (Windows + Git Bash).
# - Everything lands in D:/SWELL/.tools (portable apps, uv, Python) and D:/SWELL/.venv (packages).
# - No installer is run, no registry/PATH/global package change is made. Re-running is safe (idempotent).
# - Every download goes to its own empty folder under .tools/dl/<name>/, is SHA256-logged to .tools/manifest.txt,
#   and is checked against the publisher's SHA256 where one is published.
# Usage: bash tools/setup_tools.sh [python|apps|all]   (default: all)
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
source "$HERE/env.sh"
T="$SWELL_TOOLS"
LOG="$T/setup.log"
mkdir -p "$T/dl" "$T/cfg/matplotlib" "$T/cfg/numba" "$T/cfg/napari"
log() { echo "$(date -u +%FT%TZ) $*" | tee -a "$LOG" >&2; }

fetch() { # fetch <name> <url> [sha256-url]  -> prints local file path
  local name="$1" url="$2" shaurl="${3:-}" d f sum exp
  d="$T/dl/$name"; mkdir -p "$d"; f="$d/$(basename "${url%%\?*}")"
  if [ ! -s "$f" ]; then
    curl -L --fail --retry 3 -s -o "$f.part" "$url" && mv "$f.part" "$f" || { log "FAIL download $name $url"; return 1; }
  fi
  sum=$(sha256sum "$f" | cut -d' ' -f1)
  if [ -n "$shaurl" ]; then
    exp=$(curl -sL --fail "$shaurl" | grep -oE '[0-9a-fA-F]{64}' | head -1 | tr 'A-F' 'a-f')
    if [ "$sum" != "$exp" ]; then log "FAIL sha256 $name got=$sum expected=$exp"; rm -f "$f"; return 1; fi
    log "sha256 verified against publisher: $name"
  fi
  grep -q "^$name|" "$T/manifest.txt" 2>/dev/null || echo "$name|$(basename "$f")|$sum|$url" >> "$T/manifest.txt"
  echo "$f"
}

unzip_to() { # unzip_to <zip> <dest>  (flattens a single top-level folder)
  local z="$1" dest="$2" tmp="$2.tmp"
  rm -rf "$tmp"; mkdir -p "$tmp"; unzip -q -o "$z" -d "$tmp" || return 1
  local n; n=$(ls -A "$tmp" | wc -l)
  rm -rf "$dest"
  if [ "$n" = "1" ] && [ -d "$tmp/$(ls -A "$tmp")" ]; then mv "$tmp/$(ls -A "$tmp")" "$dest"; rmdir "$tmp"; else mv "$tmp" "$dest"; fi
}

do_python() {
  if [ ! -x "$T/uv/uv.exe" ]; then
    f=$(fetch uv https://github.com/astral-sh/uv/releases/download/0.12.24/uv-x86_64-pc-windows-msvc.zip \
             https://github.com/astral-sh/uv/releases/download/0.12.24/uv-x86_64-pc-windows-msvc.zip.sha256) || return 1
    unzip_to "$f" "$T/uv" || { log "FAIL unzip uv"; return 1; }
  fi
  log "uv: $("$T/uv/uv.exe" --version)"
  "$T/uv/uv.exe" python install 3.12 >>"$LOG" 2>&1 || { log "FAIL uv python install"; return 1; }
  if [ ! -x "$SWELL_ROOT/.venv/Scripts/python.exe" ]; then
    "$T/uv/uv.exe" venv "$SWELL_ROOT/.venv" --python 3.12 >>"$LOG" 2>&1 || { log "FAIL venv"; return 1; }
  fi
  log "venv python: $("$SWELL_ROOT/.venv/Scripts/python.exe" --version)"
  ( cd "$SWELL_ROOT" && "$T/uv/uv.exe" pip compile software/requirements.in -o software/requirements.lock \
      --python "$SWELL_ROOT/.venv/Scripts/python.exe" --python-platform x86_64-pc-windows-msvc >>"$LOG" 2>&1 ) \
      || { log "FAIL lock (see log)"; return 1; }
  ( cd "$SWELL_ROOT" && "$T/uv/uv.exe" pip sync software/requirements.lock \
      --python "$SWELL_ROOT/.venv/Scripts/python.exe" >>"$LOG" 2>&1 ) || { log "FAIL sync (see log)"; return 1; }
  log "python env OK: $(grep -c '==' "$SWELL_ROOT/software/requirements.lock") pinned packages"
}

app() { # app <name> <url> [sha-url]
  local name="$1" url="$2" sha="${3:-}" f
  if [ -e "$T/$name/.ok" ]; then log "skip $name (present)"; return 0; fi
  f=$(fetch "$name" "$url" "$sha") || return 1
  case "$f" in
    *.zip) unzip_to "$f" "$T/$name" || { log "FAIL unzip $name"; return 1; } ;;
    *.7z)  rm -rf "$T/$name.tmp"; mkdir -p "$T/$name.tmp"
           # FreeCAD's .7z uses the BCJ2 filter, which py7zr cannot read: use the official standalone 7zr.exe
           z7=$(fetch 7zr https://www.7-zip.org/a/7zr.exe) || return 1
           "$z7" x -y -bso0 -bsp0 "-o$T/$name.tmp" "$f" || { log "FAIL 7z $name"; return 1; }
           rm -rf "$T/$name"; inner=$(ls -A "$T/$name.tmp"); if [ "$(echo "$inner" | wc -l)" = "1" ]; then mv "$T/$name.tmp/$inner" "$T/$name"; rmdir "$T/$name.tmp"; else mv "$T/$name.tmp" "$T/$name"; fi ;;
  esac
  touch "$T/$name/.ok"; log "installed $name"
}

do_apps() {
  app pandoc     https://github.com/jgm/pandoc/releases/download/3.12.1/pandoc-3.12.1-windows-x86_64.zip
  app typst      https://github.com/typst/typst/releases/download/v0.15.1/typst-x86_64-pc-windows-msvc.zip
  GV=https://gitlab.com/api/v4/projects/4207231/packages/generic/graphviz-releases/16.1.0/windows_10_cmake_Release_Graphviz-16.1.0-win64.zip
  app graphviz   "$GV" "$GV.sha256"
  app openscad   https://files.openscad.org/snapshots/OpenSCAD-2026.10.05-x86-64.zip
  app prusaslicer https://github.com/prusa3d/PrusaSlicer/releases/download/version_2.9.6/PrusaSlicer-2.9.6.zip
  app qupath     https://github.com/qupath/qupath/releases/download/v0.7.0/QuPath-v0.7.0-Windows.zip
  app fiji       https://downloads.imagej.net/fiji/stable/fiji-stable-win64-jdk.zip
  FC=https://github.com/FreeCAD/FreeCAD/releases/download/1.1.4/FreeCAD_1.1.4-Windows-x86_64-py311.7z
  app freecad    "$FC" "$FC-SHA256.txt"
}

case "${1:-all}" in
  python) do_python ;;
  apps)   do_apps ;;
  all)    do_python; do_apps ;;
esac
log "setup_tools.sh finished (${1:-all})"
