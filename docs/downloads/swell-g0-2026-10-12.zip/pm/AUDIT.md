> **Lab only.** The reagents, amounts and steps in this file are design notes for a laboratory with a fume hood,
> working under its own risk assessments. They are not a method to follow. Each reagent's hazards and handling:
> `SAFETY.md`.

# AUDIT: SWELL kit, Life 1 (2026-10-09)

> **Life 2 note (2026-10-09):** AU-01's 0.2–0.35% ratio error assumed perfectly periodic sarcomeres. With realistic 3% sarcomere-to-sarcomere jitter the free-frequency fit fails, so the estimator is now the Z-disc ladder (D-33): 0.3–0.6% RMS per myofibril in the whole-gel simulation (D-34). AU-10's optics are now specified (D-29), and the D-15 cost targets were tested against a priced BOM (D-30: over; Order 5).

**Scope:** all 14 kit files (00–10 and templates).
**Method:**
- I read each file critically.
- I checked the decision-critical facts against primary or vendor sources (pm/VERIFIED_FACTS.md, F-n).
- I computed every number with `software/sim/design_calc.py` (output in docs/design/calc_v0.md).

**Severity scale:**
- **Critical:** would sink a gate or the paper.
- **High:** costs real money, time or safety margin.
- **Medium:** weakens a result.
- **Low:** tidy-up.

## Verdict
The kit's core bet holds. Chemistry does the resolution: theory gives 91 nm FWHM at 4× (λem 520 nm, NA 0.65; calc §1). Signal looks sufficient: the first pass gives 175–1,750 e⁻ per pixel per 100 ms at 1 W/cm², SNR 12–42 (calc §6).

Five things had to change before any money is spent:
1. **The primary ruler fails on supermarket breast.** Normal broiler pectoralis sarcomeres are ~1.69 µm, so only ~13% have a resolvable I-band at 4×. The new primary ruler is the **paired sarcomere-period ratio**, which is blur-proof. In simulation, E_local comes out within **0.2–0.35% per 10-sarcomere segment**, including a label-free pre-image (contrast assumed; P1 measures it) (AU-01).
2. **OFM software can't drive the planned hardware.** It supports only Pi ≤4 with Pi Camera v2, and v3 is still alpha. SWELL forks the OFM *hardware* and runs its own Pi 5 service (AU-09).
3. **Magnification must match the camera.** 3.45 µm pixels need ~17× total magnification at NA 0.65. A 50 mm OFM-style tube lens undersamples, while a 40× objective at full magnification gives ~5× more tiles than needed (AU-10).
4. **Travel:** a 2 mm punch at E 4.8, or a 1 mm punch at 10×, overruns the ~10 mm usable travel. The new punches are 1.5 mm and 0.75 mm, which also cut tiles and data by ~42% (AU-18).
5. **The north star conflicts with INV-6/INV-14.** "Chicken in, one button" needs casting and the 95 °C step inside the machine. The button is now staged. The sealed Wet Module and the chicken-prep cartridge (Buttons B + C) are designed on paper now, under approval A-1 (AU-45).

**Cheaper:**
- No on-stage heater (AU-15).
- One Pico controller (AU-16).
- A box enclosure (AU-20).
- The community lab for chemistry (AU-23).
- Smaller punches (AU-18).

The provisional target is now **imager core ≤ £500, full reference build ≤ £650, ceiling £1,000** (D-15; Order 5 proves it with live prices).

**Totals:** 47 findings: 3 Critical, 11 High, 20 Medium, 13 Low. **15 are closed today**: AU-05, 09, 15, 16, 18, 20, 24, 25, 32, 33, 35, 36, 37, 38 and 39, each settled by a decision or erratum with nothing left to do. **32 are routed** into open orders with measurable acceptance. Each one has a recorded fix in:
- ERRATA E-1–E-17
- DECISIONS D-1–D-25
- INVARIANTS INV-15–INV-18
- RISKS R18–R28
- ORDERS 2–7 and 10–20
- APPROVALS A-1–A-2, plus the backup-repo step in S-1

*Revised after a fresh OWNER_PRINCIPLES-only review (an AI session, not a person; noted in this copy) the same day: claims tightened to what is shown, "chicken in" designed now (A-1 covers Buttons B + C), a ratio simulation added, and smoke checks upgraded to real work.*

---

## A. Science and QC (kit 02, 06)

| ID | Sev | Finding | Evidence | Fix → where |
|---|---|---|---|---|
| AU-01 | Critical | **The A-band ruler fails on supermarket chicken.** The kit's primary local-E ruler (A-band ≈ 1.6 µm, use only SL ≥ 1.8 µm with a visible I-band) has almost nothing to measure in normal breast meat. | Normal broiler pectoralis SL is 1.69 µm vs 1.91 µm in wooden breast (F-10), so the I-band per side at mean SL is 45 nm. A resolvable I-band needs SL ≥ 1.78 µm at 4× and ≥ 1.73 µm at 10×: only **13% / 30%** of sarcomeres qualify (calc §4, SD 0.08 µm assumed). | **Primary ruler = paired sarcomere-period ratio**, E_local = SL_post / SL_pre per myofibril. The specimen is fixed before pre-imaging, so contraction can't change between the two. Fallback: a population ratio that needs no registration. Fourier period estimation is blur-invariant: 0.19% per post-image over 10 sarcomeres. The full ratio, with the label-free pre-image, is **0.21–0.35% over 10 sarcomeres and 0.6–1.0% over 5**, for assumed pre-image contrast of 5–50% (calc §4 Monte Carlo; P1 measures the real contrast, R21). The A-band stays as a secondary ruler where the I-band is resolved. → D-4, E-5, Orders 3 and 7 |
| AU-02 | High | **Z-disc FWHM does not read resolution directly at any E**, not just at 10×. G5's "Z-disc FWHM ≤ ~100 nm" can fail on biology alone. | Z-discs are 30–140 nm wide depending on muscle and species (F-11). Measured FWHM for true widths 30/50/80/140 nm: 96/104/121/167 nm at 4×, 73/83/104/155 nm at 10× (calc §4). | Resolution comes from bead PSF ÷ E plus FRC. Z-disc width becomes a reported *result*, quadrature-corrected with its uncertainty. The G5 criterion is rewritten. → D-5, E-4, Order 7, ORDERS G5 |
| AU-03 | Medium | "CV ≤ 5%" mixes measurement noise, biological spread and true expansion heterogeneity. | Kit 06 has no variance model. | Re-image fields to measure noise. A spatial semivariogram of E_local separates them: real inhomogeneity is spatially correlated, noise isn't. Nested mixed model: prep → gel → myofibril. → Orders 7 and 16 |
| AU-04 | Medium | Every ruler is in-plane, so axial expansion is never checked. | Kit 06 §2. | Measure E_z from gel thickness (top and bottom surfaces, corrected for focal shift) and compare with E_macro. → Order 7 |
| AU-05 | Medium | Kit 02 value #3 claims "same cell, live then fixed then nanoscale… the same-instrument design keeps the sample in place". This is false. | The specimen leaves the stage for anchoring, casting, punching and denaturation, and chicken is never live. | Reword the claim: same structures, relocated by fiducials plus mirror-aware registration. → E-2, D-11 |
| AU-06 | Medium | E_macro is a ratio, so scale cancels only if the pre and post overview images share geometry. | 3 mm of water at a 100 mm working distance shifts the apparent scale by **0.75%** (calc §5). QC would read that bias as real expansion. | Put an in-plane fiducial scale in every overview frame and calibrate lens distortion at G1. → D-13, E-10, Order 4 |
| AU-07 | Medium | The orientation mark (one cut corner) is achiral. A flipped, mirrored gel looks identical and silently breaks pre/post registration. | Geometry: a disk with one notch is mirror-symmetric. | Use a chiral mark (two unequal notches) and have registration test both handednesses. → D-11, E-11, Orders 3 and 7 |
| AU-08 | Low | There are no blank or control gels. | Kit 05 / 06. | Add a specimen-free gel (background) and a bead-only gel (PSF in gel) per protocol version. → Order 3 |

## B. Design and optics (kit 03)

| ID | Sev | Finding | Evidence | Fix → where |
|---|---|---|---|---|
| AU-09 | Critical | **OFM software reuse isn't viable** for a mono IMX296 or a Pi 5. | OFM server v2.x supports only Pi ≤4 with Pi Camera v2 (maintainer, 2025-04-14, F-2). v3 is at alpha5 (2026-04-08), unreleased and "tied to the same hardware at release" (F-3). | Fork the OFM v7 *hardware* (pinned beta5 commit, F-6). Build SWELL's own picamera2 service (Order 6 builds one anyway) and keep the Sangaboard serial protocol. The Pi 5's second CSI port takes the overview camera. → D-6, E-3, Orders 4 and 6 |
| AU-10 | High | **Magnification isn't matched to the camera.** | Nyquist is 0.200 µm at NA 0.65 / 520 nm, so 3.45 µm pixels need **17.2×** (10.6× on the 10× track). A 40× objective at full magnification gives 86 nm pixels and ~5× more tiles. OFM-style finite optics with a 50 mm lens give 10.5–11.8× and 0.29–0.33 µm pixels: undersampled. Nyquist needs ~100 mm in that geometry or an infinity objective with a 75–100 mm tube lens (calc §2, thin-lens). | Order 12 models the real OFM v7 optics module in rayoptics with vendor lens files and fixes the lens. G1 measures it with the stage micrometer. → Orders 4 and 12 |
| AU-11 | High | **The SNR budget has no background terms.** The kit asks for a budget before buying but names only E³ dilution. | First pass (calc §6): signal 175–1,754 e⁻/px per 100 ms at 1 W/cm² for 0.5–5% labelled amines. Bleed-through is ≈ 23 e⁻/px with cheap filters (dichroic OD2 + emission OD3) and ≈ 0 with OD6, giving SNR 12–42 either way. The cheap-filter route passes on paper. Not yet included: the labelled fraction (10× uncertain), out-of-focus light from the 4–9 µm expanded myofibril, and autofluorescence. | Order 12 completes the budget (autofluorescence, out-of-focus pedestal, bleaching, 10× track) and sets the filter OD spec. Measure on a blank gel at G1. → Order 12, R19 |
| AU-12 | Medium | There is no photon-dose (bleaching) budget. | Each gel point gets **12 exposures** with a field stop, **36** if the LED floods 3× the FOV, and **51** with a 5-image autofocus per tile (calc §5). | Field stop matched to FOV + overlap. Focus map instead of per-tile autofocus. Dose budget in Order 12; bleach curve measured at G1. → D-12, Orders 4, 6 and 12 |
| AU-13 | Medium | Per-tile autofocus is the wrong default. | Gels lie flat on PLL glass with the specimen at the glass (specimen-side down). | Use a 9–25-point focus map plus the z-stack margin; per-tile autofocus only as a fallback. → D-12, Order 6 |
| AU-14 | Medium | Spherical aberration of a dry 0.65 NA objective focusing into water isn't modelled. The focal shift itself checks out: 1.33–1.53. | Calc §1. | Gibson–Lanni model (MicroscPSF-Py, installed) of Strehl and axial FWHM vs depth 0–20 µm. → Order 12, R23 |
| AU-15 | High | **The on-stage 37 °C heater has no customer.** | Overnight anchoring and gelation are off-stage by INV-14, and NHS pan-staining runs at room temperature or in the off-stage incubator. Heater, PID, thermistor, cutoff and G2's 16 h hold add ~£30–60 and a safety subsystem, and they warm the PLA flexures. | No on-stage heater in v1 (reversible). G2's thermal criterion is replaced by temperature logging plus focus-drift characterisation. INV-2 stays for any future heater. → D-9, E-15, Order 4 |
| AU-16 | Medium | Two controllers (Sangaboard plus an RP2040 I/O board) where one will do. | ~£50–70 for two boards. | One Pico 2 (RP2350) with three ULN2003 boards (~£12) runs the steppers via PIO plus the LEDs, pumps and sensors. It speaks the Sangaboard protocol. The lid interlock stays in hardware. → D-8 |
| AU-17 | Medium | Attofluor chambers take 25 mm coverslips; the protocol uses 12 mm. | Kit 03 vs 05. | Printed C12 chamber (O-ring seal, kinematic seat, fiducials). → D-19, E-6, Order 4 |
| AU-18 | High | **Punch size vs travel.** | Usable XY travel is ~10 mm (F-1). With ±0.5 mm centring, a 2 mm punch at E 4.8 needs 10.3 mm and a 1 mm punch at E 10 needs 10.5 mm: **both fail** (calc §3). | Track A: **1.5 mm** punch (needs 7.5–7.9 mm). Track B: **0.75 mm** (8.0 mm). This also cuts tiles from 1,318 to 759 per plane at E 4.5 and raw data from 42 to 24 GB per gel. → D-10, E-9, Order 3 |
| AU-19 | Low | z-planes and data volume are understated. | At axial Nyquist (1.54 µm), a 2 µm myofibril at 4.5× plus ±2 µm margin needs ~10 planes, not 5–8: 759 tiles/plane, 24 GB raw, 1.2–2.1 h scan per gel (calc §3). | Feed these into the camera, data and storage plan; lossless Blosc-Zstd compression. → Order 14, D-16 |
| AU-20 | Low | A printed light-tight enclosure is costly in filament and time. | Kit 03. | A black storage box with a lid microswitch (~£10); the interlock is unchanged. → Orders 4 and 5 |
| AU-21 | Medium | Clearance between the dish and lid stack and the OFM illumination arm is unchecked, and the lid can fog in transmitted light. | Kit 03 / OFM geometry. | CAD fit-check of the OFM v7 STLs against the holders, the lid and the objective working distance. → Order 13 |

## C. BOM and cost (kit 04)

| ID | Sev | Finding | Evidence | Fix → where |
|---|---|---|---|---|
| AU-22 | High | Target, envelope and north star disagree. | The envelopes sum to £600–1,550 against a ≤ £1,000 target, and "shockingly cheap" needs a lower, provable number. IMX296 mono modules cost $61–78 from four vendors (F-5). | Provisional targets: imager core ≤ £500, reference build ≤ £650, ceiling £1,000. Order 5 proves or revises them with live prices. → D-15, Order 5 |
| AU-23 | High | **The wet lab dominates cost**: £1,200–2,500 first fill vs ≤ £1,000 hardware. It also carries R1 (supply, delivery, waste). | [personal detail removed] | [personal detail removed] This removes most equipment purchases and largely settles R1. → APPROVALS A-2, OUTREACH O-1 |
| AU-24 | Medium | Sodium acrylate batch variability is a known ExM problem. | A 2025 protocols.io protocol neutralises acrylic acid with NaOH to make 4 M SA, "much cheaper" and batch-consistent (F-9). It is corrosive, flammable and exothermic. *Hazards beside this step (lab only; from the supplier SDSs listed in `SAFETY.md`): sodium acrylate H400, H411; acrylic acid and sodium hydroxide H226, H302, H312, H332, H314, H335, H400, H290. Control: fume hood only, with goggles, gloves and lab coat; neutralising the acid gives off heat. Waste: the lab's hazardous-waste route; nothing down the drain.* | Buy high-purity SA for P3 (reject yellow; check the CoA). Keep neutralisation as a fume-hood-only fallback. → D-21, Order 3, R9 |
| AU-25 | Low | A 0.01 g balance can't make a 10% APS stock in small batches (0.10 g ± 10%). | Arithmetic. | Make 10% APS in ≥ 1 g batches (± 1%), aliquot and freeze at −20 °C. Keep the 0.01 g balance. → D-24, E-13 *Hazards beside this step (lab only; from the supplier SDSs listed in `SAFETY.md`): APS H272, H302, H315, H317, H319, H334, H335. Control: weigh into closed, pre-tared vials with minimal dust; keep away from combustible materials. Waste: the lab's hazardous-waste route; nothing down the drain.* |
| AU-26 | Low | *Left out of this copy: its fix suggested making a calibration item yourself.* | | |
| AU-27 | Low | Fluidics from a specialist supplier is pricey for water, PBS and dye. | Kit 04 sourcing. | Generic 12 V peristaltic pumps (~£8–15) with silicone tubing. → Order 5 |
| AU-28 | Low | The protease-inhibitor cocktail (~£100) may be unnecessary. | 1 mM EGTA in the rigor buffer already blocks calpains, the Ca²⁺-dependent post-mortem proteases. *Hazards beside this step (lab only; from the supplier SDSs listed in `SAFETY.md`): imidazole H302, H314, H360D. Control: the rigor buffer is made with imidazole (D-22): weigh the solid only in a fume hood; EGTA has no hazard class in its sheet (SAFETY.md). Waste: the lab's hazardous-waste route; nothing down the drain.* | Test the prep with and without it in P3 before buying. → Order 3 |

## D. Protocol (kit 05)

| ID | Sev | Finding | Evidence | Fix → where |
|---|---|---|---|---|
| AU-29 | High | The monomer solution adds to 225 µL; the missing 25 µL is resolved. | The remaining 25 µL is the initiators: 12.5 µL 10% TEMED + 12.5 µL 10% APS per 250 µL (0.5% each), the U-ExM ratio of 90 µL MS + 5 + 5 µL. The 2025 protocol confirms final concentrations of 10% AA, 19% SA, 0.1% BIS, 1× PBS, storage at −20 °C for < 2 weeks, and preparation ≥ 4 h ahead (F-8). *Hazards beside this step (lab only; from the supplier SDSs listed in `SAFETY.md`): acrylamide H302, H315, H317, H319, H340, H350, H361f, H372; bis-acrylamide H340, H301, H312, H350, H361, H372; sodium acrylate H400, H411; TEMED H225, H302, H332, H314; APS H272, H302, H315, H317, H319, H334, H335. Control: fume hood, double nitrile gloves, goggles and lab coat; never on the microscope stage. Waste: the lab's hazardous-waste route; nothing down the drain.* | Re-read the PDF in Order 2; write it into protocol v0.1. *Re-read for this copy, 2026-10-10: see F-8 and E-1.* → E-1, Order 3 |
| AU-30 | Medium | No step links the pre-imaged fields to the punch site. | Kit 05 steps 2 and 6. | Take an overview image with fiducials before punching, centre the punch on the imaged region, and log the coordinates. → Order 3 |
| AU-31 | Medium | Amine carry-over quenches NHS staining. | The denaturation buffer contains 50 mM Tris; Tris, glycine or PLL would consume NHS ester. | INV-16 protocol lint; stain off-stage before PLL mounting, as now. → INV-16, Order 3 |
| AU-32 | Low | Kit 05 leaves "Tris or imidazole" open for the rigor buffer. | Kit 05 step 0. | Choose imidazole: no primary amine to react with formaldehyde or NHS ester. → D-22 |
| AU-33 | Medium | The NHS-ester dose (≈ 2 µg/mL) was unverified. | Pan-ExM uses **20 µg/mL** in 100 mM bicarbonate, 1.5 h at room temperature (F-18, verified from the full text). | Titrate 2 / 6 / 20 µg/mL and keep the lowest dose that passes. Dye is the main per-gel cost. → E-17, Order 3 *Hazards beside this step (lab only; from the supplier SDSs listed in `SAFETY.md`): DMSO (no hazard class; see its row). Control: gloves, because DMSO carries the dissolved dye through skin; no dye is chosen yet, so read its own SDS once one is. Waste: the lab's hazardous-waste route; nothing down the drain.* |
| AU-34 | Low | *Left out of this copy: its fix suggested a shop-bought substitute for the practice gels.* | | |

## E. Roadmap and gates (kit 07)

| ID | Sev | Finding | Evidence | Fix → where |
|---|---|---|---|---|
| AU-35 | High | "Spend and order everything in Stage 2" clashes with reagent shelf life. | Monomer solution keeps < 2 weeks; APS stocks degrade; the kit buys per phase. | Stage 2 approves Baskets H + C + W together after G0 and orders H + C at once. W is released at G1, so reagents land fresh for P3. → D-14, ORDERS |
| AU-36 | Medium | Gate criteria need updating. | AU-02, AU-15. | G0 = "virtual build passed". G2 loses the thermal hold. G5 resolution is bead/FRC-based. → ORDERS |
| AU-37 | Low | G6 promises "same QC numbers", but numbers vary gel to gel. | Kit 00 / 07. | Change to "passes the same QC thresholds". → ORDERS G6 |

## F. PM, risks, templates (kit 08, 09, templates)

| ID | Sev | Finding | Evidence | Fix → where |
|---|---|---|---|---|
| AU-38 | Medium | The risk register is missing risks. | Kit 09. | Add R18 dose, R19 background, R20 own camera service, R21 period ruler needs pre-images, R22 PLA drift near heat, R23 spherical aberration, R24 shelf life, R25 claims > QC, R26 scan time and gel drift, R27 Triton supply, R28 single-SSD data loss. → pm/RISKS.md |
| AU-39 | Low | push-notification topics are public by name. | push-notification design. | Use a random topic; the brief tool refuses names and keys and caps 2 a day. → D-1, tools/brief.py |
| AU-40 | Low | Backup targets are weak. | [personal detail removed] | Local bundle on C: now; off-site = private GitHub repo once the owner says "repo yes" in S-1 (it acts on his account); raw data on its own drive (Basket H). → D-18, D-23 |

## G. Safety and legal (kit 10)

| ID | Sev | Finding | Evidence | Fix → where |
|---|---|---|---|---|
| AU-41 | Medium | The kit points to EU CLP Annex VI for classifications. GB now uses GB CLP and the HSE's GB MCL list. | UK REACH Annex XVII entries 28–30 are retained, and formaldehyde is on Appendix 2 via 2018/675 from 24 May 2018 (F-12). Bis-acrylamide: a database lists harmonised Muta 1B (H340), while supplier SDSs range from H302 only to H340/H350 (F-13). | Keep treating bis-acrylamide as CMR; check GB MCL in Order 2. → E-7, Orders 2 and 3 |
| AU-42 | Medium | Triton X-100 is on the REACH authorisation list (EU sunset 4 Jan 2021); unverified for the UK. | Scientific R&D is exempt, but UK supply may be restricted. | Confirm UK REACH Annex 14 status; switch detergent if supply bites. → Order 2, R27 |
| AU-43 | Medium | The hazardous-waste cost is unquantified. | Kit 04 E / 10. | Polymerise leftover monomer (standard practice; confirm with the carrier), keep liquid CMR volumes tiny, get quotes, and check the community lab's route. → Order 3, O-1 *Hazards beside this step (lab only; from the supplier SDSs listed in `SAFETY.md`): acrylamide H302, H315, H317, H319, H340, H350, H361f, H372; bis-acrylamide H340, H301, H312, H350, H361, H372. Control: leftover monomer stays CMR waste until the lab's waste route says otherwise. Waste: the lab's hazardous-waste route; nothing down the drain.* |
| AU-44 | Low | A new hazard appears if AU-24's fallback is used. | Acrylic acid is corrosive and flammable; neutralisation is exothermic. | Fume hood only; COSHH entry before use. → Order 3 |

## H. North star, paper, wow (new brief)

| ID | Sev | Finding | Evidence | Fix → where |
|---|---|---|---|---|
| AU-45 | Critical | **The north star needs casting, CMR liquids and the 95 °C step inside the machine**, which INV-6/INV-14 forbid without the owner. | Kit 03 "not delegated"; CLAUDE.md hard limits. | Stage the button. **A** (G4): loaded gel → images + QC + paper draft. **B**: a separate, sealed, metal-and-glass Wet Module beside the imager, never on the stage, which casts and denatures; designed only after A-1, built after G4 with a signed risk assessment. **C** ("chicken in"): a chicken-prep cartridge, designed on paper with B in Order 4. → A-1, Order 4 |
| AU-46 | High | There is no publication pipeline. | Kit 00–10. | Order 16 builds run → manuscript: methods from protocol and metadata; figures and tables from data; a pre-registered statistics plan; results with limitations; DOI references (Manubot); a data/code package; a journal shortlist; an AI-use disclosure (Claude is never an author); a claim linter (INV-15). Proven end to end on synthetic data. → Order 16, INV-15, INV-18 |
| AU-47 | High | The strongest defensible claim is not "a cheap microscope matches a confocal", which a bigger lab will always beat. It is **"a self-calibrating ExM standard you buy at the supermarket, with open QC, proven on a ≤ £650 automated box"**. | §2.11 zoom-out test. | Wow plan ranked in pm/IDEAS.md; top items adopted into Orders 3, 7, 16 and 17. → Order 17 |

---

## Upgrades adopted into orders (top items, ranked by impact ÷ cost)

| Upgrade | Why | Cost effect (estimate; Order 5 prices it) | In |
|---|---|---|---|
| Period-ratio ruler + variance decomposition + chiral registration | Turns every gel into its own calibrated, reviewer-proof measurement, including on short supermarket sarcomeres | £0 | Orders 3, 7 |
| Staged button + Wet Module proposal | The north star without breaking the safety walls | £0 now | A-1, Order 4 |
| Own Pi 5 service + OFM hardware fork + one Pico | Unblocks the mono camera; removes a board | −£40–60 | Orders 4, 6 |
| Optics matched to Nyquist, field stop, focus map | ~5× fewer tiles than a full-magnification 40×; lower dose | £0 | Orders 4, 12 |
| 1.5 mm / 0.75 mm punches | Fits the real travel; −42% tiles and data | £0 | Order 3 |
| No on-stage heater; box enclosure | Removes a safety subsystem and drift | −£40–70 | Order 4 |
| Community lab for P3 | Settles R1; avoids most wet-lab equipment | −£500–1,500 one-off, +£40/month | A-2, O-1 |
| Paper pipeline with claim linter | North-star output; claims can't outrun QC | £0 | Order 16 |
| Positive-failure gels, census, cost per nanoscale image | Validation reviewers can't argue with | ~£20–50 reagents | Orders 3, 7, 16, 17 |

## Still unverified
The single open list lives in **Order 2**: nine facts, F-8, F-11, F-13, F-14, F-16, F-17, F-19, F-22 and F-23. VERIFIED_FACTS carries each one's status, and STATUS quotes the count.
