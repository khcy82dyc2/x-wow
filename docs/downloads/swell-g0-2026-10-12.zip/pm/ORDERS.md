> **Lab only.** The reagents, amounts and steps in this file are design notes for a laboratory with a fume hood,
> working under its own risk assessments. They are not a method to follow. Each reagent's hazards and handling:
> `SAFETY.md`.

# ORDERS: SWELL

**Current: Stage 1 (= P0 Desk), working toward G0.** Rewritten in Life 1 (2026-10-09) to map the owner's three stages onto the kit's phases and gates (D-3); updated in Life 2 with the owner's S-1 answers (D-26 to D-34): wet work only at a host lab, our own optics, transverse isotropy, the whole-gel strain map. Format and lifecycle per kit/08: open → in-progress → believed-done → verified (by an auditor) → closed at the gate.

## Direction change, Life 3 (2026-10-09, D-35): read this first
SWELL stops at G0 as a fully specified theoretical prototype, given away free as invention #1 on x-wow.com. **Frozen:** Stage 2 and Stage 3 (Orders 18–20 and everything from P1 on), any lab contact (S-3 cancelled, nothing sent) and any spending. Stage 1 orders continue only where the free kit needs them (Order 22).

The site is the public face. Its source lives in D:\SWELL\site, the public repo github.com/khcy82dyc2/x-wow (D-36), served at https://khcy82dyc2.github.io/x-wow/ until the DNS switch (S-4).

**Site rules for every order below:**
- Rebuild with `python site/build.py`, which must pass.
- A fresh AI reviewer (another AI session, not a person) checks overclaims, credit, film IP, AI disclosure and anything personal before each push (D-38, D-40).
- Never touch Wix, the mail records or any other repo.

### Order 21: x-wow.com site v1 [Life 3] [believed-done: reviewed by a fresh AI agent (21 findings: 2 blockers and 10 should-fixes fixed, 9 nice-to-haves mostly fixed; 3 owner items in STATUS); live on x-wow.com since 2026-10-09 ~22:24]
**Goal:** a launch-ready site on the test URL, built only from existing material.
**Acceptance:**
- Home: manifesto, mission, origin story, gallery and builders' wall.
- SWELL page: concept model, numbers, £5 experiment, BOM, labs, safety, verified vs predicted, legal, inspiration ledger, AI note and zip.
- Six old-site showcase pages, plus redirects for every old URL.
- EN/中文 throughout; works on mobile and with reduced motion.
- A fresh-agent review passes.
- DNS check and switch steps are in S-4.

### Queue for the auto runner (written in Life 3; do them in this order; one or two per life)

### Order 22: SWELL desk work to G0 quality [open]
**Goal:** finish Orders 5, 7 and 12 to G0 quality and publish the results on the SWELL page.
**Acceptance:**
- Order 5: every BOM line is priced, with an honest real cost total. No target-change approval is needed (the owner, Life 3): publish the real number.
- Order 12: the SNR gap (R30) is closed or stated as an open problem with its numbers.
- Order 7: the two known strain-map misses are fixed or explained.
- Nuclei are added to the sim (a DAPI-like channel and nuclear landmarks) with a passing check.
- The numbers pipeline is refreshed (site/tools/numbers_swell.py) and the zip rebuilt.

### Order 23: Real CAD model on the site [open; needs Order 4 CAD]
**Goal:** replace the concept model with the real CAD in full interactive 3D.
**Acceptance:**
- glTF exported from FreeCAD/OpenSCAD.
- Clicking a part opens a HUD card with name, role, supplier, price, date checked and a file download (STL/STEP).
- A light-path toggle; the exploded view kept.
- Under 5 MB, with a WebGL fallback.
- The "concept model" label is removed only when the CAD is the real design.

### Order 24: Animated virtual test run [open; with Order 15]
**Goal:** an animated walk-through of a synthetic run (chicken in → gel → tiles → strain map → QC report), where every number shown is traceable to software/sim/ output.
**Acceptance:**
- It runs from a JSON produced by the sim (no hand-typed numbers).
- Pause and step controls.
- Reduced-motion version.

### Order 25: "Why it won't waste your money" section [open]
**Goal:** builders spend in the cheapest-failure-first order.
**Acceptance:**
- A risk register (from pm/RISKS.md, public wording).
- A build order that tests the cheapest failure first.
- Go/no-go per step, with its pass criterion.
- The cost of each failure, computed from the BOM by code.

### Order 26: Full sourcing and a take-over guide [open; after Order 22]
**Goal:** a stranger can order and build without asking anything.
**Acceptance:**
- Every line has exact URLs, SKUs, the date checked and 1–2 alternatives.
- BOM-upload CSVs per supplier.
- A numbered take-over guide with time, cost and skills per step.

### Order 27: Wet-lab protocol, chicken-in cartridge, paper starter kit, open problems [open]
**Goal:** the public kit carries everything a lab needs.
**Acceptance:**
- Protocol v1 (Order 3, for a proper lab with a fume hood; hazards per kit/10 + ERRATA).
- The chicken-in cartridge design (A-1, design only).
- A paper starter kit: methods, figures, data, references (Order 16).
- An open-problems list.

### Order 28: Credit and AI-trust design rules [open]
**Goal:** the site meets academics where they are.
**Acceptance:**
- Research how academics react to credit and attribution disputes and to AI-produced research (for example the backlash to AI-generated maths solutions), with cited sources.
- Turn the findings into one-line design rules, apply them site-wide and log them in DECISIONS.
- Complete the inspiration ledger with DOIs.

### Order 29: Back to Shine self-serve noticeboard [open; needs the owner: it touches people's data]
**Goal:** donors and seekers of retired lab equipment find each other.
**Acceptance:**
- Design first: listings, distance matching, a contact relay with no public personal details, auto-expiry, a "rehomed" status, spam protection, packing and safety rules, a stories wall.
- A privacy note.
- Hosting must be free and need no new account. If it can't be, write the cheapest option as an APPROVALS item.
- Nothing goes live before the owner approves the data handling.

### Order 30: Deep reviews [open; after Orders 22–27]
**Acceptance:** three fresh AI reviewers (AI sessions reading as each kind of reader; real outside review would come only from people), each reporting fixes as orders:
- a builder who walks the full take-over guide;
- a sceptical academic;
- an IP and overclaim reviewer.

### Order 31: After the DNS switch [mostly done 2026-10-09 22:45: HTTPS on apex and www (cert approved, expires 2027-01-07, auto-renews); http→https and www→apex 301; MX/SPF/verification unchanged; old URLs redirect. Left: recheck in 24 h that every resolver sees www → GitHub.]
**Acceptance:**
- HTTPS works on x-wow.com and www (certificate issued; "Enforce HTTPS" on).
- www redirects to the apex.
- MX and TXT are unchanged against pm/site/dns-snapshot-2026-10-09.md.
- Old URLs redirect.
- The sitemap is submitted only if the owner asks.

### Order 32: Restore the original X-WOW logo [Life 4, the owner's order] [verified: fresh AI reviewer (faithful, safe to push, 0 blockers; 7 of 8 suggestions applied, the hero-reticle logo declined because the reticle sits behind the headline); live on x-wow.com 2026-10-10 (x-wow ae989b0; 14 live files match the build byte-for-byte)]
**Goal:** the old site's own logo back on x-wow.com, wherever the site shows a mark, unchanged and legible in dark mode and on phones.
**Acceptance:**
- The original files are found and kept byte-for-byte beside the derived ones.
- No redesign: laid back over white, the derived logo reproduces the original (generator check), and a fresh AI reviewer agrees.
- The logo appears in the header, footer, boot screen, favicon set, home-screen icons, social preview and README.
- It reads well on the dark site, on light and dark browser tabs, and at 360 px, 2× and 3×.
- `python site/build.py` passes, and the link check now covers srcset entries and manifest icons.
- Live on x-wow.com, confirmed by fetching the new files from the domain.

## Stage map

| Stage | Kit phases | Exit gate | What passes it | Money | the owner time |
|---|---|---|---|---|---|
| **1. Audit, improve, simulate** | P0 Desk | **G0** (desk gate) | An auditor confirms every simulable check passed (Orders 12–16); BOM, protocol, safety pack and budget are final; the owner approves | none | S-1 (done) + S-3 (send 3 lab enquiries) + G0 sign-off |
| **2. Spend and order** | ordering window between G0 and P1 | P1 start | Baskets H + C + W approved; H + C ordered; deliveries checked against BOM; W released at G1 (D-14) | Baskets | approve + pay |
| **3. Assemble, run, fine-tune** | P1 → G1, P2 → G2, P3 → G3, P4 → G4, P5 → G5, P6 → G6 | G1–G6 | Real-machine evidence only (INV-12) | per gate | ~13–18 sessions |

Detailed orders exist for Stages 1 and 2. Stage 3 is outlined per phase; its orders are written at each gate (kit/08 scope control).

**Stage 1 working sequence:** 12 (rest) → 2 → 13 → 14 → 4 → 5, alongside 6 → 7 → 15 → 16 → 17 → 3 → 9. Order 8 was folded in during Life 2; the host lab is chosen when O-1 to O-3 are answered (S-3). Estimate: 9–13 more focused lives.

---

## Stage 1 (P0): orders

### Order 1: Boot the project + batch-1 session card [P0 · S1] [believed-done]
**Goal:** the project skeleton and PM system are live, and the owner has only the questions P0 needs.
**Acceptance:**
- Folder layout per kit/08, with CLAUDE.md (project facts filled in) and all pm/ files.
- LICENSES.md and .gitignore exist.
- git is initialised with a first commit.
- The LEDGER starts with "Life 1 started".
- A backup bundle is on C:, and the private off-site repo is live (D-27).
- pm/inbox/ is git-ignored, so private answers and photos never leave this PC.
- Another project's conventions were looked up read-only and mirrored: lessons file, brief tool.
- A SWELL push-notification topic exists, and its first message is the batch-1 ping.
- S-1 (≤ 30 min, 大白话) is in HUMAN_QUEUE.
- STATUS is written.

**Evidence:** `git log`, pm/briefs.log, pm/HUMAN_QUEUE.md, pm/STATUS.md.

### Order 2: Verify the kit [P0 · S1] [in-progress]
**Goal:** every (verify) item and every number in kit/ is checked against primary sources.
**Done:** F-1–F-21 checked; 12 verified, 2 partial but accepted (no decision depends on them), F-18 closed in Life 1. ERRATA E-1–E-17.
**Open list (the only one; STATUS quotes its count): 9 facts**
- **F-8:** re-read the protocols.io PDF (MS, initiators, gel volume and time, denaturation, expansion).
- **F-11 + F-17:** chicken pectoralis Z-disc width and thick-filament length from primary EM sources (one search).
- **F-13:** GB MCL entries for acrylamide, bis-acrylamide, formaldehyde, APS and TEMED.
- **F-14:** EP 3332258 register status, plus other EP families.
- **F-16:** OFM hardware and software licence variants → LICENSES.md.
- **F-19:** systematic prior art → docs/design/prior_art.md, with search strings and dates. Covers ExM on vertebrate muscle and myofibrils, ExM on low-cost or 3D-printed microscopes, intrinsic-ruler ExM QC, wooden-breast ultrastructure, and one-step ~10× chemistries (Magnify, ONE) vs TREx.
- **F-22:** Triton X-100 status under UK REACH Annex 14 (AU-42).
- **F-23:** IMX296 QE, read noise and full well from the Sony datasheet.
- Host-lab terms are not a desk task: O-1 to O-3 answer them.

**Evidence:** every VERIFIED_FACTS row is verified or carries a stated reason; ERRATA is updated.

### Order 3: Protocol v0.1 + safety pack [P0 · S1] [open]
**Goal:** protocols/SWELL-ExM4-v0.1.md (Track A), runnable by a careful scientist, plus the safety pack.
**Includes these audit fixes:**
- imidazole rigor buffer (D-22) *Hazards beside this step (lab only; from the supplier SDSs listed in `SAFETY.md`): imidazole H302, H314, H360D. Control: weigh the solid under local exhaust ventilation; the lab's risk assessment must cover a reproductive toxicant. Waste: the lab's hazardous-waste route; nothing down the drain.*
- initiator volumes (E-1)
- 1.5 mm punch (D-10)
- chiral notches (D-11)
- a punch-site registration step (AU-30)
- pre-imaging for the period ruler (D-4, R21):
  - fiducial-marked fields, ≥ 10 sarcomeres per segment;
  - both an oblique/DPC frame and a crossed-polariser frame.
- blank and bead-only control gels (AU-08)
- the positive-failure gel set from Order 17
- an EGTA-only vs protease-cocktail test (AU-28)
- NHS-ester dye titration, 2 / 6 / 20 µg/mL in 100 mM bicarbonate at room temperature (E-17) *Hazards beside this step (lab only; from the supplier SDSs listed in `SAFETY.md`): DMSO (no hazard class; see its row). Control: gloves, because DMSO carries the dissolved dye through skin; no dye is chosen yet, so read its own SDS once one is. Waste: the lab's hazardous-waste route; nothing down the drain.*
- APS stock per D-24 *Hazards beside this step (lab only; from the supplier SDSs listed in `SAFETY.md`): APS H272, H302, H315, H317, H319, H334, H335. Control: weigh into closed, pre-tared vials with minimal dust; keep away from combustible materials. Waste: the lab's hazardous-waste route; nothing down the drain.*
- fillet sourcing: buy and score normal and wooden-breast fillets by palpation for W-12
- the INV-16 lint
- the host-lab variant (D-26, D-31): equipment and waste route from the chosen host

**Safety pack:**
- A COSHH-style assessment per hazardous reagent, with SDS PDFs in protocols/sds/.
- A waste plan naming a UK route with quotes, including whether polymerised leftover monomer is accepted as non-hazardous (AU-43).
- A delivery-address plan.
- P3 session-card drafts.

**Acceptance:**
- Every step has volume, time, temperature, hazard, waste route and citation.
- The protocol lint passes: INV-10, INV-16, no unresolved "or".
- The risk assessments are queued in APPROVALS for sign-off.

**Depends on:** Order 2 (F-8, F-13, F-18); the host lab's answers to O-1 to O-3 (fume hood, CMR rules, waste route, deliveries).

### Order 4: Reference design v0.1 [P0 · S1] [open]
**Goal:** settle and document the reference design, with CAD.
**Finalise:**
- platform (D-6) and camera (D-7, after Order 12)
- controller and interlocks (D-8): wiring diagram with the hardware lid interlock and the leak latch
- no on-stage heater (D-9)
- C12 chamber (D-19)
- dish holder: kinematic seat, fiducials, in-plane overview scale (D-13)
- v1 cartridge concept: ports, mesh guard, weir, no heater, plus the Wet Module interface
- **Buttons B + C on paper ("chicken in", A-1):** the Wet Module (casting, 95 °C step, CMR liquids) and the chicken-prep cartridge (mince → rigor buffer → spins → settle on PLL glass → fix). Cover process flow, interfaces to the imager, wetted materials (metal and glass, no printed parts near 95 °C), hazards and controls, and a cost estimate. Built only after A-1 yes, G4 and a signed risk assessment *Hazards beside this step (lab only; from the supplier SDSs listed in `SAFETY.md`): acrylamide H302, H315, H317, H319, H340, H350, H361f, H372; bis-acrylamide H340, H301, H312, H350, H361, H372; formaldehyde H302, H312, H332, H315, H317, H319, H335, H341, H350; SDS (the detergent) H302, H315, H318, H412. Control: on paper only; built only after A-1, G4 and a signed risk assessment. Waste: the lab's hazardous-waste route; nothing down the drain.*
- objective + tube lens, and dye + LED + filter set with OD spec (from Order 12)
- field stop (D-12)
- enclosure: black box with a lid switch
- overview-camera geometry
- polariser slider for pre-imaging (R21)

**Acceptance:**
- docs/design/SWELL-design-v0.1.md with linked calculations.
- Parametric CadQuery sources in hardware/cad/ regenerate STEP and STL with one command.
- Renders.
- Wiring SVG (WireViz).
- LICENSES.md entries.
- Every decision logged.

**Depends on:** Orders 2, 12, 13.

### Order 5: BOM v0.1 + baskets [P0 · S1] [in-progress]
**Goal:** a live-priced BOM covering:
- reference hardware
- wet lab, host-lab variant only (D-26): reagents and consumables; equipment from the host
- calibration
- operations, including a raw-data drive

Every line has a primary and a fallback supplier, part number, price, date and lead time. Three baskets: H, C, W (D-14), plus T (tools: lab-provided or buy, D-28) and O (operations).

**Done (Life 2):** pm/BOM.csv v0.1 has 43 lines, and `software/sim/budget.py` computes docs/BOM.md:
- imager core £524–784, full build £727–1,072;
- project excluding tools £2,000–3,317;
- the objectives, camera, Pi 5 and tools are listed prices; 22 of 26 box lines are still estimates.

**Next:** price every estimate, and pull the box under the D-15 targets (core ≤ £500, build ≤ £650) with the D-30 levers. If it still misses, a target change goes to APPROVALS with the priced BOM.

**Acceptance:**
- pm/BOM.csv and docs/BOM.md.
- A pass/fail against D-15 (core ≤ £500, build ≤ £650, ceiling £1,000), computed by `software/sim/budget.py` (INV-18).
- Cost per gel and cost per mm² imaged, computed by code.
- A benchmark-only list.
- Print time and filament from the PrusaSlicer CLI on the real STLs.

**Depends on:** Order 4.

### Order 6: Software skeleton + simulator [P0 · S1] [open]
**Goal:** the `swell` package:
- **Hardware API** for the stage, both cameras, LEDs, pumps, sensors and interlocks, with a simulated backend.
- **Pi service:** FastAPI plus a picamera2 adapter, with a fake picamera2 for PC tests.
- **Pico firmware protocol** (Sangaboard-compatible), with a simulator.
- **Acquisition:** focus map, tiling, z-stacks, focal-shift correction, dose log.
- **Stitching:** phase correlation plus global optimisation, cross-checked with multiview-stitcher and Fiji.
- **Output:** OME-Zarr 0.5 writer plus OME-TIFF export; run folders and metadata (kit/06 + D-16).

**Acceptance:**
- pytest is green.
- A simulated run on a synthetic gel produces a valid run folder.
- The mosaic has ≤ 1 px residual against ground truth.
- The mosaic opens in napari (scripted) and exports to OME-TIFF that QuPath and Fiji open.

### Order 7: QC pipeline on synthetic gels [P0 · S1] [open]
**Goal:** the QC tools:
- E_macro from the dark-field overview, with an in-plane scale.
- Period-ratio E_ax map, paired and population (D-4), with the Z-disc ladder estimator on segments of ≥ 8 sarcomeres (D-33); A-band as secondary.
- **Transverse factor (D-32):** E_tr from the myofibril width ratio (forward-model fit with the bead PSF and the z-stack aspect), plus the nuclear diameter ratio where nuclei are present; and landmark E_land,ax / E_land,tr from local affine maps of myofibril centroids. **Axial and transverse factors are always reported separately**, never merged into one E.
- **Whole-gel strain map (D-34, Order 7a):** per-myofibril local E, anisotropy, fibril-vs-gel and distortion heatmaps, with flagged regions.
- Orientation test.
- Distortion curve (non-rigid registration, RMS error vs length).
- Resolution: bead PSF, FRC, Z-disc width with quadrature correction (D-5).
- E_z (axial expansion).
- Variance decomposition: repeats, semivariogram, mixed model.
- Coverage and focus maps.
- One-page report plus JSON.

**Synthetic generator:** myofibril phantoms with:
- known SL distributions, E (including anisotropic and spatially varying fields) and Z-disc widths;
- mirror flips, folds and tears;
- focus errors, bleaching gradients and stitching errors;
- Poisson–Gaussian noise and background.

**Acceptance (stated tolerances):**
- gel-mean E within ± 0.5%;
- local E map RMS error ≤ 1% at 10-sarcomere segments;
- a 2% anisotropy is detected (orientation slope p < 0.05 at n ≥ 200 myofibrils), and a 2% intrinsic axial-vs-transverse anisotropy is recovered within ±0.5% (D-32);
- E_tr bias ≤ 1% when the PSF and aspect are calibrated; its sensitivity to a 5% PSF error is stated in every report;
- distortion curve within ± 0.5% of truth;
- Z-disc width within ± 10 nm for discs ≥ 50 nm;
- 100% of flips detected;
- every injected failure flagged. The v1 simulation found two limits to close here: a direct crack detector in the post mosaic (a 1.5 µm tear is below the residual detector's ~2 µm limit), and adaptive landmark neighbourhoods (a +2.5% patch was flagged under the wrong label);
- a public ExM dataset is run too, if Order 2 finds a usable one.

### Order 7a: Whole-gel strain map, simulated (G0 deliverable) [P0 · S1] [believed-done: v1]
**Goal:** the owner's G0 deliverable (D-34): a per-myofibril local expansion-factor map across a whole gel, plus a distortion heatmap.
**Done (Life 2):** `software/sim/strain_map_sim.py` → docs/design/strain_map_v1.md and figs/strain_map_S0/S1/S1b/S2.png.
- Four synthetic gels. Three are development gels (good, planted defects, anisotropy; seed 7), and the detectors were fixed while looking at them. The fourth, S1b, is the blind gel: new seed, defects moved and resized, nothing tuned against it.
- Results are in strain_map_v1.md, blind result first.
- Every myofibril gets landmark and transverse factors; only those with ≥ 8 sarcomeres get an axial ratio (about half here).
- The transverse ruler fits each cross-section with the shape measured from its post z-projection. A boxy section assumed elliptical would be biased by 9–15%.
- Unit tests: software/tests/test_sim_rulers.py.
**Acceptance:**
- every check in strain_map_v1.md passes or is routed with a reason;
- the blind rerun (S1b) is reported as run, and its misses are routed to Order 7;
- an auditor reruns the command and gets the same numbers.
**Evidence:** docs/design/strain_map_v1.json and the figures.

### Order 8: Fold in batch-1 answers [P0 · S1] [believed-done]
**Goal:** apply the owner's S-1 answers (2026-10-09).
**Done (Life 2):**
- **Wet work** happens only at a host lab, with deliveries to it [personal detail removed] (D-26). [personal detail removed]
- **Off-site backup** is a private repo (D-27).
- **Tools** are lab-provided or buy (D-28).
- **Optics and camera** are our own parts [personal detail removed]; the sims and box budget were re-run (D-29, D-30, optics_v1, docs/BOM.md).
- **A-1** is yes: Buttons B + C are designed in Order 4.
- **A-2** is yes and widened: labs ranked and three enquiries drafted (D-31, OUTREACH O-1 to O-3, S-3).
**Remaining:** when replies arrive, pick the host and record its postcode district, then derive the delivery, waste and safety plan (→ Order 3).
**Acceptance:** every answer is reflected in the design, BOM and protocol plan, and every changed decision is logged.

### Order 10: Isolated toolchain [P0 · S1] [believed-done]
**Goal:** every free or open-source tool Stage 1 needs, installed per the coexistence rule (INV-17), logged in docs/SOFTWARE.md.
**Acceptance:**
- `python tools/smoke_tools.py` passes 25/25: 24 doing real work, 1 import-only (mpremote: no device until P1).
- No leaks: the automated check finds no new user folders and removes the Java registry keys that Fiji and QuPath create (D-25).
- System-wide needs are in S-2.

**Evidence:** .tools/smoke_report.json, docs/SOFTWARE.md, tools/setup_tools.sh, software/requirements.lock.

### Order 11: Kit audit [P0 · S1] [believed-done]
**Goal:** pm/AUDIT.md, with the fixes applied through ERRATA, DECISIONS, INVARIANTS, RISKS, ORDERS and APPROVALS.
**Acceptance:** each finding has evidence and a fix with a location, and every number reproduces from `software/sim/design_calc.py` (docs/design/calc_v0.md).

### Order 12: Virtual build A: optics and photons [P0 · S1] [in-progress]
**Goal:** settle the optics on paper.
**Done (Life 2, docs/design/optics_v1.md):**
- Parts named (D-29).
- Magnification and sampling: A 1.03× and B 0.84× Nyquist.
- Gibson–Lanni Strehl ≥ 0.98 over 0–12 µm.
- Tiles, time and data with the real FOV.
- Camera noise including 10-bit quantisation (use gain ≥ 4×).
- A first SNR with the out-of-focus pedestal. Worst case FAILS: 3.2× dose needed at 0.5% labelling, 2 µm myofibril.

**Remaining:**
- the rayoptics model;
- the full SNR and dose budget that resolves the pedestal FAIL (exposure × irradiance vs bleaching, deconvolution, dye titration E-17);
- the filter OD and size spec;
- confirming IMX296 QE, read noise and full well (F-23).
- **Optical layout:** rayoptics models of the OFM v7 optics module (finite RMS objective + tube lens) and the infinity alternative, using vendor lens files. Outputs: magnification, sampling vs Nyquist, field curvature and distortion across the IMX296 field, vignetting.
- **PSF:** Gibson–Lanni (MicroscPSF-Py) for a dry 0.65 NA objective into water: Strehl and lateral/axial FWHM vs depth 0–20 µm; the same for 0.4 NA. Produce a focal-shift table for the software.
- **Full SNR budget, 4× and 10×:**
  - signal over the labelled-fraction range from the literature;
  - out-of-focus pedestal;
  - autofluorescence;
  - bleed-through vs filter OD;
  - read noise;
  - photobleaching dose under D-12.

  These set the filter, LED, dye and exposure spec, and confirm the camera (D-7).

**Acceptance:**
- docs/design/optics_v1.md is generated by code.
- A pass/fail table covers:
  - Nyquist within 0.8–1.25×;
  - Strehl ≥ 0.8 over the specimen depth, or a stated mitigation;
  - SNR ≥ 10 at the low labelling bound at 4× within ≤ 200 ms exposure;
  - dose within budget.
- The chosen parts are named.

### Order 13: Virtual build B: mechanics and heat [P0 · S1] [open]
**Goal:** CAD fit-checks, tolerance stack-ups and a thermal estimate before anything is printed.
**Steps:**
- Fetch OFM v7 (pinned), build its STLs with OpenSCAD, and load them into the trimesh/manifold3d interference checker.
- Fit-check:
  - C12 chamber, dish holder and lid under the illumination arm;
  - objective working distance vs glass (Motic 40X WD 0.4 mm, 20X 0.55 mm);
  - the optics module lengthened by ≈ 20 mm for the f = 100 mm tube lens (D-29): camera position, feet height and the cube between objective and lens;
  - XY travel envelope: 7.9 mm needed for Track A and 8.0 mm for Track B, centring included (calc §3);
  - drip ring and sleeve;
  - cables;
  - overview-camera view cone.
- Monte Carlo stack-ups: kinematic repeatability, dish centring, z clearance, print shrinkage.
- Thermal estimate: LED, Pi and PSU heat, steady-state temperatures, focus drift from PLA expansion.

**Acceptance:**
- Zero interferences at nominal and at 3σ.
- Every stack-up margin ≥ 2σ.
- Drift < 1 DOF per hour after settling, or a mitigation.
- docs/design/mech_v1.md.

### Order 14: Virtual build C: fluidics, timing, data [P0 · S1] [open]
**Goal:**
- **Exchange model:** residual volumes, dilution per exchange, and exchanges needed per wash (e.g. Tris < 0.1 mM before staining; SDS removal). Gel diffusion times (τ ∝ L²) and stain uptake.
- **Flow and hardware:** flow limits that keep the gel seated (shear), weir sizing, waste per run, pump calibration plan.
- **Data:** tile count, scan time and data per gel for the Order 12 optics; compression ratio measured on synthetic data; storage plan.

**Acceptance:** docs/design/fluidics_data_v1.md; every time and volume feeds protocol v0.1 and the P4 design.

### Order 15: Virtual build D: end-to-end simulated run + fault injection [P0 · S1] [open]
**Goal:** a full run against simulated hardware: load → find gel → focus map → tiled z-scan → stitch → QC → report → paper draft.
**Faults to inject:**
- leak trip
- lid open
- motor stall
- camera timeout
- disk full
- power loss mid-run (resume)
- Pi network drop

**Acceptance:**
- The synthetic run completes and passes QC.
- Each fault reaches the safe state (INV-3, INV-4, INV-13) and the run resumes.
- Per-tile timing is within 20% of Order 14.

### Order 16: Paper pipeline [P0 · S1] [open]
**Goal:** run → manuscript draft, end to end on synthetic data. Components:
- **Methods** generated from the protocol, run metadata, instrument config, software versions and BOM cost.
- **Figures and QC tables** from the data.
- **Statistics plan,** pre-registered in git: units (prep → gel → myofibril), mixed models, thresholds, n and blinding → docs/paper/STATS_PLAN.md.
- **Results** with honest limitations; a claim linter (INV-15); templated numbers (INV-18).
- **References** via Manubot DOIs, with a CSL style per journal.
- **Data/code availability package:**
  - OME-Zarr/OME-TIFF data and QC JSON;
  - code release and environment lock;
  - CITATION.cff and a reviewer README;
  - a public-archive plan (BioImage Archive, IDR, Zenodo). Publishing goes to APPROVALS later.
- **AI-use disclosure and authorship** per journal policy: the owner is the author; Claude is disclosed, never listed.
- **Journal shortlist** with reasons → docs/paper/JOURNALS.md.
- **Public mosaic package (W-8):** a browser deep-zoom of the money shot, prepared with the data package. Publishing goes to APPROVALS at G3.

**Acceptance:**
- `python -m swell.paper build data/runs/<synthetic>` produces DOCX and PDF.
- A deliberate over-claim fails the build.
- Changing one QC JSON value changes every dependent number.

### Order 17: Wow plan: validation design and showcase [P0 · S1] [in-progress]
**Goal:** make the first paper striking at near-zero extra cost.
**Done:** ranked list W-1–W-12 in pm/IDEAS.md.
**Remaining acceptance:** docs/paper/VALIDATION.md defines:
- the "Chicken Standard";
- the positive-failure gel set: which defects, how many, expected QC response;
- blinding;
- replication: ≥ 3 birds × ≥ 3 gels;
- the cost-per-nanoscale-image method, from receipts and run logs;
- the census metrics;
- the **showcase design**: W-12 (wooden breast vs normal, run in P3, +2–4 gels) and W-7 (Supermarket Sarcomere Atlas, run after G4), with gel counts, metrics and the figure layout.

The adopted items are wired into Orders 3, 7 and 16.

### Order 9: Gate G0 pack: the Stage 1 gate [P0 · S1] [open]
**Goal:** docs/gates/G0.md. A fresh auditor confirms:
- every simulable check in Orders 12–16 passed, or its failure was fixed on paper;
- BOM, protocol v0.1, safety pack and budget are final;
- P1 orders and session cards are drafted.

**APPROVALS at the gate:** the whole-project budget, Baskets H/C/W, the safety pack, the waste route, the delivery address and the workspace.
**Acceptance:** the auditor finds no unresolved fails, and the owner approves G0.
**Depends on:** Orders 2–8 (including 7a) and 10–17.

---

## Stage 2 (ordering window, G0 → P1): orders

### Order 18: Final baskets to APPROVALS [S2] [open]
**Goal:** verified baskets with links, quantities, totals and lead times, plus the safety pack, waste route and delivery address.
**Acceptance:**
- Prices re-checked within 7 days of the request.
- Every line has a fallback.
- Totals sit inside the approved budget.
- W is marked "release at G1".

### Order 19: Delivery tracking + goods-in check [S2] [open]
**Goal:** pm/DELIVERIES.md tracks each line: ordered → shipped → received → checked against the BOM (photos in pm/inbox/). Discrepancies go to the owner as one-line supplier claims.
**Acceptance:** every BOM line is received and checked, or replaced.

### Order 20: Assembly prep while parts are in transit [S2] [open]
**Goal:**
- P1/P2 session cards (≤ 2–3 h each, 大白话).
- Print files: STL, PrusaSlicer profile, print time and filament.
- Calibration scripts: pixel size, PSF, flat-field, repeatability, dose curve.
- The Pi image recipe.

**Acceptance:** the cards pass a fresh-context dry run, and the scripts pass against the simulator.

---

## Stage 3 (P1 → G6): outline. Orders are written at each gate.
- **P1 Optics and motion → G1** (2–3 sessions):
  - XY repeatability measured.
  - Pixel size within 2% of the Order 12 model.
  - Bead PSF FWHM ≤ 1.3× theory.
  - Flat-field corrected.
  - Dose and bleach curve measured.
  - Blank-gel background within budget.
  - 5×5 mosaic stitched with ≤ 1 px residual.
  - Focus map works.
  - Remote operation end to end.
  - Opening the lid cuts the excitation LED and stops every motor in hardware, and the gear covers are on (INV-4, INV-19).
  - Overview distortion and in-plane scale calibrated.
  - Pre-image contrast chosen, DPC vs polariser (R21).
  - Pre-image PSF calibrated to ±2% with beads (the transverse factor depends on it, D-32), and centroid localisation precision measured (sets the strain-map noise floor).
  - Releases Basket W.
- **P2 Chamber and fluidics, water only → G2** (1–2 sessions; water beads are out of the design, D-67, D-69):
  - Temperature logged and focus drift characterised over 16 h (replaces the heater hold, D-9).
  - 100 exchange cycles with no leak, volumes within ± 5%.
  - The hardware leak latch stops everything.
- **P3 Chemistry by hand, 4× → G3** (3–6 sessions):
  - On the first real gel, the overview camera films its swelling and detects the plateau, and focus tracking holds during the swelling (both moved from P2 with the water beads, D-67, D-69).
  - The four checkpoints pass on ≥ 3 gels from ≥ 2 preparations, using:
    - period-ratio E_ax and transverse E_tr, reported separately (D-32);
    - the whole-gel strain map with flags (D-34);
    - the orientation test;
    - the distortion curve;
    - bead/FRC resolution;
    - the whole-gel scan.
  - Positive-failure gels are flagged.
  - Deliver the money shot, the QC reports and a generated paper draft v1. Submission is a separate approval.
- **P4 Automation → G4 = Button A** (~2 sessions):
  - Washes, staining and water exchanges run on the machine.
  - 3 consecutive unattended runs pass QC.
  - One button yields images + QC + paper draft.
- **P5 10× → G5** (~3 sessions):
  - E 8–10× with isotropy passing.
  - Effective resolution from beads/FRC ≤ ~85 nm; Z-disc width reported, not gated (D-5).
  - Uses a 20×/0.4-class objective.
- **P6 Rebuild package and release → G6** (~2 sessions + rebuild):
  - Build guide.
  - Receipts-based cost audit within ± 15%.
  - CAD and installer.
  - QC reference dataset.
  - An independent rebuild passes the **same QC thresholds**.
  - Licence, name, release plan; paper submission via APPROVALS.
- **Wet Module (Button B):** only if A-1 = yes. Interface designed in Stage 1; built after G4 with a signed risk assessment.
