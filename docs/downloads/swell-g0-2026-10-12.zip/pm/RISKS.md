> **Lab only.** The reagents, amounts and steps in this file are design notes for a laboratory with a fume hood,
> working under its own risk assessments. They are not a method to follow. Each reagent's hazards and handling:
> `SAFETY.md`.

# RISKS: register

Seeded from kit/09 (R1–R17), updated, extended with R18–R28 by the Life 1 audit and R29–R31 in Life 2. L/I = likelihood/impact (L/M/H). Owner: Claude unless stated. Burn the top risks down with the cheapest experiment that settles each one.

| ID | Risk | L/I | Cheapest de-risking move | When | Status |
|---|---|---|---|---|---|
| R1 | No host lab accepts the CMR work on workable terms (fume hood, CMR permission, waste route, deliveries for an individual). Home was ruled out by the owner (D-26). | M/H | Three parallel enquiries (O-1 to O-3, S-3); university-visitor route; [personal detail removed] | P0 | open: top 3 |
| R2 | Signal too weak after expansion (E³ dilution, uncooled camera) | L/H | First pass gives SNR 12–42 at 4× (calc §6); full budget in Order 12; bead and dye tests in P1 | P0–P3 | reduced |
| R3 | Leak from the vessel onto upward-facing optics | M/H | Water-only tests with optics shielded; drip ring and sleeve; hardware leak latch (INV-1, INV-3) | P2 | open |
| R4 | Gel drifts, flips, folds or gets sucked out during exchanges | H/M | Blank-gel trials (water beads left the design, D-69); PLL mount, mesh guard, slow flow; chiral mark detects flips (D-11) | P2–P3 | open |
| R5 | Isotropy worse than published (chicken tissue) | M/M | Axial and transverse factors plus the whole-gel strain map from the first gel (D-32, D-34); tune fixation and denaturation | P3 | open |
| R6 | Post-mortem damage in supermarket chicken | M/M | Freshest available vs an older pack; slaughter date from a butcher; record pack dates | P3 | open |
| R7 | Thermal drift of the printed flexure stage | M/M | Log focus vs temperature; no on-stage heater (D-9); electronics outside the optical box | P1–P2 | reduced |
| R8 | Widefield blur in thick 10× gels | M/M | Keep specimens thin; test deconvolution | P5 | open |
| R9 | Sodium acrylate purity makes expansion poor or variable | M/M | High-purity SA, reject yellow; TREx-style recipe; fume-hood neutralisation fallback (D-21) | P3 | open |
| R10 | Parts vanish or prices drift, breaking the "same cost" claim | M/M | Primary and fallback supplier on every line; re-price at G6 | P0, P6 | open |
| R11 | A life is cut off mid-work and loses context | H/M | Ledger first, incremental ledger writes, commit after each step | all | controlled |
| R12 | Scope creep from new ideas | H/M | IDEAS inbox; detailed orders only for the current stage | all | controlled |
| R13 | Works in simulation, fails on the bench | M/H | Physical-evidence rule from G1 (INV-12) | all | open |
| R14 | Licence breach when forking open hardware or software | L/M | LICENSES.md kept from Order 1; confirm OFM licence variants (F-16) | P0 | open |
| R15 | Patent exposure if commercialised | L/H | Private and experimental use exemptions; professional freedom-to-operate check before any sale (F-14) | P6 | open |
| R16 | Expanded gels invisible to the overview camera | M/M | Dark-field ring on a black background; optional fluorescent beads | P1–P2 | open |
| R17 | Too many tiles or too much data per gel | L/M | 1.5 mm punch: 759 tiles/plane, 24 GB, 1.2–2.1 h (calc §3); compression; data drive | P0 | reduced |
| R18 | Photobleaching from repeated exposures (z-planes, overlap, flooding, autofocus) | M/M | Field stop, focus map, dose log (D-12); bleach curve at G1 | P1 | open |
| R19 | Background (excitation bleed-through, autofluorescence, out-of-focus light) erodes contrast | M/M | Full budget and OD spec (Order 12); blank-gel test at G1 | P0–P1 | open |
| R20 | SWELL's own camera/stage service slips (no OFM software reuse) | M/M | Build against the simulator now (Order 6); vendor states picamera2 support (F-5) | P0–P1 | open |
| R21 | The rulers need usable pre-expansion images. At SL 1.69 µm label-free striation contrast is small in every mode; the axial ruler needs q = m·√N ≥ 1.2 for 1% per fibril at 10 sarcomeres (preimage_v1). The transverse ruler is PSF-sensitive (5% PSF error → 1.2–3.0% bias, D-32) | M/H | DPC with 4 oblique LEDs (predicted m ≈ 2.3%, q ≈ 10, every orientation; D-46); go/no-go measured on day 1 of P1; flat-fielding fixed the slope failure (0.95% → 0.28%); fallbacks circular polarisers (matched λ/4) then a fluorescent pre-label; bead-calibrate the PSF to ±2% | P1–P3 | open: top 3; mode chosen on paper |
| R22 | PLA flexures drift or creep near heat sources (Pi, LEDs) | M/M | Electronics outside the optical box; thermal estimate (Order 13); drift log | P1 | open |
| R23 | Spherical aberration of a dry 0.65 NA objective into water cuts peak signal and axial resolution | L/M | Gibson–Lanni gives Strehl ≥ 0.98 over 0–12 µm (optics_v1); bead check at G1 | P0 | retired on paper; G1 confirms |
| R24 | Reagent shelf life vs ordering window | M/M | Basket W released at G1 (D-14) | Stage 2 | controlled |
| R25 | Paper claims exceed QC | L/H | Claim linter and generated numbers (INV-15, INV-18) | P0 onward | controlled once Order 16 is done |
| R26 | Scan time (1–2 h) lets gels drift or dry | M/M | Lid on; drift fiducials; re-image the first tile at the end | P1–P3 | open |
| R27 | Triton X-100 supply restricted (REACH authorisation list) | M/L | Confirm UK status (Order 2); alternative detergent | P0 | open |
| R28 | Data loss: raw data on one SSD | L/H | Code and docs are pushed off-site every life (private repo, D-27); bundle to C: (D-18); raw-data drive in Basket H | P0–P1 | reduced |
| R29 | The box is over the D-15 targets: core £524–784 vs ≤ £500, build £727–1,072 vs ≤ £650; the top of the range breaks the £1,000 ceiling (22 of 26 lines still estimated) | M/M | Order 5 prices every line and pulls the D-30 levers (coloured-glass emission filter, generic tube lens, generic 20×); if it still misses, a target change goes to APPROVALS | P0 | open: top 3 |
| R30 | Widefield out-of-focus pedestal: SNR 10 needs 0.81–1.58% of amines labelled at 100 ms (0.41–0.79% at 200 ms); a pan-ExM-strength stain is estimated at ≈ 1.4% (0.30–9.6%), the kit's 2 µg/mL at ≈ 0.14% (labelling_v1) | M/M | Stain at 20 µg/mL or more: titrate 6/20/40 µg/mL (E-22, D-49), 200 ms exposures; then irradiance, a brighter dye or pedestal deconvolution *Hazards beside this step (lab only; from the supplier SDSs listed in `SAFETY.md`): DMSO (no hazard class; see its row). Control: gloves, because DMSO carries the dissolved dye through skin; no dye is chosen yet, so read its own SDS once one is. Waste: the lab's hazardous-waste route; nothing down the drain.* | P0–P3 | open: numbers on paper; the titration decides |
| R31 | Short myofibril fragments: only ~52% gave ≥ 8-sarcomere segments in the simulation (depends on the prep) | L/M | Gentle homogenisation (Order 3); short fragments still feed the landmark and width rulers | P3 | open |
| R32 | Pre↔post matching fails where the gel folds, tears or carries debris, so a fibril is compared with the wrong partner | M/M | Matching by rotation/translation voting, mirror check, local-affine prediction and one-to-one assignment; coverage-hole and non-affine flags; tested blind on S3 (red team) | P3 | open: see strain_map_v2 S3 score |
| R33 | The gel keeps swelling or shrinking during the ~2 h post scan, which reads as a gradient in raster order | M/M | Clock tile re-imaged every 50 tiles; every post object brought back to the reference time (strain_map_v2 S4) | P2–P3 | mitigated on paper; measured at G2 |

- **R29 correction (2026-10-11, runner life 18, D-78):** R29's figures are totals of typed estimates and its "over the D-15 targets" is a comparison drawn from them; both are withdrawn. A total now sums listed lines only (a floor, `docs/BOM.md`), and no target comparison is drawn until every line is priced. The risk itself (the box may miss D-15) stays open, unmeasured.
