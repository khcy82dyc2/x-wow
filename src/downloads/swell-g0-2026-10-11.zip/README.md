# SWELL: G0 design package, v0.2.0 (2026-10-11)

SWELL is a design for an automated expansion-microscopy (ExM) imager, meant to be cheap. A hydrogel
would swell a specimen about 4-10x, so that, on paper, an objective of NA 0.65 could resolve about 108 nm in
the original specimen at 4.5x expansion, and one of NA 0.40 about 79 nm at 10x (Rayleigh
criterion, `docs/design/calc_v0.md`); supermarket chicken myofibrils would carry their own rulers, so
every gel could check its own expansion. None of it has been built or measured.
This zip is the desk-stage project, given away; what it leaves out, and why, is listed under Status.

## Status: read this first
- **Stage G0 (desk stage). Never built.** No part was bought, printed or wired; no gel was ever made.
- **Every result in here is simulated** (software/sim/ -> docs/design/, data/sim/). Nothing was measured
  on a real machine. Treat every number as a prediction until someone builds it.
- Facts checked against sources are listed with their verdicts in `pm/VERIFIED_FACTS.md`.
- **Costs: most lines are not yet priced.** Only lines whose price was read on a supplier page carry a price
  (`pm/BOM.csv`, `docs/BOM.md`); every total is a floor of those lines alone, and no total is compared with a
  cost target (D-78, 2026-10-11). Cost ranges and target comparisons in older records under `pm/` (decisions,
  risks, orders, audit) were built from typed estimates and are withdrawn; they stay as history.
- Personal details of the owner were removed from the private project files before release; each removal
  is marked `[personal detail removed]` (postcodes as `[postcode removed]`). The removed lines concern the owner's own
  equipment, circumstances and schedule, and where the owner planned to work, not the SWELL design.
- **Chemistry only in a laboratory.** Several of the gel reagents are carcinogens, mutagens or reproductive
  toxicants (CMR substances). The chemistry belongs only in a laboratory with a fume hood, under that lab's own safety rules
  and risk assessments. This package holds no wet-lab protocol: where the records mention reagents, amounts or
  steps, they are design notes, not a method to follow, and each such file opens with a "Lab only" note.
  `SAFETY.md` gives the hazards of each hazardous reagent in its table as read from a named supplier's safety data
  sheet (cited with its revision date, all read on 2026-10-10; none yet for the dye, poly-L-lysine or PBS), their
  handling, the waste route and the instrument's safety rules. In this
  copy, each record step that gives reagent amounts has its hazards beside it.
- **Not included: the original brief (`kit/`).** It planned the gel chemistry at home, a plan withdrawn on
  2026-10-09 (`pm/ERRATA.md` E-18, `pm/DECISIONS.md` D-26), and that plan runs through its workspace,
  equipment, protocol, sourcing and risk files. Its design and QC were revised since: see `pm/AUDIT.md`,
  `pm/DECISIONS.md` and `docs/design/`. The records still refer to the brief's files (`kit/08`, "Kit 05" and so
  on) and to a project folder that holds no protocol yet (`protocols/`). The first version of this package
  (2026-10-09) included the brief.
- **Also left out of this copy, and marked where they stood:** from `pm/DECISIONS.md`, D-31 (labs near where
  the owner planned to work), D-51 and D-53 (the X-WOW videos page and its comment wall), D-56 (the slide
  game), D-57 to D-64 (the AI agent that runs X-WOW, its accounts and channels, hosting for another X-WOW
  project, and taking parts of the live site down), and D-65 and D-67 (decisions about this package and the
  website; D-69 restates what they decided about SWELL); rows AU-26 and AU-34 of `pm/AUDIT.md`, row F-9 of `pm/VERIFIED_FACTS.md` and one schools idea in
  `pm/IDEAS.md`. The private records keep them.
- Some records cite project files that are not in this zip: anything under `pm/` other than the files listed
  under What is inside (for example the record of the safety data sheets read, with their hashes, audits, site
  notes, archived originals and working notes such as `pm/OPEN_FINDINGS.md`). Each safety data sheet's code and
  revision date are in `SAFETY.md`.
- Where the records disagree with `pm/ERRATA.md`, a later decision or this README, the later text wins. Any
  line saying results or IP stay with the owner is superseded by this free release (D-35, D-37; licence map
  below).
- Written, designed and simulated by an AI (Claude by Anthropic, via Claude Code), working from the owner's
  original brief and orders. The project stopped before its first gate (G0) was passed, and the checks were
  run by fresh AI sessions, not by an independent person. Check the code yourself.

## What changed in this version
After a fresh AI review of v0.1.0-g0 (2026-10-09; another Claude instance, not a person), see
`docs/design/strain_map_v2.md` first:
- **Red-team test:** gel S3, built by a separate AI agent from the data format alone and scored by its own
  script (`docs/design/s3_frozen_68194b0.json`). The pipeline now matches pre to post objects itself. Results are
  published as scored, failures included: the transverse ruler is biased about -18% by a blur shape it does not
  model (true blur widths do not fix it), and small local expansion changes go unflagged. Since then the
  anisotropy call is blocked while the transverse and landmark rulers disagree by more than 3% (development fix).
- **Axial ruler:** end Z-discs of broken fragments ignored (the v1 -0.1% bias is gone on the development gels);
  flat-fielding of the pre profile; anisotropy and stretch calls by effect size instead of "CI excludes 0".
- **Pre-image:** a go/no-go defined and tested in simulation (q = m*sqrt(N) >= 1.2) and the physics of each mode
  (`docs/design/preimage_v1.md`): DPC with four oblique LEDs chosen.
- **Protocol decisions (lab only):** the reference pre-image moves to after gelation, with the gap measured on the first gels (E-21);
  stain titration 6/20/40 ug/mL (E-22, D-49; the reason is the dye-density estimate in
  `docs/design/labelling_v1.md`, which still names the older 2/6/20). The dye goes on in DMSO, which carries it
  through skin: gloves (`SAFETY.md`).
- **Safety (lab only):** `SAFETY.md` cites a named supplier's SDS for each hazardous reagent in its table (GB format
  wherever one could be opened; none yet for the dye, which is not chosen, poly-L-lysine or PBS) and HSE's GB
  mandatory classification list; imidazole, the rigor buffer's reproductive toxicant, is added;
  each record step that gives amounts has its hazards beside it; F-8 (re-read from the protocol itself) and F-13
  (checked against the GB list) are updated in this copy of `pm/VERIFIED_FACTS.md`; every BOM line carries its
  safety rating, from the maker's own document where the BOM names a part (`pm/BOM.csv` column `safety_rating`,
  `docs/BOM.md` section "Safety ratings").
- **Drift:** a clock tile re-imaged every 50 tiles corrects scan-time drift.
- **Tool:** `software/swell_ruler`, the pipeline as a standalone package with an image front-end and tests.
  Its demo scores itself PASS/FAIL: the axial factor passes; the transverse factor and the planted patch fail.
- **Credit:** `docs/design/prior_art.md` (Zhang et al. 2016 and Sheard et al. 2019 got there first).
- **Package:** the original brief (`kit/`) is left out, and so are a few decisions and rows, each marked
  where it stood (Status, above). The licence texts and the X-WOW name and logo are labelled with their own
  terms (Licences).
- **Rebuilt for audit A-11 (2026-10-10, D-69):** water beads are out of the design (`pm/BOM.csv`, `docs/BOM.md`,
  `SAFETY.md`; P2's swelling check moves to the first real gel); the stepper gears get printed covers (H-27),
  the pumps enclosed roller heads, and opening the lid now stops every motor as well as the LED (a second
  switch pole drives a relay that opens both motor rails, INV-19); the pumps get a 12 V rail (H-28, whose
  maker warns it can get hot enough to burn; its placement inside the instrument isn't designed yet); the
  BOM's line table gives part numbers. The tool's README credits Chen, Tillberg & Boyden 2015 and GelMap and
  narrows what it claims to add. Every figure carries a SIMULATION
  label. `docs/design/prior_art.md` marks its wrong line about myofibril rulers and credits Chen, Tillberg &
  Boyden 2015 where the pairing is pitched. The red-team scripts carry no local paths, and `s3_gen.py` writes
  its gzip files with no time stamp, so two runs give identical files. Reports say synthetic data "tests" the
  pipeline, not "proves" it, and AI reviews are named as AI. `swell_ruler` 0.1.2 changes wording and messages
  only (it says when it skips a figure or a TIFF file, and labels the demo's figure); what it computes is
  unchanged.
- **Rebuilt for N-20 (2026-10-11, D-75):** the build needs no hot tools. The 3D printer and the soldering iron leave
  the BOM: a print service prints the parts (H-29), and every join the builder makes is a screw or lever terminal
  (H-31) or a ready-made plug-in lead, with no soldering and no crimping. The pumps' 12 V rail is now an enclosed
  DIN-rail converter with screw terminals (H-28, MEAN WELL DDR-60G-12), mounted out of reach in a closed electronics
  compartment that opens only with a screwdriver (H-30, not drawn yet). Prices and safety ratings change with it
  (`pm/BOM.csv`, `docs/BOM.md`).
- **Prices (2026-10-11, D-78):** a typed estimate is not a price. `pm/BOM.csv` keeps a price only for lines read on a
  supplier page, and `docs/BOM.md`'s totals add those lines alone, rounded down, with how many lines they cover. H-21
  is priced from its shop page; H-10's price came from a search result, so it is not yet read (`pm/VERIFIED_FACTS.md`,
  F-30). `pm/RISKS.md` R29 carries a dated correction.

## What is inside
| folder | files |
|---|---|
| `LICENSES.md` | 1 |
| `LICENSES/` | 2 |
| `README.md` | 1 |
| `SAFETY.md` | 1 |
| `data/` | 4 |
| `docs/` | 31 |
| `pm/` | 9 |
| `software/` | 31 |
| `tools/` | 4 |

- `SAFETY.md`: each hazardous reagent's hazards from its supplier's SDS (cited), their handling, the waste route and
  the instrument's safety rules (lab only).
- `pm/`: audit, decisions log, errata, invariants, risks, verified facts, orders, ideas, and the BOM with each
  part's safety rating (CSV; most lines not yet priced).
- `docs/`: design reports, figures, BOM, toolchain notes. `software/`: simulation code and tests. Every figure in
  `docs/design/figs/` is a simulation output, labelled SIMULATION on the image and in its PNG metadata by
  `software/sim/simlabel.py`. `strain_map_v2_S3.png` is frozen as first scored (commit 68194b0): its title's
  "independent generator" means a separate AI agent; `strain_map_v2_S3_rerun.png` is the current pipeline.
- `data/sim/`: per-myofibril tables from the strain-map simulation. `tools/`: the toolchain scripts.
- `software/swell_ruler/`: the ruler pipeline as a pip-installable tool (`pip install ./software/swell_ruler`).
- `software/redteam/`: the red-team gel S3 (generator, validator, scorer), written by a separate AI
  agent that read only `docs/design/obs_schema_v1.md`.

## Rebuild the simulations
Python 3.12. The full pinned environment is `software/requirements.lock` (Windows, 250 packages);
the simulations themselves need only numpy, scipy, matplotlib, MicroscPSF-Py (for optics_v1.py) and pytest.

```
python -m venv .venv
.venv/bin/pip install numpy scipy matplotlib MicroscPSF-Py pytest   # Windows: .venv\Scripts\pip
python software/sim/design_calc.py      # -> docs/design/calc_v0.md, calc_v0.json
python software/sim/optics_v1.py        # -> docs/design/optics_v1.md, optics_v1.json
python software/sim/strain_map_sim.py   # -> docs/design/strain_map_v1.*, figs/, data/sim/*.csv
python software/sim/budget.py           # -> docs/BOM.md, docs/design/budget_v1.json
python software/redteam/s3_gen.py       # -> data/sim/S3/ (the red-team gel; about 100 s)
python software/sim/strain_map_v2.py    # -> docs/design/strain_map_v2.*: every gel run blind, S3 scored by the red team's scorer
python software/sim/preimage_v1.py      # -> docs/design/preimage_v1.*: contrast go/no-go and pre-image physics
python software/sim/labelling_v1.py     # -> docs/design/labelling_v1.*: dye density vs SNR (R30)
python -m pytest software/tests -q
cd software/swell_ruler && python -m pytest -q
```
`tools/setup_tools.sh` rebuilds the whole isolated toolchain (Windows + Git Bash; its paths assume the
project sits at D:/SWELL, so edit `tools/env.sh` / `tools/env.ps1` for your machine).

## Licences
| what | licence |
|---|---|
| Docs, text and data (everything not listed below) | CC0 1.0 Universal (`LICENSES/CC0-1.0.txt`) |
| Hardware design files: the bills of materials (`docs/BOM.md`, `pm/BOM.csv`) and any CAD, drawings or BOMs added later | CERN-OHL-P v2 (`LICENSES/CERN-OHL-P-2.0.txt`) |
| Software (the simulation code in `software/`, the scripts in `tools/`) | CC0 1.0 Universal |
| The licence texts in `LICENSES/` | their publishers' own terms; copied unmodified (CERN's text says "The CERN-OHL-P is copyright CERN 2020. Anyone is welcome to use it, in unmodified form only.") |

- **The X-WOW name and logo are trade marks, not covered by either licence;** the logo is a registered UK
  trade mark (UK00003425680). This zip contains no logo artwork.
- Short quotations from other people's papers (for example in `docs/design/prior_art.md`) stay theirs and
  are cited where they appear.
- Any part later forked from the OpenFlexure Microscope keeps OpenFlexure's own licence: its repository's
  License file is CERN-OHL-S v2 (strongly reciprocal), checked 2026-10-09 (`LICENSES.md`). This zip contains no
  OpenFlexure files.
- Third-party tools and packages keep their own licences (`LICENSES.md`).
- **Patents:** expansion microscopy is covered by MIT patents (e.g. US 10,309,879 B2; US 10,317,321 B2;
  US 11,408,890 B2). Commercial use may need a licence from MIT; research exemptions vary by country.
  These licences grant no patent rights held by others. This is not legal advice.
- **No warranty.** Provided as is. If you build it, its safety and legality are yours: the chemistry needs
  professional-user access (a lab), because UK REACH restricts the reagents.
- This package is a dated public disclosure (2026-10-11; first version 2026-10-09), published so the design
  is prior art. The first version is no longer offered: it carried the withdrawn home plan (pm/ERRATA.md E-18).
- Trademarks belong to their owners; naming a product implies no endorsement.

Published by X-WOW: https://x-wow.com
