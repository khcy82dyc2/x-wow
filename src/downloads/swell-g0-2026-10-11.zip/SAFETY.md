# SWELL: safety for the chemistry and the instrument

**The gel chemistry happens only in a laboratory with a fume hood, under that lab's own induction, risk assessments
and waste route.** Several of the reagents are carcinogens, mutagens or reproductive toxicants (CMR substances). This
package holds no wet-lab protocol: where its records mention reagents, amounts or steps, they are design notes, not a
method to follow, and each such step has its hazards beside it.

The table, the sources and the list below are copied from the safety section of the SWELL page on x-wow.com when this
zip was built. Each chemical's hazard is read from a named supplier's safety data sheet (SDS), cited in its row and
listed under "Safety data sheets read", all read on 2026-10-10; raw chicken has no sheet.
Suppliers' sheets differ and change: check the current one for the product you use. This is a starting list, not a
risk assessment; the hosting lab's own assessment comes first. An AI read these sheets and wrote this table, and a
separate AI review re-checked it against them; no person has checked it.

| Reagent | Hazard, from the SDS cited where there is one | Handling: the project's notes, checked against the sheets |
|---|---|---|
| Acrylamide (40% solution) | Danger. May cause cancer and genetic defects (Cat. 1B); suspected of damaging fertility; damages organs, including the nervous system, through prolonged or repeated exposure; may cause an allergic skin reaction; harmful if swallowed; irritates skin and eyes. H302, H315, H317, H319, H340, H350, H361f, H372: the label of this 40% solution. It can be absorbed through the skin: the UK exposure limit in the sheet's section 8 carries the skin notation of HSE's EH40/2005. As a substance, HSE's GB list classes acrylamide toxic if swallowed (Acute Tox. 3, H301). · SDS: Fisher Scientific UK BP1402-1, rev. 2024-02-09 | Use it as a 40% solution, never as powder, and only in a fume hood (its sheet: "Use only under a chemical fume hood"), with double nitrile gloves, goggles and lab coat. |
| Bis-acrylamide (solution) | May cause genetic defects: HSE's GB mandatory classification list, legally binding in Great Britain, has it as Muta. 1B (H340; GHS08, Danger), in legal effect since 2025-09-23, with suppliers to comply by 2027-03-23. Fisher's SDS lists the bis in its solution (under 5% in water) as toxic if swallowed (H301), harmful in contact with skin (H312), may cause genetic defects (H340), may cause cancer (H350), suspected of damaging fertility or the unborn child (H361) and causes damage to organs through prolonged or repeated exposure (H372), yet leaves the solution itself unclassified; that sheet is older than the GB entry. · SDS: Fisher Scientific UK BP1404-250, rev. 2023-10-13 | Treat as CMR. Use it as a solution. |
| Formaldehyde (16%, methanol-free) | Danger. May cause cancer (Cat. 1B); suspected of causing genetic defects; harmful if swallowed, in contact with skin or if inhaled; may cause an allergic skin reaction; irritates skin, eyes and airways. H302 + H312 + H332, H315, H317, H319, H335, H341, H350: the label of this 16% solution. As a substance, HSE's GB list classes formaldehyde fatal if inhaled (Acute Tox. 2, H330) and corrosive to skin (Skin Corr. 1B, H314), in an entry revised with legal effect from 2025-02-15; this sheet's section 3 still gives the older component classes. · SDS: Avocado Research Chemicals (Thermo Fisher Scientific) 43368, rev. 2026-04-13 | Methanol-free sealed ampoules, opened only in a fume hood; small volumes. The overnight anchoring step runs in a sealed box. |
| APS (ammonium persulfate) | Danger. Oxidiser: may intensify fire; may cause allergy or asthma symptoms or breathing difficulties if inhaled; may cause an allergic skin reaction; harmful if swallowed; irritates skin, eyes and airways. H272, H302, H315, H317, H319, H334, H335 · SDS: Fisher Scientific UK BP179-25, rev. 2024-09-09 | Weigh into closed, pre-tared vials with minimal dust; keep away from combustible materials. Stock made as 10% w/v in batches of at least 1 g, aliquoted and frozen. |
| TEMED | Danger. Highly flammable liquid and vapour; causes severe skin burns and eye damage; harmful if swallowed or inhaled. H225, H302 + H332, H314 · SDS: Fisher Scientific UK BP150-20, rev. 2023-10-13 | Only in a fume hood (its sheet: "Use only under a chemical fume hood"); small quantities, kept closed, stored in a flammables cabinet away from heat and ignition sources. |
| Sodium acrylate | Warning. Very toxic to aquatic life (H400) and toxic to aquatic life with long-lasting effects (H411). This supplier's SDS gives no health hazard class, though its first-aid section says contact may cause mild irritation. Purity matters. · SDS: Glentham Life Sciences GX3080, rev. 2026-05-12 (EU format) | Weighed as a powder in closed vials. Choose high purity and reject yellow solutions. Collect as waste; never down the drain. |
| Acrylic acid and sodium hydroxide (only to make sodium acrylate in the lab, a fallback) | Danger. Acrylic acid: flammable; causes severe skin burns and eye damage; harmful if swallowed, in contact with skin or if inhaled; irritates airways; very toxic to aquatic life (H226, H302 + H312 + H332, H314, H335, H400). Sodium hydroxide: causes severe skin burns and eye damage; may be corrosive to metals (H290, H314). · SDS: Fisher Scientific UK 164250010, rev. 2023-09-22; Fisher Scientific UK BP359-500, rev. 2023-10-13 | Fume hood only. Neutralising one with the other gives off heat. A fallback in the project's notes (D-21), not the plan. |
| SDS (sodium dodecyl sulfate) buffer at 95 °C | Danger. Causes serious eye damage; harmful if swallowed; irritates skin; harmful to aquatic life with long-lasting effects. H302, H315, H318, H412. At 95 °C, also a scald hazard. · SDS (the solid): Fisher Scientific UK BP166-500, rev. 2023-10-13 | Goggles. Screw-cap or lid-lock tubes in a lidded heat block, never on the microscope stage. |
| DMSO (dye solvent) | Not classified as hazardous under GB CLP; a combustible liquid. Its SDS warns that it readily penetrates skin and may carry other dissolved chemicals into the body. · SDS: Fisher Scientific UK BP231-100, rev. 2023-10-13 | Always gloves; away from heat. |
| Triton X-100 | Danger. Causes serious eye damage; harmful if swallowed; toxic to aquatic life with long-lasting effects. H302, H318, H411 · SDS: Fisher Scientific UK BP151-100, rev. 2024-04-04 | Goggles. Collected as waste, never down the drain. |
| Imidazole (rigor buffer) | Danger. May damage the unborn child (Repr. 1B, as in HSE's GB mandatory classification list); causes severe skin burns and eye damage; harmful if swallowed; the solid may form combustible dust in air. H302, H314, H360D · SDS: Fisher Scientific UK BP305-50, rev. 2023-10-13 | Treat as CMR. Weigh and handle the solid only in a fume hood (its sheet: "Use only under a chemical fume hood"), with gloves and goggles. The lab's risk assessment must cover a reproductive toxicant. |
| Sodium azide | Not added in any gel step. The calibration beads (BOM line C-03) may bring it in: Thermo Fisher's FluoSpheres user guide says they are sold "in most cases containing 2mM azide or 0.02% thimerosal as a preservative"; their North American SDS (F8803, rev. 2024-08-16) lists no hazard. | Gels are stored in water in the lab's fridge instead. Bead suspensions leave by the lab's waste route: their SDS says to "avoid discharge into drains and waterways whenever possible". |
| Raw chicken | Campylobacter and Salmonella risk until fixed. | Food-hygiene practice; dedicated tools. |

Also in the design, with no hazard class in the SDS read: EGTA (Avocado Research Chemicals A16086, rev. 2024-02-11),
Tris base (Fisher Scientific UK BP152-1, rev. 2023-10-13), sodium bicarbonate (BP328-500, rev. 2023-10-13) and sodium
chloride (BP358-1, rev. 2026-02-06), all GB format. No dye is chosen yet (an NHS-ester dye of the Alexa Fluor 488 or
ATTO 488 class, dissolved in DMSO), and no SDS was opened for poly-L-lysine or PBS: use the sheet for the product you
use.

## Safety data sheets read
Naming a supplier is not an endorsement, and nothing here is a place to buy: these are the sheets that could be
opened, from suppliers the project's notes name, plus one UK supplier for sodium acrylate.

- Acrylamide Solution, 40%, BP1402-1: SDS by Fisher Scientific UK, GB format, revision 9, 2024-02-09. fishersci.co.uk (PDF) (https://www.fishersci.co.uk/chemicalProductData_uk/wercs?itemCode=BP1402-1&lang=EN)
- Bis-Acrylamide Solution, BP1404-250: SDS by Fisher Scientific UK, GB format, revision 5, 2023-10-13. fishersci.co.uk (PDF) (https://www.fishersci.co.uk/chemicalProductData_uk/wercs?itemCode=BP1404-250&lang=EN)
- Paraformaldehyde, 16% w/v aqueous solution (formaldehyde 16% in water, no methanol in its listed composition), 43368: SDS by Avocado Research Chemicals (part of Thermo Fisher Scientific), GB format, revision 9, 2026-04-13. fishersci.co.uk (PDF) (https://www.fishersci.co.uk/chemicalProductData_uk/wercs?itemCode=11490570&lang=EN)
- Ammonium Persulfate, BP179-25: SDS by Fisher Scientific UK, GB format, revision 10, 2024-09-09. fishersci.co.uk (PDF) (https://www.fishersci.co.uk/chemicalProductData_uk/wercs?itemCode=BP179-25&lang=EN)
- N,N,N′,N′-Tetramethylethylenediamine (TEMED), BP150-20: SDS by Fisher Scientific UK, GB format, revision 8, 2023-10-13. fishersci.co.uk (PDF) (https://www.fishersci.co.uk/chemicalProductData_uk/wercs?itemCode=BP150-20&lang=EN)
- Sodium acrylate, Glentham Life Sciences GX3080: SDS version 3.1 by Glentham Life Sciences (UK), written to EU REACH (EC) 1907/2006 and (EU) 2020/878, revision 2026-05-12. glentham.com (PDF) (https://www.glentham.com/en/products/product/GX3080/sds)
- Acrylic acid, stabilized, 164250010: SDS by Fisher Scientific UK, GB format, revision 11, 2023-09-22. fishersci.co.uk (PDF) (https://www.fishersci.co.uk/chemicalProductData_uk/wercs?itemCode=10163890&lang=EN) · Sodium hydroxide, BP359-500: SDS by Fisher Scientific UK, GB format, revision 13, 2023-10-13. fishersci.co.uk (PDF) (https://www.fishersci.co.uk/chemicalProductData_uk/wercs?itemCode=BP359-500&lang=EN)
- Sodium dodecyl sulfate, BP166-500: SDS by Fisher Scientific UK, GB format, revision 9, 2023-10-13. fishersci.co.uk (PDF) (https://www.fishersci.co.uk/chemicalProductData_uk/wercs?itemCode=BP166-500&lang=EN)
- Dimethyl sulfoxide, BP231-100: SDS by Fisher Scientific UK, GB format, revision 13, 2023-10-13. fishersci.co.uk (PDF) (https://www.fishersci.co.uk/chemicalProductData_uk/wercs?itemCode=BP231-100&lang=EN)
- Triton X-100, BP151-100: SDS by Fisher Scientific UK, GB format, revision 15, 2024-04-04. fishersci.co.uk (PDF) (https://www.fishersci.co.uk/chemicalProductData_uk/wercs?itemCode=BP151-100&lang=EN)
- Imidazole, BP305-50: SDS by Fisher Scientific UK, GB format, revision 9, 2023-10-13. fishersci.co.uk (PDF) (https://www.fishersci.co.uk/chemicalProductData_uk/wercs?itemCode=BP305-50&lang=EN)
- No hazard class: EGTA, A16086 (SDS by Avocado Research Chemicals, GB format, revision 3, 2024-02-11; fishersci.co.uk (https://www.fishersci.co.uk/chemicalProductData_uk/wercs?itemCode=11443097&lang=EN)); Tris base, BP152-1 (revision 10, 2023-10-13; fishersci.co.uk (https://www.fishersci.co.uk/chemicalProductData_uk/wercs?itemCode=BP152-1&lang=EN)); sodium bicarbonate, BP328-500 (revision 9, 2023-10-13; fishersci.co.uk (https://www.fishersci.co.uk/chemicalProductData_uk/wercs?itemCode=BP328-500&lang=EN)); sodium chloride, BP358-1 (revision 12, 2026-02-06; fishersci.co.uk (https://www.fishersci.co.uk/chemicalProductData_uk/wercs?itemCode=BP358-1&lang=EN)); all four by Fisher Scientific UK except EGTA, all GB format.
- The calibration beads (BOM line C-03), for the sodium azide row: FluoSpheres carboxylate-modified microspheres, 0.1 µm, yellow-green, F8803: North American SDS by Life Technologies, revision 3, 2024-08-16, no hazard listed; no GB sheet could be opened. thermofisher.com (PDF) (https://assets.thermofisher.com/TFS-Assets/LSG/SDS/F8803_MTR-NALT_EN.pdf) · The preservative: Thermo Fisher's FluoSpheres user guide, Pub. No. MAN0001849 Rev. B.0. thermofisher.com (PDF) (https://assets.thermofisher.com/TFS-Assets/LSG/manuals/mp05000.pdf)
- The skin notation in the acrylamide row: HSE, EH40/2005 Workplace exposure limits (Fourth Edition 2020): "Sk Can be absorbed through the skin. The assigned substances are those for which there are concerns that dermal absorption will lead to systemic toxicity." hse.gov.uk (PDF) (https://www.hse.gov.uk/pubns/priced/eh40.pdf)
- The legal baseline in Great Britain: HSE, the GB mandatory classification and labelling list (spreadsheet; its page last updated 22 September 2025): acrylamide 616-003-00-0 (Carc. 1B, Muta. 1B, Repr. 2, Acute Tox. 3 if swallowed, STOT RE 1 and others); N,N′-methylenediacrylamide 616-243-00-6 (Muta. 1B, in legal effect from 2025-09-23); formaldehyde 605-001-00-5 (Carc. 1B, Muta. 2, Acute Tox. 2 if inhaled, Skin Corr. 1B, Skin Sens. 1A and others; revised, with legal effect from 2025-02-15); imidazole 613-319-00-0 (Repr. 1B, Acute Tox. 4, Skin Corr. 1C); ammonium persulphate 016-060-00-6; TEMED 612-103-00-3; acrylic acid 607-061-00-8; sodium hydroxide 011-002-00-6. Sodium acrylate, SDS (the detergent) and DMSO have no entry under their CAS numbers. hse.gov.uk (https://www.hse.gov.uk/chemical-classification/classification/mcl-list.htm)

## Waste
Hazardous waste goes through the lab's licensed route, with records. Nothing hazardous goes down the drain or into
general waste.

## The instrument: never bypassed, in code or in design
- **Lid interlock:** opening the lid cuts the excitation LED and stops every motor (the steppers and the pumps) in hardware.
- **Moving parts:** the stepper gears sit under fixed printed covers and the pumps' roller heads are enclosed, so fingers and hair can't be caught.
- **Leak cutoff:** a leak trip cuts the pumps, any heater and the LED through a hardware latch that firmware can't clear.
- **Thermal cutoff:** any heater gets a hardware cutoff rated ≤ 50 °C near printed parts. Version 1 has no heater on the stage at all.
- **No override:** software never overrides these; there are no "force" flags.
- **Low voltage:** ≤ 24 V DC inside, from certified external supplies with fused rails. Never wire mains.
- **Liquids:** only the sealed sample vessel sits over the objective, with a drip ring, a sleeve and a leak sensor; no reservoirs above the optics or electronics.
- **Stage rules:** no CMR liquids, no gel casting and no 95 °C steps on the stage.
- **Light:** the high-power excitation LED runs only inside the closed box, and opening the lid cuts it; the white and oblique LEDs, which the interlock doesn't cover, must be ones their makers rate safe to look into. Never look into the excitation LED. No lasers and no ultraviolet source in the reference build. The laser pointer in the family experiment is separate from the instrument and has its own safety box (https://x-wow.com/swell/#laser-safety).

## The parts' safety ratings
Every BOM line's safety rating is in `pm/BOM.csv` (column `safety_rating`) and in `docs/BOM.md` (section "Safety
ratings"): read from the maker's own datasheet where the BOM names a part, or the rating the part must carry where it
names none.

## The law (UK), in short
UK REACH Annex XVII (entries 28-30) bars supplying CMR substances such as acrylamide and formaldehyde to the general
public, so the chemistry needs a laboratory. Research use only: no diagnostic claims, no human material, no live
animals. This is a summary, not legal advice; check the current rules where you are.
