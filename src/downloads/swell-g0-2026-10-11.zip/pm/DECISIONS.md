> **Lab only.** The reagents, amounts and steps in this file are design notes for a laboratory with a fume hood,
> working under its own risk assessments. They are not a method to follow. Each reagent's hazards and handling:
> `SAFETY.md`.

# DECISIONS (newest first)

Format: date · D-n · decision · why · alternatives rejected · reversibility. Audit refs: pm/AUDIT.md.

- **2026-10-11 · D-75 · N-20 (the owner's Order 7): the hot tools designed out of SWELL's build.**
  - **No owned printer:** the printed parts (H-01, H-17, H-20, H-27) come from a print service (H-29): the host lab's,
    a makerspace's or a commercial one. Priced from £0 (a lab service that charges only the filament, already in those
    lines) to £120 (one on-demand service's published US$0.35 per gram of PLA for about 0.38 kg, with import VAT; its
    page is dated 2021 and was read 2026-10-11): an estimate until the parts are sliced for grams.
  - **No soldering:** every electrical join is a screw terminal or a lever connector (H-31), and every part is chosen
    or required in a version whose leads its maker fits: the LED driver becomes Mean Well LDD-350HW (the wire version
    in the same datasheet, 22 AWG leads); the LEDs, pumps, lid switch, sensors and stepper boards carry the requirement.
  - **The regulator out of reach:** the Pololu D36V50F12 needed soldering (its header pins come loose, and its maker
    says thick wires should be soldered to it for high currents) and can get hot enough to burn, so H-28 becomes an
    enclosed DIN-rail DC-DC converter with screw terminals, MEAN WELL DDR-60G-12 (9–36 V in, 12 V 5 A out, IEC and
    UL 62368-1, cooled by free air, full load up to 60 °C ambient above 18 V input; datasheet of 2026-03-31). It sits
    on a TS35 rail inside a closed electronics compartment (H-30) that opens only with a screwdriver and only with the
    supply unplugged, with no opening a 2.5 mm wire can pass (IP3X). H-19's 5 V converter is required to be the same
    kind of enclosed module.
  - **Cost (software/sim/budget.py):** core £525–£786 → £568–£1,001; build £767–£1,112 → £806–£1,339; the tools
    basket £304–£334 → £90–£105 (a multimeter and hand tools). Most of the rise is the print service's high end.
  - **Why:** X-WOW's safety rules allow no surface hot enough to burn in anything a reader builds, and the owner's
    N-20 answer was to design the hot tools out and mount the regulator out of reach. Rejected: a designed mount for
    the bare Pololu board (it still needs soldering, and is bare whenever the compartment is open); and dropping the
    12 V rail for a second certified plug-in adapter (simpler, but it changes the power design beyond the order;
    noted in pm/IDEAS.md).
  - **The wording:** the SWELL page keeps "built in an equipped workshop or lab, by adults" until the owner decides
    whether to relax it.
  - **Reversibility:** full; the old pm/BOM.csv is in pm/archive/swell/2026-10-11-bom-before-n20/.
  - *(Correction 2026-10-11, the same life: "(IP3X)" above names a code from IEC 60529, a standard I could not
    open; the requirement is simply no opening wider than 2.5 mm, as pm/BOM.csv line H-30 now says.)*
  - *(Correction 2026-10-11, the same life, after its AI review: "every electrical join is a screw terminal or a
    lever connector" was too strong, because the builder also plugs in ready-made leads (jumper wires, ribbon cables,
    USB and fan plugs, the steppers' plugs). The claim is that every join the builder makes is a screw or lever
    terminal or a ready-made plug-in lead, with no soldering and no crimping. "Its header pins come loose" means
    they come as loose strips to solder on (Pololu: "are included"). And the print service's high end now counts
    about 0.43 kg, because OpenFlexure's own v7.0.0-beta5 high-resolution BOM lists 380 g of PLA and 20 g of black
    PLA (read 2026-10-11): core £568–£1,017, build £806–£1,354.)*

- **2026-10-10 · D-69 · Audit A-11 (runner life 8): the SWELL zip and the swell-ruler wheel rebuilt in one pass.**
  - **Water beads leave the design** (decided in D-67, carried out here). Their one use was a swelling check before
    any chemistry (P2); it moves to the first real gel in a laboratory (P3), with focus tracking during the swelling.
    Gone from pm/BOM.csv (C-05), the budget, the SWELL page's parts and safety tables, and the zip's SAFETY.md.
  - **Moving parts guarded by design:** printed covers over the stepper gears (H-27, an estimate from H-01's PLA
    price); pumps whose makers enclose the roller heads (H-23's spec); the lid microswitch (H-18) becomes two-pole,
    so opening the lid stops every motor as well as cutting the excitation LED (new INV-19; INV-13 now covers it; P1
    checks it). Rejected: a warning only (the hazard is designed out first; a warning is the last layer); a software
    stop (INV-13: hardware only).
  - **A 12 V rail for the pumps** (H-28): a Pololu D36V50F12 step-down regulator from the fused 24 V supply (maker's
    page, read 2026-10-10: 13.3–50 V in, 12 V ±4% out, typical maximum continuous output 2.3–6.5 A depending on input
    voltage, reverse-voltage, over-current, short-circuit and over-temperature protection); £38.40 incl. VAT at one UK
    shop that day (a price source, not a place to buy). The maker warns it can get hot enough to burn, so it sits in
    the closed electronics compartment, and its output to the pumps passes through the lid interlock and the leak
    latch. Sourced by an AI helper with each page's SHA-256 (pm/xwow/audits/life8-sourcing-2026-10-10.json). Named as
    the fallback: Pololu's cheaper D36V28F12 (US$24.95 at the maker; 2–3.3 A typical) if the chosen pumps draw under
    about 2 A together; no UK price for it could be opened. Rejected: an unbranded buck module (no maker's ratings to
    cite); 24 V pumps (a change to H-23 the audit didn't ask for, and the pumps aren't chosen yet).
  - **H-01's note:** the f100 optics module is not a stock OpenFlexure part: OpenFlexure's v7 high-resolution module
    takes a 50 mm tube lens (AC127-050-A), and its v7.0.0-beta5 build pages and source list no 100 mm version (read
    2026-10-10 by the same helper). A modified module has not been drawn; the BOM and the SWELL page now say so.
  - **Figures:** every PNG in docs/design/figs carries a strip above the figure, "SIMULATION · synthetic data, not a
    measurement", and the same words in its PNG text (software/sim/simlabel.py, which the simulations now call, so a
    rerun labels too); the figures' own pixels are unchanged, and the unlabelled originals are in
    pm/archive/swell/2026-10-10-figs-unlabelled/. strain_map_v2_S3.png stays frozen as first scored (commit 68194b0);
    its strip says that "independent generator" in its title means a separate AI agent, not a person. Rejected:
    re-rendering every figure (the S3 figure is frozen, and a rerun could drift from the published numbers); labelling
    only inside the zip (a rerun would lose the label).
  - **Words:** the reports say synthetic data "tests" the pipeline against our own assumptions, not that it "proves"
    it, and S1b is our own blind test (strain_map_sim.py now writes what strain_map_v1.md already said);
    docs/design/prior_art.md strikes search 4's wrong line in place and credits Chen, Tillberg & Boyden 2015 where the
    pairing is pitched; pm/ORDERS.md names its AI reviews as AI. **Correction to D-45:** its "fresh reviewer" was an AI
    session (another Claude instance), not a person, and so was pm/AUDIT.md's "fresh ... review" of 2026-10-09; the
    zip's copies of both lines say so in place.
  - **Reproducible files:** software/redteam/s3_gen.py writes its gzip files with no time stamp and no stored name;
    two runs gave byte-identical .json.gz files whose decompressed SHA-256s equal the ones on the SWELL page
    (pm/xwow/audits/life8-s3-gzip-check-2026-10-10.json). The red-team scripts carry no local folder paths. The
    wheel is built from the pinned commit's own source with SOURCE_DATE_EPOCH set to 2026-10-10 00:00 UTC; two builds
    gave the same SHA-256, and the zip builder refuses a wheel whose modules differ from the zip's source.
  - **The zip's copy of this log** leaves out D-57 to D-65 and D-67: the agent that runs X-WOW, its accounts and
    channels, another project's hosting, taking parts of the live site down, and two entries that refer to the
    project's private files. What D-65 and D-67 decided about SWELL: the zip leaves out the original brief (written
    for doing the chemistry outside a laboratory, a plan that was withdrawn) and carries SAFETY.md; the charter's expert test, an AI review role-playing
    a sceptical specialist, scored principle 12 ("feels like 2030") a fail, so SWELL stays on the board labelled as
    not having passed X-WOW's gate; and water beads leave the design.
  - **The zip's README** takes its resolution sentence from docs/design/calc_v0.json (about 108 nm at NA 0.65 and
    4.5× expansion, 79 nm at NA 0.40 and 10×, on paper; the old "~80-130 nm" had no source for 130) and says an AI
    did the work from the owner's brief and orders (the old "the owner set the direction and made the calls"
    overstated his part, as the round-1 AI review of life 7 said). The download's size is given in decimal megabytes,
    and the full BOM is also offered on its own as a CSV.
  - **swell-ruler 0.1.2:** the summary drops "the Chicken Standard" and says "untested on real images"; the README
    and package docstring keep the X-WOW name and logo outside CC0; cli.py no longer says synthetic tests "prove"
    anything, says when it skips a figure or a TIFF file instead of listing files it never wrote, and labels the
    demo's figure as a simulation. What it computes is unchanged: 9 package tests and 11 simulation tests pass, and
    the demo scores as before (axial PASS; transverse and the planted patch FAIL).
  - Reversible: files in the private repo and the unpushed site; nothing was published.
  - **Correction (2026-10-10, after round 1 of the pre-push AI review):** two lines above described design the BOM
    doesn't have. H-28 does not "sit in the closed electronics compartment": no such part is designed, so its line
    now states a placement requirement (out of reach inside the instrument, with air around it, away from printed
    parts; not designed yet), and it joins the open heat question with the build tools. And one switch pole can't open
    both motor rails, which run at different voltages: H-18's second pole now drives a relay on H-19's board that
    opens the steppers' 5 V rail and the pumps' 12 V rail (INV-19 reworded to match). The same round found what this
    entry's "Words" bullet missed: the tool's README still pitched the before/after pairing and the strain map without
    Chen 2015 and GelMap (now credited and narrowed), local paths in the red-team README and the S3 report, and water
    beads in R4's mitigation and on the page's safety note; all fixed. The AI review is named in pm/OPEN_FINDINGS.md.

- **2026-10-10 · D-68 · Rung 4: the gel factor is reported, not a pass mark (runner life 7, after round 1 of the pre-push AI review).**
  - D-50's rung 4 had "gel-mean axial within ±0.5% of the overview camera". Dropped before anyone climbed, because a
    whole gel's factor is itself uncertain (observers' estimates of one gel ranged from 8.6 to 9.4 in GelMap, Damstra et
    al. 2023, as the AI specialist review read it) and a myofibril may expand less than its gel (Damstra et al. 2022;
    Sheard 2021). Rung 4 now passes on three marks (pre-image q, per-myofibril precision, isotropy) and reports the
    gel-mean axial factor, the overview camera's factor and their ratio. Rejected: keeping ±0.5% (it would fail for
    reasons unrelated to the ruler); ±1% (the page's drifted value, no better grounded). Reversible: page text and one
    number's note; nobody has climbed.
- **2026-10-10 · D-67 ·** *Left out of this copy (see README.md).*
- **2026-10-10 · D-66 · SWELL safety, cited: each reagent's hazards from a named supplier's SDS, hazards beside every record step with amounts, and every BOM line's safety rating (A-10, runner life 6).**
  - **Sheets:** the hazards on the SWELL page's safety table (EN, 中文) and in the zip's SAFETY.md are read from 16 supplier SDSs, all read 2026-10-10: 15 GB-format sheets served by Fisher Scientific UK's SDS endpoint (publishers Fisher Scientific UK and Avocado Research Chemicals, part of Thermo Fisher Scientific) and one EU-format sheet from Glentham Life Sciences for sodium acrylate. HSE's GB mandatory classification list is cited as the legal baseline. Each sheet's revision, H-statements and SHA-256 are in pm/xwow/sds/2026-10-10.json, and the zip build checks every citation on the page against that record.
  - **Why these sheets:** the project's notes name Merck, Fisher and Thermo as suppliers (W-01) but no products; Merck's SDS pages time out for scripts, Fisher UK's endpoint serves GB sheets. Naming a supplier is not an endorsement, and the page says so.
  - **Public corrections** (dated note on the page; E-23): acrylamide 40% solution H302, not "toxic"; formaldehyde 16% H332, not "toxic by inhalation"; sodium acrylate H400/H411, not "irritant"; imidazole (Repr. 1B, D-22's rigor buffer) added; acrylic acid and sodium hydroxide get a fallback row.
  - **Records in the zip:** each of 23 record steps that give reagent amounts carries its hazards, control and waste route beside it in the zip copy (none left out); the zip is refused if a pm/ record line names a reagent with an amount and has neither a note nor a reviewed reason (two reviewed: AU-31, an ORDERS simulation line). F-8 re-read from the protocol itself (ratio confirmed; stock strengths not stated, E-24); F-13 checked on the GB list.
  - **BOM:** every line's safety rating is in the site's src/data/swell/bom_safety.json, sourced by an AI worker (xwow-max) with an exact quote and the SHA-256 of each document: 9 from the maker's own document (Raspberry Pi product briefs and CB certificates, Mean Well's LDD-H datasheet, Bambu Lab's specification, PINE64's store page, UNI-T's manual, Thermo Fisher's FluoSpheres SDS and user guide), 23 requirements where no part is chosen or the part has no rating, 11 none. The SWELL page shows the 32 rated lines (EN, 中文); the zip's pm/BOM.csv gains a safety_rating column and docs/BOM.md a section; the build refuses drift between the data, the BOM and the page. Three safety-table lines changed with it (dated note): the calibration beads may contain sodium azide; water beads carry the UK product-safety alert's words (PSA7); the light rule says which LEDs the lid interlock covers. Findings outside A-10 (hot tools against the project's safety rules, unguarded gears and rollers, no 12 V rail, LED risk groups) went to A-9.
  - **Rejected:** leaving the record steps out of the zip copy (they are the design's evidence; the project's safety rules allow lab theory with each step's hazard beside it); citing the protocol's Sigma products' sheets from search snippets (the project's rule: never cite a snippet); naming brands that only search listings gave (the sheets print publisher and code); citing a dye SDS whose product name didn't show it is the NHS ester.
  - Reversible: page text, zip builder and data files.
  - **Correction (2026-10-10 19:01, after round 1 of the AI review):** the first two public corrections above were wrong: acrylamide's "toxic" and formaldehyde's "toxic by inhalation" stand for the substances (HSE's GB list: Acute Tox. 3 H301; Acute Tox. 2 H330), and acrylamide's skin absorption is in its sheet (§8.1, EH40/2005's skin notation). The page now gives the product label beside the substance's GB class (E-25). Handling now follows the sheets (fume hood for acrylamide, TEMED, imidazole and formaldehyde), and on phones the two safety tables stack row by row.
- **2026-10-10 · D-65 ·** *Left out of this copy (see README.md).*
- **2026-10-10 · D-64 ·** *Left out of this copy (see README.md).*
- **2026-10-10 · D-63 ·** *Left out of this copy (see README.md).*
- **2026-10-10 · D-62 ·** *Left out of this copy (see README.md).*
- **2026-10-10 · D-61 ·** *Left out of this copy (see README.md).*
- **2026-10-10 · D-60 ·** *Left out of this copy (see README.md).*
- **2026-10-10 · D-59 ·** *Left out of this copy (see README.md).*
- **2026-10-10 · D-58 ·** *Left out of this copy (see README.md).*
- **2026-10-10 · D-57 ·** *Left out of this copy (see README.md).*
- **2026-10-10 · D-56 ·** *Left out of this copy (see README.md).*
- **2026-10-10 · D-55 · Second review batch: AI described as AI everywhere, the wall cut to 17, the zip rebuilt from the committed project.**
  - A fresh AI reviewer found the v0.2.0 zip built from the SWELL commit before the fixes, "outside review" / "independent" wording left in project files (DECISIONS D-46/D-48, strain_map_v2.md, prior_art.md, preimage_v1, sim docstrings, the zip README), and [personal detail removed]. Fixed at the source.
  - Wall: 6 more picks dropped (a thread of joking replies, a joking reply, a writer who never says they are a scientist, a quip in the trimmed tail, a video whose top comments are innuendo, a trim that dropped a caveat): 17 quotes. The method line no longer says every candidate was read: "a keyword search picked 4,193 candidates, a rule set aside the ones that only repeat the channel's catchphrase, and Claude, an AI, read through the rest".
  - The "true blur widths do not fix it" claim now rests on data: software/sim/s3_true_psf.py (transverse bias −17.4% with the red team's true core widths; call still blocked).
  - Unpushed site history is squashed into one commit before the push, so removed quotes and superseded files never reach public git history.
- **2026-10-10 · D-54 · Corrections to earlier wording in this file:** D-46, D-48 and D-50's mentions of an "outside review" and an "independent" test refer to fresh AI sessions (other Claude instances), not people; D-53's "40 kept … 21 working scientists and doctors" was cut to 23, then 17, after AI reviews (D-55).
- **2026-10-10 · D-53 ·** *Left out of this copy (see README.md).*
- **2026-10-10 · D-52 · The evidence bar: seven stages, computed, desk evidence capped at four (Job 7b).**
  - Stages: idea → designed → simulated → red-teamed → bench-tested → built by someone else → rebuilt independently. Each is done, partial or not yet, and says what it is made of: design pieces present in the latest package, simulated checks passed/failed/below limit, the red team's headline checks, checked ladder rungs, checked builds. The current stage is the furthest reached; the next step is the stage after it.
  - Desk evidence fills at most 4 of 7; the last three move only on GitHub issues a maintainer has checked and labelled. Red-teamed counts as done only when the red team's headline checks pass; today it is partial (4 of 7).
  - `tools/evidence_bar.py` computes it from public files; build.py recomputes it and fails if the stored bar differs. Shown on the SWELL home card and at the top of the SWELL page, with the explanation in a tap-to-open panel (static HTML, so it works without JavaScript and with reduced motion).
  - Reversible.
- **2026-10-10 · D-51 ·** *Left out of this copy (see README.md).*
- **2026-10-10 · D-50 · Evidence ladder (replaces Order 25): cheapest failure first, with pass marks fixed before anyone climbs.**
  - Rung 1, measure a chicken with a laser: first-order spots on both sides; three strips within ±5% of their mean, inside 1.5–2.0 µm.
  - Rung 2, see the stripes (any 40× microscope, kitchen salt only): median q ≥ 1.2 over ≥ 10 myofibrils with ≥ 10 sarcomeres, the D-46 go/no-go, measured by `swell-ruler stripes` from the fit's own residuals (gain-free).
  - Rung 3, long enough fragments: ≥ 40% of fragments with ≥ 8 sarcomeres (the v2 simulation assumed 44%).
  - Rung 4, lab only: 3 gels with pre-image q ≥ 1.2, per-myofibril axial precision ≤ 1%, gel-mean axial within ±0.5% of the overview camera, isotropy inside the D-32 gate.
  - Each rung has a GitHub issue form, a safety note and a results wall fed by checked issues (labels rung-N + checked, and passed when it passed).
  - Why: rung 2 is the cheapest place for SWELL to fail; nobody should buy CMR reagents before it passes.
  - Reversible.
- **2026-10-10 · D-48 · Ruler pipeline v2 (swell_ruler 0.1.0), and the first red-team test: gel S3, built by a separate AI agent (another Claude instance), published as scored.**
  - **Pipeline:** observations in (docs/design/obs_schema_v1.md); pre/post matching with no pairing given (rotation/translation voting, mirror check, local-affine refinement, Hungarian assignment); Z-discs within 0.35 sarcomere of a fragment end ignored; pre profiles flat-fielded with a constant and slope in the fit; no offset search (it jumped whole sarcomeres on ~1% of fibrils); a gel-relative R² gate; clock-tile drift correction; anisotropy and gel-stretch calls by effect size (±1%, ±0.5%) instead of "CI excludes 0"; a coverage-hole flag.
  - **Development and blind gels (v2 generator: unpaired, broken ends, S4 drift):** 47 of 49 checks pass, 1 fail, 1 below the detection limit. Gel-mean axial error 0.00% on S0–S2/S1b (v1: −0.1%); per-myofibril 0.15–0.18% (v1: 0.32–0.48%); matching recall ≥ 99.3% with 100% precision.
  - **S3 (a separate AI agent, another Claude instance, built it from the format alone and scored it with its own script; pipeline frozen at commit 68194b0 before it ran):** pairing precision 1.000, recall 0.963, 0 wrong; debris rejected 100%; gel-mean axial -0.14% (median -0.008%); per-myofibril axial RMS 1.8% (robust spread 0.31%, 7.5% beyond ±2%) on 28% of pairs; **transverse ruler bias -17.8%** (told the wrong PSF, unmodelled halo) so **the anisotropy call was wrong**; bubble flagged 100%, fold 75%, bundles 55%, z-tilt 3%, curved 0%, **under/over-expanded patches 0%**; false flags 0.4%; residual drift -0.015 ± 0.100% per hour.
  - **Open problems routed to Order 7:** a transverse ruler that survives PSF error (calibrate from the data, or make the calibration-free landmark factor the transverse reference); detection of small local expansion changes where few fibrils carry an axial ratio; flags for curved and tilted fibrils; axial coverage beyond 28% of pairs; the axial outlier tail.
  - **S3 is now spent:** it has been seen, so it becomes a development gel. The next independent score needs a fresh red-team gel built the same way.
  - Reversible.
- **2026-10-10 · D-49 · Stain at pan-ExM strength or more: titrate 6 / 20 / 40 µg/mL NHS ester (refines E-17; R30 now has numbers).** *Hazards beside this step (lab only; from the supplier SDSs listed in `SAFETY.md`): DMSO (no hazard class; see its row). Control: gloves, because DMSO carries the dissolved dye through skin; no dye is chosen yet, so read its own SDS once one is. Waste: the lab's hazardous-waste route; nothing down the drain.*
  - **Need:** SNR 10 at today's dose (100 ms, 1 W/cm², gain 4×, out-of-focus pedestal included) needs 0.81% of amines labelled for a 1 µm myofibril and 1.58% for a 2 µm one; at 200 ms (Order 12's limit), 0.41% and 0.79% (docs/design/labelling_v1.md).
  - **Supply:** no paper reports the labelled fraction in pan-ExM, so a kinetic model (aminolysis vs hydrolysis, calibrated on antibody labelling, one consistent hydrolysis half-life) estimates about 1.4% at 20 µg/mL (range 0.30–9.6%) and about 0.14% for the kit's 2 µg/mL.
  - **So:** the 2 µg/mL arm of E-17 is predicted to fail; E-22 replaces it with 40 µg/mL. R30 stays open until the titration measures the real fraction from intensity on the first gels.
  - Rejected: keeping 2 / 6 / 20 (one arm wasted); raising irradiance first (bleaching budget unmeasured).
  - Reversible.
- **2026-10-10 · D-47 · The reference pre-image is taken after gelation; the first 3 gels also measure the anchoring and gelation window (E-21).**
  - **Why:** the fresh AI review showed that a pre-image taken before anchoring and gelation turns any sarcomere change in that window into apparent expansion error, which looks like under-digestion.
  - **How:** image the polymerised gel, still bonded to its coverslip and rinsed 3 × 5 min in PBS off the stage, in a lidded dish. It is a polymerised, rinsed gel like every post-expansion gel, so INV-14 holds (no CMR liquid, no casting on the stage). On the first 3 gels, also image the same fiducial fields before anchoring and report the per-myofibril change across the window (median and 95% CI). That turns a hidden error into a measured property of the protocol. *Hazards beside this step (lab only; from the supplier SDSs listed in `SAFETY.md`): formaldehyde H302, H312, H332, H315, H317, H319, H335, H341, H350; acrylamide H302, H315, H317, H319, H340, H350, H361f, H372. Control: open the formaldehyde and make the anchoring mix only in a fume hood (as a substance, the GB list classes formaldehyde fatal if inhaled, H330); anchoring runs overnight in a sealed box off the stage; only the polymerised, rinsed gel reaches the stage. Waste: the lab's hazardous-waste route; nothing down the drain.*
  - **Contrast:** the monomer infuses the fibril, so fibril-to-medium contrast drops by roughly a fifth (refractive-index estimate), but the striation contrast comes from protein density inside the fibril and stays.
  - Rejected: keeping the kit's order (an unmeasured confound); only measuring the window (it would still enter every gel's ratio).
  - Reversible after the first-gel measurement.
- **2026-10-10 · D-46 · Pre-image mode: DPC with 4 oblique green LEDs; go/no-go on q = m·√N (fresh AI review, item b).**
  - **Go/no-go (P1, day 1):** go if the median myofibril with ≥ 10 sarcomeres reaches q ≥ 1.2, which gives 1% per-fibril E_ax error (q ≥ 2.1 gives 0.5%). m is the fundamental striation modulation of the flattened pre profile and N the photo-electrons per 0.194 µm sample summed across the fibril. Points with the same q fall on one precision curve (docs/design/preimage_v1.md), and the pipeline reports m and q per fibril.
  - **Physics at SL 1.69 µm** (thin filaments overlap, the I-band is only 0.09 µm, so label-free contrast is small everywhere):
    - DPC: phase fundamental ≈ 23 mrad → m ≈ 2.3%. Photons are cheap in brightfield (4 frame pairs ≈ 200,000 e⁻ per sample), so q ≈ 10, and 4 LEDs at σ ≈ 0.85 cover every orientation (2 LEDs: 96%).
    - Crossed linear polarisers: the A-band retardance is ≈ 1.9 nm, so the signal is ~10⁻⁴ of the light, below cheap-film leakage. sin²2φ blanks fibrils near 0° and 90°: 42% of orientations reach the go q with cheap film, 78% with good film.
    - Circular polarisers: they work only with a λ/4 pair matched to the LED (100% of orientations, q 1.7–4.6). A generic 560 nm film used at 520 nm leaks too much.
    - Fluorescent pan-protein pre-label: m ≈ 5%, q ≈ 6; a Z-disc label gives far more.
  - **Detrending (same review):** each pre profile is divided by its own local mean over 1.5 sarcomeres and fitted with a constant and a slope. A 20% illumination slope at m 0.05 now costs 0.28% RMS (v1: 0.95%).
  - **Fallbacks, in order:** circular polarisers with a matched λ/4 pair and good film; then a fluorescent pre-label. The linear film pair stays as a cross-check.
  - Inputs marked ASSUMPTION in preimage_v1.py (A-band birefringence, film extinction, thin-filament length, mass fractions) are unverified. The physics ranks the modes; day 1 decides.
  - Reversible.
- **2026-10-10 · D-45 · Permanent archive: Zenodo via GitHub releases of the public site repo (A-4, the owner's overnight order).**
  - `.zenodo.json` (title as the owner wrote it; creators "X-WOW" only; licence `cc-zero`, which Zenodo's own code maps to `cc0-1.0`; software; keywords; isDocumentedBy https://x-wow.com/swell/) and CITATION.cff live in the x-wow repo root. build.py privacy-scans them and fails on a missing field, a non-CC0 licence or a personal creator.
  - A fresh reviewer *(an AI session, not a person; noted in this copy)* found 1 blocker (the text implied draft CAD and software exist) and 5 should-fixes; all were fixed before the push (x-wow 06f917a).
  - **Release v0.1.0-g0 is not created:** Claude Code's auto-mode classifier blocks `gh release create` as "create public surface", because it mints a permanent DOI. The owner runs it himself with one `!` command pinned to 06f917a (HUMAN_QUEUE S-7). The Wayback and OpenTimestamps steps wait with it, so the DOI and the stamps describe the same published state.
  - Zenodo's legacy importer files the creator "X-WOW" as a person; the owner can switch it to an organisation in the Zenodo UI after the first DOI (optional).
  - Reversible: no until the release; a DOI is permanent once minted.
- **2026-10-10 · D-44 · Brand records: N-4 yes, and the logo is a registered UK trade mark (N-5 answered by the owner).**
  - **Registration (checked by the owner on the UK IPO register):** UK00003425680, a figurative mark (the microscope logo with "X-WOW"), status Registered, renewal date 2029-09-03. My own lookups of the IPO register and TMview still return HTTP 403, so the record rests on the owner's check.
  - **® placement:** on the logo artwork only (as in the original), never on the plain-text name. A scan of the site source found no ® in running text.
  - **Wording in the legal notes:** "X-WOW is a trade mark, and the X-WOW logo (which includes the name) is a registered UK trade mark, UK00003425680." the owner's draft said "X-WOW and the X-WOW logo are registered trade marks". The registration is figurative, so calling the bare word registered could read as a false claim of registration (Trade Marks Act 1994 s.95). The owner can say "use my wording" to switch.
  - **Licence:** the name and logo stay outside CC0 and CERN-OHL-P (N-4 yes; D-42 unchanged).
  - **Renewal:** reminder for 2029-06 in pm/site/brand-notes.md and HUMAN_QUEUE (the IPO accepts renewal from 6 months before the date).
  - Reversible: wording, yes; the registration is the owner's.
- **2026-10-09 · D-43 · The logo keeps its ®, as in the original.**
  - A public podcast page calls X-WOW "now an official trademark", but gives no office or number. No registration was found: the UK IPO register blocks automated lookups (HTTP 403).
  - Showing ® on a mark that isn't registered is an offence in the UK (Trade Marks Act 1994 s.95). A registration abroad for the same goods or services also counts. So the owner confirms (N-5). If there is none, `make_brand.py --no-registered` removes the ® from every file in one run (tested).
  - Why: the owner ordered "don't redesign it", and the registration is his to know.
  - Reversible: one script run.
- **2026-10-09 · D-42 · The X-WOW name and logo stay outside CC0 and CERN-OHL-P.**
  - The site repo is CC0 by default, and a CC0 waiver can never be withdrawn. Without a carve-out, publishing the logo there could waive its artwork copyright for good.
  - The README and the site footer (EN/中文) now say the name and logo are trademarks covered by neither licence. CC0 section 4(a) leaves trademarks alone anyway.
  - Why: the inventions stay free to steal, and the brand stays the owner's. This keeps the reversible option open.
  - Reversible one way only: the owner can say "free the logo" (N-4) at any time; the opposite would be impossible.
- **2026-10-09 · D-41 · The original X-WOW logo is restored on x-wow.com and was not redrawn (the owner's order, Life 4).**
  - **Source:** the old Wix header logo (`logo3.png`, 2274 × 2004) and the old favicon (952 × 948), named in the Life 3 crawl HTML and downloaded from the Wix media server as the original uploads. Both are kept byte-for-byte in site/src/assets/img/brand/original/. Provenance: pm/site/brand-notes.md.
  - **Method:** the original isn't low-res, so nothing was traced. `site/tools/make_brand.py` derives every file:
    - Transparent background: each edge pixel is un-mixed into white plus the logo's 10 flat colours. Laid back over white, the result matches the original within 1/255 on all 4,557,096 pixels.
    - The white inside the ring stays, or the microscope's charcoal base would vanish on dark.
    - The ® is shown in the site's text colour on dark backgrounds.
  - **Placement:**
    - header (60 px tall; 48 px on phones), footer and boot screen;
    - favicon.ico (16/32/48), apple-touch and manifest icons;
    - social preview: the logo under the loupe reticle, renamed og-xwow.png so share caches refresh;
    - README (light and dark versions).
  - The stacked lockup stays, as the old header used it.
  - Rejected:
    - a vector trace (shape drift, and the original is high-res);
    - an icon-plus-text horizontal lockup (a redesign);
    - a transparent ring interior (the dark parts disappear).
  - Reversible: one commit in each repo.
- **2026-10-09 · D-40 · Site content rules for people.**
  - Never name children or patients, and give no health details about individuals. Use no photo of an identifiable child unless consent is on record; use original illustrations instead.
  - Credit adult contributors by name, exactly as the old public site credits them.
  - The Microvisioneer scanner is framed as a past collaboration, with no claim of a current partnership or endorsement and no logos.
  - Why: the owner's order, plus child-safety-first in OWNER_PRINCIPLES §3. Reversible per page once consent is on record.
- **2026-10-09 · D-39 · Site narrator: LOUPE**, an original AI narrator named after a jeweller's magnifier.
  - Voice: short, dry, precise, honest about limits, never flattering.
  - The optional read-aloud uses the visitor's own device voice; nothing autoplays.
  - The mood is holographic (cyan wireframes, gold and red accents, HUD callouts, a 2-second boot that runs once per session and is skipped under reduced motion), with no film names, characters, logos, fonts or sounds (build.py fails on film-IP words).
  - Why: the owner asked for an original AI narrator voice; a magnifier fits seeing-and-making.
  - Rejected: no narrator (generic); a name close to any film AI.
  - Reversible: the name goes to the owner for a nod.
- **2026-10-09 · D-38 · Public means nothing personal.**
  - The site repo commits as "X-WOW" with the GitHub noreply address.
  - Personal tokens live only in the private pm/site/forbidden.txt. build.py and the zip script load it, and the build fails if any token appears.
  - The public zip replaces the owner's nickname with "the owner", drops the PM files that talk to or about the owner (LEDGER, STATUS, LESSONS, HUMAN_QUEUE, APPROVALS, OUTREACH, briefs, inbox) and removes local paths.
  - Why: the site repo is public, and the owner ordered nothing personal in it.
  - Reversible.
- **2026-10-09 · D-37 · Licences.**
  - Text, docs and data: CC0 1.0. Hardware design files: CERN-OHL-P v2 (both the owner's order).
  - Software (the sim code): also CC0 1.0, my choice, to match "steal happily". This is for the owner's nod.
  - Any part later forked from OpenFlexure keeps OpenFlexure's own licence.
  - Expansion-microscopy patents are flagged for commercial use. The site is a dated defensive disclosure (the zip carries a SHA-256).
  - Why: maximum freedom with the fewest obligations.
  - Rejected: MIT-0 for code (equivalent, but two licences where one does).
  - Reversible for future releases only; CC0 grants already made can't be withdrawn.
- **2026-10-09 · D-36 · Site stack: a static site built by a stdlib Python script (`site/build.py`)**, served by GitHub Pages from the public repo github.com/khcy82dyc2/x-wow (main, /docs).
  - Test URL: https://khcy82dyc2.github.io/x-wow/.
  - EN/中文 via paired elements; every SWELL number is pulled by code from the sim JSON with its source (INV-18); the link, anchor and privacy checks run on every build.
  - Custom domain later via Wix DNS, editing only the root A records and the www CNAME. DNS stays at Wix; MX and TXT are untouched.
  - Why: free, no new accounts, fast, rebuildable by anyone.
  - Rejected: Netlify, Vercel and Cloudflare Pages (new accounts); moving nameservers (that would mean recreating the mail records).
  - Reversible: DNS rollback values are in pm/site/dns-snapshot-2026-10-09.md.
- **2026-10-09 · D-35 · Direction change (the owner, Life 3): SWELL stops at G0 as a fully specified theoretical prototype, given to the world free** as invention #1 of "inventions for others to steal happily", at the heart of the rebuilt x-wow.com.
  - No orders, no lab contact and no money spent. S-3 is cancelled before sending (nothing was ever sent), and Stages 2 and 3 are frozen.
  - The remaining desk work (the LATER queue in ORDERS) makes the free kit complete and convenient for whoever builds it.
  - Why: the owner's order.
  - Reversible only by the owner.

- **2026-10-09 · D-34 · G0 deliverable: the whole-gel strain map** (`software/sim/strain_map_sim.py` → docs/design/strain_map_v1.md; figures docs/design/figs/strain_map_S*.png).
  - **What it is:** a synthetic 1.5 mm gel of 1,200 myofibrils with planted defects and known truth.
    - Each myofibril is drawn at its place and angle, coloured by its own axial and transverse factor.
    - Smoothed maps show local E, anisotropy, fibril-vs-gel and distortion (residual after the similarity fit).
    - Flagged regions are scored against the truth.
  - **Blind gel (S1b; new seed; defects moved and resized; nothing tuned against it):**
    - Accuracy: gel-mean E −0.11%; local E map 0.13% RMS from truth; distortion curve within 0.01% of length.
    - Flags: none in the defect-free area. The −4% hotspot and the −3% under-digested patch are flagged over 100% of their area.
    - The +2.5% stretched patch is flagged everywhere, but by the non-affine detector rather than the stretch detector (51% by the strict own-detector check: FAIL).
    - The 1.5 µm tear is below the residual detector's limit (~2 µm).
  - **All four gels:** 31 of 33 checks pass, 1 fails and 1 is below the limit. Three of the gels are development gels (seed 7; the detectors were fixed while looking at them). On those, a 2% intrinsic anisotropy is recovered as −2.12% [−2.37, −1.87], and a 2% gel stretch by the orientation test (2.03% at 23°).
  - **Coverage:** every myofibril gets landmark and transverse factors; only the ~half with ≥ 8 sarcomeres get an axial ratio.
  - **Order 7 adds** a direct crack detector, adaptive landmark neighbourhoods, nuclei, and irregular sections and bundles.
  - **Why:** the owner asked for it. It turns "every gel proves its own expansion" into a picture a reviewer can check.
  - **Rejected:** a single gel-level E, which hides local failure.
  - Reversible.
- **2026-10-09 · D-33 · Period-ratio estimator = Z-disc ladder template** (refines D-4's implementation).
  - **Method:** the post image's detected Z-discs define a sarcomere coordinate. The pre profile is fitted with harmonics of that coordinate at x_post = E·x_pre, for E within E_macro ± 10%. Segments need ≥ 8 sarcomeres.
  - **Why:** the first full simulation exposed the free-frequency fit. With realistic 3% sarcomere-to-sarcomere jitter, or at SL ≈ 1.8 µm where the I-band dips cancel the Z-disc in the fundamental, it locks onto ±1/N sidelobes (10–17% of myofibrils off by 7–19%). The ladder carries the jitter: 0.3–0.6% RMS per myofibril across runs, with ≤ 0.8% of myofibrils beyond ±2%.
  - **Rejected:** a narrower prior window, which clips real local E changes; keeping 5–7-sarcomere segments (5–14% outliers).
  - Reversible.
- **2026-10-09 · D-32 · Expansion-factor pass criteria now include transverse isotropy, and axial and transverse factors are always reported separately** (the owner, Life 2).
  - **Rulers per myofibril:**
    - E_ax = period ratio (D-33).
    - E_tr = width ratio W_post / W_pre, a forward-model fit with the bead-measured PSF and the aspect from the post z-stack. Each myofibril's **cross-section shape is measured from its post z-projection** (super-ellipse exponent to ±0.01). The nuclear diameter ratio is used where nuclei are present (not yet simulated).
    - E_land,ax / E_land,tr = the landmark local affine along and across each myofibril. It is calibration-free.
  - **Pass (gel level, pre-registered):**
    - E_ax / E_tr − 1 within ±3% (95% CI, n ≥ 200);
    - E_ax / E_land,ax − 1 within ±3% (the fibril expands with the gel);
    - orientation amplitude ≤ 2%.
  - **Why ±3%:** it is 1% plus the worst transverse bias at the G1 calibration target (pre-image PSF within 2%) and with real cross-section shapes. That bias is 1.09%, for crossed polarisers at PSF +2%, so the gate is met with margin (2.09% ≤ 3%).
  - **The shape step is essential:** a boxy section fitted as an ellipse is biased by −9% (oblique/DPC) to −15% (crossed polarisers); with the post-measured shape the bias is ≤ 0.04%. A 5% PSF error still costs 1.1–3.2%, so G1 calibrates to ±2%.
  - **Rejected:** width ratio alone (calibration- and shape-sensitive); landmarks alone (they see the gel, not the fibril).
  - Reversible until the stats plan is frozen (W-5).
- **2026-10-09 · D-31 ·** *Left out of this copy (see README.md).*
- **2026-10-09 · D-30 · The box budget is re-run from a priced BOM; the D-15 targets stay.**
  - **Priced BOM** (docs/BOM.md, `software/sim/budget.py`): imager core £524–784 against ≤ £500; full build £727–1,072 against ≤ £650. The top of the build range also breaks the £1,000 ceiling. Listed prices cover £328 of the build; 22 of 26 box lines are still estimates.
  - **Order 5 levers:** a coloured-glass emission filter and one cheap dichroic (filters, £100–250, are the largest line); a generic tube lens (−£30–50); a generic 20× for the P5 stretch track (−£75).
  - **If the box still misses after every line is priced:** a target change goes to APPROVALS with the priced BOM. [personal detail removed]
  - **Why:** D-15 said to revise on live prices, and 22 lines are not priced yet. Our own objectives [personal detail removed] add ~£225, and a real filter set adds £100–250.
  - **Rejected:** raising the targets now (moving the goalposts before pricing); cutting objective quality, which sets the resolution.
  - Reversible.
- **2026-10-09 · D-29 · Optics and camera are our own parts** [personal detail removed].
  - **Parts:**
    - Track A and pre-images: Motic PL 40X/0.65 plan achromat (160 mm, DIN 45 mm parfocal, RMS; €109 ex VAT).
    - Track B: Motic PL 20X/0.40 plan (same standard).
    - Tube lens: one f = 100 mm Ø12.7 mm achromat, 25 mm behind the objective shoulder, giving 17.8× and 0.194 µm pixels (1.03× Nyquist) for A and 8.9× / 0.84× Nyquist for B.
    - Camera: Waveshare IMX296-130-BW mono (£49.87, lens removed).
  - **optics_v1 results:**
    - Strehl ≥ 0.98 over 0–12 µm into water for the dry 0.65 NA, so R23 is retired on paper.
    - 804 tiles/plane, 10 planes, 25.5 GB and 1.3–2.2 h per E 4.5 gel.
    - One FAIL routed to Order 12: widefield on thick expanded myofibrils adds an out-of-focus pedestal, so the worst case (0.5% labelling, 2 µm myofibril) needs 3.2× the dose for SNR 10.
  - The stock OFM 50 mm lens undersamples (0.66× Nyquist). The official Raspberry Pi GS camera is colour (IMX296LQR-C), so it is not used.
  - **Rejected:**
    - Bayer HQ camera (signal);
    - semi-plan or achromat objectives (OFM: poor field edges for tiling);
    - 185 mm / 35 mm parfocal objectives (wrong conjugates).
  - D-7 is confirmed. Reversible until Basket H.
- **2026-10-09 · D-28 · Tools are "lab-provided or buy", never part of the box cost.** Bambu Lab A1 mini (£169, UK store); Pinecil V2 with a 65 W USB-C PD supply (~£45–60); UNI-T UT61E+ (~£70); basic hand tools. That is £304–334 if the lab has none. [personal detail removed]
  - **Why:** the owner said to assume a proper lab, and left the models to me.
  - **Rejected:** a print service as the primary route, because repeated CAD iterations need a printer at hand.
  - Reversible.
- **2026-10-09 · D-27 · Off-site backup is live** (executes D-23 after the owner's "repo yes, private").
  - **Repo:** [personal detail removed]
  - **Before the first push:** pm/inbox/ was checked as ignored, and no emails or tokens were in tracked files.
  - **Each life:** `tools/backup.sh` now writes the bundle, refuses to push if anything in pm/inbox/ is tracked or if the repo isn't private, then pushes.
  - The push-notification topic is in CLAUDE.md, so rotate it if the repo is ever made public.
  - Reversible (the repo can be deleted).
- **2026-10-09 · D-26 · S-1 folded in:**
  - **Wet work:** all of it happens at a host lab (fume hood, lockable storage, lab fridge/freezer); nothing chemical at home.
  - **Deliveries:** all go to that lab.
  - **Planning area:** [personal detail removed]
  - **ORDERS:** [personal detail removed]; INV-10 (nothing hazardous to drains or household bins) stays.
  - **Why:** the owner's S-1 answers.
  - **Rejected:** the kit's home variant (B: £1,200–2,500 equipment).
  - Reversible only by the owner.

- **2026-10-09 · D-25 · The smoke test proves work and absence of leaks.** Every check does a real job (register, render, slice, resolve, compile) except mpremote, which is labelled import-only until a Pico exists. After each run it removes any HKCU\Software\JavaSoft keys it created (Fiji and QuPath keep Java preferences in the registry on Windows) and fails on any new %APPDATA%, %LOCALAPPDATA% or home folder. Result: 25/25, 24 doing real work, no leaks. Why: the review caught import-only rows presented as "real work" and the registry writes the first leak check missed. Reversible.
- **2026-10-09 · D-24 · APS stock: 10% w/v in ≥ 1 g batches, aliquoted, −20 °C.** The 0.01 g balance stays. Why: removes the open "or" in AU-25; a ≥ 1 g batch weighs to ± 1%. Rejected: buying a 0.001 g balance. Reversible. *Hazards beside this step (lab only; from the supplier SDSs listed in `SAFETY.md`): APS H272, H302, H315, H317, H319, H334, H335. Control: weigh into closed, pre-tared vials with minimal dust; keep away from combustible materials. Waste: the lab's hazardous-waste route; nothing down the drain.*
- **2026-10-09 · D-23 · Off-site backup = a private GitHub repo** holding code and docs only. Never pm/inbox/ (git-ignored), raw data or secrets. Execution waits for the owner's one-word "repo yes" in S-1, because it creates a repo and pushes under his account. Why: C: and D: are one SSD (R28). Rejected: [personal detail removed]; an external drive alone (not off-site). Reversible.

- **2026-10-09 · D-22 · The rigor buffer uses 10 mM imidazole, pH 7, not Tris.** Why: no primary amine to react with formaldehyde or the NHS ester (AU-32). Rejected: Tris (amine). Reversible. *Hazards beside this step (lab only; from the supplier SDSs listed in `SAFETY.md`): imidazole H302, H314, H360D. Control: weigh the solid under local exhaust ventilation with gloves and goggles; the lab's risk assessment must cover a reproductive toxicant. Waste: the lab's hazardous-waste route; nothing down the drain.*
- **2026-10-09 · D-21 · Buy high-purity sodium acrylate for P3** (check the CoA; reject yellow solutions). In-house neutralisation of acrylic acid is a fume-hood-only fallback. Why: the batch variability is real, but neutralisation adds corrosive, flammable and exothermic hazards (AU-24, AU-44). Rejected: home neutralisation. Reversible.
- **2026-10-09 · D-20 · Stage 1 uses only the project toolchain in docs/SOFTWARE.md.** New tools join through tools/setup_tools.sh with SHA256 logging. Why: reproducibility and coexistence (INV-17). Reversible.
- **2026-10-09 · D-19 · Pre-expansion imaging uses a printed C12 chamber** (12 mm #1.5 coverslip as the floor, O-ring seal, kinematic seat, fiducials). Why: Attofluor takes 25 mm (AU-17), and 12 mm keeps the gel to 17 µL. Rejected: switching to 25 mm coverslips (4× gel volume, more CMR waste). Reversible.
- **2026-10-09 · D-18 · Backups: [personal detail removed]** Reversible.
- **2026-10-09 · D-17 · Paper toolchain:** Markdown manuscript with Manubot citation-by-DOI, Pandoc → DOCX for journals, Typst → PDF, every number injected from run JSON, and a claim linter that fails the build when a claim lacks a passing QC metric. Why: north-star output with INV-15/18 enforced in code. Rejected: hand-written LaTeX (numbers drift from data); Zotero (needs a system install and a GUI). Reversible.
- **2026-10-09 · D-16 · Data format: OME-Zarr 0.5 (zarr v3) as primary, Blosc-Zstd lossless, OME-TIFF export for QuPath and Fiji.** Metadata gains: chiral-mark handedness, punch coordinates, illuminated-field size and the dose count. Why: ~24 GB raw per gel (AU-19); the viewers were proven by the smoke test. Rejected: TIFF-only (no pyramids). Reversible until P1 data exists.
- **2026-10-09 · D-15 · Cost targets: imager core (P1 scope) ≤ £500, full reference build ≤ £650, hard ceiling £1,000.** Why: "shockingly cheap" needs a provable number below the kit's envelope (AU-22). Order 5 proves or revises them with live prices. Reversible.
- **2026-10-09 · D-14 · Ordering timing: Stage 2 seeks approval for Baskets H (hardware, P1 + P2 + P4 parts), C (calibration) and W (wet lab) together after G0.** H and C are ordered at once; W is released at G1. Why: reagent shelf life (MS < 2 weeks; APS degrades) vs "spend and order" in one window (AU-35). Rejected: buying reagents at G0 (expiry before P3). Reversible.
- **2026-10-09 · D-13 · The overview camera measures in-plane:** a printed or etched fiducial scale at the gel plane appears in every frame; lens distortion is calibrated with OpenCV at G1; pre and post images share holder geometry. Why: 0.75% scale bias from water depth (AU-06). Rejected: a telecentric lens (cost). Reversible.
- **2026-10-09 · D-12 · Acquisition defaults:** an excitation field stop sized to FOV + overlap; a 9–25-point focus map with plane/spline fit (per-tile autofocus only as a fallback); a per-run photon-dose log. Why: dose ×3–4 without them (AU-12, AU-13). Rejected: per-tile fluorescence autofocus. Reversible.
- **2026-10-09 · D-11 · Orientation mark = two unequal notches (chiral).** Pre/post registration tests both handednesses and reports which one fit. "Specimen-side down" preserves handedness, so a mirror fit flags a flipped gel. Why: AU-07. Reversible.
- **2026-10-09 · D-10 · Punch 1.5 mm for Track A (4×) and 0.75 mm for Track B (10×).** Why: the kit's 2 mm and 1 mm sizes overrun ~10 mm usable travel at E 4.8 / E 10; the smaller punches cut tiles and data by 42% (AU-18). Rejected: more travel (redesign). Reversible.
- **2026-10-09 · D-9 · No on-stage heater in v1.** 37 °C steps run in the off-stage incubator, and on-stage staining runs at room temperature (validated in P3). G2's thermal hold is replaced by temperature logging and focus-drift characterisation. INV-2 stays for any future heater. Why: the heater had no on-stage customer, and it adds cost, a safety subsystem and PLA drift (AU-15). Rejected: keeping the heater "for later". Reversible (cartridge keeps a heater footprint).
- **2026-10-09 · D-8 · One controller: Raspberry Pi Pico 2 (RP2350) + 3 × ULN2003 for the 28BYJ-48 steppers (PIO step timing), plus LED enables, pumps, leak sensors and the waste-level sensor.** It speaks the Sangaboard serial protocol. Interlocks stay in hardware: the lid switch breaks the excitation LED supply, and a leak trip cuts the pump/LED rail via a relay latch that firmware can't override. Why: −£40–60 and one board fewer (AU-16). Rejected: Sangaboard plus a separate RP2040. Reversible.
- **2026-10-09 · D-7 · Main camera (provisional): mono IMX296 global shutter, 1456 × 1088, 3.45 µm.** Four vendors. Order 12 confirms it with the SNR, tile and time budget before Basket H. Why: mono, global shutter, picamera2 support claimed by the vendor, ~£50–65 (F-5). Rejected for now: a Bayer HQ camera (signal loss), astronomy USB cameras (closed SDKs). Reversible until Basket H.
- **2026-10-09 · D-6 · Platform: fork OpenFlexure v7 hardware (pinned v7.0.0-beta5 commit), with SWELL's own picamera2/FastAPI service on a Raspberry Pi 5.** Pi 5 because it has two CSI ports (main + overview). Why: OFM software is Pi ≤ 4 + Camera v2 only, and v3 is alpha (AU-09). Rejected: waiting for OFM v3; Pi 4 with a USB overview camera. Reversible.
- **2026-10-09 · D-5 · Resolution QC = bead PSF ÷ E plus FRC, at every E.** Z-disc FWHM is reported as an apparent width with a quadrature-corrected true width and its uncertainty (a result, not a gate test). G5 is rewritten to match. Why: AU-02. Reversible.
- **2026-10-09 · D-4 · Primary local-expansion ruler = paired sarcomere-period ratio, SL_post / SL_pre per myofibril.** Fourier estimate with a multi-harmonic fit, prior window from SL_pre × E_macro ± 15%; population-ratio fallback without registration; A-band length secondary (resolved I-band only). Why: supermarket SL ~1.69 µm defeats the A-band rule; the period is blur-invariant: the full pre/post ratio, including a label-free pre-image, has 0.21–0.35% error at 10 sarcomeres for assumed contrast of 5–50% (calc §4; P1 measures the contrast) (AU-01). Rejected: a stricter A-band rule (discards ~87% of data). Reversible. **Life 2 note:** the 0.21–0.35% figure assumed perfectly periodic sarcomeres. With realistic 3% sarcomere-to-sarcomere jitter, the free-frequency fit fails, so the estimator is now the Z-disc ladder (D-33): 0.3–0.6% RMS per myofibril over 8–20 sarcomeres across runs of the whole-gel simulation (D-34).
- **2026-10-09 · D-3 · Stage model:** Stage 1 = P0 → G0 (virtual build passed); Stage 2 = ordering window between G0 and P1 (W released at G1); Stage 3 = P1 → G6. Orders are written in detail for Stages 1–2, while Stage 3 is outlined per phase and detailed at each gate. Why: the owner's brief, with kit/08 scope control kept. Reversible.
- **2026-10-09 · D-2 · Isolated toolchain:** our own uv 0.12.24 and CPython 3.12.15 inside .tools/, a .venv with 250 pinned packages (software/requirements.lock), portable apps in .tools/, and caches and config redirected by tools/env.*. Proven by tools/smoke_tools.py (25/25, 24 doing real work; D-25). psfmodels swapped for MicroscPSF-Py + pyotf (no cp312 Windows wheel; a compiler would need a system install). Why: coexistence with another project on the same PC (INV-17). Reversible.
- **2026-10-09 · D-1 · PM conventions:** the kit layout plus two patterns from another project, read once and read-only: a lessons file (pm/LESSONS.md) and a brief tool that refuses names and keys and enforces the cap (tools/brief.py). The push-notification topic is random (public-by-name service). Why: kit/08 says to copy better conventions (AU-39). Reversible.
