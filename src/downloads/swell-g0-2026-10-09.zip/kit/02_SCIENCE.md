# The science

## Principle
- **How ExM works:** biomolecules are anchored to a swellable polyelectrolyte gel (sodium acrylate and acrylamide, crosslinked with bis-acrylamide). The specimen's mechanical integrity is then disrupted, either by heat and SDS denaturation or by proteinase K digestion. Finally the gel swells in water.
- **Expansion factor:** close to isotropic. E ≈ 4–4.5× for U-ExM-type gels and ≈10× for TREx-type gels. Effective resolution ≈ optical resolution ÷ E.
- **Contrast:** an NHS-ester pan-protein stain applied after expansion maps protein density and gives EM-like contrast.
- **Practice gels:** the gel is a chemical cousin of nappy superabsorbent (sodium polyacrylate). Water beads swell by the same mechanism, so they make safe practice gels for testing fluidics, filming and focus tracking in Phase 2.

## Why chicken myofibrils first
- They're cheap, legal and available. No microtome is needed: blending gives isolated myofibrils.
- Myofibrils are ~1–2 µm thick, so even expanded they need only a handful of z-planes (~5–8).
- Their ultrastructure survives death far better than kidney's. Use the freshest meat available, because ageing is enzymes breaking down Z-disc proteins.
- **They come with built-in rulers (the core QC idea):**
  - **A-band ≈ 1.6 µm (thick-filament length).** It stays nearly constant in vertebrate skeletal muscle whatever the contraction state **(verify for chicken pectoralis)**. This is the primary ruler for local E.
  - **Sarcomere period ≈ 1.6–2.5 µm.** It changes with contraction, so it only works as a ruler when you compare the same myofibrils before and after expansion.
  - **Z-disc.** It is tens of nm wide in fast muscle **(verify)**, so it behaves as a sub-resolution line source and its FWHM reads out effective resolution directly.
  - **Random orientations.** Myofibrils settle at random angles. If expansion is isotropic, the A-band length after expansion won't depend on angle. That gives an isotropy test that needs no registration.
- Muscle-biopsy EM is a real clinical service, so muscle is a credible bridge to later medical relevance.
- **Prior art (Order 2):** search for ExM on vertebrate myofibrils and for low-cost ExM imaging. If it's been done, cite it and position SWELL as the cheap automated platform. If not, the first chicken result is notable in itself.

## Value
1. **Statistics at the nanoscale:** thousands of structures per sample instead of the handful EM allows.
2. **Built-in QC:** each gel measures its own expansion and distortion, which could make SWELL a reference method. Reproducibility between labs is a known ExM concern.
3. **Same cell, live then fixed then nanoscale (later):** possible because the same-instrument design keeps the sample in place.
4. **Screening and atlases:** nanoscale phenotypic screening and ultrastructure atlases under one protocol on one machine.
5. **Paired data:** before/after-expansion pairs test whether ordinary images hide recoverable nanoscale information.
6. **Access:** nanoscale imaging in ordinary labs, teaching labs and low-resource settings.

## Honest limits
- Resolution is ~115–130 nm at 4× and ~80–90 nm at 10×, not EM.
- You only see what you label. The chemistry can create artefacts, and widefield imaging blurs thick gels.
- Research use only. SWELL is not a diagnostic device.

## Literature (Order 2 confirms details and finds newer work)
- Chen, Tillberg & Boyden 2015, *Science*: expansion microscopy, plus the distortion-analysis method.
- Tillberg et al. 2016, *Nat Biotechnol*: proExM and AcX anchoring.
- Zhao et al. 2017, *Nat Biotechnol*: ExPath on clinical specimens.
- Gambarotto et al. 2019, *Nat Methods*: U-ExM.
- protocols.io, "U-ExM of diverse samples" (2025): the source of the v0 recipe in 05.
- M'Saad & Bewersdorf 2020, *Nat Commun*: pan-ExM and NHS-ester total-protein labelling.
- Damstra et al. 2022, *eLife* 11:e73775: TREx, 10× in one step. Also check its published correction (eLife 85169, **verify**).
- Collins et al. 2020, *Biomed Opt Express*: the OpenFlexure Microscope.
