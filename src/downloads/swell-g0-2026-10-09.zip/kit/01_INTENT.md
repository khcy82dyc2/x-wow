# The owner's intent

Treat this as the owner's voice. When the kit doesn't cover something, choose what this file points to.

## Why SWELL exists
- Nanoscale imaging is locked inside institutions: electron microscopy (EM) services, expensive super-resolution systems, vendor lock-in, office politics and ownership fights.
- The chemistry that breaks this open has been published for years (ExM in 2015, shown on clinical samples in 2017). But the gel chemistry and the scanning automation sit in different departments, and nobody owns both halves.
- SWELL puts both halves in one cheap box that the owner owns outright. It should be advanced, genuinely useful, and completely legal.
- "Doable by anyone" means:
  - Any maker can build the instrument.
  - The chemistry needs a lab, a community lab or a registered business, because UK REACH restricts the reagents to professional users.

## What success looks like
1. **"Ya, it's close enough":** the four checkpoints in 06_QC.md pass on chicken myofibrils.
2. **The button:** chicken in, button pressed, nanoscale muscle out, with the gel's own QC proving the expansion was even.
3. **Rebuildable:** a stranger with the docs, a 3D printer, the BOM and access to a lab for the chemistry gets the same QC numbers at the same cost.

## Decisions already made (don't reopen without new evidence)
- Build from zero. [personal detail removed]
- Smallest size, one or two samples at a time, cheapest option, and all-new parts so others can rebuild at the same cost.
- The owner does the hands-on work himself, guided by you. Imaging facilities and community labs are optional infrastructure, proposed only through OUTREACH.
- First specimen: chicken-breast myofibrils (blended, no microtome).
- [personal detail removed] Gates pass on BOM parts.
- No human tissue, no live animals, no clinical claims.
- Design for robots. One day a robot will do the hands-on steps, so every manual step must be discrete, documented, and done on a standard holder or cartridge.

## How the owner wants to work with you
- You make technical decisions yourself. Don't give him option menus. Ask him to act only when you can't: money, hands, accounts, outreach, publication, safety sign-off.
- [personal detail removed] Skip the basics. Session cards can assume lab competence but must still list every hazard and control.
- He likes thinking at the idea level, so keep his sessions rare, short and well prepared.
- Anything written for him to read (STATUS, session cards, approval requests) is in English first, followed by a short colloquial Chinese (大白话) version.
- He values bold, unexpected ideas. Put yours in pm/IDEAS.md marked [Claude], but never let them derail the current phase.

## What he cares about beyond the build
- **Ownership.** Results and IP stay his. Don't agree to anything framed as a "collaboration" that gives someone co-ownership or authorship without his explicit approval.
- **Openness for rebuilders.** The licence is decided at the release gate.
- **Evidence over hype.** Every claim needs measured QC behind it.
