# SWELL handoff kit — READ FIRST

You are local Claude Code. From now on you run this project end to end: research, design, CAD, firmware, software, protocols, QC, documentation and project management. The owner only does what you can't: pay, use his hands, sign off safety, and talk to people. This kit holds everything decided in the owner's planning chat with Claude on 2026-10-09, plus a final design review.

## Mission
Build **SWELL**: a small, cheap, rebuildable, automated **expansion-microscopy (ExM)** imager.
- Chemistry does the resolution work: a hydrogel swells the specimen 4–10× in every direction, so cheap optics resolve ~80–130 nm.
- First specimen: myofibrils from supermarket chicken breast. Muscle carries its own rulers, so every gel can prove its own expansion was even.
- North star: sample in, one button, out comes a stitched whole-gel nanoscale image plus a QC report that proves it is trustworthy.
- Reference build: all-new parts, about £1,000 of hardware, documented so that any maker can build the instrument for the same cost and get the same QC numbers.
- The chemistry is the exception. It needs professional-user access (a lab, a community lab, or a business), because UK rules restrict the reagents.

## Boot sequence (first life)
1. Read every file in this kit in order (00 → 10, then templates/). Read 08 (how the project runs) and 10 (safety and legal) closely.
2. Start pm/LEDGER.md with "Life 1 started" before anything substantial (structure in 08).
3. Work through the orders from templates/ORDERS.md, starting with Order 1 (it sets the project up). Phase 0 is desk-only: run it to Gate G0 without the owner, except for one short batch-1 human session.
4. End every life by rewriting pm/STATUS.md, appending to the ledger and committing.

After boot, every later session starts from ./CLAUDE.md (the standing rules). The owner will just say "continue".

## Rules about this kit
- The kit is read-only. If something here is wrong, record it in pm/ERRATA.md with evidence and act on the corrected version.
- Items marked **(verify)** come from memory or quick checks. Confirm them against primary sources (Order 2) before relying on them.
- Where the kit is silent, decide the way 01_INTENT.md points, and log the decision.

## Files
| File | Contents |
|---|---|
| 01_INTENT.md | What the owner wants, decisions already made, how to work with him |
| 02_SCIENCE.md | ExM principle, why chicken myofibrils, built-in rulers, value, limits, literature |
| 03_DESIGN.md | Reference architecture, key numbers, design rules, delegated decisions |
| 04_BOM.md | Cost envelopes, sourcing rules, per-phase baskets |
| 05_PROTOCOL.md | Wet-lab starting protocol (4× now, 10× later) |
| 06_QC.md | The four "close enough" checkpoints, QC report, data rules |
| 07_ROADMAP.md | Phases P0–P6 and their gates |
| 08_PM_SYSTEM.md | Lives, ledger, orders, auditors, approvals, human queue, push-notification |
| 09_RISKS.md | Seed risk register |
| 10_SAFETY_LEGAL.md | Hazards, UK legal map, hard stops |
| templates/CLAUDE.md | Standing rules → copy to the project root |
| templates/ORDERS.md | Seed orders for Phase 0 → pm/ORDERS.md |
| templates/INVARIANTS.md | Seed invariants → pm/INVARIANTS.md |

## Phases (detail in 07)
P0 Desk → P1 Optics and motion → P2 Chamber and fluidics (water only) → P3 Chemistry by hand, 4× ("close enough") → P4 Automation → P5 10× with cheaper optics → P6 Rebuild package and release.

## Priority and pace
- [personal detail removed] Batch his tasks into rare, well-prepared sessions. Never interrupt him for anything you can decide.
- Don't loop non-stop on SWELL unless the owner starts it that way. If every open order is blocked on him, update STATUS, send one push-notification, and end the life instead of burning usage.

## Glossary
- **E**: linear expansion factor.
- **ExM**: expansion microscopy.
- **U-ExM**: ultrastructure ExM (~4×, heat/SDS denaturation).
- **TREx**: ten-fold robust ExM.
- **NHS-ester pan-stain**: a dye that labels all proteins, giving EM-like contrast.
- **PLL**: poly-L-lysine.
- **OFM**: OpenFlexure Microscope.
- **Life**: one Claude Code session.
- **Order**: a numbered work item.
- **Gate**: the exit check for a phase.
- **Auditor**: a fresh session or subagent that verifies work it didn't build.
