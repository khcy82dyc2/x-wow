# Wet-lab protocol: v0 starting point

Turn this into protocols/SWELL-ExM4-v0.1.md. It must be versioned, and every step needs a volume, time, temperature, hazard and waste route.

Before the owner runs anything:
- Verify every number against its source.
- Wherever this file offers an "or", pick one option and log the choice in DECISIONS, so the session cards contain no options.

Session cards for the owner are derived from the protocol (format in 08).

## Track A: ≈4× (U-ExM-type), the "close enough" path
**Sources:** protocols.io "U-ExM of diverse samples" (2025) and Gambarotto et al. 2019. The values below were read from the protocols.io page on 2026-10-09.

**0. Myofibril prep** (adapt from a cited primary myofibril-isolation protocol; verify every value)
- Use the freshest chicken breast available.
- Mince a small piece into ice-cold rigor buffer with ~0.5–1% Triton X-100 and a protease-inhibitor cocktail.
  - Typical rigor buffer: ~100 mM KCl, 2 mM MgCl₂, 1 mM EGTA, 10 mM Tris or imidazole, pH 7.
- Blend or homogenise briefly.
- Wash 2–3× by low-speed spin in buffer without detergent.
- Settle onto PLL-coated 12 mm #1.5 coverslips.
- Check for striated myofibrils under transmitted light.

**1. Fix**
- 4% formaldehyde (methanol-free) in buffer, 20 min at room temperature (bench).
- Wash 3× 5 min in PBS.

**2. Pre-expansion imaging** (SWELL addition, on the stage, in PBS only)
- Mount the specimen coverslip as the floor of the coverslip chamber.
- Take label-free transmitted and oblique images of fiducial-marked fields (for the A-band and sarcomere rulers), plus an overview image.
- Confirm in Order 2 that imaging before anchoring doesn't harm the protocol.

**3. Anchor**
- 1% acrylamide + 0.7% formaldehyde in PBS, overnight at 37 °C.
- Keep the dish inside a sealed box in the incubator, off the stage. The mix gives off vapour.

**4. Monomer solution (MS)**
- Final concentrations: 10% acrylamide, 19% sodium acrylate, 0.1% bis, 1× PBS.
- Per 250 µL, as listed on the source page: 62.5 µL 40% acrylamide, 125 µL 38% sodium acrylate, 12.5 µL 2% bis, 25 µL 10× PBS.
- **These volumes only add up to 225 µL.** Take the remaining 25 µL, and the APS and TEMED amounts, from the source before use. U-ExM commonly uses 10% stocks of APS and TEMED at ~0.5% final each **(verify)**.
- Store MS at −20 °C, in the lab freezer, for less than 2 weeks.
- Sodium acrylate purity matters: the solution should be colourless (see the source's purity note).

**5. Gel**
- Work fast and cold: add APS and TEMED to the MS on ice.
- Use ~150 µm spacers, with about 17 µL for a 12 mm coverslip. Compute the exact volume from the spacer height.
- Lower the coverslip specimen-side down onto the drop on cold parafilm.
- 5 min on ice, then ≥45 min at 37 °C in a humid chamber.
- The thin sandwich keeps oxygen out, so no gas purge is needed.

**6. Punch**
- Punch ≤2 mm disks from the gel (2 mm biopsy punch). Several disks from one coverslip are technical replicates.
- Record each disk's diameter before expansion from an overview image.
- Cut one corner or notch to mark orientation.

**7. Denature**
- Buffer: 50 mM Tris, 200 mM NaCl, 200 mM SDS, pH 9.0, preheated to 95 °C.
- 1–1.5 h at 95 °C in screw-cap or lid-lock tubes in a lidded heat block, off the stage.
- Disks detach and swell to about 2×.

**8. First expansion**
- Wash in PBS 2× 5 min, then water 3× ≥15 min.
- Transfer the disk into the imaging dish with water. Do the liquid exchanges off the stage, then seat the dish.
- The overview camera (dark-field) films the swelling, measures E_macro against the recorded diameter, and detects the plateau. Expect ≈4–4.5×.

**9. Stain** (pan-protein, off the stage)
- Shrink the gel in PBS, 3× 5 min.
- Stain with NHS-ester dye at ≈2 µg/mL in PBS or 100 mM bicarbonate pH 8.3, for ≥2 h at 37 °C.
- Wash 3× 15 min in water to re-expand.

**10. Mount**
- Coat the dish with PLL (~20 min), then rinse.
- Lay the gel specimen-side down. Blot excess water without drying it.
- Don't reposition it. Put the lid on.

**11. Image**
- Find the specimen at low magnification.
- Take tiled z-stacks.
- Run QC (06).

**12. Store** in water at 4 °C, in the lab fridge.

## Track B: ≈10× (TREx-type), after G4
**Source:** Damstra et al. 2022, *eLife*. Check the published correction too (Order 2).
- **What it achieves:** about 10× expansion in a single step.
- **Recipe:** the chosen recipe family uses a higher acrylamide-to-acrylate ratio, so it's less sensitive to acrylate purity.
- **Disruption and staining:** SDS/heat disruption keeps more total-protein signal than proteinase K, and NHS-ester total-protein stains work.
- **Anchoring:** TREx uses AcX anchoring. Decide by experiment whether FA/AA anchoring works with the TREx gel, or buy AcX.
- **Handling:** punch disks of ≤1 mm. The gels are fragile, so design handling around that.

## SWELL additions to test (decide by experiment, log in DECISIONS)
- Embed 1 µm fluorescent beads in the MS. They give a full deformation field and a visible gel outline.
- Compare two pre-expansion references: a pre-gel pan-label with a polymerisation-robust dye, and label-free pre-images. Keep whichever registers better against the post-expansion image.
- Replace "overnight" waits with plateau detection.
- Use expansion kinetics as a QC signal: flag gels that swell abnormally fast or slow.

## Safety and waste (full detail in 10)
- **CMR substances:** acrylamide, bis-acrylamide and formaldehyde. Rules:
  - Use them as solutions, with double nitrile gloves.
  - Work in a ventilated, lockable room, never the kitchen.
  - Never put them on the stage.
- **Powders** (sodium acrylate, APS): weigh into closed, pre-tared vials. Don't pour them on an open bench.
- **Waste:** nothing goes down the drain. Order 3 names the UK waste route, and whether leftover monomer is polymerised before disposal follows that route.
- **Sodium azide:** skip it; it isn't needed.
- **95 °C SDS:** scald risk. Use screw-cap or lid-lock tubes and a lidded block.
- **Raw chicken:** treat with food hygiene until it's fixed. Keep dedicated tools.
