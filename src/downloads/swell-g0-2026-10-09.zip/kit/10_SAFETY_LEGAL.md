# Safety and legal: hard boundaries

You aren't at the bench, so you can't see the hazards. To compensate:
- Every session card names its hazards and controls.
- Before the first use of each hazardous reagent, the owner signs off a COSHH-style risk assessment for it (via APPROVALS).

## Workspace rules
- **The room:**
  - A ventilated, lockable room that is not the kitchen.
  - No food or drink in the workspace.
  - Children and pets kept out, and chemicals locked away when the room is unattended.
- **Equipment:**
  - A dedicated, labelled lab fridge/freezer that never holds food.
  - TEMED (flammable) stays at room temperature in a closed container, never in a domestic fridge.
- **Overnight anchoring** (formaldehyde/acrylamide at 37 °C) runs in a sealed box.

## Chemical hazards
Verify each one against the supplier SDS, and keep the SDS PDFs in protocols/sds/.

**CMR substances (acrylamide, bis-acrylamide, formaldehyde)**
- **Acrylamide:** toxic, Cat. 1B carcinogen and mutagen, neurotoxic, and absorbed through skin. Buy it as a 40% solution, never as powder.
- **Bis-acrylamide:** suppliers classify it as a mutagen and carcinogen (Cat. 1B) with repeated-exposure toxicity **(verify the SDS)**. Treat it as CMR and buy it as a solution.
- **Formaldehyde:** Cat. 1B carcinogen, sensitiser, and toxic by inhalation. Use methanol-free ampoules, opened only with ventilation, and keep volumes small.
- **Controls for all three:** double nitrile gloves, goggles and a lab coat; a ventilated dedicated area. They never go on the stage.

**Polymerisation reagents and other powders**
- **APS:** oxidiser and respiratory sensitiser.
- **Sodium acrylate:** irritant, and its purity matters.
- **Handling both powders:** weigh into closed, pre-tared vials with minimal dust.
- **TEMED:** flammable, corrosive and strong-smelling. Use small quantities and keep it closed.

**Buffers and solvents**
- **SDS:** irritant. The 95 °C buffer is a scald hazard: use screw-cap or lid-lock tubes in a lidded block.
- **DMSO (dye solvent):** carries dissolved chemicals through skin. Always wear gloves.
- **Triton X-100:** harmful to aquatic life. It goes to waste, never down the drain.
- **Sodium azide:** don't use it. Gels are stored in water at 4 °C instead.

**Biological and other**
- **Raw chicken:** Campylobacter and Salmonella risk, so use food-hygiene practice until it's fixed. Dedicated tools never return to the kitchen.
- **Water beads:** ingestion hazard. Keep them sealed and away from children and pets.

## Physical hazards
- **Electrical:** ≤24 V DC inside the instrument, certified external PSUs and fused rails. The builder never wires mains.
- **Heat:**
  - Every heater has a hardware thermal cutoff. It is rated ≤50 °C for anything on or near printed parts.
  - Firmware turns heaters off on any fault.
  - 95 °C steps happen off-stage only.
- **Light:** high-power LEDs. Interlock the lid and never look into the beam.
- **Liquids near optics and electronics:** see INV-1 and INV-3.
- **Not in the reference build:** lasers and UV-C.

## Legal map (UK, England — Order 2 checks the current versions; you are not a lawyer, so flag doubts)
**Chemicals and workplace safety**
- **UK REACH Annex XVII, entries 28–30.**
  - CMR substances can't be supplied to the general public. This covers acrylamide and, by Reg. (EU) 2018/675 as retained in UK law, formaldehyde.
  - So buy as a business or professional user only if that is genuinely true; never misrepresent. Otherwise use a community lab.
  - Expect some suppliers to refuse residential delivery.
  - For rebuilders, anyone can build the instrument, but the chemistry needs professional-user access (a lab, a community lab, or a business). Say so in the docs.
- **COSHH 2002.** [personal detail removed] Either way, do the assessment.
- **Hazardous waste.** The Hazardous Waste (England and Wales) Regulations 2005 and the duty of care under EPA 1990 s.34 apply. Use a licensed carrier and keep consignment records. Nothing hazardous goes down the drain or into household waste.

**Biological material**
- **Human Tissue Act 2004.** No human material in this project. Later, only through an ethics-approved partner.
- **Animals.** Food-chain tissue only. No live animals; that would fall under the Animals (Scientific Procedures) Act 1986.

**Medical claims**
- **Medical devices.** Research use only, with no diagnostic claims. Diagnostic use would fall under UK MDR 2002 (or the EU IVDR). Label the docs "Research use only".

**Intellectual property**
- **Patents (UK Patents Act 1977, s.60(5)(a)/(b)).** The exemptions are narrow:
  - (a) needs use that is both private and non-commercial.
  - (b) covers experiments on the subject matter of the invention itself.
  - Work run through a business, or publicity with commercial intent, may fall outside both.
  - In Order 2, map the relevant ExM patents (UK/EP status, expiry). Then put a professional freedom-to-operate check in APPROVALS before any public release or commercial step.
- **Open-hardware licences.** Comply with OpenFlexure's licences and those of any other forked project. Keep LICENSES.md from Order 1 onward.

**Selling hardware**
- Selling hardware brings product-safety, EMC and marking duties. Research these at G6, before any sale.

## Hard stops
For any of these, stop and raise it in APPROVALS, or refuse:
- Human tissue or any human-derived material, or live animals.
- Mains wiring, or disabling or bypassing an interlock, thermal cutoff or leak cutoff.
- First use of any hazardous reagent without a signed risk assessment.
- Any CMR liquid, casting step or 95 °C step on the stage.
- Any purchase, account creation, contact with people or organisations, public posting, or licence or release decision.
- Misrepresenting the owner's status to a supplier.
- Disposal by any route other than the approved one.
- Any claim of diagnostic performance.
