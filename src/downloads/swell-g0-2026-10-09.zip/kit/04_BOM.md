# Bill of materials

Planning envelopes in GBP, roughly as of Oct 2026. Order 5 replaces them with a live, priced BOM in pm/BOM.csv and docs/BOM.md.

## A. Reference hardware (the rebuild cost): target ≤ £1,000
The line items below add up to about £600–1,550. Reaching the target means staying near the low end of each line; Order 5 proves it.

| Item | Envelope |
|---|---|
| Printed flexure stage and frame (OFM fork), plus the OFM screws/fixings kit | £30–70 (filament ~£20) |
| Steppers and motor controller | £20–80 |
| Objective(s): RMS plan achromat | £40–150 |
| Tube lens and optics mounts | £40–100 |
| Raspberry Pi (4 or 5, per Order 4), PSU and SD card | £60–100 |
| Main camera (mono preferred) | £50–150 |
| Overview camera with dark-field LED ring | £20–40 |
| LEDs (excitation, white, oblique) and constant-current drivers | £30–70 |
| Excitation filter, emission filter and dichroic | £100–350 |
| Coverslip chamber (pre-expansion) and kinematic dish holder | £20–50 |
| v1 cartridge: body, glass, heater, thermistor, ≤50 °C thermal cutoff, seals | £50–150 |
| v1 fluidics: 4–6 peristaltic pumps, waste pump, chemical-compatible tubing, mesh, overfill sensor | £80–160 |
| Control board (RP2040-class), MOSFET drivers, leak sensors, lid interlock | £20–50 |
| PSUs, fuses, wiring, light-tight enclosure, objective drip ring and sleeve | £50–100 |

## B. Wet lab, first fill: £1,200–2,500
Minimum pack sizes from UK lab suppliers drive most of this. Per-gel cost is likely pennies to a couple of pounds; compute it.

**Equipment**
- Adjustable pipettes (P20, P200, P1000) and tips.
- Mini-centrifuge.
- 0.01 g balance.
- Heat block that reaches ≥95 °C, with a lid, plus screw-cap or lid-lock tubes.
- 37 °C incubation (a cheap incubator), plus a sealable box for the overnight anchoring step.
- **A dedicated, labelled lab fridge with a freezer compartment. No food ever goes in it.** TEMED is flammable, so store it at room temperature in a closed container, never in a domestic fridge.
- Dedicated blender (never goes back to the kitchen), ice bucket, pH meter or strips, humid chamber, parafilm.
- #1.5 coverslips (12 mm and dish-sized), glass-bottom dishes, PLL, coverslip spacers (~150 µm).
- Biopsy punches (1 mm and 2 mm), fine brushes, razor blades, tubes, timers.

**Reagents** (the exact list comes from the protocol, Order 3)
- Gel: high-purity sodium acrylate, 40% acrylamide solution, 2% bis-acrylamide solution, APS, TEMED.
- Fixative: methanol-free formaldehyde in ampoules.
- Buffers and myofibril prep: 20% SDS solution, Tris, NaCl, PBS, KCl, MgCl₂, EGTA, Triton X-100, protease-inhibitor cocktail.
- Stain: sodium bicarbonate, a pH-insensitive NHS-ester dye, and anhydrous DMSO for the dye stock.
- Ultrapure water.

**PPE and safety**
- Nitrile gloves (double for acrylamide and bis), goggles, lab coat.
- Spill kit and labelled waste containers.
- Lockable chemical storage.

## C. Calibration and test: £100–400
- Stage micrometer (10 µm divisions) and a USAF 1951 target.
- Sub-diffraction fluorescent beads (≈100–200 nm) for the PSF.
- A uniform fluorescent reference for flat-field correction.
- Water beads for practice gels.
- Optional: ≈1 µm fluorescent beads to embed as fiducials and to outline the gel.

## D. Tools (only if the owner lacks them; ask in batch 1)
- A 3D printer, or a print service or local makerspace. You decide, but buying a printer needs approval.
- Basic hand tools and a multimeter.

## E. Operations (not part of the rebuild cost, but in the project budget)
- Data storage: a 2–4 TB drive plus a backup. Expect tens of GB per gel.
- Hazardous-waste collection fees (get quotes in Order 3).
- Community-lab membership, if that route is used.

## Sourcing rules
- **All new.** Every line has a primary and a fallback supplier, a part number, a price and the date checked.
- **Stable suppliers:**
  - Optics: Thorlabs or Edmund.
  - Raspberry Pi parts: official resellers.
  - Electronics: RS, Farnell, Mouser or DigiKey.
  - Fluidics: Darwin Microfluidics.
  - Reagents: major lab suppliers.
  - Commodity parts are fine where several sources exist.
- **Hazardous reagents:**
  - UK REACH bars supplying CMR substances (acrylamide, bis-acrylamide, formaldehyde) to the general public.
  - Buy as a business or professional user **only if that is genuinely true. Never misrepresent.** Otherwise use the community-lab route.
  - Many suppliers won't deliver hazardous goods to residential addresses. Settle the delivery address before G0 (see 10).
- **Buy per phase.** Each phase gets one basket in APPROVALS (links, quantities, total). The owner pays; you never touch money.
- **Keep receipts** in pm/receipts/. The "same cost" claim is audited at G6.
