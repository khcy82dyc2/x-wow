# Reference design: SWELL v1

This is a starting point. You own the details and log every change in DECISIONS.

## Philosophy
1. Chemistry does the resolution, so the optics stay cheap. Spend effort on gel QC, not glass.
2. Build the smallest thing that works: one or two samples, desk-sized, ≤24 V DC inside.
3. Make it rebuildable: all-new parts with more than one supplier, printable parts, and no soldering if achievable. Hardware target ≤ ~£1,000.
4. Make it robot-ready: every manual step is discrete, documented, and done on a standard holder or cartridge.
5. Measure, don't assume: every gel reports its own expansion and distortion.

## Architecture
- **Base: fork the OpenFlexure Microscope (OFM, v7)** unless Order 4 finds a better route.
  - Printed flexure XYZ stage, inverted optics (objective below, sample above).
  - Raspberry Pi with a Pi-class camera, RMS-thread objectives, printable filter cubes for epi-fluorescence.
  - XY travel nominally ~12 × 12 mm (users report ~10 mm); steps under 100 nm **(verify both)**.
  - The Z axis moves the optics, not the sample, which is good for liquids.
  - **Pi version (verify):** as of 2025 the OFM software targeted a Pi 4 with Pi Camera v2. A Pi 5, or a mono camera, may need SWELL's own camera service. Decide in Order 4.
- **Imaging modes:**
  - **Epi-fluorescence:** one LED plus a filter set matched to the chosen NHS-ester dye.
  - **Transmitted white light from above, through the lid:** for finding samples and taking label-free pre-expansion images. 2–4 switchable oblique LEDs give cheap differential phase contrast, so unstained striations show up.
  - **Overview camera:** a second small camera that sees the whole dish or cartridge. It films the expansion and measures macro E and the gel outline.
    - Use dark-field lighting (a low-angle LED ring over a black background).
    - Expanded gels are almost index-matched to water and nearly invisible in plain light.
    - Optionally, trace fluorescent beads in the gel make the outline unambiguous.
- **Sample holders:**
  - **v0 pre-expansion:** an Attofluor-style coverslip chamber where the specimen coverslip *is* the floor. A dry 0.65 NA objective has ~0.5 mm working distance and can't image through a second glass layer.
  - **v0 expanded gels:** a standard 35 mm glass-bottom dish, PLL-coated, in a printed holder with a kinematic seat. The holder lifts off for liquid handling and drops back repeatably.
  - **v1:** the SWELL cartridge: glass floor, kinematic seat, fiducials, and a lid with ports.
- **Where the chemistry happens:**
  - **v0:** every hazardous wet step is done by hand on the bench. Only PBS and water ever go on the stage (pre-expansion imaging in PBS; expansion and imaging in water). Liquid exchanges happen with the holder lifted off the stage.
  - **v1:** automates on-stage exchanges of non-hazardous liquids (washes, staining, water changes) and 37 °C steps.
  - Casting, CMR liquids and the 95 °C step stay off the stage (INV-6, INV-14). Changing that needs the owner's approval.
- **Fluidics (v1):**
  - Small peristaltic pumps, one per reagent with no shared valves, so there's no cross-contamination. Plus a waste pump.
  - An overflow weir to waste, so the chamber can't overfill.
  - A mesh guard so the gel can't be sucked out.
  - Reservoirs and the waste bottle sit low, never above the optics or electronics. The waste bottle has overfill sensing.
- **Thermal:** film heater, thermistor and PID on the cartridge, plus a hardware thermal cutoff independent of software, rated ≤50 °C for anything on or near printed parts.
- **Electronics:**
  - Raspberry Pi (4 or 5, see above).
  - OFM motor controller (Sangaboard or its successor, **verify**).
  - A small RP2040-class board for the LEDs, heater, pumps, leak sensors and lid interlock.
  - Certified external PSUs only, and nothing mains inside.
- **Enclosure:** light-tight, with a lid interlock that cuts the excitation LED.
- **Software:**
  - A Python service on the Pi providing the hardware API, with a simulated backend.
  - Orchestration, acquisition and analysis on the PC, driven by you.
  - Reuse OFM software pieces where they fit.
- **Data:** OME-Zarr (or pyramidal OME-TIFF), one folder per run, metadata per 06.

## Key numbers (λem ≈ 550 nm; compute the specifics for the chosen dye in Order 4)
- **Lateral resolution:**
  - Rayleigh ≈ 0.61·λ/NA. FWHM ≈ 0.51·λ/NA (QC measures FWHM).
  - 4–4.5× gel with a 40×/0.65 objective: Rayleigh ≈ 115–130 nm, FWHM ≈ 95–110 nm.
  - 10× gel with a 20×/0.4 objective: Rayleigh ≈ 85 nm, FWHM ≈ 70 nm.
  - More expansion plus a lower NA beats expensive glass.
- **Sampling:** sample-plane pixel ≤ λ/(4·NA): ≈ 210 nm at NA 0.65 and ≈ 340 nm at NA 0.4. Choose a magnification that just meets this, because a bigger field of view means fewer tiles.
- **Depth of field:** ≈ λ·n/NA². In water: ≈ 1.7 µm at NA 0.65, ≈ 4.6 µm at NA 0.4.
- **Specimen depth:** myofibrils are ~1–2 µm thick, so ~4–9 µm at 4× and ~10–20 µm at 10×. That's roughly 3–5 depths of field either way, so plan for ~5–8 z-planes.
- **Dry objective focusing into a water gel:** the real focal shift is ≈ 1.33–1.5 × the nominal z step, depending on NA (paraxial vs marginal rays). Calibrate it for each objective.
- **Signal dilution:** ≈ E³, i.e. 64× at 4× and 1,000× at 10×. Make an SNR budget before buying parts.
- **Gel geometry:**
  - Cast thin: ~150 µm spacers.
  - Punch the imaged piece before denaturation: ≤2 mm for 4× (→ ≤9 mm expanded) and ≤1 mm for 10× (→ ≤10 mm), so it fits the ~10 mm stage travel.
  - Dish or chamber inner size ≥ 1.3 × the expanded size.
- **Swelling:** time scales with thickness². Detect the plateau with the overview camera rather than waiting a fixed time.
- **Tiles and data:**
  - Tiles ≈ (expanded size / FOV)² × z-planes. Camera pixel count drives tile count and scan time.
  - At Nyquist, a 1.6 MP camera needs on the order of 1,000–2,500 tiles per plane for a 9 mm gel. Expect tens of GB per gel.
  - Make these numbers part of the camera decision.

## Design rules (enforced as INVARIANTS)
- **Inverted plus liquids means leaks fall towards the optics:**
  - Only the sealed sample vessel sits over the objective.
  - A drip ring or tray around the objective drains to a leak sensor.
  - The objective has a protective sleeve.
  - No tubing or reservoirs above the optics or electronics.
  - A leak trip cuts the pumps, heater and LED.
- **Temperature limits:**
  - The 95 °C step never happens on the stage or near printed parts. PLA softens at ~55–60 °C; PETG at ~80 °C.
  - On-stage heating is 37 °C only. Anything touching printed parts stays <45 °C.
  - Expect thermal drift: settle and refocus after temperature changes.
- **LEDs:** constant-current drive. No PWM dimming, because it causes banding.
- **Power:** low voltage only, from certified PSUs with fused rails.
- **Dye:**
  - NHS-ester, photostable and pH-insensitive. Gels sit in unbuffered water, and fluorescein dims below pH ~7, so no fluorescein.
  - If you pre-label before gelation, the dye must survive radical polymerisation. Cyanines often don't.
- **Camera:** mono is preferred for fluorescence. Mono IMX296 global-shutter boards for the Pi exist **(verify supply, noise and driver support)**. A Bayer sensor costs roughly 2–4× signal per channel.
- **Cartridges and holders that leave the stage:** kinematic seat plus fiducials.
- **Gel handling:**
  - Cut one corner to mark orientation.
  - Place the gel specimen-side down on PLL glass and never reposition it.
  - Keep the lid on against evaporation.
  - Store gels in water at 4 °C.

## Decisions delegated to you (decide by evidence and log them)
- **Platform:** fork OFM or go custom; Pi version; software reuse.
- **Optics:** objective(s); main and overview cameras; dye, LED and filter set.
- **Holders and fluidics:** coverslip chamber, dish holder, cartridge v1, pump type.
- **Data:** data format; deconvolution.

Moving casting, CMR liquids or the 95 °C step onto the machine is *not* delegated. Propose it in APPROVALS.

## Benchmark-only hardware
[personal detail removed]

## Considered and set aside (don't reopen without new evidence)
- [personal detail removed]
- **Nitrogen purge:** a thin gelation sandwich already excludes oxygen.
- **Multi-cartridge "hotel" and a big motorised stage:** not needed for one or two samples; expansion makes small specimens big enough.
- **sCMOS and high-NA glass:** expansion does the resolution work.
- **Lasers and UV-C:** safety and cost.
- **Other modalities from the planning chat** (Fourier ptychography, hyperspectral, polarisation, MUSE, rapid AST, haematology): parked in IDEAS.
