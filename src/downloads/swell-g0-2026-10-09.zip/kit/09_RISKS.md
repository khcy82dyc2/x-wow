# Risk register (seed)

Burn the top risks down early, using the cheapest experiment that settles each one. Copy this table to pm/RISKS.md and keep it current: likelihood/impact (L/M/H), owner and status.

| ID | Risk | L/I | Cheapest de-risking move | When |
|---|---|---|---|---|
| R1 | Hazardous reagents can't legally be bought, delivered or disposed of at a home address | M/H | Check supplier account rules, residential-delivery policies and licensed-waste-carrier quotes; draft an OUTREACH proposal for a community-lab fallback | P0 |
| R2 | Signal too weak after expansion with an uncooled camera and cheap optics (E³ dilution) | M/H | SNR budget in P0; bead and dye tests in P1; prove 4× before 10× | P0–P3 |
| R3 | Leak from the cartridge onto upward-facing optics | M/H | Water-only tests with optics shielded or removed; drip ring and objective sleeve; leak cutoff (INV-1, INV-3) | P2 |
| R4 | Gel drifts, flips, folds or gets sucked out during exchanges | H/M | Water-bead and blank-gel trials; PLL mount, mesh guard, slow flow, fiducials | P2–P3 |
| R5 | Isotropy worse than published (home conditions, chicken tissue) | M/M | A-band ruler and orientation test from the first gel; tune fixation and denaturation | P3 |
| R6 | Post-mortem damage in supermarket chicken | M/M | Freshest available vs an older pack; a butcher who knows the slaughter date | P3 |
| R7 | Thermal drift of the printed flexure stage | M/M | Log focus vs temperature; set settle and refocus rules | P1–P2 |
| R8 | Widefield blur in thick 10× gels | M/M | Keep specimens thin; test deconvolution | P5 |
| R9 | Sodium acrylate purity makes expansion poor or variable | M/M | Buy high-purity; reject yellow solutions; the TREx-style recipe is less sensitive | P3 |
| R10 | Parts vanish or prices drift, breaking the "same cost" claim | M/M | Primary and fallback supplier on every line; re-price at G6 | P0, P6 |
| R11 | A life is cut off mid-work and loses context | H/M | Ledger first, plus incremental ledger writes | all |
| R12 | Scope creep from new ideas | H/M | IDEAS inbox; orders only for the current phase | all |
| R13 | Works in simulation, fails on the bench | M/H | Physical-evidence rule at every gate | all |
| R14 | Licence breach when forking open hardware or software | L/M | Keep LICENSES.md from Order 1 | P0 |
| R16 | Expanded gels invisible to the overview camera (nearly index-matched to water) | M/M | Dark-field LED ring on a black background; optional fluorescent beads in the gel | P1–P2 |
| R17 | Too many tiles or too much data per gel (low-pixel-count camera) | M/M | Count tiles and scan time in the camera decision; data drive and backup | P0 |
| R15 | Patent exposure if commercialised | L/H | Private and experimental use are exempt; freedom-to-operate check before any sale | P6 |
