# SWELL: standing rules (read at the start of every session)

SWELL is a cheap, rebuildable, automated expansion-microscopy imager. Owner: the project owner. The full brief is in kit/ (read-only); corrections go in pm/ERRATA.md.

## Project facts (fill in during Order 1, keep current)
- Push-notification topic: (set in Order 1)
- Data drive and backup: (set in Order 1)
- Microscope host (Pi address): (set in P1)

## Every session
1. Append "Life N started: plan …" to pm/LEDGER.md before any substantial work.
2. Read pm/STATUS.md, pm/ORDERS.md and the latest pm/DECISIONS.md.
3. Work the highest-priority unblocked order in the current phase. Write to the ledger after each meaningful step.
4. End by rewriting pm/STATUS.md, appending "Life N ended" and committing.
5. If everything is blocked on the owner, update STATUS, send one push-notification and stop. Don't idle-loop.

## Authority
- Decide all technical matters yourself and log them in pm/DECISIONS.md. Never give the owner option menus.
- Involve the owner only for what you can't do yourself, via pm/APPROVALS.md or pm/HUMAN_QUEUE.md:
  - money and accounts
  - physical work
  - outreach and publication
  - licence and public name
  - safety sign-offs
  - irreversible steps, or a full project restart

## Hard limits
- Follow UK law and kit/10_SAFETY_LEGAL.md.
- Keep no secrets from the owner, and never misrepresent him to anyone.
- Never spend money or create accounts.
- Never contact people or organisations. Write drafts in pm/OUTREACH.md only.
- Never post publicly.
- No human-derived material, no live animals, no diagnostic claims.
- Never bypass an interlock, thermal cutoff or leak cutoff, in code or in design.
- Low voltage only. No CMR liquids, casting or 95 °C steps on the stage.
- Don't touch other projects on this PC; the only exception is the read-only conventions lookup in Order 1.
- Never open a folder whose name says Claude must not open it.
- [personal detail removed] Don't run SWELL non-stop unless the owner starts it that way.

## Evidence
- An order moves from believed-done to verified only after an auditor (a fresh session or subagent) checks it.
- G0 is a desk gate. From G1 on, gates need real-machine evidence; simulation never passes them.
- Invariants (pm/INVARIANTS.md) are never broken to finish an order.

## Talking to the owner
- STATUS, session cards and approval requests: short English, then a short 大白话 Chinese version.
- Use push-notification only for approvals, sessions ready, safety issues and gate results. At most 2 a day, except safety.
- New ideas from the owner go to pm/IDEAS.md, not orders. Triage them at gates.

## Data
- Runs live in `data/runs/YYYYMMDD-<id>/`.
- Raw data is immutable, and all processing is reproducible from raw.
- Metadata follows kit/06_QC.md.
- Large data stays out of git, on the data drive with a backup.
