# INVARIANTS: rules that must always hold

Format: INV-n · rule · subsystem · check. Add more as the design matures. Never weaken a safety invariant without the owner's approval.

## Hardware safety

- **INV-1 · Fluidics / mechanics**
  - Rule: only the sealed sample vessel sits over the objective. A drip ring or tray around the objective drains to a leak sensor, and the objective has a protective sleeve. No tubing or reservoirs sit above the optics or electronics. The waste bottle sits low and has overfill sensing.
  - Check: design review, plus a water test.
- **INV-2 · Thermal**
  - Rule: every heater has a hardware thermal cutoff that works independently of software. The cutoff is rated ≤50 °C for anything on or near printed parts. Firmware switches heaters off on any fault or lost heartbeat.
  - Check: fault-injection test.
- **INV-3 · Safety**
  - Rule: a leak-sensor trip turns off the pumps, the heater and the excitation LED, and sends a push-notification alert.
  - Check: wet-sensor test.
- **INV-4 · Optics / safety**
  - Rule: opening the lid turns off the excitation LED, through a hardware interlock.
  - Check: manual test.
- **INV-5 · Electrical**
  - Rule: ≤24 V DC inside the instrument, from certified PSUs, with fused rails.
  - Check: BOM and wiring review.
- **INV-6 · Thermal / process**
  - Rule: 95 °C steps never happen on the stage or near printed parts.
  - Check: protocol review.
- **INV-7 · Optics**
  - Rule: LEDs use constant-current drive. No PWM dimming during exposures.
  - Check: schematic review.
- **INV-13 · Software**
  - Rule: software never overrides INV-2, INV-3 or INV-4. No "force" flags.
  - Check: code review.
- **INV-14 · Process / safety**
  - Rule: no CMR-containing liquid (acrylamide, bis-acrylamide, formaldehyde, monomer solution) and no gel casting on the stage. Changing this needs the owner's approval.
  - Check: protocol review.

## Build and data integrity

- **INV-8 · Build**
  - Rule: the reference build uses only BOM parts. Benchmark parts never count toward a gate.
  - Check: gate audit.
- **INV-9 · Data**
  - Rule: raw data is immutable, and every image carries full metadata (kit/06).
  - Check: automated test.

## Process and ethics

- **INV-10 · Process**
  - Rule: every protocol step has a hazard and a waste route. Nothing hazardous goes to the drain or household bins.
  - Check: protocol lint.
- **INV-11 · Ethics / legal**
  - Rule: no human-derived material and no live animals.
  - Check: protocol review.
- **INV-12 · Process**
  - Rule: gates G1–G6 pass only on real-machine evidence. G0 is a desk gate.
  - Check: gate audit.
