# ORDERS — SWELL

Current phase: **P0 Desk**. P1 orders are written at Gate G0 (Order 9). Orders 2–7 can run in parallel lanes once Order 1 is done.

### Order 1 — Boot the project + batch-1 session card [P0] [open]
**Goal:** the project skeleton and PM system are live, and the owner has the only questions P0 needs answered.

**Acceptance:**
- **Setup:**
  - Folder layout per kit/08, with CLAUDE.md (project facts filled in) and all pm/ files.
  - LICENSES.md created.
  - git initialised.
  - The LEDGER starts with "Life 1 started".
  - Backups configured: local git plus a copy to another drive. A private remote repo goes in APPROVALS.
- **Conventions:** the owner's existing conventions are looked up read-only and mirrored where they're better.
  - [personal detail removed] If it doesn't, use the kit defaults and never ask.
  - Never write there. Never reuse its push-notification topic or social accounts. Never open folders whose names say Claude must not open them.
- **Push-notification:** a SWELL topic is created, and its first message is the batch-1 ping.
- **Batch-1 session card** in HUMAN_QUEUE (≤30 min, with 大白话), asking only for what you can't find out yourself:
  1. Subscribe to the SWELL push-notification topic.
  2–6. [personal detail removed]
- **STATUS.md** is written.

**Evidence:** tree listing, first commit hash, STATUS.md, HUMAN_QUEUE.md.

### Order 2 — Verify the kit [P0] [open]
**Goal:** check every **(verify)** item and every number in kit/ against primary sources.

**Covers:**
- **Prior art:** ExM on vertebrate myofibrils/muscle, and low-cost or OpenFlexure-based ExM imaging.
- **OFM v7 facts:** travel, controller, licences, fluorescence cubes, software, and Pi/camera support.
- **TREx:** the published correction.
- **Patents:** the ExM patent landscape (UK/EP status, expiry).
- **Law:** the UK legal map, checked against legislation.gov.uk, HSE and gov.uk.

**Acceptance:**
- pm/VERIFIED_FACTS.md (claim → verdict → source link).
- pm/ERRATA.md for anything wrong, with the corrected value.

### Order 3 — Protocol v0.1 + safety pack [P0] [open]
**Goal:** protocols/SWELL-ExM4-v0.1.md (Track A), runnable by a careful scientist.

**Includes:**
- Myofibril prep from a cited primary protocol.
- Every "or" resolved.
- A COSHH-style risk assessment per hazardous reagent, with SDS links.
- A waste plan naming a UK route, with quotes.
- A delivery-address plan for hazardous reagents.
- Session-card drafts for P3.

**Acceptance:**
- Every step has volume, time, temperature, hazard and waste route.
- Every number is cited.
- Risk assessments are queued in APPROVALS for the owner's sign-off.

### Order 4 — Reference design v0.1 [P0] [open]
**Goal:** settle the reference design.
- **Decisions:**
  - fork OFM or not
  - Pi version
  - objective
  - main and overview cameras (including tile count and scan time)
  - dye, LED and filter set
  - coverslip chamber, dish holder and v1 cartridge concept
  - electronics and enclosure
- **Calculations:** SNR budget and sampling.
- **Outputs:** parametric CAD for custom parts, a wiring diagram, and LICENSES.md entries.

**Acceptance:**
- docs/design/SWELL-design-v0.1.md, with the calculations.
- CAD renders.
- Every decision logged in DECISIONS.

### Order 5 — BOM v0.1 + baskets [P0] [open]
**Goal:** a live-priced BOM covering reference hardware, wet lab, calibration and operations. Each line has a primary and a fallback supplier, a part number and a date.

**Includes:**
- Per-phase baskets.
- Hardware total checked against the ≤ £1,000 target.
- A benchmark-only list.
- Cost per gel.

**Acceptance:**
- pm/BOM.csv and docs/BOM.md.
- The P1 basket in APPROVALS, with links and total.

### Order 6 — Software skeleton + simulator [P0] [open]
**Goal:** the `swell` Python package:
- A hardware API for the stage, cameras, LEDs, heater, pumps and sensors, with a simulated backend.
- Acquisition: tiling, z-stacks, autofocus, and the dry-into-water focal-shift correction.
- Stitching.
- An OME-Zarr writer.
- Run folders and metadata per kit/06.

**Acceptance:**
- pytest is green.
- A simulated full run produces a valid run folder and mosaic.

### Order 7 — QC pipeline on synthetic data [P0] [open]
**Goal:** the QC tools from kit/06:
- E_macro from dark-field overview images.
- An A-band E_local map, with the inclusion rule.
- The orientation test.
- The distortion curve.
- Z-disc FWHM, with the 10× width correction.
- FRC.
- Coverage and focus maps.
- The one-page report.

**Acceptance:** on synthetic myofibril images with known E and injected distortions, the pipeline recovers them within stated tolerances. Test on public ExM datasets too, if any are available.

### Order 8 — Fold in batch-1 answers [P0] [open]
**Goal:** apply the owner's batch-1 answers.
- [personal detail removed]
- **Tools:** decide print in-house vs print service.
- **Sourcing:** business status and address shape the sourcing and delivery plan.
- **Location:** the postcode district shapes the waste-carrier and community-lab options. Draft OUTREACH if a community lab is needed.
- [personal detail removed]

**Acceptance:** the answers are reflected in the design, BOM and protocol, and every changed decision is logged.

**Depends on:** Order 1, and the owner completing batch 1. Keep working Orders 2–7 while waiting.

### Order 9 — Gate G0 pack [P0] [open]
**Goal:**
- docs/gates/G0.md, which passes an auditor review.
- P1 orders and P1 session cards drafted.
- In APPROVALS: the whole-project budget, the P1 basket, the safety pack, the waste route, the delivery address and the workspace.

**Acceptance:** the auditor finds no unresolved fails, and the owner approves.

**Depends on:** Orders 2–8.
