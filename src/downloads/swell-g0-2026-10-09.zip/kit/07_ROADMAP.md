# Roadmap: phases and gates

Write orders only for the current phase, plus prep for the next one.

A gate needs three things: an evidence pack, an auditor pass, and the owner's sign-off where marked. "the owner time" is a rough count of his sessions, each ≤3 h.

## P0 Desk (no money; no hands except batch 1)
- **Goal:**
  - Everything decided and priced on paper.
  - Software runs against simulated hardware.
  - QC code proven on synthetic data.
- **Orders:** templates/ORDERS.md (1–9).
- **G0 (the owner approves; desk gate, so no machine evidence is needed):**
  - Verified facts.
  - Design v0.1 and protocol v0.1.
  - Risk assessments, waste route and delivery-address plan.
  - Workspace.
  - P1 basket and the whole-project budget.
- **The owner time:** one short session.

## P1 Optics and motion
- **Goal:** print and assemble the stage, optics, cameras, LEDs and enclosure, then calibrate.
- **G1:**
  - XY repeatability measured.
  - Pixel size calibrated (stage micrometer).
  - Bead PSF FWHM within ≈1.3× of theory.
  - Fluorescence flat-field corrected.
  - 5×5 tile mosaic of a test target stitched with ≤1 px residual.
  - Autofocus works.
  - You can run the microscope remotely end to end.
- **The owner time:** 2–3 sessions.

## P2 Chamber and fluidics (water and water beads only, no chemicals)
- **Goal:** v0 dish holder and a v1 cartridge prototype, with heater, pumps, leak sensor and interlocks.
- **G2:**
  - 37.0 ± 0.5 °C held for ≥16 h (overnight steps).
  - 100 exchange cycles with no leak and correct volumes.
  - A leak-sensor trip stops everything.
  - The overview camera films a water bead swelling and measures its expansion curve.
  - Focus tracking works during swelling.
- **The owner time:** 1–2 sessions.

## P3 Chemistry by hand, 4× (the "close enough" phase)
- **Goal:** the owner runs the session cards and the machine does the imaging.
- **G3:**
  - The four checkpoints in 06 pass on ≥3 gels from ≥2 separate preparations.
  - Deliver the money shot and the QC reports.
- **The owner time:** 3–6 sessions.

## P4 Automation
- **Goal:** move the washes, staining, water exchanges and 37 °C steps onto the machine. The owner only casts gels, runs the 95 °C step and loads.
- **G4:** 3 consecutive automated runs pass QC unattended.
- **The owner time:** ~2 sessions.

## P5 10× with cheaper optics (TREx-type)
- **G5:**
  - E ≈ 8–10×, with the isotropy checks passing.
  - Z-disc FWHM ≤ ~100 nm (pre-expansion units).
  - Uses a 20×/0.4-class objective.
- **The owner time:** ~3 sessions.

## P6 Rebuild package and release
- **Goal:**
  - A docs/ build guide written for non-experts.
  - Final BOM, with a cost audit based on receipts.
  - STL/CAD files and a software installer.
  - A QC reference dataset and a validation-sample protocol.
- **G6 (the owner approves):**
  - Independent rebuild evidence: a fresh-context audit of the docs, plus a physical second unit or a volunteer build arranged via OUTREACH.
  - Cost within ±15% of the BOM.
  - Licence, public name and release plan.
- **The owner time:** ~2 sessions, plus the rebuild.

## Out of scope until the owner says so (keep these in IDEAS)
- Kidney/EM comparison with partners.
- A paired before/after AI "virtual expansion" dataset.
- In-situ sequencing on expanded gels.
- A multi-cartridge hotel.
- Human tissue. Never without an ethics-approved partner.
