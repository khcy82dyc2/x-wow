# How the project runs

If the owner's existing projects on this PC use better conventions for any of this (ledger format, orders, approvals, push-notification, QA skills), copy theirs. Order 1 looks, read-only.

## Layout (created in Order 1)
```
./CLAUDE.md            standing rules (from kit/templates)
./kit/                 this kit, read-only
./pm/
  STATUS.md            one-screen digest, rewritten every life
  LEDGER.md            append-only log of lives
  ORDERS.md            numbered work orders (current phase + prep for next)
  INVARIANTS.md        rules that must always hold
  DECISIONS.md         your decisions and why (newest first)
  RISKS.md             risk register (seeded from kit/09)
  HUMAN_QUEUE.md       the owner's physical tasks, as session cards
  APPROVALS.md         what only the owner can decide
  OUTREACH.md          proposals to contact people/orgs (the owner sends, never you)
  IDEAS.md             the owner's new ideas + your own [Claude] ideas — not orders
  ERRATA.md            corrections to the kit
  VERIFIED_FACTS.md    claim → verdict → source
  BOM.csv, receipts/, inbox/ (the owner drops photos/files here, one folder per session)
./hardware/  (cad/, stl/, electronics/)
./firmware/
./software/  (swell package, tests/, sim/)
./protocols/ (versioned protocols, sds/)
./docs/      (design docs, gates/, build guide)
./data/      (runs; git-ignored except metadata and QC)
```

## Lives
- A life is one Claude Code session, either interactive or under the owner's runner.
- **First action:** append "Life N started: plan …" to LEDGER. Then read STATUS, ORDERS and recent DECISIONS.
- **During the life:** append to LEDGER after every meaningful step, not only at the end. A life that gets cut off then loses nothing.
- **Last actions:** rewrite STATUS, append "Life N ended: done / next / blockers", commit.
- **Order size:** each order should fit in one life. Split anything bigger.

## Orders
```
### Order N — title [Pk] [open | in-progress | believed-done | verified | closed | blocked]
Goal:
Acceptance: (measurable)
Evidence: (files, images, logs)
Depends on:
Notes:
```
- **Lifecycle:** open → in-progress → believed-done (the builder marks it) → verified → closed at the gate.
  - **Verified** means an auditor (a fresh session or subagent that didn't build it) has checked the evidence against Acceptance.
  - The owner sees only failures and gate summaries.
- **Scope control:**
  - Orders exist only for the current phase plus prep for the next.
  - The owner's new ideas go to IDEAS, never straight into ORDERS. The same applies to your own ideas.
  - At each gate, triage IDEAS: adopt (as an order in a named phase), park, or decline with a reason.

## Gates
- **Gate pack:** `docs/gates/G<n>.md`, with evidence links, QC numbers, deviations and remaining risks.
- **Order:** the auditor passes it first, then you ask the owner in APPROVALS where the gate needs him.
- **Physical-evidence rule:** simulation, synthetic data and headless tests help you build. From G1 onward, no gate passes without real-machine data. G0 is a desk gate.

## Invariants
- **Format:** INV-n · rule · subsystem · how it's checked (automated wherever possible).
- **Never break one to finish an order.** If a safety invariant blocks progress, raise it in APPROVALS. Never work around it.

## Decisions
- **Format:** date · D-n · decision · why · alternatives rejected · reversibility.
- You decide every technical matter. Log each one.

## Human queue (the owner's hands)
- **Never ask the owner for anything you can do yourself.** Once the microscope is connected, you run imaging experiments on your own.
- **Batch his physical tasks** into session cards of ≤2–3 h, and keep them rare.

Card template:
```
## Session S-n — title (est. time)
Why: (one line)
Before you start: (parts, tools, PPE checklist)
Steps: (numbered, one action each, with expected result)
Safety: (hazards and controls for this session)
Report back: (which photos/files go in pm/inbox/S-n/, or just say "S-n done")
大白话: (short Chinese version of the whole card)
```

## Approvals
- **Format:** one line per item: what · why · cost/impact · your recommendation · by when. The owner answers yes or no.
- **Always needs approval:**
  - money (every basket)
  - safety sign-offs (the risk assessment before first use of each hazardous reagent; the waste route)
  - outreach and publication
  - licence and public name
  - anything irreversible
  - a full project restart

## Outreach
- **You never contact anyone.** Draft proposals in OUTREACH.md: who, why, a draft message, what we'd give and get, and ownership terms. The owner sends them himself.
- **Ownership rule:** fee-for-service or clearly scoped help only. Nothing that gives anyone co-ownership of results or IP without the owner's explicit approval.
- **Candidates you may draft proposals for, when useful:**
  - A community lab for the wet steps, e.g. Biomakespace on the Cambridge Biomedical Campus **(verify it still operates and what it allows)**.
  - Cambridge Makespace, for fabrication.
  - Later: an EM facility for ground truth, and a pathologist.

## STATUS.md (one screen, rewritten every life)
- Phase and progress toward the gate.
- Orders by status, and blockers.
- Next HUMAN_QUEUE session, with time estimate.
- Approvals pending.
- Spend vs approved budget.
- Top 3 risks.
- Next 3 steps.
- 大白话 summary.

## Push-notification
- **Topic:** a separate SWELL topic, never another project's. Record it under "Project facts" in CLAUDE.md.
- **Push only for:** an approval needed, a human session ready, a safety issue, or a gate passed or failed.
- **Volume:** at most 2 a day, except for safety. One line each, in English.

## Lanes, audits, rebuilds
- **Lanes:** parallel subagents are fine for independent work (CAD, software, protocol, BOM). Keep a single lane for safety interlocks, heater control and invariants.
- **Audits:** audit before any big change (architecture, protocol track, data format).
- **Rebuilds:** you may archive and rebuild a messy subsystem; log a DECISION. A whole-project restart needs the owner's approval.
- **Git:** commit at the end of each order ("Order N: …"). Never commit large raw data.
