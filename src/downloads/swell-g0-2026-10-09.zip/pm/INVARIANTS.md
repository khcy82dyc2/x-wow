# INVARIANTS: rules that must always hold

Format: INV-n · rule · subsystem · check. Seeded from kit/templates/INVARIANTS.md; INV-15 to INV-18 added in Life 1 (pm/AUDIT.md). Never weaken a safety invariant without the owner's approval.

## Hardware safety
- **INV-1 · Fluidics / mechanics**
  - Rule: only the sealed sample vessel sits over the objective. A drip ring or tray around the objective drains to a leak sensor, and the objective has a protective sleeve. No tubing or reservoirs above the optics or electronics. The waste bottle sits low and has overfill sensing.
  - Check: design review, plus a water test.
- **INV-2 · Thermal**
  - Rule: every heater has a hardware thermal cutoff that works independently of software, rated ≤ 50 °C for anything on or near printed parts. Firmware switches heaters off on any fault or lost heartbeat.
  - v1 has no on-stage heater (D-9). This rule governs any heater added later.
  - Check: fault-injection test.
- **INV-3 · Safety**
  - Rule: a leak-sensor trip turns off the pumps, any heater and the excitation LED through a hardware latch that firmware can't clear (D-8), and sends a safety brief.
  - Check: wet-sensor test; simulated in Order 15.
- **INV-4 · Optics / safety**
  - Rule: opening the lid turns off the excitation LED through a hardware interlock in the LED supply.
  - Check: manual test; simulated in Order 15.
- **INV-5 · Electrical**
  - Rule: ≤ 24 V DC inside the instrument, from certified PSUs, with fused rails.
  - Check: BOM and wiring review.
- **INV-6 · Thermal / process**
  - Rule: 95 °C steps never happen on the stage or near printed parts. Moving them into a separate Wet Module needs approval A-1 and a signed risk assessment.
  - Check: protocol review.
- **INV-7 · Optics**
  - Rule: LEDs use constant-current drive. No PWM dimming during exposures.
  - Check: schematic review.
- **INV-13 · Software**
  - Rule: software never overrides INV-2, INV-3 or INV-4. No "force" flags.
  - Check: code review, plus a test that greps for override paths (Order 15).
- **INV-14 · Process / safety**
  - Rule: no CMR-containing liquid (acrylamide, bis-acrylamide, formaldehyde, monomer solution) and no gel casting on the stage. Changing this needs the owner's approval (A-1 covers only a separate module, never the stage).
  - Check: protocol review.

## Build and data integrity
- **INV-8 · Build**
  - Rule: the reference build uses only BOM parts. Benchmark parts never count toward a gate.
  - Check: gate audit.
- **INV-9 · Data**
  - Rule: raw data is immutable, and every image carries full metadata (kit/06 + D-16).
  - Check: automated test.
- **INV-15 · Claims (new)**
  - Rule: no claim in a generated manuscript, report or STATUS exceeds what the QC proves. Every quantitative claim is bound to a QC metric that passed its pre-registered threshold; the claim linter fails the build otherwise.
  - Check: paper-pipeline test (Order 16).
- **INV-16 · Process (new)**
  - Rule: no primary-amine buffer (Tris, glycine, ethanolamine) and no PLL in, or in the step immediately before, NHS-ester staining.
  - Check: protocol lint (Order 3).
- **INV-17 · Coexistence (new)**
  - Rule: every SWELL tool and cache lives inside D:\SWELL (.tools/, .venv/). No global packages, no PATH or scheduled-task changes. App config is redirected into .tools/cfg/, and Java preference keys created in HKCU by automated runs are removed. System-wide needs go to HUMAN_QUEUE.
  - Check: `tools/smoke_tools.py` ends with an automated leak check (new user folders fail the run; JavaSoft keys it created are removed) (D-25).
- **INV-18 · Reproducibility (new)**
  - Rule: every number in a generated document (methods, results, tables, QC report, STATUS cost lines) is computed by code from run data, receipts or a cited source. Nothing is hand-typed.
  - Check: paper-pipeline test; numbers are template variables (Order 16).

## Process and ethics
- **INV-10 · Process**
  - Rule: every protocol step has a hazard and a waste route. Nothing hazardous goes to the drain or household bins.
  - Check: protocol lint.
- **INV-11 · Ethics / legal**
  - Rule: no human-derived material and no live animals.
  - Check: protocol review.
- **INV-12 · Process**
  - Rule: gates G1–G6 pass only on real-machine evidence. G0 is a desk gate (virtual build).
  - Check: gate audit.
