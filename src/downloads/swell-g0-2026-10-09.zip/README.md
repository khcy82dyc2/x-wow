# SWELL: G0 design package (2026-10-09)

SWELL is a design for a cheap, automated expansion-microscopy (ExM) imager: a hydrogel swells a specimen
4-10x so cheap optics resolve ~80-130 nm, and supermarket chicken myofibrils carry their own rulers so
every gel can check its own expansion. This zip is the whole desk-stage project, given away.

## Status: read this first
- **Stage G0 (desk stage). Never built.** No part was bought, printed or wired; no gel was ever made.
- **Every result in here is simulated** (software/sim/ -> docs/design/, data/sim/). Nothing was measured
  on a real machine. Treat every number as a prediction until someone builds it.
- Facts checked against sources are listed with their verdicts in `pm/VERIFIED_FACTS.md`.
- Personal details of the owner were removed from the private project files before release; each removal
  is marked `[personal detail removed]` (postcodes as `[postcode removed]`). The removed lines concern the owner's own
  equipment, circumstances and schedule, not the SWELL design.
- `kit/` is the original brief, kept as written apart from those removals. Where it disagrees with
  `pm/ERRATA.md`, `pm/DECISIONS.md` or this README, the later files win. In particular, any line saying
  results or IP stay with the owner is superseded by this free release (D-35, D-37; licence map below).
- Designed, simulated and documented with AI assistance (Claude by Anthropic, via Claude Code); the owner set
  the direction and made the calls. The project stopped before its first gate (G0) was passed, and the
  checks were run by fresh AI sessions, not by an independent person. Check the code yourself.

## What is inside
| folder | files |
|---|---|
| `LICENSES.md` | 1 |
| `LICENSES/` | 2 |
| `README.md` | 1 |
| `data/` | 4 |
| `docs/` | 13 |
| `kit/` | 14 |
| `pm/` | 9 |
| `software/` | 7 |
| `tools/` | 4 |

- `kit/`: the original brief (science, design, BOM, protocol, QC, roadmap, risks, safety and legal).
- `pm/`: audit, decisions log, errata, invariants, risks, verified facts, orders, ideas, priced BOM (CSV).
- `docs/`: design reports, figures, BOM, toolchain notes. `software/`: simulation code and tests.
- `data/sim/`: per-myofibril tables from the strain-map simulation. `tools/`: the toolchain scripts.

## Rebuild the simulations
Python 3.12. The full pinned environment is `software/requirements.lock` (Windows, 250 packages);
the simulations themselves need only numpy, scipy, matplotlib, MicroscPSF-Py (for optics_v1.py) and pytest.

```
python -m venv .venv
.venv/bin/pip install numpy scipy matplotlib MicroscPSF-Py pytest   # Windows: .venv\Scripts\pip
python software/sim/design_calc.py      # -> docs/design/calc_v0.md, calc_v0.json
python software/sim/optics_v1.py        # -> docs/design/optics_v1.md, optics_v1.json
python software/sim/strain_map_sim.py   # -> docs/design/strain_map_v1.*, figs/, data/sim/*.csv
python software/sim/budget.py           # -> docs/BOM.md, docs/design/budget_v1.json
python -m pytest software/tests -q
```
`tools/setup_tools.sh` rebuilds the whole isolated toolchain (Windows + Git Bash; its paths assume the
project sits at D:/SWELL, so edit `tools/env.sh` / `tools/env.ps1` for your machine).

## Licences
| what | licence |
|---|---|
| Docs, text and data (everything not listed below) | CC0 1.0 Universal (`LICENSES/CC0-1.0.txt`) |
| Hardware design files: the bills of materials (`docs/BOM.md`, `pm/BOM.csv`) and any CAD, drawings or BOMs added later | CERN-OHL-P v2 (`LICENSES/CERN-OHL-P-2.0.txt`) |
| Software (the simulation code in `software/`, the scripts in `tools/`) | CC0 1.0 Universal |

- Any part later forked from the OpenFlexure Microscope keeps OpenFlexure's own licence: its repository's
  License file is CERN-OHL-S v2 (strongly reciprocal), checked 2026-10-09. This zip contains no OpenFlexure files.
- Third-party tools and packages keep their own licences (`LICENSES.md`).
- **Patents:** expansion microscopy is covered by MIT patents (e.g. US 10,309,879 B2; US 10,317,321 B2;
  US 11,408,890 B2). Commercial use may need a licence from MIT; research exemptions vary by country.
  These licences grant no patent rights held by others. This is not legal advice.
- **No warranty.** Provided as is. If you build it, its safety and legality are yours: the chemistry needs
  professional-user access (a lab), because UK REACH restricts the reagents.
- This package is a dated public disclosure (2026-10-09), published so the design is prior art.
- Trademarks belong to their owners; naming a product implies no endorsement.

Published by X-WOW: https://x-wow.com
